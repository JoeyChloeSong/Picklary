# v0.2.1 Changes

## Auto Setup Beta

- Detects court lines and uses regulation pickleball geometry to place the 8 floor reference points.
- Runs YOLOX person detection across multiple frames, filters candidates to the selected court, and places Players A–D.
- Labels positions as A=near-right, B=near-left, C=far-left, and D=far-right.
- Classifies the result as `Automatic`, `Assisted`, or `Manual`.

## Assisted Setup Guidance

- Adds a dedicated `What you need to set now` panel.
- Lists only the current required actions: missing court point, court verification, missing player foot center, or player-label verification.
- Uncertain court points must be adjusted and confirmed with `Court Verified`.
- Uncertain player points must be adjusted and confirmed with `Players Verified`.
- The next step stays disabled until all required verification is complete.

## Safe Behavior

- Missing models or low-confidence court detection switch to manual setup instead of closing the program.
- The video copy used by auto setup remains inside the local data folder.
- Zoom, pan, point dragging, undo, and reset remain available after automatic placement.
