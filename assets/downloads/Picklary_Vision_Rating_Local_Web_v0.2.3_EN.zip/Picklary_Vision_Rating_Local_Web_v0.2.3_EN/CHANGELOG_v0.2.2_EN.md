# v0.2.2 Changes

- Auto Setup starts automatically when Step 2 opens.
- Court detection now combines multiple frames, white-line segmentation, edges, Hough lines, and regulation-court geometry.
- Player detection now uses more frames, a lower YOLOX setup threshold, far-court tiling, OpenCV HOG/motion backup, and court-slot assignment.
- When confidence is low, the app still displays its recommended 8 court points and A–D player positions instead of a blank manual canvas.
- Once all 8 court points and 4 player points exist, they are automatically verified and the Next button is enabled. Separate Verify clicks are no longer required.
- Added a clear error when START_HERE.cmd is run inside the ZIP preview instead of an extracted folder.
