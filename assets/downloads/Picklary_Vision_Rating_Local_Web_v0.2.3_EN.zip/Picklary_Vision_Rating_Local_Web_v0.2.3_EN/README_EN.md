# Picklary Vision Rating Local v0.2.3

## Launch
1. Extract the ZIP completely into a new folder.
2. Run `START_HERE.cmd`.
3. The first run prepares the Python environment and person-detection model.
4. When the browser opens, select a video and enter 8 court points, 4 player positions, and match information.

## English edition isolation
- Default address: `http://127.0.0.1:8865/?lang=en`
- Data folder: `Documents\PicklaryVisionLocal_EN`
- Korean and English editions use different ports and data folders.
- The launcher verifies the server locale and will never open the Korean UI by mistake.

## Full report contents
The report keeps the hexagonal performance profile and also includes:
- Picklary DUPR estimate, expected range, and confidence
- Six skill dimensions with evidence for every score
- Serve/return success and depth
- Median/top serve and drive speed with sample counts
- Shot-type distribution and tactical tendencies
- Distance, movement speed, coverage, and NVZ positioning
- Shot trajectories and contact-location distribution
- Strengths, priority improvements, evidence, and interpretation notes

Results are independent Picklary estimates, not official DUPR ratings.

## v0.2.3 Auto Setup

1. Choose a video and click `Set Court`.
2. Click `Run Auto Setup`; the video is copied only to the local analysis folder on this PC.
3. The app places the 8 court points and Players A–D.
4. Complete only the actions shown in `What you need to set now`.
5. Adjust uncertain blue points and click `Court Verified`; adjust orange player points and click `Players Verified`.
6. When detection fails, the same panel tells you the exact next court point or player to mark.

Auto setup is a convenience feature. Incorrect court or player placement can affect the entire analysis, so complete every assisted-verification item shown by the app.
