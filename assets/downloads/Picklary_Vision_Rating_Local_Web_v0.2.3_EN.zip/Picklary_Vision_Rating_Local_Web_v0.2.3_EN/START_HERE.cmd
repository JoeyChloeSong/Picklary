@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Picklary Vision Rating v0.2.3 EN
set "PVR_LOCALE=en"
set "PVR_PACKAGE_LOCALE=en"
set "PVR_LOCAL_PORT=8865"

if not exist "%~dp0SETUP_LOCAL.cmd" (
  echo.
  echo [ERROR] This file is running inside the ZIP preview.
  echo Right-click the ZIP, choose Extract All, then run START_HERE.cmd from the extracted folder.
  pause
  exit /b 2
)


if exist ".venv\Scripts\python.exe" goto runtime_check
call "%~dp0SETUP_LOCAL.cmd"
if errorlevel 1 goto failed

:runtime_check
call "%~dp0ENSURE_SAFE_RUNTIME.cmd"
if errorlevel 1 goto failed
call "%~dp0START_LOCAL.cmd"
exit /b %errorlevel%

:failed
echo.
echo Setup or runtime repair did not complete. See the logs folder.
pause
exit /b 1
