@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Picklary Vision Rating v0.2.3 EN
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "PVR_ALLOW_CUDA=0"
set "PVR_LOCALE=en"
set "PVR_PACKAGE_LOCALE=en"
set "PVR_LOCAL_PORT=8865"

if not exist ".venv\Scripts\python.exe" (
  echo The local environment is not installed.
  echo Run START_HERE.cmd.
  pause
  exit /b 1
)

if not exist "models\yolox_nano.onnx" (
  echo [WARNING] Person detection model is missing.
  echo Run DOWNLOAD_PERSON_MODEL.cmd for person analysis.
)

".venv\Scripts\python.exe" "local_launcher.py"
if errorlevel 1 (
  echo.
  echo The local server stopped with an error.
  echo Check logs\local_server.log if it exists.
  pause
)
