from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import json
import os
import re
import shutil
import tempfile
import threading
import uuid

_SAFE_NAME = re.compile(r"[^A-Za-z0-9._-]+")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_filename(value: str) -> str:
    name = Path(value or "video.mp4").name
    cleaned = _SAFE_NAME.sub("_", name).strip("._")
    return cleaned or "video.mp4"


@dataclass(slots=True)
class StoreConfig:
    root: Path
    max_upload_bytes: int = 2 * 1024 * 1024 * 1024
    chunk_size: int = 8 * 1024 * 1024


class JobStore:
    def __init__(self, config: StoreConfig):
        self.config = config
        self.config.root.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

    def job_dir(self, job_id: str) -> Path:
        if not re.fullmatch(r"[0-9a-f]{32}", job_id):
            raise ValueError("invalid job id")
        return self.config.root / job_id

    def create_job(self, filename: str, size: int, content_type: str | None) -> dict[str, Any]:
        if size <= 0:
            raise ValueError("empty upload")
        if size > self.config.max_upload_bytes:
            raise ValueError("upload exceeds server limit")
        job_id = uuid.uuid4().hex
        root = self.job_dir(job_id)
        (root / "chunks").mkdir(parents=True)
        state: dict[str, Any] = {
            "id": job_id,
            "created_at": utc_now(),
            "updated_at": utc_now(),
            "status": "uploading",
            "progress": 0,
            "message": "Preparing upload",
            "filename": safe_filename(filename),
            "size": int(size),
            "content_type": content_type or "application/octet-stream",
            "chunk_size": self.config.chunk_size,
            "received_chunks": [],
            "metadata": {},
            "configuration": None,
            "error": None,
            "report_ready": False,
        }
        self.save(job_id, state)
        return state

    def state_path(self, job_id: str) -> Path:
        return self.job_dir(job_id) / "job.json"

    def load(self, job_id: str) -> dict[str, Any]:
        path = self.state_path(job_id)
        if not path.exists():
            raise FileNotFoundError(job_id)
        return json.loads(path.read_text(encoding="utf-8"))

    def save(self, job_id: str, state: dict[str, Any]) -> None:
        with self._lock:
            root = self.job_dir(job_id)
            root.mkdir(parents=True, exist_ok=True)
            state["updated_at"] = utc_now()
            fd, tmp_name = tempfile.mkstemp(prefix="job-", suffix=".json", dir=root)
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump(state, f, ensure_ascii=False, indent=2)
                os.replace(tmp_name, self.state_path(job_id))
            finally:
                if os.path.exists(tmp_name):
                    os.unlink(tmp_name)

    def update(self, job_id: str, **changes: Any) -> dict[str, Any]:
        state = self.load(job_id)
        state.update(changes)
        self.save(job_id, state)
        return state

    def chunk_path(self, job_id: str, index: int) -> Path:
        if index < 0 or index > 100000:
            raise ValueError("invalid chunk index")
        return self.job_dir(job_id) / "chunks" / f"{index:08d}.part"

    def write_chunk(self, job_id: str, index: int, data: bytes) -> dict[str, Any]:
        state = self.load(job_id)
        if state["status"] not in {"uploading", "uploaded"}:
            raise ValueError("upload is no longer writable")
        if not data:
            raise ValueError("empty chunk")
        if len(data) > int(state["chunk_size"]) + 1024:
            raise ValueError("chunk too large")
        path = self.chunk_path(job_id, index)
        path.write_bytes(data)
        received = sorted(set(int(x) for x in state.get("received_chunks", [])) | {index})
        state["received_chunks"] = received
        uploaded = sum(self.chunk_path(job_id, i).stat().st_size for i in received if self.chunk_path(job_id, i).exists())
        state["progress"] = min(95, int(uploaded * 95 / max(1, int(state["size"]))))
        state["message"] = f"Video upload {uploaded / 1024 / 1024:.1f}MB"
        self.save(job_id, state)
        return state

    def complete_upload(self, job_id: str, total_chunks: int) -> Path:
        state = self.load(job_id)
        if total_chunks <= 0:
            raise ValueError("invalid total chunk count")
        missing = [i for i in range(total_chunks) if not self.chunk_path(job_id, i).exists()]
        if missing:
            raise ValueError(f"missing chunks: {missing[:10]}")
        video_path = self.job_dir(job_id) / state["filename"]
        with video_path.open("wb") as out:
            for i in range(total_chunks):
                with self.chunk_path(job_id, i).open("rb") as src:
                    shutil.copyfileobj(src, out, length=1024 * 1024)
        actual = video_path.stat().st_size
        expected = int(state["size"])
        if actual != expected:
            video_path.unlink(missing_ok=True)
            raise ValueError(f"size mismatch: expected {expected}, got {actual}")
        shutil.rmtree(self.job_dir(job_id) / "chunks", ignore_errors=True)
        state["status"] = "uploaded"
        state["progress"] = 100
        state["message"] = "Upload complete"
        state["video_path"] = str(video_path)
        self.save(job_id, state)
        return video_path

    def configure(self, job_id: str, configuration: dict[str, Any]) -> dict[str, Any]:
        state = self.load(job_id)
        if state["status"] not in {"uploaded", "configured", "failed"}:
            raise ValueError("upload must be completed first")
        state["configuration"] = configuration
        state["status"] = "configured"
        state["progress"] = 0
        state["message"] = "Analysis configuration complete"
        state["error"] = None
        self.save(job_id, state)
        return state

    def purge_older_than(self, cutoff_timestamp: float) -> int:
        removed = 0
        for child in self.config.root.iterdir():
            if not child.is_dir():
                continue
            try:
                if child.stat().st_mtime < cutoff_timestamp:
                    shutil.rmtree(child, ignore_errors=True)
                    removed += 1
            except OSError:
                continue
        return removed
