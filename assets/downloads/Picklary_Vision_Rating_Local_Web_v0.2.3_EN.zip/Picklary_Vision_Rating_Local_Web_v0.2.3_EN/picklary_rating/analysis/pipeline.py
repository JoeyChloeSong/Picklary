from __future__ import annotations

from collections.abc import Callable
from bisect import bisect_left
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import time

import cv2

from picklary_rating.analysis.audio_onset import detect_audio_onsets_with_diagnostics
from picklary_rating.analysis.audio_shot_proxy import build_audio_motion_proxy_rallies
from picklary_rating.analysis.ball_detect import TrackNetHeatmapDetector
from picklary_rating.analysis.ball_profile import get_ball_profile
from picklary_rating.analysis.ball_track import MultiHypothesisBallTracker
from picklary_rating.analysis.ball_tracker import ClassicalBallTracker
from picklary_rating.analysis.court import CourtCalibration
from picklary_rating.analysis.device import combined_processing_summary, inspect_runtime_capabilities
from picklary_rating.analysis.events import build_rallies_and_shots, detect_ball_events
from picklary_rating.analysis.features import all_player_metrics
from picklary_rating.analysis.lens import build_lens_corrector, court_line_residual_rms
from picklary_rating.analysis.player_tracker import PlayerTracker
from picklary_rating.analysis.preflight import resolve_analysis_preflight
from picklary_rating.analysis.rating import IndependentRatingEngine
from picklary_rating.analysis.reporting import save_result
from picklary_rating.config import AnalysisConfig
from picklary_rating.models import AnalysisResult, HitEvent, Point2D
from picklary_rating.rating.anchored import apply_universal_ratings

ProgressCallback = Callable[[int, str], None]


def _normalize_player_seed_labels(
    seeds: dict[str, Point2D], calibration: CourtCalibration
) -> tuple[dict[str, Point2D], dict[str, Any]]:
    """Map four clicked players to fixed start positions regardless of click order.

    Picklary's label convention is A=near-right, B=near-left, C=far-left,
    D=far-right. v0.1.5 trusted click order, so the PB Vision subject in the
    near-left red shirt could be reported as Player A. This mapper uses calibrated
    court coordinates and removes that identity mismatch.
    """
    if len(seeds) != 4:
        return seeds, {"applied": False, "reason": "four seeds required"}
    items = []
    for original_label, point in seeds.items():
        try:
            ground = calibration.image_to_ground(point)
        except Exception:
            return seeds, {"applied": False, "reason": "seed projection failed"}
        items.append((original_label, point, ground))
    near = sorted([x for x in items if x[2].y >= calibration.net_y], key=lambda x: x[2].x)
    far = sorted([x for x in items if x[2].y < calibration.net_y], key=lambda x: x[2].x)
    if len(near) != 2 or len(far) != 2:
        return seeds, {
            "applied": False,
            "reason": f"expected two players per side, found near={len(near)} far={len(far)}",
        }
    assigned = {
        "B": near[0][1],
        "A": near[1][1],
        "C": far[0][1],
        "D": far[1][1],
    }
    source_by_target = {
        "B": near[0][0],
        "A": near[1][0],
        "C": far[0][0],
        "D": far[1][0],
    }
    changed = any(source_by_target[label] != label for label in "ABCD")
    return assigned, {
        "applied": True,
        "changed": changed,
        "source_click_label_by_final_label": source_by_target,
        "convention": {"A": "near_right", "B": "near_left", "C": "far_left", "D": "far_right"},
    }


class VideoAnalysisPipeline:
    def __init__(self, config: AnalysisConfig | None = None):
        self.config = config or AnalysisConfig()
        self.config.validate()

    @staticmethod
    def _resolve(base: Path, value: str) -> Path:
        path = Path(value)
        return path if path.is_absolute() else base / path

    def analyze(
        self,
        video_path: str | Path,
        calibration_points: list[Point2D],
        player_names: dict[str, str] | None = None,
        anchor_duprs: dict[str, float] | None = None,
        progress: ProgressCallback | None = None,
        player_seed_points: dict[str, Point2D] | None = None,
    ) -> AnalysisResult:
        path = Path(video_path)
        if not path.exists():
            raise FileNotFoundError(path)
        callback = progress or (lambda _p, _m: None)
        timing: dict[str, float] = {}
        total_clock = time.perf_counter()
        cap = cv2.VideoCapture(str(path))
        if not cap.isOpened():
            raise RuntimeError(f"Cannot open video: {path}")
        fps = float(cap.get(cv2.CAP_PROP_FPS) or 30.0)
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 1920)
        frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 1080)
        duration_s = frame_count / fps if frame_count else 0.0
        if duration_s > self.config.max_video_minutes * 60:
            cap.release()
            raise ValueError(f"Video exceeds {self.config.max_video_minutes} minute safety limit")

        # Read one raw frame for auto lens estimation, then seek to requested start.
        ok, first_raw = cap.read()
        if not ok:
            cap.release()
            raise RuntimeError("Could not read first video frame")
        project_root = Path.cwd()
        profiles_path = self._resolve(project_root, self.config.lens_profiles_path)
        user_lens_path = self._resolve(project_root, self.config.user_lens_calibration_path)
        lens_clock = time.perf_counter()
        lens_corrector, lens_profile, lens_diag = build_lens_corrector(
            self.config.lens_mode,
            (frame_width, frame_height),
            profiles_path,
            self.config.lens_profile_id,
            user_lens_path,
            first_raw,
        )
        corrected_first = lens_corrector.undistort_frame(first_raw)
        line_rms, line_count = court_line_residual_rms(corrected_first)
        lens_diag.update({
            "post_correction_line_residual_rms_px": None if not line_rms < float("inf") else round(line_rms, 3),
            "line_groups": line_count,
            "warning": bool(line_rms < float("inf") and line_rms > self.config.lens_line_residual_warn_px),
        })
        timing["lens_initialization_s"] = time.perf_counter() - lens_clock

        corrected_points = lens_corrector.undistort_points(calibration_points)
        corrected_player_seeds: dict[str, Point2D] = {}
        if player_seed_points:
            labels = list(player_seed_points)
            values = lens_corrector.undistort_points([player_seed_points[label] for label in labels])
            corrected_player_seeds = dict(zip(labels, values))

        calibration_clock = time.perf_counter()
        calibration = CourtCalibration(
            corrected_points,
            self.config.court_width_ft,
            self.config.court_length_ft,
            self.config.kitchen_line_from_net_ft,
            (frame_width, frame_height),
        )
        timing["calibration_s"] = time.perf_counter() - calibration_clock
        if calibration.diagnostics.reprojection_rmse_px > self.config.calibration_reject_rmse_px:
            cap.release()
            raise ValueError(
                f"Ground calibration error {calibration.diagnostics.reprojection_rmse_px:.1f}px "
                f"exceeds the allowed limit of {self.config.calibration_reject_rmse_px:.1f}px. "
                f"Please review highlighted point #{calibration.diagnostics.worst_point_index + 1}."
            )

        corrected_player_seeds, seed_mapping_diagnostics = _normalize_player_seed_labels(
            corrected_player_seeds, calibration
        )

        person_model_path = self._resolve(project_root, self.config.person_model_path)
        player_tracker = PlayerTracker(
            model_name=self.config.detector_model,
            tracker=self.config.tracker,
            confidence=self.config.detector_confidence,
            failure_limit=self.config.consecutive_tracker_failures_limit,
            model_path=person_model_path,
            input_size=self.config.person_model_input_size,
            nms_iou=self.config.detector_nms_iou,
            requested_device=self.config.processing_device,
            decoded_output=self.config.person_model_decoded_output,
            tile_enabled=self.config.person_tile_enabled,
        )
        player_tracker.set_calibration(calibration)
        if not player_tracker.available:
            cap.release()
            diag = player_tracker.diagnostics()
            raise RuntimeError(
                "The person detector could not be initialized. "
                f"{diag.get('backend_error')}. Install models/yolox_nano.onnx or "
                "run DOWNLOAD_PERSON_MODEL.cmd."
            )

        model_path = self._resolve(project_root, self.config.ball_model_path)
        ball_profile = get_ball_profile(self.config.ball_profile_id)
        preflight = resolve_analysis_preflight(
            self.config.analysis_mode,
            model_path,
            self.config.enable_classical_ball_fallback,
        )
        ball_detector = None
        ball_detector_error = None
        ball_tracker = None
        classical_tracker = None
        if preflight.resolved_mode == "full":
            ball_detector = TrackNetHeatmapDetector(
                model_path,
                input_size=preflight.model.input_size,
                stack_frames=preflight.model.stack_frames,
                requested_device=self.config.processing_device,
            )
            ball_tracker = MultiHypothesisBallTracker(self.config.ball_max_gap_frames)
        elif preflight.resolved_mode == "full_experimental":
            ball_detector_error = preflight.model.error
            classical_tracker = ClassicalBallTracker(self.config.ball_max_gap_frames, profile=ball_profile)
        else:
            ball_detector_error = preflight.model.error

        audio_clock = time.perf_counter()
        audio_onsets: list[float] = []
        audio_error: str | None = None
        audio_diagnostics: dict[str, Any] = {}
        if self.config.enable_audio_onset:
            try:
                audio_onsets, audio_diagnostics = detect_audio_onsets_with_diagnostics(
                    path,
                    self.config.audio_onset_threshold_z,
                    self.config.audio_onset_min_gap_s,
                    self.config.audio_onset_quantile,
                )
                audio_error = audio_diagnostics.get("error")
            except Exception as exc:
                audio_error = f"{type(exc).__name__}: {exc}"
                audio_diagnostics = {"method": "spectral_flux_adaptive_v2", "error": audio_error}
        timing["audio_onset_s"] = time.perf_counter() - audio_clock

        ball_device_label = ball_detector.device_label if ball_detector is not None else (
            "CPU · Franklin X-40 visual tracker" if classical_tracker is not None else None
        )
        processing_summary = combined_processing_summary(player_tracker.device_label, ball_device_label)
        last_processing_summary = processing_summary
        runtime_caps = inspect_runtime_capabilities(self.config.processing_device)
        callback(1, "Initializing analysis engine")
        callback(2, f"Processing device: {processing_summary}")
        callback(3, f"Analysis mode: {preflight.resolved_mode}")
        if preflight.warning:
            callback(4, preflight.warning)

        start_frame = max(0, int(round(self.config.analysis_start_s * fps)))
        cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
        players = []
        balls = []
        frame_index = start_frame - 1
        person_sampled = 0
        current_player_boxes: list[tuple[float, float, float, float]] = []
        inference_clock = time.perf_counter()
        first_processed = True
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            frame_index += 1
            frame = lens_corrector.undistort_frame(frame)
            time_s = frame_index / fps
            if first_processed and corrected_player_seeds:
                player_tracker.set_manual_seeds(frame, corrected_player_seeds, calibration)
            first_processed = False
            if frame_index % self.config.person_stride == 0:
                detections = player_tracker.detect(frame)
                current_player_boxes = [d.xyxy for d in detections]
                players.extend(player_tracker.observations(detections, calibration, frame_index, time_s))
                person_sampled += 1
            ball = None
            if ball_detector is not None and ball_tracker is not None:
                candidates = [c for c in ball_detector.detect(frame) if calibration.image_point_in_roi(c.position, frame.shape)]
                # P2 will replace this with a local perspective function. It is kept
                # explicit in diagnostics rather than hidden as a calibrated value.
                px_per_ft = max(20.0, frame_width / self.config.court_width_ft * 0.55)
                ball = ball_tracker.update(candidates, frame_index, time_s, px_per_ft)
            elif classical_tracker is not None:
                pos = bisect_left(audio_onsets, time_s) if audio_onsets else 0
                onset_candidates = audio_onsets[max(0, pos - 1): min(len(audio_onsets), pos + 2)] if audio_onsets else []
                near_audio = bool(onset_candidates and min(abs(x - time_s) for x in onset_candidates) <= 0.12)
                ball = classical_tracker.update(
                    frame, calibration, frame_index, time_s, player_boxes=current_player_boxes, near_audio=near_audio
                )
            if ball is not None:
                balls.append(ball)

            current_ball_label = ball_detector.device_label if ball_detector is not None else (
                "CPU · Franklin X-40 visual tracker" if classical_tracker is not None else None
            )
            current_processing_summary = combined_processing_summary(player_tracker.device_label, current_ball_label)
            if current_processing_summary != last_processing_summary:
                last_processing_summary = current_processing_summary
                callback(max(2, min(72, int(5 + 68 * (frame_index - start_frame) / max(1, frame_count - start_frame)))),
                         f"Processing device: {current_processing_summary}")

            if frame_index and frame_index % max(30, int(fps)) == 0:
                pct = int(5 + 68 * (frame_index - start_frame) / max(1, frame_count - start_frame))
                elapsed = max(0.001, time.perf_counter() - inference_clock)
                rate = (frame_index - start_frame + 1) / elapsed
                remaining = (frame_count - frame_index - 1) / max(rate, 0.001)
                callback(min(pct, 73), f"Analyzing frames {frame_index:,}/{frame_count:,} · estimated remaining {remaining / 60:.1f} min")
        cap.release()
        timing["frame_decode_detection_tracking_s"] = time.perf_counter() - inference_clock
        ball_device_label = ball_detector.device_label if ball_detector is not None else (
            "CPU · Franklin X-40 visual tracker" if classical_tracker is not None else None
        )
        processing_summary = combined_processing_summary(player_tracker.device_label, ball_device_label)

        event_clock = time.perf_counter()
        if preflight.positioning_only:
            callback(76, "Refining player tracks")
            ball_events, hits, rallies = [], [], []
        else:
            callback(76, "Separating contact and bounce events")
            ball_events = detect_ball_events(
                balls,
                players,
                calibration,
                self.config.event_window_seconds,
                self.config.min_hit_gap_seconds,
                audio_onsets_s=audio_onsets,
                audio_match_window_s=self.config.audio_match_window_s,
            )
            hits = [
                HitEvent(
                    e.frame_index,
                    e.time_s,
                    e.player_label or "?",
                    e.court_position,
                    None,
                    None,
                    e.diagnostics.get("angle_deg"),
                    e.confidence,
                    image_position=e.image_position,
                    tracklet_id=int(e.diagnostics.get("tracklet_id", 0)),
                )
                for e in ball_events
                if e.event_type == "hit" and e.player_label
            ]
            rallies = build_rallies_and_shots(hits, balls, calibration, self.config.min_rally_gap_seconds, ball_events)

        proxy_diagnostics: dict[str, Any] | None = None
        visual_shot_count = sum(len(r.shots) for r in rallies)
        # Franklin visual tracking can be sparse on 30 fps wide-angle footage. When
        # it does not yield enough continuous contacts, combine the fixed X-40
        # visual candidates with paddle-like audio and player motion instead of
        # silently switching to a motion-only report.
        if not preflight.positioning_only and audio_onsets and visual_shot_count < max(24, int(len(audio_onsets) * 0.18)):
            proxy_rallies, proxy_diagnostics = build_audio_motion_proxy_rallies(
                audio_onsets, players, balls, calibration,
                initial_server_label=self.config.initial_server_label,
                rally_gap_s=min(2.4, max(1.8, self.config.min_rally_gap_seconds * 0.75)),
            )
            proxy_shot_count = sum(len(r.shots) for r in proxy_rallies)
            if proxy_shot_count > visual_shot_count:
                rallies = proxy_rallies
                hits = [
                    HitEvent(
                        frame_index=int(round(s.time_s * fps)), time_s=s.time_s, player_label=s.player_label,
                        court_position=s.start_position, incoming_speed_mph=None, outgoing_speed_mph=None,
                        direction_change_deg=None, confidence=s.confidence, event_type="proxy_hit",
                        image_position=None, tracklet_id=0,
                    )
                    for rally in rallies for s in rally.shots
                ]
        timing["events_and_rallies_s"] = time.perf_counter() - event_clock

        feature_clock = time.perf_counter()
        callback(84, "Calculating player metrics")
        metrics_by_player = all_player_metrics(
            players,
            rallies,
            max(0.0, duration_s - self.config.analysis_start_s),
            fps,
            self.config.person_stride,
            calibration.length_ft / 2,
            calibration.kitchen_ft,
            self.config.max_player_speed_ft_s,
        )
        for metrics in metrics_by_player.values():
            metrics["reference_benchmark_id"] = self.config.reference_benchmark_id
            metrics["analysis_final_score_near"] = self.config.final_score_near
            metrics["analysis_final_score_far"] = self.config.final_score_far
        rating_engine = IndependentRatingEngine()
        names = player_names or {}
        if preflight.positioning_only:
            rating_measurement_mode = "motion_fallback"
        else:
            # The Franklin X-40 profile path is allowed to feed observed shots into
            # the normal quality gate. Each player automatically falls back to
            # motion-only rating when their shot evidence is sparse or inconsistent.
            rating_measurement_mode = "full"
        reports = rating_engine.rank([
            rating_engine.evaluate(label, metrics_by_player[label], names.get(label), rating_measurement_mode)
            for label in "ABCD"
        ])
        reports = apply_universal_ratings(
            reports,
            anchor_duprs,
            final_score_near=self.config.final_score_near,
            final_score_far=self.config.final_score_far,
            target_points=self.config.game_target_points,
        )
        measurement_mode = preflight.resolved_mode
        report_bases = {report.rating_basis for report in reports}
        if report_bases == {"shot_and_motion"}:
            rating_basis = "shot_and_motion"
        elif "shot_and_motion" in report_bases:
            rating_basis = "hybrid_shot_and_motion"
        elif proxy_diagnostics and int(proxy_diagnostics.get("assigned_shots", 0)) > 0:
            rating_basis = "franklin_audio_motion_hybrid"
        elif "franklin_low_evidence" in report_bases:
            rating_basis = "franklin_profile_low_evidence"
        else:
            rating_basis = "motion_fallback"
        timing["features_and_rating_s"] = time.perf_counter() - feature_clock

        cdiag = calibration.diagnostics
        calibration_diag = {
            "mode": cdiag.mode,
            "reprojection_rmse_px": round(cdiag.reprojection_rmse_px, 3),
            "ground_rmse_px": None if cdiag.ground_rmse_px is None else round(cdiag.ground_rmse_px, 3),
            "full_model_rmse_px": None if cdiag.full_model_rmse_px is None else round(cdiag.full_model_rmse_px, 3),
            "net_rmse_px": None if cdiag.net_rmse_px is None else round(cdiag.net_rmse_px, 3),
            "max_error_px": round(cdiag.max_error_px, 3),
            "worst_point_index": cdiag.worst_point_index,
            "speed_metrics_enabled": cdiag.speed_metrics_enabled,
            "input_order_adjusted": cdiag.input_order_adjusted,
            "fallback_reason": cdiag.fallback_reason,
            "ground_global_rmse_px": cdiag.ground_global_rmse_px,
            "ground_piecewise_rmse_px": cdiag.ground_piecewise_rmse_px,
            "ground_mapping_mode": cdiag.ground_mapping_mode,
            "systematic_distortion_detected": cdiag.systematic_distortion_detected,
            "warning": cdiag.reprojection_rmse_px > self.config.calibration_warn_rmse_px,
        }
        diagnostics: dict[str, Any] = {
            "model_version": rating_engine.VERSION,
            "measurement_mode": measurement_mode,
            "rating_measurement_mode": rating_measurement_mode,
            "rating_basis": rating_basis,
            "dupr_always_output": True,
            "preflight": preflight.to_dict(),
            "calibration": calibration_diag,
            "lens": {
                "mode": self.config.lens_mode,
                "profile_id": lens_profile.profile_id,
                "profile_source": lens_profile.source,
                **lens_corrector.diagnostics(),
                **lens_diag,
            },
            "player_tracker": player_tracker.diagnostics(),
            "player_seed_mapping": seed_mapping_diagnostics,
            "processing_device": {
                "requested": self.config.processing_device,
                "summary": processing_summary,
                "person": player_tracker.device_label,
                "ball": ball_device_label or "disabled",
                "hardware": runtime_caps.to_dict(),
            },
            "audio_onset": {
                "enabled": self.config.enable_audio_onset,
                "count": len(audio_onsets),
                "error": audio_error,
                "wired_to_event_scoring": True,
                "interpretation": "candidate paddle-like transients; vision confirmation required",
                **audio_diagnostics,
            },
            "game_context": {
                "session_preset_id": self.config.session_preset_id,
                "game_target_points": self.config.game_target_points,
                "initial_server_label": self.config.initial_server_label,
                "first_server_side": self.config.first_server_side,
                "final_score_near": self.config.final_score_near,
                "final_score_far": self.config.final_score_far,
                "analysis_start_s": self.config.analysis_start_s,
                "score_reconstruction_enabled": False,
                "score_reconstruction_blocker": "P0 production G1 must pass before P3 score reconstruction is activated",
                "reference_benchmark_id": self.config.reference_benchmark_id,
            },
            "detector_model": self.config.detector_model,
            "person_stride": self.config.person_stride,
            "ball_stride": self.config.ball_stride,
            "analysis_start_s": self.config.analysis_start_s,
            "person_sampled_frames": person_sampled,
            "player_observations": len(players),
            "ball_observations": len([b for b in balls if not b.predicted]),
            "hit_events": len(hits),
            "bounce_events": sum(1 for e in ball_events if e.event_type == "bounce"),
            "ambiguous_events": sum(1 for e in ball_events if e.event_type == "ambiguous"),
            "rallies": len(rallies),
            "shots": sum(len(r.shots) for r in rallies),
            "ball_detector": "TrackNet-style ONNX heatmap" if ball_detector else (
                "Franklin X-40 profile-aware visual tracker" if classical_tracker else "disabled_positioning_mode"
            ),
            "ball_profile": ball_profile.to_dict(),
            "ball_profile_assumption": "All balls are treated as Franklin X-40 Outdoor unless a validated TrackNet model overrides the visual fallback.",
            "classical_ball_tracker": classical_tracker.diagnostics() if classical_tracker is not None else None,
            "ball_detector_error": ball_detector_error,
            "audio_motion_shot_proxy": proxy_diagnostics,
            "official_rating": False,
            "absolute_rating_requires_anchor": False,
            "anchors_provided": anchor_duprs or {},
            "rating_policy": "always output Picklary DUPR estimate; Franklin X-40 visual tracks are primary, audio+player-motion shot proxy is secondary, motion-only is last resort",
            "timing": timing,
        }
        if self.config.emit_evaluation_tracks:
            diagnostics["ball_track"] = [
                {"frame_index": b.frame_index, "visible": b.visible, "image_position": {"x": b.image_position.x, "y": b.image_position.y}, "tracklet_id": b.tracklet_id}
                for b in balls if not b.predicted
            ]
            diagnostics["player_track"] = [
                {
                    "frame_index": p.frame_index,
                    "track_id": p.track_id,
                    "label": p.label,
                    "bbox": list(p.bbox) if p.bbox else None,
                    "foot_px": [p.image_foot.x, p.image_foot.y],
                    "court_position": None if p.court_position is None else [p.court_position.x, p.court_position.y],
                }
                for p in players
            ]
            diagnostics["hit_event_frames"] = [h.frame_index for h in hits]
            diagnostics["bounce_event_frames"] = [e.frame_index for e in ball_events if e.event_type == "bounce"]
            diagnostics["audio_onsets_s"] = audio_onsets

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        out = self.config.output_root / f"{path.stem}_{stamp}"
        diagnostics["output_files"] = {
            "json": str(out / "analysis.json"),
            "html": str(out / "report.html"),
            "shots_csv": str(out / "shots.csv"),
        }
        result = AnalysisResult(
            video_path=str(path),
            created_at=datetime.now(timezone.utc).isoformat(),
            duration_s=duration_s,
            fps=fps,
            frame_count=frame_count,
            calibration_points=calibration_points,
            player_reports=reports,
            rallies=rallies,
            diagnostics=diagnostics,
            output_dir=str(out),
        )
        callback(93, "Generating report")
        # The persisted JSON must contain usable timing information before the
        # single allowed save_result() call. Report serialization time is shown
        # in the live result object only; pre-report timing is persisted.
        timing["pre_report_total_s"] = time.perf_counter() - total_clock
        timing["report_s"] = None
        timing["total_s"] = timing["pre_report_total_s"]
        report_clock = time.perf_counter()
        save_result(result, out)
        timing["report_s"] = time.perf_counter() - report_clock
        timing["total_s"] = time.perf_counter() - total_clock
        callback(100, "Analysis complete")
        return result


def read_first_frame(video_path: str | Path):
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {video_path}")
    ok, frame = cap.read()
    cap.release()
    if not ok:
        raise RuntimeError("Could not read first frame")
    return frame
