@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Local environment is not installed. Run START_HERE.cmd.
  pause
  exit /b 1
)
set "PVR_ALLOW_CUDA=0"
".venv\Scripts\python.exe" -c "import sys,cv2,onnxruntime as o; print('Python:',sys.version); print('OpenCV:',cv2.__version__); print('ONNX Runtime:',o.__version__); print('Providers:',o.get_available_providers()); print('Safe GPU:', 'DmlExecutionProvider' in o.get_available_providers())"
".venv\Scripts\python.exe" -m pip show onnxruntime-gpu >nul 2>&1
if not errorlevel 1 echo WARNING: onnxruntime-gpu is installed. Run START_HERE.cmd to migrate it.
if exist "models\yolox_nano.onnx" (
  for %%A in ("models\yolox_nano.onnx") do echo Person model: ready ^(%%~zA bytes^)
) else (
  echo Person model: missing
)
pause
