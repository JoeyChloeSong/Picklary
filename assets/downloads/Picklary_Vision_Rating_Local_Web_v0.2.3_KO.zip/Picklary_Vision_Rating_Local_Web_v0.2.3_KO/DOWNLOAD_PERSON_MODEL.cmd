@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist "models" mkdir "models"
set "MODEL=models\yolox_nano.onnx"
set "TEMP=models\yolox_nano.onnx.download"
set "URL=https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0/yolox_nano.onnx"

if exist "%MODEL%" (
  for %%A in ("%MODEL%") do if %%~zA GTR 3000000 (
    echo Person model is already installed.
    exit /b 0
  )
)

echo Downloading the YOLOX-Nano person model...
where curl.exe >nul 2>&1
if errorlevel 1 goto powershell_download
curl.exe -L --fail --retry 3 --retry-delay 3 --connect-timeout 30 --max-time 1200 -o "%TEMP%" "%URL%"
if errorlevel 1 goto failed
goto verify

:powershell_download
powershell.exe -NoProfile -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri '%URL%' -OutFile '%TEMP%'"
if errorlevel 1 goto failed

:verify
if not exist "%TEMP%" goto failed
for %%A in ("%TEMP%") do if %%~zA LSS 3000000 goto failed
move /Y "%TEMP%" "%MODEL%" >nul
echo Person model installed: %MODEL%
exit /b 0

:failed
if exist "%TEMP%" del /Q "%TEMP%"
echo [ERROR] Person model download failed.
echo A company or school network may block GitHub downloads.
echo Open this URL in a browser and save the file as:
echo %CD%\models\yolox_nano.onnx
start "" "%URL%"
pause
exit /b 1
