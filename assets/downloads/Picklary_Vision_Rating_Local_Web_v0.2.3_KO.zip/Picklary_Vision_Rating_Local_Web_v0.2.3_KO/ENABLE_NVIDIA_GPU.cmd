@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run START_HERE.cmd first.
  pause
  exit /b 1
)
if exist ".runtime\safe_runtime_v016.ok" del /Q ".runtime\safe_runtime_v016.ok" >nul 2>&1
call "%~dp0ENSURE_SAFE_RUNTIME.cmd"
if errorlevel 1 (
  echo GPU runtime setup failed. CPU fallback may still be available.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -c "import onnxruntime as o; print('Providers:',o.get_available_providers())"
echo DmlExecutionProvider means Windows GPU support is ready.
echo CUDA is disabled by default to prevent missing-DLL crashes.
pause
