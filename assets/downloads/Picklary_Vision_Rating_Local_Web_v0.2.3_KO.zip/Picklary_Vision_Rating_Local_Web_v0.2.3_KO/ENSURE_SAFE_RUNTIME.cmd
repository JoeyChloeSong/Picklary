@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" exit /b 1
if not exist ".runtime" mkdir ".runtime"
set "MARKER=.runtime\safe_runtime_v016.ok"
set "LOG=logs\runtime_setup.log"
if not exist "logs" mkdir "logs"
".venv\Scripts\python.exe" -m pip show onnxruntime-gpu >nul 2>&1
if not errorlevel 1 goto migrate
if exist "%MARKER%" exit /b 0

echo Checking the safe Windows GPU runtime...
>>"%LOG%" echo Started: %DATE% %TIME%

".venv\Scripts\python.exe" -c "import onnxruntime as o,sys; p=o.get_available_providers(); print(p); sys.exit(0 if 'DmlExecutionProvider' in p else 1)" >>"%LOG%" 2>&1
if not errorlevel 1 goto dml_ready

:migrate
echo Installing DirectML GPU support. CUDA packages will be removed...
".venv\Scripts\python.exe" -m pip uninstall -y onnxruntime onnxruntime-gpu onnxruntime-directml >>"%LOG%" 2>&1
".venv\Scripts\python.exe" -m pip install "onnxruntime-directml>=1.19,<2" --disable-pip-version-check --timeout 240 --retries 3 >>"%LOG%" 2>&1
if errorlevel 1 goto cpu_fallback
".venv\Scripts\python.exe" -c "import onnxruntime as o,sys; p=o.get_available_providers(); print(p); sys.exit(0 if 'DmlExecutionProvider' in p else 1)" >>"%LOG%" 2>&1
if errorlevel 1 goto cpu_fallback

:dml_ready
>"%MARKER%" echo directml
exit /b 0

:cpu_fallback
echo DirectML installation failed. Installing the CPU-safe runtime...
".venv\Scripts\python.exe" -m pip uninstall -y onnxruntime onnxruntime-gpu onnxruntime-directml >>"%LOG%" 2>&1
".venv\Scripts\python.exe" -m pip install "onnxruntime>=1.19,<2" --disable-pip-version-check --timeout 180 --retries 3 >>"%LOG%" 2>&1
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -c "import onnxruntime as o; print(o.get_available_providers())" >>"%LOG%" 2>&1
if errorlevel 1 goto failed
>"%MARKER%" echo cpu
exit /b 0

:failed
echo [ERROR] ONNX Runtime installation failed.
echo Log file: %CD%\%LOG%
exit /b 1
