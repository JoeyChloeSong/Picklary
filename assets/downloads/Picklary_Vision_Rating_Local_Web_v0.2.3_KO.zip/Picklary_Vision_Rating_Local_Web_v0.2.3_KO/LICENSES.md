# Picklary Vision Rating v0.5.0-G1.5 License Inventory

| Component | Purpose | License | Notes |
|---|---|---|---|
| Python | Runtime | PSF | Compatible |
| NumPy | Arrays | BSD-3-Clause | Compatible |
| SciPy | Optimization/assignment | BSD-3-Clause | Compatible |
| OpenCV | Video, geometry, DNN, remap | Apache-2.0 | Retain notices |
| Pydantic | Schema validation | MIT | Compatible |
| PyYAML | Evaluation gates | MIT | Compatible |
| PySide6 | Desktop UI | LGPL-3.0 / commercial | Follow LGPL obligations or use commercial terms |
| ONNX Runtime | CPU/GPU inference | MIT | DirectML runtime is used for the Windows local GPU path; CUDA is disabled by default |
| YOLOX code and official release weights | Person detection | Apache-2.0 | Official project notices and COCO dataset attribution must be retained |
| Picklary ByteTrack-style association | Tracking | Project code | Independent implementation of public two-stage association idea |
| Picklary TrackNet-style model code | Ball training/inference | Project code | Production weights are not bundled |

## Model files

`models/yolox_nano.onnx` and `models/tracknet_pickleball.onnx` are not included in this ZIP. Code license and weight/data rights are checked separately. A production ball model is enabled only when its sidecar metadata records dataset ownership, model license, holdout metrics, and release approval.

## Prohibited runtime dependencies

No Ultralytics or other AGPL runtime dependency is included in `requirements.txt`.
