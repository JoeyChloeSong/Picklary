@echo off
setlocal EnableExtensions
set "DATA_DIR=%USERPROFILE%\Documents\PicklaryVisionLocal"
if not exist "%DATA_DIR%" mkdir "%DATA_DIR%"
start "" "%DATA_DIR%"
