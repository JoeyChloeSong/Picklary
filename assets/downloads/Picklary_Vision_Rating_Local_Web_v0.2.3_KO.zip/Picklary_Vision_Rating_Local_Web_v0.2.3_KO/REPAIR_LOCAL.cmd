@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo This will remove the local Python environment and reinstall it.
choice /M "Continue"
if errorlevel 2 exit /b 0
if exist ".venv" rmdir /S /Q ".venv"
if exist ".runtime\safe_runtime_v015.ok" del /Q ".runtime\safe_runtime_v015.ok" >nul 2>&1
call "%~dp0SETUP_LOCAL.cmd"
