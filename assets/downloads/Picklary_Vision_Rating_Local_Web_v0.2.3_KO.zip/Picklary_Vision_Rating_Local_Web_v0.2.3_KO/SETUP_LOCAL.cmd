@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Picklary Vision Rating - Local Setup
if not exist "logs" mkdir "logs"
set "LOG=%CD%\logs\setup.log"
>"%LOG%" echo Picklary Vision Rating Setup
>>"%LOG%" echo Started: %DATE% %TIME%

echo ============================================================
echo Picklary Vision Rating - Local Setup
echo ============================================================
echo.
echo [1/5] Looking for Python 3.11 or 3.12...
call :find_python
if defined PYEXE goto python_ready

echo Python was not found.
where winget.exe >nul 2>&1
if errorlevel 1 goto no_python

echo [INFO] Installing Python 3.11 for the current Windows user...
winget install --id Python.Python.3.11 -e --scope user --silent --accept-package-agreements --accept-source-agreements >>"%LOG%" 2>&1
call :find_python
if not defined PYEXE goto no_python

:python_ready
echo [OK] Python command: %PYEXE% %PYARG%
>>"%LOG%" echo Python command: %PYEXE% %PYARG%

if exist ".venv\Scripts\python.exe" goto install_packages
echo [2/5] Creating the local Python environment...
"%PYEXE%" %PYARG% -m venv ".venv" >>"%LOG%" 2>&1
if errorlevel 1 goto failed

:install_packages
if not exist ".venv\Scripts\python.exe" goto failed
echo [3/5] Installing required packages. This can take several minutes...
".venv\Scripts\python.exe" -m pip install --upgrade pip --disable-pip-version-check --timeout 120 --retries 3 >>"%LOG%" 2>&1
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r "requirements-local.txt" --disable-pip-version-check --timeout 180 --retries 3 >>"%LOG%" 2>&1
if errorlevel 1 goto failed

echo [4/5] Installing the crash-safe GPU runtime...
if exist ".runtime\safe_runtime_v016.ok" del /Q ".runtime\safe_runtime_v016.ok" >nul 2>&1
call "%~dp0ENSURE_SAFE_RUNTIME.cmd"
if errorlevel 1 goto failed

:model_check
echo [5/5] Checking the person detection model...
if exist "models\yolox_nano.onnx" goto complete
call "%~dp0DOWNLOAD_PERSON_MODEL.cmd"
if errorlevel 1 echo [WARNING] The person model was not downloaded. The app can open, but person analysis will be unavailable.

:complete
echo.
echo ============================================================
echo Setup completed.
echo Run START_HERE.cmd next time.
echo ============================================================
>>"%LOG%" echo Completed: %DATE% %TIME%
exit /b 0

:find_python
set "PYEXE="
set "PYARG="
if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
  set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
  goto :eof
)
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
  set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
  goto :eof
)
where py.exe >nul 2>&1
if not errorlevel 1 (
  py.exe -3.11 -c "import sys" >nul 2>&1
  if not errorlevel 1 (
    set "PYEXE=py.exe"
    set "PYARG=-3.11"
    goto :eof
  )
  py.exe -3.12 -c "import sys" >nul 2>&1
  if not errorlevel 1 (
    set "PYEXE=py.exe"
    set "PYARG=-3.12"
    goto :eof
  )
)
where python.exe >nul 2>&1
if not errorlevel 1 (
  python.exe -c "import sys; raise SystemExit(0 if (3,11) <= sys.version_info[:2] <= (3,12) else 1)" >nul 2>&1
  if not errorlevel 1 set "PYEXE=python.exe"
)
goto :eof

:no_python
echo.
echo [ERROR] Python 3.11 or 3.12 could not be installed automatically.
echo Install Python 3.11 and select Add python.exe to PATH.
start "" "https://www.python.org/downloads/release/python-3119/"
>>"%LOG%" echo ERROR: Python not found.
pause
exit /b 1

:failed
echo.
echo [ERROR] Setup failed.
echo Log file: %LOG%
echo.
echo The last 25 log lines are shown below:
powershell.exe -NoProfile -Command "if (Test-Path -LiteralPath '%LOG%') { Get-Content -LiteralPath '%LOG%' -Tail 25 }"
pause
exit /b 1
