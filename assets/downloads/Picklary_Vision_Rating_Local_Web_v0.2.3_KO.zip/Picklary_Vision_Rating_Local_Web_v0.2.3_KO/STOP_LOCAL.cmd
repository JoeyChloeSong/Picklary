@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".runtime\server.pid" (
  echo No running local server was found.
  pause
  exit /b 0
)
set /p SERVER_PID=<".runtime\server.pid"
taskkill /PID %SERVER_PID% /T /F >nul 2>&1
if errorlevel 1 (
  echo The server was already stopped or the PID was invalid.
) else (
  echo Picklary local server stopped.
)
del /Q ".runtime\server.pid" 2>nul
del /Q ".runtime\server_port.txt" 2>nul
pause
