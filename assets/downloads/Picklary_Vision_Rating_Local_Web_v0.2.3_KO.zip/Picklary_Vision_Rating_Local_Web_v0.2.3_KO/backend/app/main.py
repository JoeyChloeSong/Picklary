from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any
import json
import os
import subprocess
import sys
import threading
import time

from fastapi import Body, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from picklary_rating.analysis.device import choose_dnn_device, inspect_runtime_capabilities

from .analysis_runner import create_preview
from picklary_rating.analysis.auto_setup import run_auto_setup
from .store import JobStore, StoreConfig

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_ROOT = Path(os.getenv("PVR_DATA_ROOT", str(PROJECT_ROOT / "data" / "jobs"))).resolve()
MAX_UPLOAD_BYTES = int(os.getenv("PVR_MAX_UPLOAD_BYTES", str(2 * 1024 * 1024 * 1024)))
CHUNK_SIZE = int(os.getenv("PVR_CHUNK_SIZE", str(8 * 1024 * 1024)))
TTL_HOURS = int(os.getenv("PVR_JOB_TTL_HOURS", "24"))
WORKERS = max(1, int(os.getenv("PVR_ANALYSIS_WORKERS", "1")))
CORS_ORIGINS = [x.strip() for x in os.getenv("PVR_CORS_ORIGINS", "*").split(",") if x.strip()]
DEPLOYMENT_MODE = os.getenv("PVR_DEPLOYMENT_MODE", "web")

store = JobStore(StoreConfig(DATA_ROOT, MAX_UPLOAD_BYTES, CHUNK_SIZE))
executor = ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix="pvr-analysis")
running_jobs: set[str] = set()
running_lock = threading.Lock()


class UploadInit(BaseModel):
    filename: str = Field(min_length=1, max_length=255)
    size: int = Field(gt=0)
    content_type: str | None = None


class UploadComplete(BaseModel):
    total_chunks: int = Field(gt=0, le=100000)


class AutoSetupRequest(BaseModel):
    time_s: float = Field(default=0.0, ge=0.0)
    processing_device: str = "gpu"


class ConfigureJob(BaseModel):
    court_points: list[dict[str, float]]
    player_points: list[dict[str, float]]
    players: list[dict[str, Any]]
    analysis_mode: str = "full"
    processing_device: str = "gpu"
    enable_classical_ball_fallback: bool = True
    ball_profile_id: str = "franklin_x40_outdoor"
    person_stride: int = 2
    lens_mode: str = "none"
    enable_audio_onset: bool = True
    analysis_start_s: float = 0.0
    game_target_points: int = 15
    initial_server_label: str | None = None
    first_server_side: str | None = None
    final_score_near: int | None = None
    final_score_far: int | None = None


@asynccontextmanager
async def lifespan(_app: FastAPI):
    stop = threading.Event()

    def cleanup() -> None:
        while not stop.wait(3600):
            if TTL_HOURS <= 0:
                continue
            cutoff = time.time() - TTL_HOURS * 3600
            store.purge_older_than(cutoff)

    thread = threading.Thread(target=cleanup, name="pvr-cleanup", daemon=True)
    thread.start()
    yield
    stop.set()
    executor.shutdown(wait=False, cancel_futures=False)


app = FastAPI(title="Picklary Vision Rating Local Web", version="0.2.3", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "OPTIONS"],
    allow_headers=["*"],
)


def public_state(state: dict[str, Any]) -> dict[str, Any]:
    hidden = {"video_path"}
    return {k: v for k, v in state.items() if k not in hidden}


def get_state(job_id: str) -> dict[str, Any]:
    try:
        return store.load(job_id)
    except (FileNotFoundError, ValueError):
        raise HTTPException(status_code=404, detail="작업을 찾을 수 없습니다.")


@app.get("/api/health")
def health() -> dict[str, Any]:
    model = PROJECT_ROOT / "models" / "yolox_nano.onnx"
    ball_model = PROJECT_ROOT / "models" / "tracknet_pickleball.onnx"
    caps = inspect_runtime_capabilities("gpu")
    backend_key, device_label = choose_dnn_device("gpu")
    is_gpu = device_label.startswith("GPU")
    fallback = "fallback" in device_label.lower()
    return {
        "status": "ok",
        "version": "local-web-0.2.3" if DEPLOYMENT_MODE == "local" else "web-beta-0.2.3",
        "locale": os.getenv("PVR_LOCALE", "ko"),
        "person_model_ready": model.exists() and model.stat().st_size > 1_000_000,
        "ball_model_ready": ball_model.exists() and ball_model.stat().st_size > 1_000_000,
        "default_mode": "full",
        "default_processing_device": "gpu",
        "full_analysis_policy": "assume Franklin X-40; use visual trajectories first, audio-motion hybrid second, and Franklin-profile low-evidence estimation last",
        "default_ball_profile": {
            "profile_id": "franklin_x40_outdoor",
            "display_name": "Franklin X-40 Outdoor",
            "diameter_mm": 74.0,
            "mass_g": 26.0,
            "hole_count": 40,
            "user_selection_required": False,
        },
        "processing": caps.to_dict(),
        "preferred_processing": {
            "requested": "gpu",
            "backend": backend_key,
            "summary": device_label,
            "is_gpu": is_gpu,
            "fallback": fallback,
            "detail": caps.hardware_summary,
        },
        "max_upload_bytes": MAX_UPLOAD_BYTES,
        "job_ttl_hours": TTL_HOURS,
        "deployment_mode": DEPLOYMENT_MODE,
        "data_root": str(DATA_ROOT) if DEPLOYMENT_MODE == "local" else None,
    }


@app.post("/api/uploads/init")
def init_upload(payload: UploadInit) -> dict[str, Any]:
    try:
        state = store.create_job(payload.filename, payload.size, payload.content_type)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"job": public_state(state), "chunk_size": CHUNK_SIZE}


@app.put("/api/uploads/{job_id}/chunks/{index}")
async def upload_chunk(job_id: str, index: int, request: Request) -> dict[str, Any]:
    body = await request.body()
    try:
        state = store.write_chunk(job_id, index, body)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="작업을 찾을 수 없습니다.")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"job": public_state(state)}


@app.post("/api/uploads/{job_id}/complete")
def complete_upload(job_id: str, payload: UploadComplete) -> dict[str, Any]:
    try:
        video = store.complete_upload(job_id, payload.total_chunks)
        preview_path = store.job_dir(job_id) / "preview.jpg"
        metadata = create_preview(video, preview_path)
        state = store.load(job_id)
        state["metadata"] = metadata
        store.save(job_id, state)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="작업을 찾을 수 없습니다.")
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"job": public_state(state)}




@app.post("/api/jobs/{job_id}/auto-setup")
def auto_setup_job(job_id: str, payload: AutoSetupRequest) -> dict[str, Any]:
    state = get_state(job_id)
    video_path = state.get("video_path")
    if not video_path:
        raise HTTPException(status_code=400, detail=(
            "영상 업로드를 먼저 완료해 주세요." if os.getenv("PVR_LOCALE", "ko").lower().startswith("ko")
            else "Complete the video upload first."
        ))
    try:
        result = run_auto_setup(
            video_path=video_path,
            time_s=float(payload.time_s),
            project_root=PROJECT_ROOT,
            requested_device=payload.processing_device,
        )
        state["auto_setup"] = result
        store.save(job_id, state)
        return {"job": public_state(state), "auto_setup": result}
    except Exception as exc:
        detail = (
            f"자동 설정 실패: {type(exc).__name__}: {exc}"
            if os.getenv("PVR_LOCALE", "ko").lower().startswith("ko")
            else f"Auto setup failed: {type(exc).__name__}: {exc}"
        )
        raise HTTPException(status_code=400, detail=detail)


@app.get("/api/jobs/{job_id}")
def job_status(job_id: str) -> dict[str, Any]:
    return {"job": public_state(get_state(job_id))}


@app.get("/api/jobs/{job_id}/preview")
def job_preview(job_id: str) -> FileResponse:
    get_state(job_id)
    path = store.job_dir(job_id) / "preview.jpg"
    if not path.exists():
        raise HTTPException(status_code=404, detail="미리보기가 아직 준비되지 않았습니다.")
    return FileResponse(path, media_type="image/jpeg", filename="preview.jpg")


@app.post("/api/jobs/{job_id}/configure")
def configure_job(job_id: str, payload: ConfigureJob) -> dict[str, Any]:
    if len(payload.court_points) != 8:
        raise HTTPException(status_code=400, detail="코트 지면 기준점 8개가 필요합니다.")
    if len(payload.player_points) != 4:
        raise HTTPException(status_code=400, detail="선수 위치 4개가 필요합니다.")
    if len(payload.players) != 4:
        raise HTTPException(status_code=400, detail="선수 정보 4명이 필요합니다.")
    try:
        state = store.configure(job_id, payload.model_dump())
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="작업을 찾을 수 없습니다.")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"job": public_state(state)}


def _run_and_release(job_id: str) -> None:
    """Run native inference in a child process so a provider crash cannot close the UI server."""
    log_path = store.job_dir(job_id) / "worker_console.log"
    command = [
        sys.executable,
        "-m",
        "backend.app.worker",
        job_id,
        str(DATA_ROOT),
        str(MAX_UPLOAD_BYTES),
        str(CHUNK_SIZE),
        str(PROJECT_ROOT),
    ]
    try:
        with log_path.open("w", encoding="utf-8", errors="replace") as log:
            worker_env = os.environ.copy()
            worker_env["PVR_LOCALE"] = os.getenv("PVR_LOCALE", "ko")
            worker_env["PVR_PACKAGE_LOCALE"] = os.getenv("PVR_PACKAGE_LOCALE", worker_env["PVR_LOCALE"])
            completed = subprocess.run(
                command,
                cwd=str(PROJECT_ROOT),
                stdout=log,
                stderr=subprocess.STDOUT,
                check=False,
                env=worker_env,
            )
        try:
            state = store.load(job_id)
        except Exception:
            state = {}
        if completed.returncode != 0 and state.get("status") not in {"failed", "complete"}:
            store.update(
                job_id,
                status="failed",
                progress=0,
                message="분석 워커 종료",
                error=(
                    "분석 엔진이 예기치 않게 종료되었습니다. 프로그램 창은 유지됩니다. "
                    "worker_console.log를 확인해 주세요."
                ),
                report_ready=False,
            )
    except Exception as exc:
        store.update(
            job_id,
            status="failed",
            progress=0,
            message="분석 워커 시작 실패",
            error=f"{type(exc).__name__}: {exc}",
            report_ready=False,
        )
    finally:
        with running_lock:
            running_jobs.discard(job_id)


@app.post("/api/jobs/{job_id}/start")
def start_job(job_id: str) -> dict[str, Any]:
    state = get_state(job_id)
    if state.get("configuration") is None:
        raise HTTPException(status_code=400, detail="분석 설정을 먼저 완료해 주세요.")
    model = PROJECT_ROOT / "models" / "yolox_nano.onnx"
    if not model.exists() or model.stat().st_size < 1_000_000:
        raise HTTPException(status_code=503, detail="서버에 사람 인식 모델이 설치되지 않았습니다. 운영자가 모델 설치를 완료해야 합니다.")
    with running_lock:
        if job_id in running_jobs:
            return {"job": public_state(state)}
        if state["status"] == "complete":
            return {"job": public_state(state)}
        running_jobs.add(job_id)
    store.update(job_id, status="queued", progress=0, message="분석 대기열 등록", error=None)
    executor.submit(_run_and_release, job_id)
    return {"job": public_state(store.load(job_id))}


@app.get("/api/jobs/{job_id}/report")
def report(job_id: str) -> FileResponse:
    state = get_state(job_id)
    path = store.job_dir(job_id) / "published" / "report.html"
    if state.get("status") != "complete" or not path.exists():
        raise HTTPException(status_code=404, detail="보고서가 아직 준비되지 않았습니다.")
    return FileResponse(path, media_type="text/html; charset=utf-8")


@app.get("/api/jobs/{job_id}/analysis")
def analysis_json(job_id: str) -> JSONResponse:
    get_state(job_id)
    path = store.job_dir(job_id) / "published" / "analysis.json"
    if not path.exists():
        raise HTTPException(status_code=404, detail="분석 JSON이 아직 준비되지 않았습니다.")
    return JSONResponse(json.loads(path.read_text(encoding="utf-8")))


FRONTEND = PROJECT_ROOT / "frontend"
app.mount("/", StaticFiles(directory=FRONTEND, html=True), name="frontend")
