from __future__ import annotations

from pathlib import Path
import sys

from .analysis_runner import run_job
from .store import JobStore, StoreConfig


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if len(args) != 5:
        print("usage: worker JOB_ID DATA_ROOT MAX_UPLOAD_BYTES CHUNK_SIZE PROJECT_ROOT", file=sys.stderr)
        return 2
    job_id, data_root, max_upload, chunk_size, project_root = args
    store = JobStore(StoreConfig(Path(data_root), int(max_upload), int(chunk_size)))
    run_job(store, job_id, Path(project_root))
    try:
        state = store.load(job_id)
    except Exception:
        return 3
    return 0 if state.get("status") == "complete" else 1


if __name__ == "__main__":
    raise SystemExit(main())
