from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np
from scipy.optimize import least_squares

from picklary_rating.analysis.camera import FullCameraCalibration
from picklary_rating.models import BallObservation, Point3D


GRAVITY_FT_S2 = 32.174


@dataclass(slots=True)
class BallisticFitResult:
    success: bool
    p0: Point3D | None
    v0_ft_s: Point3D | None
    speed_mph: float | None
    reprojection_rmse_px: float | None
    positions: list[Point3D]
    message: str


def fit_ballistic_trajectory(
    observations: list[BallObservation],
    camera: FullCameraCalibration,
    max_reprojection_rmse_px: float = 5.0,
    bounce_anchor: Point3D | None = None,
) -> BallisticFitResult:
    valid = [o for o in observations if o.visible and not o.predicted]
    if len(valid) < 4 or not camera.speed_metrics_enabled:
        return BallisticFitResult(False, None, None, None, None, [], "requires >=4 observations and 11-point calibration")
    t0 = valid[0].time_s
    times = np.asarray([o.time_s - t0 for o in valid], dtype=float)
    rays = [camera.image_ray(o.image_position) for o in valid]

    if bounce_anchor is not None:
        p_init = np.asarray(bounce_anchor.as_tuple(), dtype=float)
    else:
        ground = camera.image_to_ground(valid[0].image_position)
        p_init = np.asarray([ground.x, ground.y, 3.0], dtype=float)
    last_ground = camera.image_to_ground(valid[-1].image_position)
    dt = max(times[-1], 0.05)
    v_init = np.asarray([(last_ground.x - p_init[0]) / dt, (last_ground.y - p_init[1]) / dt, 4.0], dtype=float)
    x0 = np.concatenate([p_init, v_init])

    def position(params: np.ndarray, t: float) -> np.ndarray:
        p0 = params[:3]
        v0 = params[3:]
        return p0 + v0 * t + np.asarray([0.0, 0.0, -0.5 * GRAVITY_FT_S2 * t * t])

    def residual(params: np.ndarray) -> np.ndarray:
        values: list[float] = []
        for t, (origin, direction) in zip(times, rays):
            delta = position(params, t) - origin
            perpendicular = delta - direction * float(np.dot(delta, direction))
            values.extend(perpendicular.tolist())
        if bounce_anchor is not None:
            values.extend(((params[:3] - np.asarray(bounce_anchor.as_tuple())) * 2.0).tolist())
        return np.asarray(values)

    fit = least_squares(residual, x0, method="trf", max_nfev=800)
    params = fit.x
    positions_np = [position(params, t) for t in times]
    if any(p[2] < -0.5 or p[2] > 30.0 for p in positions_np):
        return BallisticFitResult(False, None, None, None, None, [], "fitted trajectory violates plausible height bounds")

    pixel_errors: list[float] = []
    positions: list[Point3D] = []
    for obs, p in zip(valid, positions_np):
        p3 = Point3D(float(p[0]), float(p[1]), float(p[2]))
        positions.append(p3)
        projected = camera.project_3d(p3)
        pixel_errors.append(math.hypot(projected.x - obs.image_position.x, projected.y - obs.image_position.y))
    rmse = float(math.sqrt(np.mean(np.square(pixel_errors))))
    success = bool(fit.success and rmse <= max_reprojection_rmse_px)
    v0 = Point3D(float(params[3]), float(params[4]), float(params[5]))
    speed_mph = math.sqrt(params[3] ** 2 + params[4] ** 2 + params[5] ** 2) * 0.681818 if success else None
    return BallisticFitResult(
        success=success,
        p0=Point3D(float(params[0]), float(params[1]), float(params[2])) if success else None,
        v0_ft_s=v0 if success else None,
        speed_mph=float(speed_mph) if speed_mph is not None else None,
        reprojection_rmse_px=rmse,
        positions=positions if success else [],
        message="ok" if success else f"reprojection RMSE {rmse:.2f}px exceeds {max_reprojection_rmse_px:.2f}px",
    )
