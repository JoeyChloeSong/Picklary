(() => {
  const cfg = window.PVR_CONFIG || {};
  const API = String(cfg.API_BASE || "").replace(/\/$/, "");
  const EXPECTED_LOCALE = String(cfg.LOCALE || "ko").toLowerCase().startsWith("en") ? "en" : "ko";
  const T = {"courtLabels":["먼쪽 베이스라인 왼쪽","먼쪽 베이스라인 오른쪽","가까운쪽 베이스라인 오른쪽","가까운쪽 베이스라인 왼쪽","먼쪽 키친라인 왼쪽","먼쪽 키친라인 오른쪽","가까운쪽 키친라인 오른쪽","가까운쪽 키친라인 왼쪽"],"nearRight":"가까운쪽 오른쪽","nearLeft":"가까운쪽 왼쪽","farLeft":"먼쪽 왼쪽","farRight":"먼쪽 오른쪽","noDevice":"장치 정보 없음","deviceAfterStart":"분석을 시작하면 실제 사용 장치가 표시됩니다.","gpuActive":"GPU 가속이 활성화되었습니다.","cpuActive":"CPU로 처리 중입니다.","deviceChecking":"장치 정보 확인 중","person":"사람","ball":"공","actualBackend":"실제 분석 백엔드를 표시합니다.","wrongLocale":"다른 언어판 서버가 이 포트에서 실행 중입니다. 다른 Picklary 창을 닫고 한글판을 다시 실행해 주세요.","engineReady":"로컬 엔진 준비","modelNeeded":"사람 모델 설치 필요","serverFailed":"서버 연결 실패","chooseVideo":"영상 파일을 선택해 주세요.","waiting":"대기","automatic":"자동 적용","assisted":"반자동","manual":"직접 지정","courtActionPrefix":"지금 지정할 코트 점","playerActionPrefix":"지금 지정할 선수","markCourt":"코트 점","verifyCourtAction":"파란색 1~8번 점이 실제 코트 선 교차점과 맞는지 확인하세요. 8개가 배치되면 자동으로 확인 완료됩니다.","verifyPlayersAction":"주황색 A~D 점이 선수 발 중앙과 위치 라벨에 맞는지 확인하세요. 4개가 배치되면 자동으로 확인 완료됩니다.","setupReady":"필수 설정이 완료되었습니다. 경기 정보 입력 단계로 이동할 수 있습니다.","guideWaiting":"자동 인식을 실행하면 사용자가 확인하거나 직접 지정해야 하는 항목이 표시됩니다.","guideReady":"자동·반자동 설정 확인이 모두 완료되었습니다.","guidePending":"아래 항목만 완료하면 됩니다. 현재 필요한 작업을 순서대로 안내합니다.","manualGuide":"자동 인식이 어려워 직접 지정이 필요합니다. 정확도가 낮은 추천점은 표시하지 않습니다.","manualCourt":"먼쪽 베이스라인 왼쪽부터 안내 순서대로 실제 코트 선 교차점 8곳을 클릭하세요.","manualPlayers":"코트 8점 완료 후 선수 A~D의 실제 발 중앙을 안내 순서대로 클릭하세요.","manualCurrent":"현재 지정","selectCourt":"{point}을 선택하세요.","courtVerified":"코트 8점 자동 확인 완료 · 필요한 점은 언제든 드래그해 수정할 수 있습니다.","courtComplete":"코트 8점 자동 확인 완료 · 별도 확인 버튼이 필요하지 않습니다.","finishCourt":"코트 8점을 완료하면 선수 A부터 지정합니다.","selectPlayer":"선수 {label} · {position}의 발 중앙을 선택하세요.","playersVerified":"선수 4명 자동 확인 완료 · 필요한 점은 언제든 드래그해 수정할 수 있습니다.","playersComplete":"선수 4명 자동 확인 완료 · 라벨과 발 중앙을 확인해 주세요.","autoSetupBusy":"영상을 로컬 분석 폴더로 복사하고 자동 인식 중입니다.","copyProgress":"로컬 영상 복사 {done}/{total} 조각","job":"작업","uploading":"영상 업로드","chunks":"조각","uploadComplete":"업로드 완료","sendingSettings":"분석 설정을 전송합니다.","autoSetupFailed":"자동 인식 실패","manualFallback":"자동 인식에 실패해 직접 지정 모드로 전환했습니다.","playerName":"선수 이름","noDupr":"DUPR 없음","playerDupr":"선수 DUPR","analysisComplete":"분석 완료","reportReady":"결과 보고서가 준비되었습니다.","analysisFailed":"분석 실패","queued":"분석 대기","analyzing":"영상 분석","processing":"처리 중","preparingCopy":"로컬 복사 준비","copyingLocal":"영상을 이 PC의 로컬 분석 폴더로 복사합니다.","stopped":"처리 중단","forceCpu":"CPU 강제","cpuDetail":"모든 AI 추론을 CPU에서 실행합니다."};
  const $ = (id) => document.getElementById(id);
  const state = {
    step: 1, file: null, objectUrl: null, videoWidth: 0, videoHeight: 0,
    court: [], players: [null, null, null, null], autoBoxes: [],
    courtConfirmed: false, playersConfirmed: false, setupMode: "waiting",
    zoom: 1, panX: 0, panY: 0, mode: "point",
    dragging: false, dragPoint: null, lastX: 0, lastY: 0, frameReady: false,
    jobId: null, health: null, uploadedComplete: false, uploadPromise: null, setupSummary: null, setupActions: []
  };
  const courtLabels = T.courtLabels;
  const playerDefaults = [["A", T.nearRight], ["B", T.nearLeft], ["C", T.farLeft], ["D", T.farRight]];
  const canvas = $("frameCanvas"), ctx = canvas.getContext("2d"), video = $("sourceVideo");

  function endpoint(path){ return `${API}${path}`; }
  async function api(path, options={}){
    const response = await fetch(endpoint(path), options);
    if (!response.ok){
      let detail = `${response.status} ${response.statusText}`;
      try { const body = await response.json(); detail = body.detail || detail; } catch (_) {}
      throw new Error(detail);
    }
    const type = response.headers.get("content-type") || "";
    return type.includes("application/json") ? response.json() : response;
  }

  function deviceInfo(value){
    if(!value) return {label:T.noDevice,detail:T.deviceAfterStart,kind:"checking"};
    if(typeof value === "string"){
      const gpu=value.includes("GPU")&&!value.toLowerCase().includes("fallback");
      return {label:value,detail:gpu?T.gpuActive:T.cpuActive,kind:gpu?"gpu":(value.toLowerCase().includes("fallback")?"fallback":"cpu")};
    }
    const summary=value.summary||value.label||value.device_label||value.resolved_label||value.hardware_summary||T.deviceChecking;
    const person=value.person||value.person_device||"";
    const ball=value.ball||value.ball_device||"";
    const combined=[person&&`${T.person}: ${person}`,ball&&`${T.ball}: ${ball}`].filter(Boolean).join(" · ");
    const gpu=(value.is_gpu===true)||(summary.includes("GPU")&&!summary.toLowerCase().includes("fallback"));
    const fallback=value.fallback===true||summary.toLowerCase().includes("fallback");
    return {label:summary,detail:combined||value.detail||T.actualBackend,kind:fallback?"fallback":(gpu?"gpu":"cpu")};
  }
  function renderDeviceStatus(value, active=false){
    const info=deviceInfo(value), card=$("deviceStatusCard");
    if(card){card.className=`device-card ${info.kind}`;$("deviceStatus").textContent=info.label;$("deviceDetail").textContent=info.detail;}
    if(active&&$("activeDeviceStatus")) $("activeDeviceStatus").textContent=info.label;
  }

  function formatBytes(n){ const u=["B","KB","MB","GB"]; let i=0,v=n; while(v>=1024&&i<u.length-1){v/=1024;i++;} return `${v.toFixed(i?1:0)} ${u[i]}`; }
  function formatTime(s){ const m=Math.floor(s/60), sec=Math.round(s%60); return `${m}:${String(sec).padStart(2,"0")}`; }
  function setStep(n){ state.step=n; document.querySelectorAll(".panel").forEach((p,i)=>p.classList.toggle("active",i===n-1)); document.querySelectorAll(".step").forEach((p,i)=>p.classList.toggle("active",i===n-1)); window.scrollTo({top:0,behavior:"smooth"}); }
  document.querySelectorAll(".back").forEach(b=>b.addEventListener("click",()=>setStep(Number(b.dataset.target))));

  async function health(){
    const badge=$("serverBadge");
    try{
      state.health=await api("/api/health");
      if(String(state.health.locale||"").toLowerCase() !== EXPECTED_LOCALE){ throw new Error(T.wrongLocale); }
      badge.textContent=state.health.person_model_ready?T.engineReady:T.modelNeeded;
      badge.className=`server-badge ${state.health.person_model_ready?"ok":"fail"}`;
      $("healthDetails").textContent=JSON.stringify(state.health,null,2);
      renderDeviceStatus(state.health.preferred_processing || state.health.processing, false);
    }catch(e){ badge.textContent=T.serverFailed; badge.className="server-badge fail"; $("healthDetails").textContent=e.message; }
  }

  function resetSetup(){
    state.court=[]; state.players=[null,null,null,null]; state.autoBoxes=[];
    state.courtConfirmed=false; state.playersConfirmed=false; state.setupMode="waiting";
    state.jobId=null; state.uploadedComplete=false; state.uploadPromise=null; state.setupSummary=null; state.setupActions=[];
    renderSetupGuide(); updatePrompts(); draw();
  }
  function acceptFile(file){
    if(!file) return;
    if(!file.type.startsWith("video/")){alert(T.chooseVideo);return;}
    if(state.objectUrl) URL.revokeObjectURL(state.objectUrl);
    resetSetup(); state.file=file; state.objectUrl=URL.createObjectURL(file); video.src=state.objectUrl;
    $("fileName").textContent=file.name; $("fileMeta").textContent=formatBytes(file.size); $("fileCard").classList.remove("hidden"); $("dropzone").classList.add("hidden");
    video.onloadedmetadata=()=>{state.videoWidth=video.videoWidth;state.videoHeight=video.videoHeight;$("fileMeta").textContent=`${formatBytes(file.size)} · ${video.videoWidth}×${video.videoHeight} · ${formatTime(video.duration)}`;$("toStep2").disabled=false;seekAndDraw(Number($("startTime").value)||0);};
  }
  $("videoInput").addEventListener("change",e=>acceptFile(e.target.files[0]));
  $("changeFile").addEventListener("click",()=>$("videoInput").click());
  ["dragenter","dragover"].forEach(ev=>$("dropzone").addEventListener(ev,e=>{e.preventDefault();$("dropzone").classList.add("drag");}));
  ["dragleave","drop"].forEach(ev=>$("dropzone").addEventListener(ev,e=>{e.preventDefault();$("dropzone").classList.remove("drag");}));
  $("dropzone").addEventListener("drop",e=>acceptFile(e.dataTransfer.files[0]));
  $("toStep2").addEventListener("click",()=>{setStep(2);resizeCanvas();draw();renderSetupGuide();setTimeout(()=>{if(state.file&&!state.uploadedComplete)$("runAutoSetup").click();},250);});

  function resizeCanvas(){ const rect=canvas.getBoundingClientRect(); const dpr=Math.min(2,window.devicePixelRatio||1); canvas.width=Math.max(1,Math.floor(rect.width*dpr));canvas.height=Math.max(1,Math.floor(rect.height*dpr));ctx.setTransform(dpr,0,0,dpr,0,0);draw(); }
  window.addEventListener("resize",resizeCanvas);
  function baseScale(){ return Math.min(canvas.clientWidth/Math.max(1,state.videoWidth),canvas.clientHeight/Math.max(1,state.videoHeight)); }
  function transform(){ const s=baseScale()*state.zoom; const w=state.videoWidth*s,h=state.videoHeight*s; return {s,x:(canvas.clientWidth-w)/2+state.panX,y:(canvas.clientHeight-h)/2+state.panY}; }
  function sourceFromScreen(x,y){ const t=transform(); return {x:(x-t.x)/t.s,y:(y-t.y)/t.s}; }
  function screenFromSource(p){ const t=transform(); return {x:t.x+p.x*t.s,y:t.y+p.y*t.s}; }
  function draw(){
    if(!canvas.clientWidth) return;
    ctx.clearRect(0,0,canvas.clientWidth,canvas.clientHeight);ctx.fillStyle="#020813";ctx.fillRect(0,0,canvas.clientWidth,canvas.clientHeight);
    if(state.frameReady){ const t=transform();ctx.drawImage(video,t.x,t.y,state.videoWidth*t.s,state.videoHeight*t.s); }
    const t=transform();
    state.autoBoxes.forEach((entry,index)=>{
      const b=entry.box||entry;
      if(!Array.isArray(b)||b.length!==4)return;
      ctx.strokeStyle="rgba(255,182,90,.72)";ctx.lineWidth=2;ctx.setLineDash([7,5]);
      ctx.strokeRect(t.x+b[0]*t.s,t.y+b[1]*t.s,(b[2]-b[0])*t.s,(b[3]-b[1])*t.s);ctx.setLineDash([]);
      if(entry.label){ctx.fillStyle="#ffb65a";ctx.font="800 12px system-ui";ctx.fillText(entry.label,t.x+b[0]*t.s+4,t.y+b[1]*t.s+14);}
    });
    const drawPoint=(p,label,color)=>{if(!p)return;const s=screenFromSource(p);ctx.beginPath();ctx.arc(s.x,s.y,10,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();ctx.lineWidth=3;ctx.strokeStyle="#fff";ctx.stroke();ctx.fillStyle="#061829";ctx.font="800 11px system-ui";ctx.textAlign="center";ctx.textBaseline="middle";ctx.fillText(label,s.x,s.y);};
    state.court.forEach((p,i)=>drawPoint(p,String(i+1),"#56d9ff"));
    state.players.forEach((p,i)=>drawPoint(p,playerDefaults[i][0],"#ffb65a"));
  }
  function seekAndDraw(time){ if(!state.file) return; const safe=Math.max(0,Math.min(video.duration||0,time)); state.frameReady=false;video.currentTime=safe;video.onseeked=()=>{state.frameReady=true;state.zoom=1;state.panX=state.panY=0;resizeCanvas();}; }
  $("loadFrame").addEventListener("click",()=>{seekAndDraw(Number($("startTime").value)||0);updatePrompts();});

  function playerCount(){return state.players.filter(Boolean).length;}
  function nextMissingPlayer(){return state.players.findIndex(p=>!p);}
  function syncAutoVerification(){
    state.courtConfirmed=state.court.length===8;
    state.playersConfirmed=playerCount()===4;
  }
  function manualCurrentInstruction(){
    if(state.court.length<8) return `${T.manualCurrent}: ${T.selectCourt.replace("{point}",courtLabels[state.court.length])}`;
    const missing=nextMissingPlayer();
    if(missing>=0) return `${T.manualCurrent}: ${T.selectPlayer.replace("{label}",playerDefaults[missing][0]).replace("{position}",playerDefaults[missing][1])}`;
    return T.setupReady;
  }
  function renderSetupGuide(summary=null, mode=null, actions=null){
    syncAutoVerification();
    if(mode) state.setupMode=mode;
    if(summary!==null) state.setupSummary=summary;
    if(Array.isArray(actions)) state.setupActions=actions;
    const guide=$("setupGuide"); guide.className=`setup-guide ${state.setupMode}`;
    const labels={waiting:T.waiting,automatic:T.automatic,semi_auto:T.assisted,manual:T.manual};
    $("setupModeBadge").textContent=labels[state.setupMode]||T.waiting;
    const dynamic=[];
    if(state.court.length<8) dynamic.push(`${T.courtActionPrefix}: ${courtLabels[state.court.length]||T.markCourt}.`);
    const missing=nextMissingPlayer();
    if(state.court.length===8&&missing>=0) dynamic.push(`${T.playerActionPrefix}: ${playerDefaults[missing][0]} · ${playerDefaults[missing][1]}.`);
    let rendered=[];
    if(state.setupMode==="manual"){
      if(state.court.length<8) rendered.push(T.manualCourt);
      else if(missing>=0) rendered.push(T.manualPlayers);
      if(!rendered.length) rendered.push(T.setupReady);
    }else if(state.setupActions.length && !state.courtConfirmed){
      rendered=state.setupActions.map(a=>`${a.title}: ${a.description}`);
    }else{
      rendered=dynamic;
      if(!rendered.length) rendered.push(T.setupReady);
    }
    $("setupGuideSummary").textContent=state.setupMode==="manual"?T.manualGuide:(state.setupSummary||(
      state.setupMode==="waiting"?T.guideWaiting:
      rendered.length===1&&rendered[0]===T.setupReady?T.guideReady:T.guidePending
    ));
    $("setupActionList").innerHTML=rendered.map(item=>`<li>${item}</li>`).join("");
    const notice=$("manualSetupNotice");
    if(notice){
      notice.classList.toggle("hidden",state.setupMode!=="manual"||state.courtConfirmed&&state.playersConfirmed);
      $("manualNoticeCurrent").textContent=manualCurrentInstruction();
    }
    document.querySelectorAll(".task-card")[0].classList.toggle("needs-attention",state.court.length<8);
    document.querySelectorAll(".task-card")[0].classList.toggle("verified",state.court.length===8);
    document.querySelectorAll(".task-card")[1].classList.toggle("needs-attention",playerCount()<4);
    document.querySelectorAll(".task-card")[1].classList.toggle("verified",playerCount()===4);
  }
  function updatePrompts(){
    syncAutoVerification();
    $("courtCount").textContent=`${state.court.length}/8`;$("playerCount").textContent=`${playerCount()}/4`;
    $("courtPrompt").textContent=state.court.length<8?T.selectCourt.replace("{point}",courtLabels[state.court.length]):T.courtVerified;
    const missing=nextMissingPlayer();
    $("playerPrompt").textContent=state.court.length<8?T.finishCourt:(missing>=0?T.selectPlayer.replace("{label}",playerDefaults[missing][0]).replace("{position}",playerDefaults[missing][1]):T.playersVerified);
    $("confirmCourt").disabled=true;$("confirmPlayers").disabled=true;
    $("confirmCourt").classList.toggle("verified",state.courtConfirmed);$("confirmPlayers").classList.toggle("verified",state.playersConfirmed);
    $("toStep3").disabled=!(state.courtConfirmed&&state.playersConfirmed);
    renderSetupGuide();
  }
  function nearestPoint(sx,sy){ let best=null,dist=Infinity; [["court",state.court],["players",state.players]].forEach(([type,arr])=>arr.forEach((p,i)=>{if(!p)return;const s=screenFromSource(p),d=Math.hypot(s.x-sx,s.y-sy);if(d<dist&&d<18){best={type,index:i};dist=d;}})); return best; }
  canvas.addEventListener("wheel",e=>{e.preventDefault();if(!state.frameReady)return;const r=canvas.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top,before=sourceFromScreen(mx,my),factor=e.deltaY<0?1.14:.88,newZoom=Math.max(1,Math.min(8,state.zoom*factor));state.zoom=newZoom;const after=screenFromSource(before);state.panX+=mx-after.x;state.panY+=my-after.y;draw();},{passive:false});
  canvas.addEventListener("pointerdown",e=>{if(!state.frameReady)return;canvas.setPointerCapture(e.pointerId);const r=canvas.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;state.dragging=true;state.lastX=x;state.lastY=y;state.dragPoint=state.mode==="point"?nearestPoint(x,y):null;if(state.mode==="point"&&!state.dragPoint){const p=sourceFromScreen(x,y);if(p.x>=0&&p.y>=0&&p.x<=state.videoWidth&&p.y<=state.videoHeight){if(state.court.length<8){state.court.push(p);}else{const missing=nextMissingPlayer();if(missing>=0){state.players[missing]=p;}}updatePrompts();draw();}}});
  canvas.addEventListener("pointermove",e=>{if(!state.dragging)return;const r=canvas.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;if(state.dragPoint){const p=sourceFromScreen(x,y),arr=state.dragPoint.type==="court"?state.court:state.players;arr[state.dragPoint.index]={x:Math.max(0,Math.min(state.videoWidth,p.x)),y:Math.max(0,Math.min(state.videoHeight,p.y))};}else if(state.mode==="pan"){state.panX+=x-state.lastX;state.panY+=y-state.lastY;}state.lastX=x;state.lastY=y;draw();});
  canvas.addEventListener("pointerup",()=>{state.dragging=false;state.dragPoint=null;updatePrompts();});canvas.addEventListener("pointercancel",()=>{state.dragging=false;state.dragPoint=null;});
  $("pointMode").addEventListener("click",()=>{state.mode="point";$("pointMode").classList.add("active");$("panMode").classList.remove("active");canvas.style.cursor="crosshair";});
  $("panMode").addEventListener("click",()=>{state.mode="pan";$("panMode").classList.add("active");$("pointMode").classList.remove("active");canvas.style.cursor="grab";});
  $("fitView").addEventListener("click",()=>{state.zoom=1;state.panX=state.panY=0;draw();});
  $("undoCourt").addEventListener("click",()=>{state.court.pop();state.courtConfirmed=false;state.players=[null,null,null,null];state.playersConfirmed=false;updatePrompts();draw();});
  $("resetCourt").addEventListener("click",()=>{state.court=[];state.players=[null,null,null,null];state.autoBoxes=[];state.courtConfirmed=false;state.playersConfirmed=false;state.setupMode="manual";state.setupSummary=T.manualGuide;state.setupActions=[];updatePrompts();draw();});
  $("undoPlayer").addEventListener("click",()=>{for(let i=3;i>=0;i--){if(state.players[i]){state.players[i]=null;break;}}state.playersConfirmed=false;updatePrompts();draw();});
  $("resetPlayer").addEventListener("click",()=>{state.players=[null,null,null,null];state.autoBoxes=[];state.playersConfirmed=false;state.setupMode="manual";state.setupSummary=T.manualGuide;state.setupActions=[];updatePrompts();draw();});
  $("confirmCourt").addEventListener("click",()=>updatePrompts());
  $("confirmPlayers").addEventListener("click",()=>updatePrompts());
  $("toStep3").addEventListener("click",()=>setStep(3));

  function enterManualSetup(reason=null){
    state.setupMode="manual";
    state.court=[];
    state.players=[null,null,null,null];
    state.autoBoxes=[];
    state.courtConfirmed=false;
    state.playersConfirmed=false;
    state.setupSummary=reason||T.manualGuide;
    state.setupActions=[];
    renderSetupGuide(state.setupSummary,"manual",[]);
    updatePrompts();
    draw();
  }


  function setSetupBusy(busy,text=T.autoSetupBusy){$("runAutoSetup").disabled=busy;$("setupProgress").classList.toggle("hidden",!busy);if(text)$("setupProgress").querySelector("strong").textContent=text;}
  async function uploadFile(file, forSetup=false){
    if(state.uploadedComplete&&state.jobId)return;
    const init=await api("/api/uploads/init",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({filename:file.name,size:file.size,content_type:file.type})});
    state.jobId=init.job.id;$("jobIdLabel").textContent=`${T.job} ${state.jobId.slice(0,8)}`;
    const chunkSize=init.chunk_size,total=Math.ceil(file.size/chunkSize);
    for(let i=0;i<total;i++){
      const blob=file.slice(i*chunkSize,Math.min(file.size,(i+1)*chunkSize));let lastErr;
      for(let attempt=0;attempt<(cfg.CHUNK_RETRIES||3);attempt++){
        try{await api(`/api/uploads/${state.jobId}/chunks/${i}`,{method:"PUT",headers:{"Content-Type":"application/octet-stream"},body:blob});lastErr=null;break;}
        catch(e){lastErr=e;await new Promise(r=>setTimeout(r,700*(attempt+1)));}
      }
      if(lastErr)throw lastErr;
      if(forSetup)setSetupBusy(true,T.copyProgress.replace("{done}",String(i+1)).replace("{total}",String(total)));
      else setProgress((i+1)/total*45,T.uploading,`${i+1}/${total} ${T.chunks} · ${formatBytes(Math.min(file.size,(i+1)*chunkSize))}`);
    }
    await api(`/api/uploads/${state.jobId}/complete`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({total_chunks:total})});
    state.uploadedComplete=true;
    if(!forSetup)setProgress(48,T.uploadComplete,T.sendingSettings);
  }
  async function ensureUploaded(forSetup=false){
    if(state.uploadedComplete&&state.jobId)return;
    if(!state.uploadPromise)state.uploadPromise=uploadFile(state.file,forSetup).finally(()=>{state.uploadPromise=null;});
    await state.uploadPromise;
  }
  $("runAutoSetup").addEventListener("click",async()=>{
    if(!state.file)return;
    setSetupBusy(true);
    try{
      await ensureUploaded(true);
      const body={time_s:Number($("startTime").value)||0,processing_device:$("processingDevice").value||"gpu"};
      const response=await api(`/api/jobs/${state.jobId}/auto-setup`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
      const result=response.auto_setup;
      state.setupMode=result.mode||"semi_auto";
      state.court=Array.isArray(result.court.points)?result.court.points.filter(Boolean):[];
      const rawPlayers=Array.isArray(result.players.points)?result.players.points:[];
      state.players=[0,1,2,3].map(i=>rawPlayers[i]||null);
      state.autoBoxes=Array.isArray(result.players.boxes)?result.players.boxes.filter(b=>!b.recommended):[];
      if(state.setupMode==="manual"){
        state.court=[];state.players=[null,null,null,null];state.autoBoxes=[];
      }
      syncAutoVerification();
      renderSetupGuide(result.summary,result.mode,result.required_actions||[]);updatePrompts();draw();
    }catch(e){enterManualSetup(`${T.manualFallback} ${e.message}`);}
    finally{setSetupBusy(false);}
  });

  function buildPlayers(){ $("playersForm").innerHTML=playerDefaults.map(([label])=>`<div class="player-row"><span class="player-letter">${label}</span><input id="name${label}" value="Player ${label}" aria-label="${T.playerName} ${label}"><div class="dupr-wrap"><input id="dupr${label}" type="number" min="2" max="8" step="0.001" placeholder="${T.noDupr}" aria-label="${T.playerDupr} ${label}"></div></div>`).join(""); }
  buildPlayers();
  function configuration(){
    const players=playerDefaults.map(([label])=>({label,name:$("name"+label).value.trim()||`Player ${label}`,dupr:$("dupr"+label).value?Number($("dupr"+label).value):null}));
    return {court_points:state.court,player_points:state.players,players,analysis_mode:$("analysisMode").value,processing_device:$("processingDevice").value,enable_classical_ball_fallback:true,ball_profile_id:"franklin_x40_outdoor",person_stride:Number($("personStride").value),lens_mode:$("lensMode").value,enable_audio_onset:$("audioOnset").checked,analysis_start_s:Number($("startTime").value)||0,game_target_points:Number($("targetPoints").value),initial_server_label:$("initialServer").value||null,first_server_side:$("serverSide").value||null,final_score_near:$("scoreNear").value?Number($("scoreNear").value):null,final_score_far:$("scoreFar").value?Number($("scoreFar").value):null};
  }
  function setProgress(p,title,msg){$("progressBar").style.width=`${Math.max(0,Math.min(100,p))}%`;$("statusPercent").textContent=`${Math.round(p)}%`;$("statusTitle").textContent=title;$("statusMessage").textContent=msg;}
  async function pollJob(){
    while(true){const data=await api(`/api/jobs/${state.jobId}`),job=data.job;const runtime=job.analysis_device||(job.analysis_summary&&job.analysis_summary.processing_device);if(runtime)renderDeviceStatus(runtime,true);if(job.status==="complete"){setProgress(100,T.analysisComplete,T.reportReady);$("resultCard").classList.remove("hidden");$("reportLink").href=endpoint(`/api/jobs/${state.jobId}/report`);$("jsonLink").href=endpoint(`/api/jobs/${state.jobId}/analysis`);return;}if(job.status==="failed"){throw new Error(job.error||job.message||T.analysisFailed);}const mapped=job.status==="uploading"?job.progress*.48:48+(job.progress||0)*.52;setProgress(mapped,job.status==="queued"?T.queued:T.analyzing,job.message||T.processing);await new Promise(r=>setTimeout(r,cfg.POLL_INTERVAL_MS||1800));}
  }
  $("startAnalysis").addEventListener("click",async()=>{
    syncAutoVerification();if(!state.file||state.court.length!==8||playerCount()!==4)return;
    setStep(4);$("resultCard").classList.add("hidden");$("errorCard").classList.add("hidden");
    try{renderDeviceStatus(state.health&&state.health.preferred_processing,true);setProgress(1,T.preparingCopy,T.copyingLocal);await ensureUploaded(false);await api(`/api/jobs/${state.jobId}/configure`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(configuration())});await api(`/api/jobs/${state.jobId}/start`,{method:"POST"});await pollJob();}
    catch(e){$("errorMessage").textContent=e.message;$("errorCard").classList.remove("hidden");setProgress(0,T.stopped,e.message);}
  });
  $("processingDevice").addEventListener("change",()=>{const selected=$("processingDevice").value;if(selected==="cpu")renderDeviceStatus({summary:T.forceCpu,detail:T.cpuDetail,is_gpu:false},false);else if(state.health)renderDeviceStatus(state.health.preferred_processing||state.health.processing,false);});
  $("retryButton").addEventListener("click",()=>setStep(3));
  updatePrompts();health();
})();
