from __future__ import annotations

import atexit
import json
import os
from pathlib import Path
import socket
import sys
import threading
import time
import urllib.request
import webbrowser

import uvicorn

ROOT = Path(__file__).resolve().parent
PACKAGE_LOCALE = "ko"
PACKAGE_PORT = 8765
PACKAGE_DATA_DIR = "PicklaryVisionLocal_KO"
RUNTIME = ROOT / ".runtime"
RUNTIME.mkdir(parents=True, exist_ok=True)
PID_PATH = RUNTIME / "server.pid"
PORT_PATH = RUNTIME / "server_port.txt"
LOG_PATH = ROOT / "logs" / "local_server.log"


def documents_dir() -> Path:
    home = Path.home()
    docs = home / "Documents"
    return docs if docs.exists() else home


def port_is_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def health_payload(port: int) -> dict | None:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=1.5) as response:
            return json.loads(response.read().decode("utf-8"))
    except Exception:
        return None


def choose_port() -> int:
    preferred = int(os.getenv("PVR_LOCAL_PORT", str(PACKAGE_PORT)))
    running = health_payload(preferred)
    if running and running.get("status") == "ok" and running.get("locale") == PACKAGE_LOCALE:
        webbrowser.open(f"http://127.0.0.1:{preferred}/?lang={PACKAGE_LOCALE}")
        print(f"Picklary {PACKAGE_LOCALE.upper()} is already running: http://127.0.0.1:{preferred}")
        raise SystemExit(0)
    # A different language edition may already occupy the default port. Never open it.
    for port in range(preferred, preferred + 30):
        if port_is_free(port):
            return port
    raise RuntimeError(f"No local port is available in the range {preferred}-{preferred + 29}.")


def configure_environment() -> Path:
    data_root = documents_dir() / PACKAGE_DATA_DIR / "jobs"
    data_root.mkdir(parents=True, exist_ok=True)
    os.environ["PVR_LOCALE"] = PACKAGE_LOCALE
    os.environ["PVR_PACKAGE_LOCALE"] = PACKAGE_LOCALE
    os.environ["PVR_DATA_ROOT"] = str(data_root)
    os.environ.setdefault("PVR_JOB_TTL_HOURS", "0")
    os.environ.setdefault("PVR_MAX_UPLOAD_BYTES", str(8 * 1024 * 1024 * 1024))
    os.environ.setdefault("PVR_ANALYSIS_WORKERS", "1")
    os.environ.setdefault("PVR_CORS_ORIGINS", "http://127.0.0.1,http://localhost")
    os.environ.setdefault("PVR_DEPLOYMENT_MODE", "local")
    os.environ.setdefault("PVR_DEFAULT_ANALYSIS_MODE", "full")
    os.environ.setdefault("PVR_DEFAULT_PROCESSING_DEVICE", "gpu")
    os.environ.setdefault("PVR_ALLOW_CUDA", "0")
    return data_root


def cleanup() -> None:
    try:
        PID_PATH.unlink(missing_ok=True)
        PORT_PATH.unlink(missing_ok=True)
    except OSError:
        pass


def main() -> int:
    data_root = configure_environment()
    model = ROOT / "models" / "yolox_nano.onnx"
    if not model.exists() or model.stat().st_size < 1_000_000:
        print("[WARNING] Person detection model is missing.")
        print("Run DOWNLOAD_PERSON_MODEL.cmd first.")
        print(f"Required file: {model}")
    port = choose_port()
    PID_PATH.write_text(str(os.getpid()), encoding="ascii")
    PORT_PATH.write_text(str(port), encoding="ascii")
    atexit.register(cleanup)

    url = f"http://127.0.0.1:{port}/?lang={PACKAGE_LOCALE}"

    def open_browser_when_ready() -> None:
        for _ in range(90):
            payload = health_payload(port)
            if payload and payload.get("status") == "ok" and payload.get("locale") == PACKAGE_LOCALE:
                webbrowser.open(url)
                return
            time.sleep(0.5)
        print(f"If the browser does not open automatically, visit: {url}")

    threading.Thread(target=open_browser_when_ready, daemon=True).start()
    print("=" * 66)
    print(f"Picklary Vision Rating Local v0.2.1 [{PACKAGE_LOCALE.upper()}]")
    print(f"Address    : {url}")
    print(f"Local data: {data_root}")
    print("Stop       : press Ctrl+C here or run STOP_LOCAL.cmd")
    print("Videos are processed only on this computer.")
    print("=" * 66)

    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    config = uvicorn.Config(
        "backend.app.main:app",
        host="127.0.0.1",
        port=port,
        log_level="info",
        access_log=False,
    )
    server = uvicorn.Server(config)
    try:
        server.run()
        return 0
    except KeyboardInterrupt:
        return 0
    finally:
        cleanup()


if __name__ == "__main__":
    raise SystemExit(main())
