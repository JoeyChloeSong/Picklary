필수 사람 모델:
  yolox_nano.onnx
  Download_Person_Model.bat로 받을 수 있습니다.

선택 공 모델:
  tracknet_pickleball.onnx
  검증된 Picklary 전용 모델이 있을 때만 전체 샷/속도 분석이 활성화됩니다.
