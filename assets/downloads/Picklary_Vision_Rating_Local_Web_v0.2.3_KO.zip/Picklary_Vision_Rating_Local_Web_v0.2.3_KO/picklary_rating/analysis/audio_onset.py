from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import subprocess
import tempfile
import wave
import os
import shutil

import numpy as np
from scipy.signal import find_peaks, medfilt


@dataclass(slots=True)
class AudioOnsetDiagnostics:
    method: str = "spectral_flux_adaptive_v2"
    sample_rate_hz: int = 8000
    hop_s: float = 0.01
    threshold_quantile: float = 0.99
    threshold_value: float | None = None
    candidate_count: int = 0
    median_gap_s: float | None = None
    gaps_over_2s: int = 0
    gaps_over_3s: int = 0
    duration_s: float = 0.0
    error: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


def _find_ffmpeg() -> str | None:
    """Resolve FFmpeg without requiring the user to edit PATH.

    Local web builds include imageio-ffmpeg, but older installations may also have
    ffmpeg.exe in Downloads. The resolver intentionally checks both.
    """
    explicit = os.environ.get("PICKLARY_FFMPEG") or os.environ.get("FFMPEG_BINARY")
    candidates: list[str] = []
    if explicit:
        candidates.append(explicit)
    found = shutil.which("ffmpeg")
    if found:
        candidates.append(found)
    try:
        import imageio_ffmpeg  # type: ignore
        candidates.append(imageio_ffmpeg.get_ffmpeg_exe())
    except Exception:
        pass
    home = Path.home()
    candidates.extend([
        str(home / "Downloads" / "ffmpeg.exe"),
        str(home / "Downloads" / "ffmpeg" / "bin" / "ffmpeg.exe"),
        str(Path.cwd() / "bin" / "ffmpeg.exe"),
    ])
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return str(Path(candidate))
    return None


def _extract_pcm(video_path: str | Path, sample_rate: int = 8000) -> tuple[np.ndarray, int, str | None]:
    """Extract mono PCM using a bundled or locally discovered FFmpeg."""
    ffmpeg = _find_ffmpeg()
    if not ffmpeg:
        return np.empty(0, dtype=np.float32), sample_rate, "FFmpeg was not found (bundled imageio-ffmpeg unavailable)"
    with tempfile.TemporaryDirectory() as td:
        wav_path = Path(td) / "audio.wav"
        command = [
            ffmpeg, "-y", "-i", str(video_path), "-vn", "-ac", "1", "-ar", str(sample_rate),
            "-acodec", "pcm_s16le", str(wav_path),
        ]
        try:
            result = subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=180)
        except FileNotFoundError:
            return np.empty(0, dtype=np.float32), sample_rate, "FFmpeg was not found"
        except subprocess.TimeoutExpired:
            return np.empty(0, dtype=np.float32), sample_rate, "FFmpeg audio extraction timed out"
        if result.returncode != 0 or not wav_path.exists():
            tail = result.stderr.decode("utf-8", errors="replace")[-500:]
            return np.empty(0, dtype=np.float32), sample_rate, f"FFmpeg audio extraction failed: {tail}"
        try:
            with wave.open(str(wav_path), "rb") as wf:
                rate = wf.getframerate()
                samples = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
        except (wave.Error, OSError) as exc:
            return np.empty(0, dtype=np.float32), sample_rate, f"WAV read failed: {type(exc).__name__}: {exc}"
    return samples, rate, None


def _spectral_flux(samples: np.ndarray, rate: int, hop_s: float = 0.01) -> tuple[np.ndarray, float]:
    """Compute positive high-frequency spectral flux in bounded-memory batches."""
    if samples.size < rate:
        return np.empty(0, dtype=np.float32), hop_s
    # Pre-emphasis suppresses HVAC/voice energy and emphasizes paddle-like transients.
    x = np.concatenate(([samples[0]], samples[1:] - 0.97 * samples[:-1])).astype(np.float32, copy=False)
    window_n = max(64, int(round(0.025 * rate)))
    hop_n = max(1, int(round(hop_s * rate)))
    nfft = 1
    while nfft < window_n:
        nfft *= 2
    window = np.hanning(window_n).astype(np.float32)
    starts = np.arange(0, len(x) - window_n, hop_n, dtype=np.int64)
    flux = np.zeros(len(starts), dtype=np.float32)
    frequencies = np.fft.rfftfreq(nfft, 1.0 / rate)
    band = (frequencies >= 1000.0) & (frequencies <= min(3800.0, rate / 2 - 20.0))
    previous: np.ndarray | None = None
    batch_size = 3000
    for offset in range(0, len(starts), batch_size):
        subset = starts[offset:offset + batch_size]
        frames = np.stack([x[s:s + window_n] for s in subset], axis=0) * window
        spectrum = np.log1p(np.abs(np.fft.rfft(frames, nfft, axis=1)) * 100.0).astype(np.float32)
        selected = spectrum[:, band]
        if previous is None:
            difference = np.diff(selected, axis=0, prepend=selected[:1])
        else:
            difference = np.diff(np.vstack([previous[None, :], selected]), axis=0)
        flux[offset:offset + len(subset)] = np.maximum(difference, 0.0).sum(axis=1)
        previous = selected[-1]
    return flux, hop_n / rate


def detect_audio_onsets_with_diagnostics(
    video_path: str | Path,
    threshold_z: float = 5.0,
    min_gap_s: float = 0.09,
    threshold_quantile: float | None = None,
) -> tuple[list[float], dict]:
    """Detect sharp audio transients using adaptive spectral flux.

    These are *candidate paddle-like transients*, not automatically verified
    pickleball shots. The vision event layer must still confirm them.

    The v0.5 G1 implementation used log-energy differences whose MAD could be
    effectively zero, causing one onset every 0.10 seconds. This implementation
    uses a local spectral-flux baseline plus a percentile floor so the threshold
    cannot collapse.
    """
    diagnostics = AudioOnsetDiagnostics()
    samples, rate, error = _extract_pcm(video_path, diagnostics.sample_rate_hz)
    diagnostics.sample_rate_hz = rate
    diagnostics.duration_s = float(len(samples) / rate) if rate else 0.0
    if error:
        diagnostics.error = error
        return [], diagnostics.to_dict()
    flux, hop_s = _spectral_flux(samples, rate, diagnostics.hop_s)
    diagnostics.hop_s = hop_s
    if flux.size < 10:
        diagnostics.error = "Audio was too short for onset analysis"
        return [], diagnostics.to_dict()

    # A 2.01-second median baseline follows slow ambient changes without
    # absorbing brief paddle impacts.
    kernel = max(3, int(round(2.01 / hop_s)))
    if kernel % 2 == 0:
        kernel += 1
    local_baseline = medfilt(flux, kernel_size=kernel)
    residual = np.maximum(0.0, flux - local_baseline)
    median = float(np.median(residual))
    mad = float(np.median(np.abs(residual - median)) + 1e-9)

    if threshold_quantile is None:
        # Preserve the existing threshold_z UI while mapping it to a stable
        # percentile floor. z=5 -> q=0.990 for the current default.
        threshold_quantile = float(np.clip(0.965 + 0.005 * threshold_z, 0.97, 0.997))
    diagnostics.threshold_quantile = threshold_quantile
    robust_threshold = median + max(1.0, threshold_z) * 1.4826 * mad
    percentile_threshold = float(np.quantile(residual, threshold_quantile))
    threshold = max(robust_threshold, percentile_threshold)
    diagnostics.threshold_value = float(threshold)

    minimum_distance = max(1, int(round(min_gap_s / hop_s)))
    peaks, properties = find_peaks(
        residual,
        height=threshold,
        distance=minimum_distance,
        prominence=max(float(threshold) * 0.12, 1e-6),
    )
    times = (peaks.astype(np.float64) * hop_s).tolist()
    diagnostics.candidate_count = len(times)
    if len(times) > 1:
        gaps = np.diff(times)
        diagnostics.median_gap_s = float(np.median(gaps))
        diagnostics.gaps_over_2s = int(np.sum(gaps > 2.0))
        diagnostics.gaps_over_3s = int(np.sum(gaps > 3.0))
    return [float(t) for t in times], diagnostics.to_dict()


def detect_audio_onsets(video_path: str | Path, threshold_z: float = 5.0, min_gap_s: float = 0.09) -> list[float]:
    onsets, _ = detect_audio_onsets_with_diagnostics(video_path, threshold_z, min_gap_s)
    return onsets
