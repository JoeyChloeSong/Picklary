from __future__ import annotations

from bisect import bisect_left
from collections import defaultdict
from dataclasses import dataclass
import math
from statistics import median
from typing import Iterable

import numpy as np

from picklary_rating.analysis.court import CourtCalibration
from picklary_rating.models import BallObservation, PlayerObservation, Point2D, Rally, ShotEvent


@dataclass(slots=True)
class ProxyDiagnostics:
    input_onsets: int = 0
    motion_scored_onsets: int = 0
    accepted_onsets: int = 0
    rally_count: int = 0
    assigned_shots: int = 0
    ball_supported_shots: int = 0
    activity_threshold: float = 0.0
    completed_trajectories: int = 0
    visual_projected_endpoints: int = 0
    receiver_proxy_endpoints: int = 0
    inferred_speeds: int = 0
    method: str = "franklin_x40_audio_motion_hybrid_v2_trajectory_completion"

    def to_dict(self) -> dict[str, int | float | str]:
        return {
            "method": self.method,
            "input_onsets": self.input_onsets,
            "motion_scored_onsets": self.motion_scored_onsets,
            "accepted_onsets": self.accepted_onsets,
            "rally_count": self.rally_count,
            "assigned_shots": self.assigned_shots,
            "ball_supported_shots": self.ball_supported_shots,
            "activity_threshold": round(self.activity_threshold, 4),
            "completed_trajectories": self.completed_trajectories,
            "visual_projected_endpoints": self.visual_projected_endpoints,
            "receiver_proxy_endpoints": self.receiver_proxy_endpoints,
            "inferred_speeds": self.inferred_speeds,
        }


def _clip(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def _distance(a: Point2D, b: Point2D) -> float:
    return math.hypot(a.x - b.x, a.y - b.y)


def _build_label_index(players: Iterable[PlayerObservation]) -> dict[str, list[PlayerObservation]]:
    output: dict[str, list[PlayerObservation]] = defaultdict(list)
    for obs in players:
        if obs.court_position is not None and obs.label in "ABCD":
            output[obs.label].append(obs)
    for values in output.values():
        values.sort(key=lambda x: x.time_s)
    return dict(output)


def _nearest(values: list[PlayerObservation], t: float) -> tuple[PlayerObservation | None, float]:
    if not values:
        return None, float("inf")
    times = [x.time_s for x in values]
    idx = bisect_left(times, t)
    candidates = values[max(0, idx - 2): min(len(values), idx + 3)]
    if not candidates:
        return None, float("inf")
    best = min(candidates, key=lambda x: abs(x.time_s - t))
    return best, abs(best.time_s - t)


def _activity(values: list[PlayerObservation], t: float) -> tuple[float, PlayerObservation | None]:
    """Return a contact-proxy activity score around an audio transient."""
    if len(values) < 3:
        return 0.0, None
    times = [x.time_s for x in values]
    idx = bisect_left(times, t)
    lo = max(0, idx - 4)
    hi = min(len(values), idx + 5)
    window = values[lo:hi]
    nearest, delta = _nearest(values, t)
    if nearest is None or delta > 0.40:
        return 0.0, nearest
    speeds: list[float] = []
    image_speeds: list[float] = []
    for a, b in zip(window, window[1:]):
        dt = b.time_s - a.time_s
        if dt <= 0 or dt > 0.35 or a.court_position is None or b.court_position is None:
            continue
        speeds.append(_distance(a.court_position, b.court_position) / dt)
        image_speeds.append(_distance(a.image_center, b.image_center) / dt)
    if not speeds:
        return 0.0, nearest
    speed_med = float(median(speeds))
    speed_peak = float(max(speeds))
    image_med = float(median(image_speeds)) if image_speeds else 0.0
    acceleration = 0.0
    if len(speeds) >= 2:
        acceleration = max(abs(b - a) for a, b in zip(speeds, speeds[1:]))
    identity = max(0.0, min(1.0, float(nearest.identity_confidence)))
    timing = math.exp(-delta / 0.16)
    score = (
        min(1.0, speed_med / 5.0) * 0.28
        + min(1.0, speed_peak / 9.0) * 0.22
        + min(1.0, acceleration / 18.0) * 0.24
        + min(1.0, image_med / 450.0) * 0.10
        + identity * 0.10
        + timing * 0.06
    )
    return float(max(0.0, min(1.0, score))), nearest


def _nearest_ball(balls: list[BallObservation], t: float, window_s: float = 0.24) -> BallObservation | None:
    if not balls:
        return None
    times = [x.time_s for x in balls]
    idx = bisect_left(times, t)
    candidates = balls[max(0, idx - 4): min(len(balls), idx + 5)]
    candidates = [x for x in candidates if abs(x.time_s - t) <= window_s]
    return min(candidates, key=lambda x: abs(x.time_s - t)) if candidates else None


def _zone_shot_type(index: int, obs: PlayerObservation | None, calibration: CourtCalibration) -> str:
    if index == 1:
        return "serve"
    if index == 2:
        return "return"
    if index == 3:
        if obs and obs.court_position:
            distance_to_net = abs(obs.court_position.y - calibration.net_y)
            return "third_drop" if distance_to_net <= 14.0 else "third_drive"
        return "third_drive"
    if obs is None or obs.court_position is None:
        return "unknown"
    zone = calibration.zone(obs.court_position)
    if zone == "kitchen":
        return "dink" if index % 3 else "volley"
    if zone == "transition":
        return "reset" if index % 2 else "drive"
    return "drive" if index % 4 else "drop"


def _contact_position(obs: PlayerObservation | None, calibration: CourtCalibration) -> Point2D | None:
    if obs is None or obs.court_position is None:
        return None
    p = obs.court_position
    # Contact is usually slightly toward the net from the detected foot point.
    y = p.y - 0.9 if p.y >= calibration.net_y else p.y + 0.9
    return Point2D(_clip(p.x, 0.0, calibration.width_ft), _clip(y, 0.0, calibration.length_ft))


def _project_ball(ball: BallObservation, calibration: CourtCalibration) -> Point2D | None:
    try:
        p = ball.court_position or calibration.image_to_ground(ball.image_position)
    except Exception:
        return None
    # Allow a small margin because an airborne point projected onto the ground can
    # fall just outside the court. Large excursions are rejected.
    if not (-3.0 <= p.x <= calibration.width_ft + 3.0 and -4.0 <= p.y <= calibration.length_ft + 4.0):
        return None
    return Point2D(_clip(float(p.x), 0.0, calibration.width_ft), _clip(float(p.y), 0.0, calibration.length_ft))


def _visual_points_between(
    balls: list[BallObservation],
    start_s: float,
    end_s: float,
    calibration: CourtCalibration,
) -> list[tuple[float, Point2D, float, bool]]:
    if not balls or end_s <= start_s:
        return []
    times = [x.time_s for x in balls]
    lo = bisect_left(times, start_s + 0.03)
    hi = bisect_left(times, end_s - 0.02)
    output: list[tuple[float, Point2D, float, bool]] = []
    for ball in balls[lo:hi]:
        p = _project_ball(ball, calibration)
        if p is None:
            continue
        is_anchor = ball.court_position is not None and ball.court_position_source == "bounce_anchor"
        output.append((ball.time_s, p, float(ball.confidence), is_anchor))
    return output


def _target_side(start: Point2D | None, calibration: CourtCalibration) -> str:
    if start is None:
        return "far"
    return "far" if start.y >= calibration.net_y else "near"


def _receiver_proxy_endpoint(
    start: Point2D | None,
    receiver: PlayerObservation | None,
    shot_type: str,
    interval_s: float,
    calibration: CourtCalibration,
) -> Point2D | None:
    if start is None:
        return None
    target = _target_side(start, calibration)
    sign_to_net = 1.0 if target == "far" else -1.0
    baseline_y = 0.0 if target == "far" else calibration.length_ft

    if shot_type in {"third_drop", "drop", "dink", "reset"}:
        # Soft shots are targeted around the opponent NVZ line. The offset varies
        # slightly with contact interval to avoid drawing identical artificial paths.
        line_y = calibration.net_y - calibration.kitchen_ft if target == "far" else calibration.net_y + calibration.kitchen_ft
        toward_net = 1.0 if target == "far" else -1.0
        soft_offset = _clip(1.0 + (interval_s - 0.65) * 0.8, 0.4, 2.6)
        end_y = line_y + toward_net * soft_offset
        receiver_x = receiver.court_position.x if receiver and receiver.court_position else calibration.width_ft - start.x
        end_x = 0.72 * receiver_x + 0.28 * start.x
        return Point2D(_clip(end_x, 0.6, calibration.width_ft - 0.6), _clip(end_y, 0.0, calibration.length_ft))

    if receiver is not None and receiver.court_position is not None:
        rp = receiver.court_position
        base_offset = {
            "serve": 2.5,
            "return": 2.2,
            "third_drive": 1.8,
            "drive": 1.4,
            "speedup": 1.0,
            "volley": 1.0,
            "overhead_smash": 1.0,
        }.get(shot_type, 1.6)
        timing_adjustment = _clip((interval_s - 0.72) * 2.8, -0.7, 3.8)
        lateral_adjustment = min(1.4, abs(rp.x - start.x) * 0.07)
        offset = base_offset + timing_adjustment + lateral_adjustment
        end_y = rp.y + sign_to_net * offset
        end_x = 0.80 * rp.x + 0.20 * start.x
    else:
        typical_depth = {
            "serve": 6.5,
            "return": 8.0,
            "third_drive": 9.5,
            "drive": 10.5,
            "speedup": 12.0,
            "volley": 11.0,
            "overhead_smash": 9.0,
        }.get(shot_type, 10.0)
        end_y = baseline_y + typical_depth if target == "far" else baseline_y - typical_depth
        end_x = calibration.width_ft - start.x

    # Serves must land in the opposite service box. This is a geometric constraint,
    # not a claim about the exact bounce point.
    if shot_type == "serve":
        half = calibration.width_ft / 2.0
        if start.x < half:
            end_x = _clip(end_x, half + 0.35, calibration.width_ft - 0.45)
        else:
            end_x = _clip(end_x, 0.45, half - 0.35)
        if target == "far":
            end_y = _clip(end_y, 0.5, calibration.net_y - calibration.kitchen_ft - 0.35)
        else:
            end_y = _clip(end_y, calibration.net_y + calibration.kitchen_ft + 0.35, calibration.length_ft - 0.5)
    else:
        end_x = _clip(end_x, 0.45, calibration.width_ft - 0.45)
        end_y = _clip(end_y, 0.3, calibration.length_ft - 0.3)
    return Point2D(float(end_x), float(end_y))


def _infer_endpoint(
    start: Point2D | None,
    receiver: PlayerObservation | None,
    shot_type: str,
    interval_s: float,
    visual_points: list[tuple[float, Point2D, float, bool]],
    calibration: CourtCalibration,
) -> tuple[Point2D | None, str]:
    proxy = _receiver_proxy_endpoint(start, receiver, shot_type, interval_s, calibration)
    if start is None:
        return proxy, "receiver_proxy" if proxy else "missing"
    target = _target_side(start, calibration)
    candidates = []
    for _, p, confidence, is_anchor in visual_points:
        on_target_side = p.y < calibration.net_y if target == "far" else p.y >= calibration.net_y
        if not on_target_side:
            continue
        if proxy is not None and _distance(p, proxy) > 11.0 and not is_anchor:
            continue
        score = confidence + (0.65 if is_anchor else 0.0)
        if proxy is not None:
            score += max(0.0, 0.45 - _distance(p, proxy) / 24.0)
        candidates.append((score, p, is_anchor))
    if candidates:
        _, visual, is_anchor = max(candidates, key=lambda item: item[0])
        if is_anchor or proxy is None:
            return visual, "visual_anchor" if is_anchor else "visual_projection"
        # Airborne ground projections are noisy. Blend them with the receiver/role
        # geometry rather than trusting a single projected pixel.
        blended = Point2D(0.42 * visual.x + 0.58 * proxy.x, 0.42 * visual.y + 0.58 * proxy.y)
        return blended, "visual_projection_blended"
    return proxy, "receiver_proxy" if proxy else "missing"


def _estimate_speed_mph(start: Point2D | None, end: Point2D | None, interval_s: float, shot_type: str) -> float | None:
    if start is None or end is None or not (0.28 <= interval_s <= 2.8):
        return None
    distance_ft = _distance(start, end)
    if distance_ft < 2.0:
        return None
    # Contact-to-contact time includes the bounce and receiver reaction. Estimate the
    # airborne fraction by shot family, then report average horizontal flight speed.
    flight_fraction = {
        "serve": 0.58,
        "return": 0.62,
        "third_drive": 0.67,
        "drive": 0.68,
        "speedup": 0.74,
        "volley": 0.74,
        "overhead_smash": 0.66,
        "third_drop": 0.79,
        "drop": 0.80,
        "dink": 0.84,
        "reset": 0.84,
    }.get(shot_type, 0.72)
    speed = distance_ft / max(0.20, interval_s * flight_fraction) * 0.681818
    bounds = {
        "serve": (18.0, 65.0),
        "return": (12.0, 60.0),
        "third_drive": (14.0, 62.0),
        "drive": (12.0, 65.0),
        "speedup": (12.0, 65.0),
        "volley": (8.0, 58.0),
        "overhead_smash": (18.0, 65.0),
        "third_drop": (6.0, 40.0),
        "drop": (5.0, 38.0),
        "dink": (4.0, 28.0),
        "reset": (4.0, 30.0),
    }.get(shot_type, (5.0, 65.0))
    return round(_clip(speed, bounds[0], bounds[1]), 2)


def build_audio_motion_proxy_rallies(
    audio_onsets_s: list[float],
    players: list[PlayerObservation],
    balls: list[BallObservation],
    calibration: CourtCalibration,
    *,
    initial_server_label: str | None = None,
    rally_gap_s: float = 2.15,
    min_shot_gap_s: float = 0.20,
) -> tuple[list[Rally], dict[str, int | float | str]]:
    """Build shot sequences when continuous Franklin X-40 tracks are sparse.

    The v2 completion stage reconstructs a low-confidence horizontal trajectory from
    the hitter contact, visual ball candidates, the next receiver position, court
    geometry and contact interval. These values are explicitly tagged as estimates;
    they are not equivalent to a continuously tracked TrackNet trajectory.
    """
    diag = ProxyDiagnostics(input_onsets=len(audio_onsets_s))
    by_label = _build_label_index(players)
    balls = sorted(balls, key=lambda b: b.time_s)
    if not audio_onsets_s or not by_label:
        return [], diag.to_dict()

    scored: list[dict] = []
    for t in sorted(audio_onsets_s):
        activities: dict[str, float] = {}
        nearest_obs: dict[str, PlayerObservation | None] = {}
        for label in "ABCD":
            score, obs = _activity(by_label.get(label, []), t)
            activities[label] = score
            nearest_obs[label] = obs
        max_activity = max(activities.values(), default=0.0)
        ball = _nearest_ball(balls, t)
        evidence = max_activity + (0.22 if ball is not None else 0.0)
        scored.append({"time": float(t), "activities": activities, "obs": nearest_obs, "ball": ball, "evidence": evidence})
    diag.motion_scored_onsets = len(scored)
    positive = [x["evidence"] for x in scored if x["evidence"] > 0]
    if not positive:
        return [], diag.to_dict()
    threshold = float(np.quantile(np.asarray(positive, float), 0.25))
    diag.activity_threshold = threshold
    filtered = [x for x in scored if x["evidence"] >= max(0.12, threshold)]

    deduped: list[dict] = []
    for item in filtered:
        if deduped and item["time"] - deduped[-1]["time"] < min_shot_gap_s:
            if item["evidence"] > deduped[-1]["evidence"]:
                deduped[-1] = item
            continue
        deduped.append(item)
    diag.accepted_onsets = len(deduped)
    if not deduped:
        return [], diag.to_dict()

    groups: list[list[dict]] = [[]]
    for item in deduped:
        if groups[-1] and item["time"] - groups[-1][-1]["time"] > rally_gap_s:
            groups.append([])
        groups[-1].append(item)
    groups = [g for g in groups if len(g) >= 2]

    teams = {"A": "near", "B": "near", "C": "far", "D": "far"}
    rallies: list[Rally] = []
    previous_first: str | None = None
    for rally_index, group in enumerate(groups, 1):
        assigned: list[dict] = []
        last_team: str | None = None
        for shot_index, item in enumerate(group, 1):
            activities: dict[str, float] = item["activities"]
            if shot_index == 1 and rally_index == 1 and initial_server_label in teams:
                chosen = str(initial_server_label)
            else:
                expected_team = None if last_team is None else ("far" if last_team == "near" else "near")
                candidates = [label for label in "ABCD" if expected_team is None or teams[label] == expected_team]
                chosen = max(candidates, key=lambda label: activities.get(label, 0.0))
                if shot_index == 1 and chosen == previous_first:
                    alternatives = [label for label in candidates if label != chosen]
                    if alternatives:
                        alt = max(alternatives, key=lambda label: activities.get(label, 0.0))
                        if activities.get(alt, 0.0) >= activities.get(chosen, 0.0) * 0.85:
                            chosen = alt
            assigned.append({**item, "chosen": chosen, "shot_index": shot_index})
            last_team = teams[chosen]

        shots: list[ShotEvent] = []
        for index, item in enumerate(assigned):
            shot_index = int(item["shot_index"])
            chosen = str(item["chosen"])
            obs = item["obs"].get(chosen)
            start = _contact_position(obs, calibration)
            shot_type = _zone_shot_type(shot_index, obs, calibration)
            next_item = assigned[index + 1] if index + 1 < len(assigned) else None
            next_obs = None
            interval_s = 1.15
            if next_item is not None:
                next_obs = next_item["obs"].get(next_item["chosen"])
                interval_s = max(0.20, float(next_item["time"]) - float(item["time"]))
            visual_points = _visual_points_between(
                balls,
                float(item["time"]),
                float(next_item["time"]) if next_item is not None else float(item["time"]) + min(1.6, rally_gap_s),
                calibration,
            )
            end, endpoint_source = _infer_endpoint(start, next_obs, shot_type, interval_s, visual_points, calibration)
            speed = _estimate_speed_mph(start, end, interval_s, shot_type) if next_item is not None else None
            confidence = min(
                0.82,
                0.34
                + item["activities"].get(chosen, 0.0) * 0.30
                + (0.08 if item["ball"] is not None else 0.0)
                + (0.07 if endpoint_source.startswith("visual") else 0.03 if end is not None else 0.0),
            )
            outcome = "in_play" if next_item is not None else "unknown_tracking_loss"
            stroke_side = "unknown"
            if start is not None and end is not None:
                stroke_side = "crosscourt" if abs(end.x - start.x) >= calibration.width_ft * 0.30 else "middle_or_line"
                diag.completed_trajectories += 1
            if endpoint_source.startswith("visual"):
                diag.visual_projected_endpoints += 1
            elif endpoint_source == "receiver_proxy":
                diag.receiver_proxy_endpoints += 1
            if speed is not None:
                diag.inferred_speeds += 1
            if item["ball"] is not None:
                diag.ball_supported_shots += 1
            shots.append(ShotEvent(
                rally_index=rally_index,
                shot_index=shot_index,
                time_s=float(item["time"]),
                player_label=chosen,
                shot_type=shot_type,
                stroke_side=stroke_side,
                start_position=start,
                end_position=end,
                estimated_speed_mph=speed,
                trajectory_profile=f"franklin-hybrid-estimated:{endpoint_source}",
                outcome=outcome,
                confidence=confidence,
                speed_source="contact_interval_physics_estimate" if speed is not None else "audio_motion_proxy",
                speed_outlier=False,
            ))
        if shots:
            previous_first = shots[0].player_label
            rallies.append(Rally(
                rally_index,
                max(0.0, shots[0].time_s - 0.5),
                shots[-1].time_s + 1.2,
                shots,
                None,
                "audio_motion_proxy",
                [],
            ))
    diag.rally_count = len(rallies)
    diag.assigned_shots = sum(len(r.shots) for r in rallies)
    return rallies, diag.to_dict()
