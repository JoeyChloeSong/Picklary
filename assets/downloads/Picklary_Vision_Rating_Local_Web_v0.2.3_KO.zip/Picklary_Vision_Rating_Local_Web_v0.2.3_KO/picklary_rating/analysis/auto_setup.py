from __future__ import annotations

from dataclasses import asdict, dataclass
from itertools import permutations
from pathlib import Path
from typing import Any
import math
import os

import cv2
import numpy as np

from picklary_rating.analysis.court import CourtCalibration
from picklary_rating.analysis.player_tracker import YoloXOnnxPersonDetector
from picklary_rating.models import Point2D


@dataclass(slots=True)
class AutoSetupAction:
    action_id: str
    target: str
    title: str
    description: str
    required: bool = True


@dataclass(slots=True)
class AutoSetupSection:
    status: str
    confidence: float
    points: list[dict[str, float] | None]
    method: str
    message: str
    needs_confirmation: bool
    boxes: list[dict[str, Any]] | None = None
    recommended: bool = False


def _locale() -> str:
    return "en" if os.getenv("PVR_LOCALE", "ko").lower().startswith("en") else "ko"


def _tr(ko: str, en: str) -> str:
    return en if _locale() == "en" else ko


def _order_quad(points: np.ndarray) -> np.ndarray:
    pts = np.asarray(points, dtype=np.float32).reshape(4, 2)
    by_y = pts[np.argsort(pts[:, 1])]
    top = by_y[:2][np.argsort(by_y[:2, 0])]
    bottom = by_y[2:][np.argsort(by_y[2:, 0])]
    return np.asarray([top[0], top[1], bottom[1], bottom[0]], dtype=np.float32)


def _sample_line_support(mask: np.ndarray, a: np.ndarray, b: np.ndarray, radius: int = 5, samples: int = 100) -> float:
    h, w = mask.shape[:2]
    values: list[float] = []
    for t in np.linspace(0.0, 1.0, samples):
        x = int(round(float(a[0] * (1.0 - t) + b[0] * t)))
        y = int(round(float(a[1] * (1.0 - t) + b[1] * t)))
        x1, x2 = max(0, x - radius), min(w, x + radius + 1)
        y1, y2 = max(0, y - radius), min(h, y + radius + 1)
        if x1 >= x2 or y1 >= y2:
            continue
        values.append(1.0 if np.any(mask[y1:y2, x1:x2] > 0) else 0.0)
    return float(np.mean(values)) if values else 0.0


def _project_template(quad: np.ndarray) -> np.ndarray:
    court = np.asarray(
        [[0, 0], [20, 0], [20, 44], [0, 44], [0, 15], [20, 15], [20, 29], [0, 29]],
        dtype=np.float32,
    )
    H = cv2.getPerspectiveTransform(
        np.asarray([[0, 0], [20, 0], [20, 44], [0, 44]], dtype=np.float32),
        quad.astype(np.float32),
    )
    return cv2.perspectiveTransform(court.reshape(1, -1, 2), H)[0]


def _default_court_quad(width: int, height: int) -> np.ndarray:
    # Conservative broadcast/end-line camera recommendation. It is never marked
    # automatic; it only gives the user draggable starting points instead of a blank frame.
    return np.asarray(
        [
            [width * 0.30, height * 0.18],
            [width * 0.70, height * 0.18],
            [width * 0.93, height * 0.91],
            [width * 0.07, height * 0.91],
        ],
        dtype=np.float32,
    )


def _score_quad(quad: np.ndarray, edge_mask: np.ndarray) -> float:
    h, w = edge_mask.shape[:2]
    area = abs(float(cv2.contourArea(quad.astype(np.float32))))
    area_ratio = area / max(1.0, float(h * w))
    if area_ratio < 0.045 or area_ratio > 0.94 or not cv2.isContourConvex(quad.astype(np.float32)):
        return 0.0
    projected = _project_template(quad)
    line_pairs = [
        (0, 1, 1.45), (1, 2, 1.45), (2, 3, 1.45), (3, 0, 1.45),
        (4, 5, 1.15), (6, 7, 1.15),
    ]
    weighted = 0.0
    total_weight = 0.0
    for i, j, weight in line_pairs:
        weighted += weight * _sample_line_support(edge_mask, projected[i], projected[j])
        total_weight += weight
    canonical = np.asarray([[0, 22], [20, 22], [10, 0], [10, 15], [10, 29], [10, 44]], dtype=np.float32)
    H = cv2.getPerspectiveTransform(
        np.asarray([[0, 0], [20, 0], [20, 44], [0, 44]], dtype=np.float32), quad.astype(np.float32)
    )
    extra = cv2.perspectiveTransform(canonical.reshape(1, -1, 2), H)[0]
    for a, b, weight in [(extra[0], extra[1], 0.75), (extra[2], extra[3], 0.60), (extra[4], extra[5], 0.60)]:
        weighted += weight * _sample_line_support(edge_mask, a, b)
        total_weight += weight
    support = weighted / max(total_weight, 1e-6)
    far_len = float(np.linalg.norm(quad[1] - quad[0]))
    near_len = float(np.linalg.norm(quad[2] - quad[3]))
    perspective = float(np.clip((near_len / max(far_len, 1.0) - 0.65) / 1.8, 0.0, 1.0))
    area_score = min(1.0, max(0.0, (area_ratio - 0.045) / 0.32))
    center = np.mean(quad, axis=0)
    center_score = 1.0 - min(1.0, math.hypot(center[0] - w / 2, center[1] - h * 0.55) / max(w, h))
    return float(np.clip(0.66 * support + 0.15 * area_score + 0.10 * perspective + 0.09 * center_score, 0.0, 1.0))


def _edge_mask(frame: np.ndarray) -> tuple[np.ndarray, float]:
    h0, w0 = frame.shape[:2]
    scale = min(1.0, 1440.0 / max(w0, h0))
    small = cv2.resize(frame, (int(round(w0 * scale)), int(round(h0 * scale)))) if scale < 1 else frame.copy()
    gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
    gray = cv2.createCLAHE(clipLimit=2.4, tileGridSize=(8, 8)).apply(gray)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    canny = cv2.Canny(blur, 32, 112)
    hsv = cv2.cvtColor(small, cv2.COLOR_BGR2HSV)
    white = cv2.inRange(hsv, np.asarray([0, 0, 138], np.uint8), np.asarray([180, 92, 255], np.uint8))
    white = cv2.morphologyEx(white, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    mask = cv2.bitwise_or(canny, white)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8), iterations=2)
    mask = cv2.dilate(mask, np.ones((3, 3), np.uint8), iterations=1)
    return mask, scale


def _court_quad_candidates(frame: np.ndarray) -> tuple[list[tuple[float, np.ndarray, str]], float]:
    mask, scale = _edge_mask(frame)
    h, w = mask.shape[:2]
    candidates: list[tuple[np.ndarray, str]] = []
    contours, _ = cv2.findContours(mask, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    for contour in sorted(contours, key=cv2.contourArea, reverse=True)[:180]:
        area = cv2.contourArea(contour)
        if area < h * w * 0.025:
            continue
        hull = cv2.convexHull(contour)
        peri = cv2.arcLength(hull, True)
        for epsilon in (0.012, 0.020, 0.032, 0.048, 0.070, 0.10):
            approx = cv2.approxPolyDP(hull, epsilon * peri, True)
            if len(approx) == 4:
                candidates.append((_order_quad(approx.reshape(4, 2)), "contour_geometry"))
                break
        rect = cv2.minAreaRect(hull)
        box = cv2.boxPoints(rect)
        candidates.append((_order_quad(box), "contour_rotated_rect"))

    lines = cv2.HoughLinesP(
        mask, 1, np.pi / 360,
        threshold=max(42, int(min(h, w) * 0.055)),
        minLineLength=max(45, int(min(h, w) * 0.10)),
        maxLineGap=max(24, int(min(h, w) * 0.035)),
    )
    if lines is not None:
        segments = lines[:320, 0]
        endpoints = np.asarray([p for line in segments for p in ((line[0], line[1]), (line[2], line[3]))], dtype=np.float32)
        if len(endpoints) >= 8:
            hull = cv2.convexHull(endpoints)
            peri = cv2.arcLength(hull, True)
            for epsilon in (0.022, 0.035, 0.050, 0.075, 0.11, 0.15):
                approx = cv2.approxPolyDP(hull, epsilon * peri, True)
                if len(approx) == 4:
                    candidates.append((_order_quad(approx.reshape(4, 2)), "hough_endpoint_hull"))
                    break
        # Use the widest line extent per horizontal band as another recommendation.
        pts = []
        for x1, y1, x2, y2 in segments:
            length = math.hypot(float(x2 - x1), float(y2 - y1))
            if length < min(h, w) * 0.10:
                continue
            pts.extend([(x1, y1), (x2, y2)])
        if len(pts) >= 8:
            pts_arr = np.asarray(pts, dtype=np.float32)
            top_band = pts_arr[pts_arr[:, 1] <= np.percentile(pts_arr[:, 1], 38)]
            bottom_band = pts_arr[pts_arr[:, 1] >= np.percentile(pts_arr[:, 1], 62)]
            if len(top_band) >= 2 and len(bottom_band) >= 2:
                quad = np.asarray([
                    top_band[np.argmin(top_band[:, 0])], top_band[np.argmax(top_band[:, 0])],
                    bottom_band[np.argmax(bottom_band[:, 0])], bottom_band[np.argmin(bottom_band[:, 0])],
                ], dtype=np.float32)
                candidates.append((_order_quad(quad), "hough_band_extent"))

    # Always score a conservative default, but keep it recommendation-only.
    candidates.append((_default_court_quad(w, h), "standard_geometry_recommendation"))
    scored: list[tuple[float, np.ndarray, str]] = []
    seen: list[np.ndarray] = []
    for quad, method in candidates:
        if any(float(np.mean(np.linalg.norm(quad - old, axis=1))) < min(h, w) * 0.015 for old in seen):
            continue
        seen.append(quad)
        scored.append((_score_quad(quad, mask), quad / scale, method))
    scored.sort(key=lambda item: item[0], reverse=True)
    return scored, scale


def detect_court_frames(frames: list[np.ndarray]) -> AutoSetupSection:
    all_results: list[tuple[float, np.ndarray, str]] = []
    for frame in frames:
        scored, _ = _court_quad_candidates(frame)
        all_results.extend(scored[:5])
    all_results.sort(key=lambda item: item[0], reverse=True)
    h, w = frames[0].shape[:2]
    if not all_results:
        best_score, best_quad, best_method = 0.0, _default_court_quad(w, h), "standard_geometry_recommendation"
    else:
        best_score, best_quad, best_method = all_results[0]

    # Multi-frame consensus: combine geometrically similar strong candidates.
    close = []
    tolerance = max(w, h) * 0.055
    for score, quad, method in all_results[:24]:
        mean_dist = float(np.mean(np.linalg.norm(quad - best_quad, axis=1)))
        if mean_dist <= tolerance and score >= max(0.12, best_score - 0.18):
            close.append((score, quad, method))
    if close:
        weights = np.asarray([max(0.05, item[0]) for item in close], dtype=np.float32)
        stack = np.stack([item[1] for item in close], axis=0)
        consensus = np.average(stack, axis=0, weights=weights)
        spread = float(np.mean(np.linalg.norm(stack - consensus[None, ...], axis=2)))
        stability = float(np.clip(1.0 - spread / max(1.0, tolerance), 0.0, 1.0))
        best_quad = consensus.astype(np.float32)
    else:
        stability = 0.0
    combined = float(np.clip(0.76 * best_score + 0.24 * stability, 0.0, 0.98))
    projected = _project_template(best_quad)
    points = [{"x": float(p[0]), "y": float(p[1])} for p in projected]

    is_default = best_method == "standard_geometry_recommendation" or best_score < 0.13
    manual = is_default or combined < 0.28
    automatic = (not manual) and combined >= 0.60 and len(close) >= 2
    status = "manual" if manual else ("automatic" if automatic else "semi_auto")
    if manual:
        # Do not expose low-quality geometry guesses. A wrong 8-point calibration is
        # more harmful than asking the user to mark the actual intersections.
        points = []
        message = _tr(
            "코트 선을 신뢰할 수 없어 낮은 품질의 추천점을 표시하지 않습니다. 화면에서 실제 코트 교차점 1~8을 순서대로 직접 지정해 주세요.",
            "Court lines could not be detected reliably, so low-quality suggested points are not shown. Mark the actual court intersections 1–8 in order.",
        )
    elif automatic:
        message = _tr(
            "여러 프레임에서 코트 선을 일관되게 찾아 8점을 자동 적용했습니다. 필요하면 점을 드래그해 미세 조정할 수 있습니다.",
            "Court lines were detected consistently across multiple frames and all 8 points were applied automatically. Drag any point if a fine adjustment is needed.",
        )
    else:
        message = _tr(
            "감지된 코트 선을 바탕으로 8개 지점을 배치했습니다. 실제 교차점과 다른 점만 드래그해 수정해 주세요.",
            "Eight points were placed from detected court lines. Drag only points that do not match the actual intersections.",
        )
    return AutoSetupSection(
        status=status,
        confidence=combined,
        points=points,
        method=f"multiframe_{best_method}",
        message=message,
        needs_confirmation=manual,
        recommended=(status == "semi_auto"),
    )


def detect_court(frame: np.ndarray) -> AutoSetupSection:
    # Backward-compatible single-frame entry used by tests and utilities.
    return detect_court_frames([frame])


def _read_frames(video_path: Path, time_s: float) -> tuple[list[np.ndarray], float]:
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(_tr("영상을 열 수 없습니다.", "Could not open the video."))
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 30.0)
    duration = float(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0.0) / max(fps, 1e-6)
    offsets = [-0.45, 0.0, 0.30, 0.60, 0.90, 1.20, 1.55, 1.90, 2.25, 2.60]
    frames: list[np.ndarray] = []
    for offset in offsets:
        t = max(0.0, min(max(0.0, duration - 0.05), time_s + offset))
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000.0)
        ok, frame = cap.read()
        if ok and frame is not None:
            frames.append(frame)
    cap.release()
    if not frames:
        raise RuntimeError(_tr("선수 인식용 프레임을 읽지 못했습니다.", "Could not read frames for player detection."))
    return frames, fps


def _cluster_player_detections(
    detections: list[tuple[float, float, float, tuple[float, float, float, float], str]],
    width: int,
    height: int,
) -> list[dict[str, Any]]:
    clusters: list[dict[str, Any]] = []
    threshold = max(36.0, min(width, height) * 0.085)
    for x, y, confidence, box, source in sorted(detections, key=lambda d: d[2], reverse=True):
        best = None
        best_dist = float("inf")
        for cluster in clusters:
            cx, cy = cluster["sum_x"] / cluster["count"], cluster["sum_y"] / cluster["count"]
            dist = math.hypot(x - cx, y - cy)
            if dist < threshold and dist < best_dist:
                best, best_dist = cluster, dist
        if best is None:
            clusters.append({"sum_x": x, "sum_y": y, "count": 1, "confidence_sum": confidence, "boxes": [box], "sources": {source}})
        else:
            best["sum_x"] += x
            best["sum_y"] += y
            best["count"] += 1
            best["confidence_sum"] += confidence
            best["boxes"].append(box)
            best["sources"].add(source)
    result = []
    for cluster in clusters:
        count = int(cluster["count"])
        boxes = cluster["boxes"]
        result.append({
            "x": float(cluster["sum_x"] / count),
            "y": float(cluster["sum_y"] / count),
            "count": count,
            "confidence": float(cluster["confidence_sum"] / count),
            "box": [float(np.median([b[i] for b in boxes])) for i in range(4)],
            "sources": sorted(cluster["sources"]),
        })
    return sorted(result, key=lambda c: (c["count"], len(c["sources"]), c["confidence"]), reverse=True)


def _court_calibration(court: AutoSetupSection, width: int, height: int) -> tuple[CourtCalibration | None, np.ndarray | None]:
    if len(court.points) != 8:
        return None, None
    try:
        calibration = CourtCalibration(
            [Point2D(float(p["x"]), float(p["y"])) for p in court.points],
            image_size=(width, height),
        )
        polygon = np.asarray([[court.points[i]["x"], court.points[i]["y"]] for i in (0, 1, 2, 3)], dtype=np.float32)
        return calibration, polygon
    except Exception:
        return None, None


def _hog_detections(frames: list[np.ndarray]) -> list[tuple[float, float, float, tuple[float, float, float, float], str]]:
    raw: list[tuple[float, float, float, tuple[float, float, float, float], str]] = []
    try:
        hog = cv2.HOGDescriptor()
        hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
    except Exception:
        return raw
    for frame in frames[::2]:
        h, w = frame.shape[:2]
        scale = min(1.0, 960.0 / max(h, w))
        small = cv2.resize(frame, (int(w * scale), int(h * scale))) if scale < 1 else frame
        rects, weights = hog.detectMultiScale(small, winStride=(8, 8), padding=(8, 8), scale=1.055)
        for (x, y, bw, bh), weight in zip(rects, weights):
            x1, y1, x2, y2 = x / scale, y / scale, (x + bw) / scale, (y + bh) / scale
            conf = float(np.clip(0.20 + float(weight) * 0.10, 0.20, 0.52))
            raw.append(((x1 + x2) / 2.0, y2, conf, (x1, y1, x2, y2), "opencv_hog"))
    return raw


def _motion_detections(frames: list[np.ndarray]) -> list[tuple[float, float, float, tuple[float, float, float, float], str]]:
    if len(frames) < 3:
        return []
    h, w = frames[0].shape[:2]
    scale = min(1.0, 960.0 / max(h, w))
    grays = []
    for frame in frames:
        small = cv2.resize(frame, (int(w * scale), int(h * scale))) if scale < 1 else frame
        grays.append(cv2.GaussianBlur(cv2.cvtColor(small, cv2.COLOR_BGR2GRAY), (5, 5), 0))
    background = np.median(np.stack(grays, axis=0), axis=0).astype(np.uint8)
    union = np.zeros_like(background)
    for gray in grays:
        diff = cv2.absdiff(gray, background)
        _, mask = cv2.threshold(diff, 22, 255, cv2.THRESH_BINARY)
        union = cv2.bitwise_or(union, mask)
    union = cv2.morphologyEx(union, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    union = cv2.morphologyEx(union, cv2.MORPH_CLOSE, np.ones((11, 7), np.uint8), iterations=2)
    contours, _ = cv2.findContours(union, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    raw = []
    area_total = union.shape[0] * union.shape[1]
    for contour in sorted(contours, key=cv2.contourArea, reverse=True)[:24]:
        area = cv2.contourArea(contour)
        if area < area_total * 0.00035 or area > area_total * 0.055:
            continue
        x, y, bw, bh = cv2.boundingRect(contour)
        if bh < max(12, bw * 0.65):
            continue
        x1, y1, x2, y2 = x / scale, y / scale, (x + bw) / scale, (y + bh) / scale
        raw.append(((x1 + x2) / 2.0, y2, 0.22, (x1, y1, x2, y2), "motion"))
    return raw


def _target_image_points(calibration: CourtCalibration | None, court: AutoSetupSection) -> list[dict[str, float]]:
    canonical = [(15.0, 35.0), (5.0, 35.0), (5.0, 9.0), (15.0, 9.0)]
    if calibration is not None:
        result = []
        for x, y in canonical:
            p = calibration.ground_to_image(Point2D(x, y))
            result.append({"x": float(p.x), "y": float(p.y)})
        return result
    if len(court.points) == 8:
        quad = np.asarray([[court.points[i]["x"], court.points[i]["y"]] for i in (0, 1, 2, 3)], dtype=np.float32)
        H = cv2.getPerspectiveTransform(
            np.asarray([[0, 0], [20, 0], [20, 44], [0, 44]], dtype=np.float32), quad
        )
        arr = cv2.perspectiveTransform(np.asarray(canonical, dtype=np.float32).reshape(1, -1, 2), H)[0]
        return [{"x": float(p[0]), "y": float(p[1])} for p in arr]
    return []


def _assign_players(candidates: list[dict[str, Any]], calibration: CourtCalibration | None) -> tuple[list[dict[str, Any] | None], float]:
    targets = [(15.0, 35.0), (5.0, 35.0), (5.0, 9.0), (15.0, 9.0)]
    if calibration is None or not candidates:
        return [None, None, None, None], 0.0
    valid = []
    for c in candidates[:10]:
        try:
            cp = calibration.image_to_court(Point2D(c["x"], c["y"]))
            c = dict(c)
            c["court_x"], c["court_y"] = float(cp.x), float(cp.y)
            if -4 <= c["court_x"] <= 24 and -6 <= c["court_y"] <= 50:
                valid.append(c)
        except Exception:
            continue
    if not valid:
        return [None, None, None, None], 0.0
    best_cost = float("inf")
    best_assignment: list[dict[str, Any] | None] = [None, None, None, None]
    max_take = min(4, len(valid))
    # Try assigning one candidate per target; missing targets are filled later by recommendations.
    for target_indices in permutations(range(4), max_take):
        chosen = valid[:max_take]
        cost = 0.0
        assignment: list[dict[str, Any] | None] = [None, None, None, None]
        for cand, target_index in zip(chosen, target_indices):
            tx, ty = targets[target_index]
            dist = math.hypot((cand["court_x"] - tx) / 20.0, (cand["court_y"] - ty) / 44.0)
            quality_bonus = 0.10 * min(1.0, cand["count"] / 4.0) + 0.08 * cand["confidence"]
            cost += dist - quality_bonus
            assignment[target_index] = cand
        if cost < best_cost:
            best_cost, best_assignment = cost, assignment
    assigned = [c for c in best_assignment if c is not None]
    confidence = float(np.mean([c["confidence"] for c in assigned])) if assigned else 0.0
    return best_assignment, confidence


def detect_players(video_path: Path, time_s: float, court: AutoSetupSection, model_path: Path, requested_device: str = "gpu") -> AutoSetupSection:
    frames, _ = _read_frames(video_path, time_s)
    h, w = frames[0].shape[:2]
    calibration, polygon = _court_calibration(court, w, h)
    raw: list[tuple[float, float, float, tuple[float, float, float, float], str]] = []
    detector_ready = False
    detector_label = ""

    if model_path.exists() and model_path.stat().st_size >= 1_000_000:
        detector = YoloXOnnxPersonDetector(
            model_path,
            requested_device=requested_device,
            confidence=0.14,
            nms_iou=0.42,
            tile_enabled=True,
            tile_overlap=0.16,
        )
        detector_ready = detector.available
        detector_label = detector.device_label if detector.available else (detector.error or "")
        if detector.available:
            for frame in frames:
                for det in detector.detect(frame, calibration):
                    x1, y1, x2, y2 = det.xyxy
                    foot_x, foot_y = (x1 + x2) / 2.0, y2
                    if polygon is not None:
                        distance = cv2.pointPolygonTest(polygon, (float(foot_x), float(foot_y)), True)
                        if distance < -max(24.0, h * 0.045):
                            continue
                    if (x2 - x1) * (y2 - y1) < h * w * 0.00010:
                        continue
                    raw.append((foot_x, foot_y, float(det.confidence), det.xyxy, "yolox"))

    # Secondary local detectors improve the odds when the ONNX model is unavailable,
    # blocked by a network, or misses a distant player.
    if len(raw) < 12:
        raw.extend(_hog_detections(frames))
        raw.extend(_motion_detections(frames))

    filtered = []
    for item in raw:
        x, y, confidence, box, source = item
        if polygon is not None:
            distance = cv2.pointPolygonTest(polygon, (float(x), float(y)), True)
            if distance < -max(28.0, h * 0.055):
                continue
        filtered.append(item)
    clusters = _cluster_player_detections(filtered, w, h)
    # Keep persistent candidates first, but allow one-frame far-court detections.
    candidates = [c for c in clusters if c["count"] >= 2 or c["confidence"] >= 0.30][:10]
    assignment, assigned_conf = _assign_players(candidates, calibration)
    points: list[dict[str, float] | None] = [None, None, None, None]
    boxes: list[dict[str, Any]] = []
    detected_count = 0
    persistence_scores = []
    for index, label in enumerate("ABCD"):
        candidate = assignment[index] if index < len(assignment) else None
        if candidate is None:
            continue
        detected_count += 1
        points[index] = {"x": float(candidate["x"]), "y": float(candidate["y"])}
        persistence_scores.append(min(1.0, candidate["count"] / max(1, len(frames) * 0.55)))
        boxes.append({
            "label": label,
            "box": candidate["box"],
            "confidence": float(candidate["confidence"]),
            "persistence": int(candidate["count"]),
            "source": "+".join(candidate.get("sources", [])),
            "recommended": False,
        })

    persistence = float(np.mean(persistence_scores)) if persistence_scores else 0.0
    coverage = detected_count / 4.0
    confidence = float(np.clip(0.46 * assigned_conf + 0.32 * persistence + 0.22 * coverage, 0.0, 0.98))
    all_yolox = detected_count == 4 and any("yolox" in b.get("source", "") for b in boxes)
    automatic = detected_count == 4 and confidence >= 0.58 and (detector_ready or all_yolox)
    status = "automatic" if automatic else ("semi_auto" if detected_count > 0 else "manual")

    if automatic:
        message = _tr(
            "여러 프레임과 코트 영역을 결합해 선수 A~D를 자동 적용했습니다. 필요하면 주황색 점을 드래그해 수정할 수 있습니다.",
            "Players A–D were applied automatically using multiple frames and the court region. Drag any orange point if an adjustment is needed.",
        )
    elif detected_count:
        missing = 4 - detected_count
        message = _tr(
            f"영상에서 선수 {detected_count}명을 감지했습니다. 정확도가 낮은 예상 선수 위치는 표시하지 않으므로, 남은 {missing}명은 실제 발 중앙을 직접 지정해 주세요.",
            f"Detected {detected_count} players from the video. Low-quality estimated player positions are hidden; mark the actual foot centers for the remaining {missing} players.",
        )
    elif not model_path.exists():
        message = _tr(
            "사람 인식 모델을 사용할 수 없어 예상 선수 위치를 표시하지 않습니다. 선수 A~D의 실제 발 중앙을 순서대로 직접 지정해 주세요.",
            "The person model is unavailable, so estimated player positions are not shown. Mark the actual foot centers of Players A–D in order.",
        )
    else:
        message = _tr(
            "선수 검출 신뢰도가 낮아 잘못된 추천점을 표시하지 않습니다. 선수 A~D의 실제 발 중앙을 순서대로 직접 지정해 주세요.",
            "Player-detection confidence was too low, so inaccurate suggested points are not shown. Mark the actual foot centers of Players A–D in order.",
        )

    method_parts = ["multiframe"]
    if detector_ready:
        method_parts.append("yolox")
    if any("opencv_hog" in b.get("source", "") for b in boxes):
        method_parts.append("hog")
    if any("motion" in b.get("source", "") for b in boxes):
        method_parts.append("motion")
    if detected_count < 4:
        method_parts.append("manual_missing_players")
    if detector_label:
        method_parts.append(detector_label.replace(" ", "_")[:40])
    return AutoSetupSection(
        status=status,
        confidence=confidence,
        points=points,
        method="_".join(method_parts),
        message=message,
        needs_confirmation=(status != "automatic"),
        boxes=boxes,
        recommended=False,
    )


def run_auto_setup(video_path: str | Path, time_s: float, project_root: str | Path, requested_device: str = "gpu") -> dict[str, Any]:
    video_path = Path(video_path)
    project_root = Path(project_root)
    frames, _ = _read_frames(video_path, float(time_s))
    court = detect_court_frames(frames[:6])

    # Player labels depend on a reliable court transform. When court detection falls
    # back to manual, suppress all positional guesses and let the user mark both
    # the court and players from the real frame.
    if court.status == "manual":
        players = AutoSetupSection(
            status="manual",
            confidence=0.0,
            points=[None, None, None, None],
            method="manual_after_court_failure",
            message=_tr(
                "코트 기준점이 없으므로 선수 예상 위치도 표시하지 않습니다. 코트 8점을 먼저 지정한 다음 선수 A~D의 발 중앙을 지정해 주세요.",
                "Player estimates are hidden because no reliable court calibration is available. Mark the 8 court points first, then mark the foot centers of Players A–D.",
            ),
            needs_confirmation=True,
            boxes=[],
            recommended=False,
        )
    else:
        players = detect_players(video_path, float(time_s), court, project_root / "models" / "yolox_nano.onnx", requested_device)

    actions: list[AutoSetupAction] = []
    if court.status == "manual":
        actions.append(AutoSetupAction(
            "mark_court_manually", "court", _tr("코트 8점 직접 지정", "Mark 8 court points manually"),
            _tr(
                "파란 추천점은 표시하지 않습니다. 먼쪽 베이스라인 왼쪽부터 화면 안내 순서대로 실제 선 교차점 8곳을 클릭하세요.",
                "No blue suggested points are shown. Starting at the far baseline-left corner, click the 8 actual line intersections in the on-screen order.",
            ),
        ))
    elif court.status == "semi_auto":
        actions.append(AutoSetupAction(
            "check_detected_court", "court", _tr("감지된 코트 8점 확인", "Check the 8 detected court points"),
            _tr(
                "파란 점은 실제 영상에서 감지된 선을 기반으로 합니다. 잘못된 점만 실제 교차점으로 드래그하세요.",
                "Blue points are based on lines detected in the video. Drag only incorrect points onto the actual intersections.",
            ),
        ))

    if players.status == "manual":
        actions.append(AutoSetupAction(
            "mark_players_manually", "players", _tr("선수 A~D 직접 지정", "Mark Players A–D manually"),
            _tr(
                "주황색 추천점은 표시하지 않습니다. 코트 8점 완료 후 A 가까운쪽 오른쪽부터 D 먼쪽 오른쪽까지 실제 발 중앙을 순서대로 클릭하세요.",
                "No orange suggested points are shown. After the court is complete, click the actual foot centers in order from A (near right) through D (far right).",
            ),
        ))
    elif players.status == "semi_auto":
        missing = sum(1 for p in players.points if p is None)
        actions.append(AutoSetupAction(
            "complete_detected_players", "players", _tr("선수 위치 확인 및 누락 선수 지정", "Check detected players and mark missing players"),
            _tr(
                f"실제 검출된 선수만 표시했습니다. 잘못된 점은 수정하고, 표시되지 않은 {missing}명은 화면 안내 순서대로 발 중앙을 직접 클릭하세요.",
                f"Only actual detections are shown. Correct any wrong point and click the foot centers for the {missing} missing players in the prompted order.",
            ),
        ))

    if not actions:
        mode = "automatic"
        summary = _tr(
            "코트와 선수 4명을 자동 적용했습니다. 설정은 자동으로 확인 완료되었으며 바로 다음 단계로 이동할 수 있습니다.",
            "The court and all 4 players were applied automatically. Setup is auto-verified and you can continue immediately.",
        )
    elif court.status == "manual" or players.status == "manual":
        mode = "manual"
        summary = _tr(
            "자동 인식 신뢰도가 낮아 잘못된 추천점은 표시하지 않습니다. 아래의 큰 안내문을 따라 실제 코트 8점과 선수 발 중앙을 직접 지정해 주세요.",
            "Auto-detection confidence was too low, so inaccurate suggested points are hidden. Follow the prominent instructions below to mark the actual court points and player foot centers.",
        )
    else:
        mode = "semi_auto"
        summary = _tr(
            "영상에서 실제로 감지된 위치만 표시했습니다. 잘못된 점을 수정하고 누락된 항목만 직접 지정하면 자동으로 확인 완료됩니다.",
            "Only positions actually detected in the video are shown. Correct wrong points and mark only missing items; verification completes automatically.",
        )

    return {
        "mode": mode,
        "summary": summary,
        "frame_time_s": float(time_s),
        "court": asdict(court),
        "players": asdict(players),
        "required_actions": [asdict(a) for a in actions],
        "detector_device": players.method,
        "auto_verify": True,
    }

