from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

from picklary_rating.analysis.device import create_ort_session_with_fallback
from picklary_rating.models import Point2D


@dataclass(slots=True)
class BallCandidate:
    position: Point2D
    confidence: float


class TrackNetHeatmapDetector:
    """TrackNet-style ONNX heatmap detector with safe GPU fallback.

    Windows local builds prefer ONNX Runtime DirectML. CUDA is not selected by
    default because missing CUDA/cuDNN DLLs can terminate native inference. If a
    GPU session fails during inference, the same model is reopened on CPU and the
    frame is retried once instead of closing the local server.
    """

    def __init__(
        self,
        model_path: str | Path,
        input_size: tuple[int, int] = (640, 360),
        stack_frames: int = 3,
        requested_device: str = "auto",
    ):
        self.model_path = Path(model_path)
        self.input_size = input_size
        self.stack_frames = stack_frames
        self.frames: list[np.ndarray] = []
        self.requested_device = requested_device
        self.runtime_fallbacks: list[str] = []
        if not self.model_path.exists():
            raise FileNotFoundError(f"TrackNet ONNX model not found: {self.model_path}")

        self.device_backend = "unavailable"
        self.device_label = "unavailable"
        self.net = None
        self.ort_session = None
        self.ort_input_name: str | None = None

        try:
            result = create_ort_session_with_fallback(self.model_path, requested_device)
            self.ort_session = result.session
            self.ort_input_name = result.input_name
            self.device_backend = result.backend_key
            self.device_label = result.device_label
            self.runtime_fallbacks.extend(result.attempts)
        except Exception as ort_exc:
            self.runtime_fallbacks.append(str(ort_exc))
            self.net = cv2.dnn.readNetFromONNX(str(self.model_path))
            self.net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
            self.net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
            self.device_backend = "opencv_cpu"
            self.device_label = f"CPU fallback · ONNX Runtime 초기화 실패: {type(ort_exc).__name__}"

    def _forward(self, blob: np.ndarray) -> np.ndarray:
        if self.ort_session is not None and self.ort_input_name is not None:
            try:
                outputs = self.ort_session.run(None, {self.ort_input_name: blob.astype(np.float32, copy=False)})
                return np.asarray(outputs[0])
            except Exception as exc:
                if self.device_backend != "cpu":
                    self.runtime_fallbacks.append(f"inference failure: {type(exc).__name__}: {exc}")
                    result = create_ort_session_with_fallback(self.model_path, "cpu")
                    self.ort_session = result.session
                    self.ort_input_name = result.input_name
                    self.device_backend = "cpu"
                    self.device_label = f"CPU fallback · GPU 추론 실패: {type(exc).__name__}"
                    outputs = self.ort_session.run(None, {self.ort_input_name: blob.astype(np.float32, copy=False)})
                    return np.asarray(outputs[0])
                raise
        assert self.net is not None
        try:
            self.net.setInput(blob)
            return np.asarray(self.net.forward())
        except cv2.error as exc:
            self.net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
            self.net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
            self.device_backend = "opencv_cpu"
            self.device_label = f"CPU fallback · OpenCV DNN 재시도: {type(exc).__name__}"
            self.net.setInput(blob)
            return np.asarray(self.net.forward())

    def detect(self, frame: np.ndarray) -> list[BallCandidate]:
        resized = cv2.resize(frame, self.input_size)
        self.frames.append(resized)
        self.frames = self.frames[-self.stack_frames :]
        if len(self.frames) < self.stack_frames:
            return []
        stacked = np.concatenate([f.astype(np.float32) / 255.0 for f in self.frames], axis=2)
        blob = np.transpose(stacked, (2, 0, 1))[None, ...]
        heatmap = np.squeeze(self._forward(blob)).astype(np.float32)
        if heatmap.ndim == 3:
            heatmap = heatmap[-1]
        if float(np.nanmin(heatmap)) < 0.0 or float(np.nanmax(heatmap)) > 1.0:
            heatmap = 1.0 / (1.0 + np.exp(-np.clip(heatmap, -30.0, 30.0)))
        heatmap = cv2.GaussianBlur(heatmap, (3, 3), 0)
        candidates: list[BallCandidate] = []
        temp = heatmap.copy()
        for _ in range(3):
            _, peak, _, loc = cv2.minMaxLoc(temp)
            if peak < 0.20:
                break
            x = loc[0] * frame.shape[1] / self.input_size[0]
            y = loc[1] * frame.shape[0] / self.input_size[1]
            candidates.append(BallCandidate(Point2D(float(x), float(y)), float(peak)))
            cv2.circle(temp, loc, 12, 0.0, -1)
        return candidates
