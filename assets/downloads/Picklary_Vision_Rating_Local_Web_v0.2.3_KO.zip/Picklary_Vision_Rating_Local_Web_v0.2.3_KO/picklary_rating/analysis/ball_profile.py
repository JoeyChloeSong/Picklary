from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass(frozen=True, slots=True)
class BallProfile:
    profile_id: str
    display_name: str
    diameter_mm: float
    mass_g: float
    hole_count: int
    construction: str
    primary_color: str
    approved_for_outdoor_play: bool

    @property
    def diameter_ft(self) -> float:
        return self.diameter_mm / 304.8

    def to_dict(self) -> dict[str, object]:
        return asdict(self) | {"diameter_ft": round(self.diameter_ft, 6)}


FRANKLIN_X40 = BallProfile(
    profile_id="franklin_x40_outdoor",
    display_name="Franklin X-40 Outdoor",
    diameter_mm=74.0,
    mass_g=26.0,
    hole_count=40,
    construction="one-piece polyethylene",
    primary_color="optic_yellow_assumed",
    approved_for_outdoor_play=True,
)


def get_ball_profile(profile_id: str | None) -> BallProfile:
    normalized = (profile_id or FRANKLIN_X40.profile_id).strip().lower()
    aliases = {
        "franklin_x40": FRANKLIN_X40,
        "franklin_x-40": FRANKLIN_X40,
        "franklin_x40_outdoor": FRANKLIN_X40,
        "x40": FRANKLIN_X40,
        "x-40": FRANKLIN_X40,
    }
    try:
        return aliases[normalized]
    except KeyError as exc:
        raise ValueError(f"Unsupported ball profile: {profile_id}") from exc
