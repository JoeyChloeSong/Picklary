from __future__ import annotations

from dataclasses import dataclass
import math

import cv2
import numpy as np

from picklary_rating.analysis.ball_detect import BallCandidate
from picklary_rating.models import BallObservation, Point2D


@dataclass(slots=True)
class _Hypothesis:
    tracklet_id: int
    kalman: cv2.KalmanFilter
    last_position: Point2D
    gap: int
    score: float


def _make_filter(position: Point2D) -> cv2.KalmanFilter:
    kf = cv2.KalmanFilter(4, 2)
    kf.transitionMatrix = np.asarray([[1, 0, 1, 0], [0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32)
    kf.measurementMatrix = np.asarray([[1, 0, 0, 0], [0, 1, 0, 0]], np.float32)
    kf.processNoiseCov = np.eye(4, dtype=np.float32) * 0.08
    kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * 2.5
    kf.errorCovPost = np.eye(4, dtype=np.float32)
    kf.statePost = np.asarray([[position.x], [position.y], [0], [0]], np.float32)
    return kf


class MultiHypothesisBallTracker:
    def __init__(self, max_gap_frames: int = 6, max_hypotheses: int = 3):
        self.max_gap_frames = max_gap_frames
        self.max_hypotheses = max_hypotheses
        self._next_id = 1
        self._hypotheses: list[_Hypothesis] = []

    def update(self, candidates: list[BallCandidate], frame_index: int, time_s: float, px_per_ft: float = 45.0) -> BallObservation | None:
        predicted: list[tuple[_Hypothesis, Point2D]] = []
        for h in self._hypotheses:
            state = h.kalman.predict()
            predicted.append((h, Point2D(float(state[0, 0]), float(state[1, 0]))))

        assignments: list[tuple[float, _Hypothesis, BallCandidate]] = []
        gate = max(35.0, px_per_ft * 3.0)
        for h, pred in predicted:
            for c in candidates:
                dist = math.hypot(c.position.x - pred.x, c.position.y - pred.y)
                cost = dist / gate + (1.0 - c.confidence) * 0.5
                if dist <= gate:
                    assignments.append((cost, h, c))
        assignments.sort(key=lambda x: x[0])
        used_h: set[int] = set()
        used_c: set[int] = set()
        outputs: list[tuple[float, _Hypothesis, BallCandidate]] = []
        for cost, h, c in assignments:
            if h.tracklet_id in used_h or id(c) in used_c:
                continue
            used_h.add(h.tracklet_id)
            used_c.add(id(c))
            h.kalman.correct(np.asarray([[c.position.x], [c.position.y]], np.float32))
            h.last_position = c.position
            h.gap = 0
            h.score = 0.7 * h.score + 0.3 * c.confidence
            outputs.append((h.score - cost * 0.1, h, c))

        for h in self._hypotheses:
            if h.tracklet_id not in used_h:
                h.gap += 1
                h.score *= 0.92
        self._hypotheses = [h for h in self._hypotheses if h.gap <= self.max_gap_frames]

        for c in candidates:
            if id(c) in used_c:
                continue
            h = _Hypothesis(self._next_id, _make_filter(c.position), c.position, 0, c.confidence)
            self._next_id += 1
            self._hypotheses.append(h)
            outputs.append((h.score, h, c))
        self._hypotheses.sort(key=lambda h: h.score, reverse=True)
        self._hypotheses = self._hypotheses[: self.max_hypotheses]

        if outputs:
            _, h, c = max(outputs, key=lambda x: x[0])
            return BallObservation(
                frame_index=frame_index, time_s=time_s, image_position=c.position,
                court_position=None, confidence=c.confidence, source="tracknet_heatmap",
                tracklet_id=h.tracklet_id, visible=True, predicted=False,
            )
        if self._hypotheses:
            h = self._hypotheses[0]
            return BallObservation(
                frame_index=frame_index, time_s=time_s, image_position=h.last_position,
                court_position=None, confidence=max(0.0, h.score * 0.5), source="kalman_prediction",
                tracklet_id=h.tracklet_id, visible=False, predicted=True,
            )
        return None
