from __future__ import annotations

import math
from collections import deque

import cv2
import numpy as np

from picklary_rating.analysis.ball_profile import BallProfile, FRANKLIN_X40
from picklary_rating.analysis.court import CourtCalibration
from picklary_rating.models import BallObservation, Point2D


class ClassicalBallTracker:
    """Franklin X-40-aware visual fallback tracker.

    This is still a classical computer-vision tracker, not a trained TrackNet model.
    The fixed X-40 profile improves candidate ranking using regulation diameter,
    bright-ball color priors, court perspective, motion continuity and physical speed
    gates. It is intentionally transparent and exposes diagnostics.
    """

    def __init__(self, max_gap_frames: int = 6, profile: BallProfile = FRANKLIN_X40):
        self.profile = profile
        self.previous_gray: np.ndarray | None = None
        self.previous_position: Point2D | None = None
        self.previous_velocity = (0.0, 0.0)
        self.previous_time_s: float | None = None
        self.frames_since_seen = 0
        self.max_gap_frames = max_gap_frames
        self.tracklet_id = 1
        self.accepted = 0
        self.rejected = 0
        self.candidate_total = 0
        self.score_history: deque[float] = deque(maxlen=240)
        self.size_ratio_history: deque[float] = deque(maxlen=240)
        self.color_history: deque[float] = deque(maxlen=240)

    @staticmethod
    def _clip(value: float, low: float = 0.0, high: float = 1.0) -> float:
        return max(low, min(high, value))

    def _expected_diameter_px(self, center: Point2D, calibration: CourtCalibration) -> float:
        """Estimate apparent X-40 diameter from local court scale.

        A ground-plane homography cannot know ball height, so this is a soft prior,
        not a hard size filter. Motion blur and airborne balls receive a wide band.
        """
        try:
            ground = calibration.image_to_ground(center)
            base = calibration.ground_to_image(ground)
            x_neighbor = calibration.ground_to_image(Point2D(ground.x + 1.0, ground.y))
            y_neighbor = calibration.ground_to_image(Point2D(ground.x, ground.y + 1.0))
            px_per_ft_x = math.hypot(x_neighbor.x - base.x, x_neighbor.y - base.y)
            px_per_ft_y = math.hypot(y_neighbor.x - base.x, y_neighbor.y - base.y)
            px_per_ft = max(3.0, math.sqrt(max(1.0, px_per_ft_x * px_per_ft_y)))
            return max(1.5, min(42.0, px_per_ft * self.profile.diameter_ft))
        except Exception:
            return 6.0

    @staticmethod
    def _ball_color_score(patch_hsv: np.ndarray) -> float:
        if patch_hsv.size == 0:
            return 0.0
        h = patch_hsv[:, :, 0]
        s = patch_hsv[:, :, 1]
        v = patch_hsv[:, :, 2]
        # Franklin X-40 is commonly optic yellow, but the profile is not made
        # color-exclusive. Bright white/orange/pink variants still receive credit.
        optic = ((h >= 18) & (h <= 42) & (s >= 70) & (v >= 105))
        white = ((s <= 55) & (v >= 175))
        orange = ((h >= 3) & (h <= 18) & (s >= 85) & (v >= 120))
        pink = (((h <= 5) | (h >= 165)) & (s >= 75) & (v >= 120))
        bright_chroma = ((s >= 90) & (v >= 135))
        mask = optic | white | orange | pink
        main_fraction = float(np.mean(mask))
        broad_fraction = float(np.mean(bright_chroma))
        return min(1.0, main_fraction * 1.35 + broad_fraction * 0.30)

    def _physical_motion_score(self, center: Point2D, time_s: float, calibration: CourtCalibration) -> float:
        if self.previous_position is None or self.previous_time_s is None:
            return 0.55
        dt = max(1e-3, time_s - self.previous_time_s)
        px_dist = math.hypot(center.x - self.previous_position.x, center.y - self.previous_position.y)
        try:
            a = calibration.image_to_ground(self.previous_position)
            b = calibration.image_to_ground(center)
            mph = math.hypot(b.x - a.x, b.y - a.y) / dt * 0.681818
            # Homography overestimates airborne-ball ground motion. Keep a broad
            # allowed interval while strongly rejecting impossible jumps.
            if mph <= 0.2:
                return 0.35
            if mph <= 65.0:
                return 1.0
            if mph <= 90.0:
                return 0.55
            return 0.05
        except Exception:
            return math.exp(-px_dist / 220.0)

    @staticmethod
    def _player_overlap_penalty(
        center: Point2D,
        player_boxes: list[tuple[float, float, float, float]] | None,
        near_audio: bool = False,
    ) -> float:
        if not player_boxes:
            return 0.0
        penalty = 0.0
        for x1, y1, x2, y2 in player_boxes:
            width = max(1.0, x2 - x1)
            height = max(1.0, y2 - y1)
            margin_x = width * 0.08
            margin_y = height * 0.05
            if x1 + margin_x <= center.x <= x2 - margin_x and y1 + margin_y <= center.y <= y2 - margin_y:
                relative_y = (center.y - y1) / max(1.0, height)
                # Shoes, socks and bright court reflections were the dominant false
                # positives in v0.1.5. A true contact ball may overlap the upper body
                # near an audio transient, so that area remains a soft penalty.
                if relative_y >= 0.62:
                    penalty = max(penalty, 0.62)
                else:
                    penalty = max(penalty, 0.10 if near_audio else 0.34)
        return penalty

    def update(
        self,
        frame: np.ndarray,
        calibration: CourtCalibration,
        frame_index: int,
        time_s: float,
        player_boxes: list[tuple[float, float, float, float]] | None = None,
        near_audio: bool = False,
    ) -> BallObservation | None:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        if self.previous_gray is None:
            self.previous_gray = gray
            self.previous_time_s = time_s
            return None

        diff = cv2.absdiff(gray, self.previous_gray)
        diff = cv2.GaussianBlur(diff, (3, 3), 0)
        _, motion = cv2.threshold(diff, 14, 255, cv2.THRESH_BINARY)
        motion = cv2.morphologyEx(motion, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
        motion = cv2.dilate(motion, np.ones((2, 2), np.uint8), iterations=1)
        motion_contours, _ = cv2.findContours(motion, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        # OpenCV returns a tuple on some Windows wheels and a list on others.
        # Normalize before merging candidate groups so .extend() is always valid.
        contours = list(motion_contours)

        # Add Franklin-color candidates. Outside a paddle-like audio window, color
        # must also overlap recent motion; near a transient, the full color mask is
        # allowed so a blurred contact frame is not missed.
        hch, sch, vch = cv2.split(hsv)
        optic = cv2.inRange(hsv, np.array([17, 65, 100], np.uint8), np.array([45, 255, 255], np.uint8))
        white = cv2.inRange(hsv, np.array([0, 0, 175], np.uint8), np.array([179, 70, 255], np.uint8))
        orange = cv2.inRange(hsv, np.array([2, 85, 115], np.uint8), np.array([18, 255, 255], np.uint8))
        color_mask = cv2.bitwise_or(cv2.bitwise_or(optic, white), orange)
        color_mask = cv2.morphologyEx(color_mask, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
        if not near_audio:
            color_mask = cv2.bitwise_and(color_mask, cv2.dilate(motion, np.ones((5, 5), np.uint8), iterations=1))
        color_contours, _ = cv2.findContours(color_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        contours.extend(list(color_contours))

        expected = None
        if self.previous_position is not None:
            expected = Point2D(
                self.previous_position.x + self.previous_velocity[0],
                self.previous_position.y + self.previous_velocity[1],
            )

        best: tuple[float, Point2D, float, float, dict[str, float]] | None = None
        h, w = frame.shape[:2]
        for contour in contours:
            area = float(cv2.contourArea(contour))
            if area < 1.0 or area > max(650.0, h * w * 0.00042):
                self.rejected += 1
                continue
            x, y, bw, bh = cv2.boundingRect(contour)
            center = Point2D(x + bw / 2.0, y + bh / 2.0)
            if not calibration.image_point_in_roi(center, frame.shape):
                self.rejected += 1
                continue
            self.candidate_total += 1

            perimeter = float(cv2.arcLength(contour, True))
            circularity = self._clip(4.0 * math.pi * area / (perimeter * perimeter + 1e-6))
            elongation = max(bw, bh) / max(1.0, min(bw, bh))
            blur_shape = self._clip((elongation - 1.0) / 7.0)
            shape_score = 0.65 * circularity + 0.35 * (1.0 - blur_shape)

            pad = max(2, int(round(max(bw, bh) * 0.35)))
            patch = hsv[max(0, y - pad): min(h, y + bh + pad), max(0, x - pad): min(w, x + bw + pad)]
            color_score = self._ball_color_score(patch)

            expected_diameter = self._expected_diameter_px(center, calibration)
            observed_diameter = math.sqrt(max(1.0, bw * bh))
            size_ratio = observed_diameter / max(1.0, expected_diameter)
            # The contour can be a streak several diameters long. Log-distance gives
            # a tolerant prior while rejecting person-sized blobs.
            size_score = math.exp(-abs(math.log(max(0.08, size_ratio))) / 1.35)

            continuity = 0.45
            if expected is not None:
                distance = math.hypot(center.x - expected.x, center.y - expected.y)
                local_gate = max(65.0, expected_diameter * 18.0, h * 0.075)
                continuity = math.exp(-distance / local_gate)

            physical = self._physical_motion_score(center, time_s, calibration)
            overlap_penalty = self._player_overlap_penalty(center, player_boxes, near_audio)
            score = (
                0.29 * continuity
                + 0.24 * color_score
                + 0.18 * size_score
                + 0.14 * shape_score
                + 0.15 * physical
                - overlap_penalty
            )
            diagnostics = {
                "continuity": continuity,
                "color": color_score,
                "size": size_score,
                "shape": shape_score,
                "physical": physical,
                "size_ratio": size_ratio,
            }
            if best is None or score > best[0]:
                best = (score, center, size_ratio, color_score, diagnostics)

        self.previous_gray = gray
        threshold = (0.39 if near_audio else 0.45) if self.previous_position is not None else (0.43 if near_audio else 0.52)
        if best is None or best[0] < threshold:
            self.frames_since_seen += 1
            if self.frames_since_seen > self.max_gap_frames:
                self.previous_position = None
                self.previous_velocity = (0.0, 0.0)
                self.tracklet_id += 1
            if self.previous_position is None:
                self.previous_time_s = time_s
            return None

        score, position, size_ratio, color_score, _components = best
        if self.previous_position is not None:
            self.previous_velocity = (
                position.x - self.previous_position.x,
                position.y - self.previous_position.y,
            )
        self.previous_position = position
        self.previous_time_s = time_s
        self.frames_since_seen = 0
        self.accepted += 1
        self.score_history.append(float(score))
        self.size_ratio_history.append(float(size_ratio))
        self.color_history.append(float(color_score))
        confidence = min(0.86, max(0.30, 0.22 + score * 0.78))
        return BallObservation(
            frame_index,
            time_s,
            position,
            None,
            float(confidence),
            "franklin_x40_visual_prior",
            None,
            self.tracklet_id,
            True,
            False,
        )

    def diagnostics(self) -> dict[str, object]:
        mean = lambda values: round(sum(values) / len(values), 4) if values else None
        return {
            "method": "franklin_x40_classical_visual_prior_v2_audio_guided",
            "profile": self.profile.to_dict(),
            "accepted_observations": self.accepted,
            "candidate_total": self.candidate_total,
            "rejected_candidates": self.rejected,
            "mean_candidate_score": mean(self.score_history),
            "mean_size_ratio": mean(self.size_ratio_history),
            "mean_color_score": mean(self.color_history),
            "limitations": [
                "brand/profile assumption improves ranking and scale priors but is not a trained ball detector",
                "airborne ball height is unknown in a single-camera ground homography",
                "occlusion and motion blur can still create missed or false observations",
            ],
        }
