from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

import cv2
import numpy as np


def calibrate_checkerboard(
    image_paths: Iterable[str | Path],
    output_path: str | Path,
    board_size: tuple[int, int] = (9, 6),
    square_size: float = 1.0,
) -> dict:
    """Calibrate a camera from checkerboard images and save a reusable profile."""
    object_template = np.zeros((board_size[0] * board_size[1], 3), np.float32)
    object_template[:, :2] = np.mgrid[0:board_size[0], 0:board_size[1]].T.reshape(-1, 2)
    object_template *= float(square_size)
    object_points: list[np.ndarray] = []
    image_points: list[np.ndarray] = []
    image_size: tuple[int, int] | None = None
    used: list[str] = []
    for raw in image_paths:
        path = Path(raw)
        image = cv2.imread(str(path))
        if image is None:
            continue
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        image_size = (gray.shape[1], gray.shape[0])
        ok, corners = cv2.findChessboardCorners(gray, board_size)
        if not ok:
            continue
        corners = cv2.cornerSubPix(
            gray, corners, (11, 11), (-1, -1),
            (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001),
        )
        object_points.append(object_template.copy())
        image_points.append(corners)
        used.append(str(path))
    if image_size is None or len(object_points) < 8:
        raise ValueError("At least 8 checkerboard images with detected corners are required")
    rms, K, distortion, rvecs, tvecs = cv2.calibrateCamera(object_points, image_points, image_size, None, None)
    per_image: list[float] = []
    for obj, img, rvec, tvec in zip(object_points, image_points, rvecs, tvecs):
        projected, _ = cv2.projectPoints(obj, rvec, tvec, K, distortion)
        per_image.append(float(np.sqrt(np.mean(np.sum((projected.reshape(-1, 2) - img.reshape(-1, 2)) ** 2, axis=1)))))
    payload = {
        "schema_version": 1,
        "method": "checkerboard_cv2_calibrateCamera",
        "board_size": list(board_size),
        "square_size": float(square_size),
        "image_size": list(image_size),
        "camera_matrix": K.tolist(),
        "distortion": distortion.reshape(-1).tolist(),
        "rms_px": float(rms),
        "per_image_rmse_px": per_image,
        "images_used": used,
    }
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return payload
