from __future__ import annotations

from dataclasses import dataclass
import math

import cv2
import numpy as np
from scipy.optimize import least_squares

from picklary_rating.models import Point2D, Point3D


@dataclass(slots=True)
class CameraCalibrationDiagnostics:
    reprojection_rmse_px: float
    max_error_px: float
    worst_point_index: int
    mode: str
    speed_metrics_enabled: bool
    input_order_adjusted: bool = False
    ground_rmse_px: float | None = None
    full_model_rmse_px: float | None = None
    net_rmse_px: float | None = None
    net_post_offset_ft: float | None = None
    net_center_height_ft: float | None = None
    fallback_reason: str | None = None
    ground_global_rmse_px: float | None = None
    ground_piecewise_rmse_px: float | None = None
    ground_mapping_mode: str = "global_homography"
    systematic_distortion_detected: bool = False


def normalize_calibration_points(
    image_points: list[Point2D],
    width_ft: float = 20.0,
    length_ft: float = 44.0,
) -> tuple[list[Point2D], list[int]]:
    """Normalize clicks inside each landmark group.

    Groups are: four baseline corners, four kitchen-line intersections, two
    net-post tops, and one net-center top. Click order inside a group is free.
    """
    if len(image_points) not in (4, 8, 11):
        raise ValueError("Calibration requires 4, 8, or 11 points")

    def sort_left_right(indices: list[int], coords: np.ndarray) -> list[int]:
        return sorted(indices, key=lambda i: float(coords[i, 0]))

    pts = np.asarray([[p.x, p.y] for p in image_points], dtype=np.float64)

    hull = cv2.convexHull(pts[:4].astype(np.float32), returnPoints=False)
    if hull is None or len(hull) != 4:
        raise ValueError("The four baseline corners must form a non-degenerate quadrilateral")
    hids = [int(v) for v in hull.reshape(-1)]

    def edge_score(a: int, b: int) -> float:
        dx = float(pts[b, 0] - pts[a, 0])
        dy = float(pts[b, 1] - pts[a, 1])
        length = max(1e-6, math.hypot(dx, dy))
        return abs(dx) / length

    pairings = [
        ((hids[0], hids[1]), (hids[2], hids[3])),
        ((hids[1], hids[2]), (hids[3], hids[0])),
    ]
    baseline_edges = max(pairings, key=lambda pair: edge_score(*pair[0]) + edge_score(*pair[1]))

    def edge_length(edge: tuple[int, int]) -> float:
        a, b = edge
        return float(np.linalg.norm(pts[a] - pts[b]))

    far_edge, near_edge = sorted(baseline_edges, key=edge_length)
    far_ids = sort_left_right(list(far_edge), pts)
    near_lr = sort_left_right(list(near_edge), pts)
    corner_order = [far_ids[0], far_ids[1], near_lr[1], near_lr[0]]
    ordered_ids = list(corner_order)

    if len(image_points) >= 8:
        src4 = pts[corner_order].astype(np.float32)
        dst4 = np.asarray(
            [[0, 0], [width_ft, 0], [width_ft, length_ft], [0, length_ft]],
            dtype=np.float32,
        )
        H = cv2.getPerspectiveTransform(src4, dst4)
        kitchen_ids = list(range(4, 8))
        kitchen_img = pts[kitchen_ids].astype(np.float32).reshape(1, -1, 2)
        kitchen_court = cv2.perspectiveTransform(kitchen_img, H)[0]
        kitchen_by_y_local = sorted(range(4), key=lambda j: float(kitchen_court[j, 1]))
        far_local = sorted(kitchen_by_y_local[:2], key=lambda j: float(kitchen_court[j, 0]))
        near_local = sorted(kitchen_by_y_local[2:], key=lambda j: float(kitchen_court[j, 0]))
        ordered_ids.extend([
            kitchen_ids[far_local[0]], kitchen_ids[far_local[1]],
            kitchen_ids[near_local[0]], kitchen_ids[near_local[1]],
        ])

    if len(image_points) == 11:
        post_ids = sorted([8, 9], key=lambda i: float(pts[i, 0]))
        ordered_ids.extend(post_ids)
        ordered_ids.append(10)

    return [image_points[i] for i in ordered_ids], ordered_ids


class FullCameraCalibration:
    """Camera calibration using ground landmarks and optional net landmarks.

    Important v0.2.2 correction: regulation net posts are 22 ft apart, while
    the court is 20 ft wide. Therefore the nominal post coordinates are x=-1
    and x=21, not x=0 and x=20. The optimizer also allows a small variation for
    portable nets. If a full 3-D fit is not trustworthy but the eight ground
    landmarks are internally consistent, calibration automatically falls back
    to position-only mode instead of blocking the entire analysis.
    """

    def __init__(
        self,
        image_points: list[Point2D],
        image_size: tuple[int, int] | None = None,
        width_ft: float = 20.0,
        length_ft: float = 44.0,
        kitchen_ft: float = 7.0,
        camera_matrix: np.ndarray | None = None,
        distortion: np.ndarray | None = None,
        net_post_offset_ft: float = 1.0,
        full_model_reject_rmse_px: float = 20.0,
    ):
        if len(image_points) not in (4, 8, 11):
            raise ValueError("Calibration requires 4, 8, or 11 points")
        self.input_image_points = list(image_points)
        self.width_ft = float(width_ft)
        self.length_ft = float(length_ft)
        self.kitchen_ft = float(kitchen_ft)
        self.nominal_net_post_offset_ft = float(net_post_offset_ft)
        self.full_model_reject_rmse_px = float(full_model_reject_rmse_px)
        normalized, normalized_to_input = normalize_calibration_points(
            self.input_image_points, self.width_ft, self.length_ft
        )
        self.image_points = normalized
        self.normalized_to_input_index = normalized_to_input
        self.input_order_adjusted = normalized_to_input != list(range(len(image_points)))
        self.net_y = self.length_ft / 2.0
        self.image_size = image_size
        self.distortion = np.zeros((5, 1), dtype=np.float64) if distortion is None else distortion.astype(np.float64)
        self.mode = "homography_4pt" if len(image_points) == 4 else "ground_piecewise_8pt"
        self.speed_metrics_enabled = False
        self.rvec: np.ndarray | None = None
        self.tvec: np.ndarray | None = None
        self.P: np.ndarray | None = None
        self.net_post_offset_ft: float | None = None
        self.net_center_height_ft: float | None = None
        self.full_model_rmse_px: float | None = None
        self.net_rmse_px: float | None = None
        self.fallback_reason: str | None = None

        src4 = np.array([[p.x, p.y] for p in self.image_points[:4]], dtype=np.float32)
        dst4 = np.array(
            [[0, 0], [self.width_ft, 0], [self.width_ft, self.length_ft], [0, self.length_ft]],
            np.float32,
        )
        self.homography = cv2.getPerspectiveTransform(src4, dst4)
        self.inverse_homography = cv2.getPerspectiveTransform(dst4, src4)
        self._piecewise_ground_models = self._build_piecewise_ground_models() if len(self.image_points) >= 8 else []
        self.ground_global_rmse_px, self._global_ground_errors = self._global_ground_validation_errors()
        self.ground_piecewise_rmse_px, self._piecewise_ground_errors = self._piecewise_ground_validation_errors()
        if self._piecewise_ground_models:
            self.ground_mapping_mode = "piecewise_8pt"
            self.ground_rmse_px = self.ground_piecewise_rmse_px
            self._ground_errors = self._piecewise_ground_errors
        else:
            self.ground_mapping_mode = "global_homography"
            self.ground_rmse_px = self.ground_global_rmse_px
            self._ground_errors = self._global_ground_errors
        self.systematic_distortion_detected = bool(
            self._piecewise_ground_models
            and self.ground_global_rmse_px > max(8.0, self.ground_piecewise_rmse_px + 8.0)
        )

        self.camera_matrix = camera_matrix if camera_matrix is not None else self._initial_camera_matrix(image_size, self.image_points)
        if len(self.image_points) == 11:
            try:
                self._fit_full_camera(camera_matrix_was_supplied=camera_matrix is not None)
            except Exception as exc:
                self.fallback_reason = f"3D camera fit failed: {type(exc).__name__}: {exc}"
                self.mode = "ground_piecewise_8pt_fallback"
                self.speed_metrics_enabled = False
                self.rvec = self.tvec = self.P = None

            if self.full_model_rmse_px is not None and self.full_model_rmse_px > self.full_model_reject_rmse_px:
                self.fallback_reason = (
                    f"3D fit RMSE {self.full_model_rmse_px:.1f}px exceeds "
                    f"{self.full_model_reject_rmse_px:.1f}px; ground-only analysis remains available"
                )
                self.mode = "ground_piecewise_8pt_fallback"
                self.speed_metrics_enabled = False
                self.rvec = self.tvec = self.P = None

        self.diagnostics = self._diagnostics()

    def _ground_object_points(self) -> np.ndarray:
        k_far = self.net_y - self.kitchen_ft
        k_near = self.net_y + self.kitchen_ft
        return np.asarray([
            [0, 0], [self.width_ft, 0], [self.width_ft, self.length_ft], [0, self.length_ft],
            [0, k_far], [self.width_ft, k_far], [0, k_near], [self.width_ft, k_near],
        ], dtype=np.float32)

    def _build_piecewise_ground_models(self) -> list[tuple[float, float, np.ndarray, np.ndarray, np.ndarray]]:
        """Build three local homographies using all eight ground landmarks.

        A single projective transform cannot absorb wide-angle radial distortion.
        Local transforms preserve the exact user-selected court intersections and
        avoid the impossible 5-versus-8 adjustment loop seen on action cameras.
        """
        if len(self.image_points) < 8:
            return []
        k_far = self.net_y - self.kitchen_ft
        k_near = self.net_y + self.kitchen_ft
        bands = [
            (0.0, k_far, [0, 1, 5, 4]),
            (k_far, k_near, [4, 5, 7, 6]),
            (k_near, self.length_ft, [6, 7, 2, 3]),
        ]
        models: list[tuple[float, float, np.ndarray, np.ndarray, np.ndarray]] = []
        for y0, y1, ids in bands:
            image_quad = np.asarray([[self.image_points[i].x, self.image_points[i].y] for i in ids], dtype=np.float32)
            court_quad = np.asarray([[0, y0], [self.width_ft, y0], [self.width_ft, y1], [0, y1]], dtype=np.float32)
            if abs(float(cv2.contourArea(image_quad))) < 1.0:
                raise ValueError("Ground calibration band is degenerate; re-click the four line intersections")
            H = cv2.getPerspectiveTransform(image_quad, court_quad)
            Hinv = cv2.getPerspectiveTransform(court_quad, image_quad)
            models.append((float(y0), float(y1), H, Hinv, image_quad))
        return models

    def _global_ground_validation_errors(self) -> tuple[float, np.ndarray]:
        count = min(8, len(self.image_points))
        expected = self._ground_object_points()[:count]
        projected = cv2.perspectiveTransform(expected.reshape(1, -1, 2), self.inverse_homography)[0]
        actual = np.asarray([[p.x, p.y] for p in self.image_points[:count]], dtype=float)
        errors = np.linalg.norm(projected - actual, axis=1)
        return float(math.sqrt(np.mean(errors ** 2))), errors

    def _piecewise_ground_validation_errors(self) -> tuple[float, np.ndarray]:
        if not self._piecewise_ground_models:
            return self.ground_global_rmse_px, self._global_ground_errors.copy()
        expected = self._ground_object_points()[:8]
        projected = np.asarray([[self.ground_to_image(Point2D(float(x), float(y))).x,
                                 self.ground_to_image(Point2D(float(x), float(y))).y]
                                for x, y in expected], dtype=float)
        actual = np.asarray([[p.x, p.y] for p in self.image_points[:8]], dtype=float)
        errors = np.linalg.norm(projected - actual, axis=1)
        return float(math.sqrt(np.mean(errors ** 2))), errors

    def _object_points_11(self, post_offset_ft: float | None = None, center_height_ft: float | None = None) -> np.ndarray:
        offset = self.nominal_net_post_offset_ft if post_offset_ft is None else float(post_offset_ft)
        center_h = 34 / 12 if center_height_ft is None else float(center_height_ft)
        k_far = self.net_y - self.kitchen_ft
        k_near = self.net_y + self.kitchen_ft
        return np.asarray([
            [0, 0, 0], [self.width_ft, 0, 0], [self.width_ft, self.length_ft, 0], [0, self.length_ft, 0],
            [0, k_far, 0], [self.width_ft, k_far, 0], [0, k_near, 0], [self.width_ft, k_near, 0],
            [-offset, self.net_y, 3.0], [self.width_ft + offset, self.net_y, 3.0],
            [self.width_ft / 2, self.net_y, center_h],
        ], dtype=np.float64)

    def _fit_full_camera(self, camera_matrix_was_supplied: bool) -> None:
        image_arr = np.asarray([[p.x, p.y] for p in self.image_points], dtype=np.float64)
        cx, cy = float(self.camera_matrix[0, 2]), float(self.camera_matrix[1, 2])
        width_hint = float(self.image_size[0] if self.image_size else max(p.x for p in self.image_points) * 1.1)
        focal_hints = [
            float(self.camera_matrix[0, 0]),
            width_hint * 0.75,
            width_hint * 1.10,
            width_hint * 1.60,
            width_hint * 2.20,
        ]
        offset_hints = [self.nominal_net_post_offset_ft, 0.0, 0.5, 1.25, 1.5]
        best: tuple[float, np.ndarray, np.ndarray, np.ndarray, float, float] | None = None

        for f0 in focal_hints:
            K0 = np.array([[f0, 0, cx], [0, f0, cy], [0, 0, 1]], dtype=np.float64)
            for offset0 in offset_hints:
                object0 = self._object_points_11(offset0, 34 / 12)
                try:
                    success, rvec0, tvec0 = cv2.solvePnP(
                        object0, image_arr, K0, self.distortion, flags=cv2.SOLVEPNP_SQPNP
                    )
                except cv2.error:
                    continue
                if not success:
                    continue

                params0 = np.concatenate([
                    [math.log(max(1.0, f0))], rvec0.reshape(3), tvec0.reshape(3),
                    [offset0, 34 / 12],
                ])

                def residual(params: np.ndarray) -> np.ndarray:
                    focal = math.exp(float(params[0]))
                    K = np.array([[focal, 0, cx], [0, focal, cy], [0, 0, 1]], dtype=np.float64)
                    objects = self._object_points_11(params[7], params[8])
                    projected, _ = cv2.projectPoints(objects, params[1:4], params[4:7], K, self.distortion)
                    return (projected.reshape(-1, 2) - image_arr).reshape(-1)

                lower_f = math.log(max(50.0, width_hint * (0.35 if not camera_matrix_was_supplied else 0.60)))
                upper_f = math.log(width_hint * (5.0 if not camera_matrix_was_supplied else 2.50))
                fit = least_squares(
                    residual,
                    params0,
                    method="trf",
                    loss="soft_l1",
                    f_scale=5.0,
                    bounds=(
                        np.array([lower_f, -np.inf, -np.inf, -np.inf, -np.inf, -np.inf, -np.inf, 0.0, 2.60]),
                        np.array([upper_f, np.inf, np.inf, np.inf, np.inf, np.inf, np.inf, 2.0, 3.05]),
                    ),
                    max_nfev=3000,
                )
                params = fit.x
                focal = math.exp(float(params[0]))
                K = np.array([[focal, 0, cx], [0, focal, cy], [0, 0, 1]], dtype=np.float64)
                rvec = params[1:4].reshape(3, 1)
                tvec = params[4:7].reshape(3, 1)
                offset = float(params[7])
                center_h = float(params[8])
                objects = self._object_points_11(offset, center_h)
                projected, _ = cv2.projectPoints(objects, rvec, tvec, K, self.distortion)
                errors = np.linalg.norm(projected.reshape(-1, 2) - image_arr, axis=1)
                rmse = float(math.sqrt(np.mean(errors ** 2)))
                if best is None or rmse < best[0]:
                    best = (rmse, K, rvec, tvec, offset, center_h)

        if best is None:
            raise RuntimeError("no stable camera solution found")

        rmse, self.camera_matrix, self.rvec, self.tvec, self.net_post_offset_ft, self.net_center_height_ft = best
        objects = self._object_points_11(self.net_post_offset_ft, self.net_center_height_ft)
        projected, _ = cv2.projectPoints(objects, self.rvec, self.tvec, self.camera_matrix, self.distortion)
        errors = np.linalg.norm(projected.reshape(-1, 2) - image_arr, axis=1)
        self.full_model_rmse_px = rmse
        self.net_rmse_px = float(math.sqrt(np.mean(errors[8:] ** 2)))
        R, _ = cv2.Rodrigues(self.rvec)
        self.P = self.camera_matrix @ np.hstack([R, self.tvec])
        self.mode = "full_11pt"
        self.speed_metrics_enabled = True

    def _initial_camera_matrix(self, image_size: tuple[int, int] | None, points: list[Point2D]) -> np.ndarray:
        if image_size:
            width, height = image_size
        else:
            width = int(max(p.x for p in points) * 1.05) or 1920
            height = int(max(p.y for p in points) * 1.05) or 1080
        focal = max(width, height) * 1.35
        return np.array([[focal, 0, width / 2], [0, focal, height / 2], [0, 0, 1]], dtype=np.float64)

    def _diagnostics(self) -> CameraCalibrationDiagnostics:
        if self.mode == "full_11pt" and self.rvec is not None and self.tvec is not None:
            objects = self._object_points_11(self.net_post_offset_ft, self.net_center_height_ft)
            projected, _ = cv2.projectPoints(objects, self.rvec, self.tvec, self.camera_matrix, self.distortion)
            projected = projected.reshape(-1, 2)
            actual = np.asarray([[p.x, p.y] for p in self.image_points], dtype=float)
            errors = np.linalg.norm(projected - actual, axis=1)
            active_rmse = float(math.sqrt(np.mean(errors ** 2)))
            max_error = float(errors.max(initial=0))
            worst_normalized = int(errors.argmax()) if len(errors) else -1
        else:
            errors = self._ground_errors
            active_rmse = self.ground_rmse_px
            max_error = float(errors.max(initial=0))
            worst_normalized = int(errors.argmax()) if len(errors) else -1

        worst_input = (
            int(self.normalized_to_input_index[worst_normalized])
            if 0 <= worst_normalized < len(self.normalized_to_input_index)
            else -1
        )
        if self.mode == "ground_piecewise_8pt_fallback" and self.systematic_distortion_detected:
            # The residual is systematic lens/model mismatch, not one bad click.
            # Do not send the user into an endless alternating-point adjustment loop.
            worst_input = -1
            max_error = float(self.ground_global_rmse_px)
        return CameraCalibrationDiagnostics(
            reprojection_rmse_px=active_rmse,
            max_error_px=max_error,
            worst_point_index=worst_input,
            mode=self.mode,
            speed_metrics_enabled=self.speed_metrics_enabled,
            input_order_adjusted=self.input_order_adjusted,
            ground_rmse_px=self.ground_rmse_px,
            full_model_rmse_px=self.full_model_rmse_px,
            net_rmse_px=self.net_rmse_px,
            net_post_offset_ft=self.net_post_offset_ft,
            net_center_height_ft=self.net_center_height_ft,
            fallback_reason=self.fallback_reason,
            ground_global_rmse_px=self.ground_global_rmse_px,
            ground_piecewise_rmse_px=self.ground_piecewise_rmse_px,
            ground_mapping_mode=self.ground_mapping_mode,
            systematic_distortion_detected=self.systematic_distortion_detected,
        )

    def image_to_ground(self, point: Point2D) -> Point2D:
        src = np.array([[[point.x, point.y]]], dtype=np.float32)
        if not self._piecewise_ground_models:
            out = cv2.perspectiveTransform(src, self.homography)[0, 0]
            return Point2D(float(out[0]), float(out[1]))

        best: tuple[float, np.ndarray] | None = None
        for y0, y1, H, _Hinv, polygon in self._piecewise_ground_models:
            out = cv2.perspectiveTransform(src, H)[0, 0]
            x, y = float(out[0]), float(out[1])
            inside = cv2.pointPolygonTest(polygon, point.as_tuple(), False) >= 0
            outside_y = max(y0 - y, 0.0, y - y1)
            outside_x = max(-x, 0.0, x - self.width_ft)
            penalty = outside_y * 3.0 + outside_x + (0.0 if inside else 0.25)
            if best is None or penalty < best[0]:
                best = (penalty, out)
        assert best is not None
        out = best[1]
        return Point2D(float(out[0]), float(out[1]))

    def ground_to_image(self, point: Point2D) -> Point2D:
        src = np.array([[[point.x, point.y]]], dtype=np.float32)
        if not self._piecewise_ground_models:
            out = cv2.perspectiveTransform(src, self.inverse_homography)[0, 0]
            return Point2D(float(out[0]), float(out[1]))
        y = float(point.y)
        if y <= self._piecewise_ground_models[0][1]:
            model = self._piecewise_ground_models[0]
        elif y <= self._piecewise_ground_models[1][1]:
            model = self._piecewise_ground_models[1]
        else:
            model = self._piecewise_ground_models[2]
        out = cv2.perspectiveTransform(src, model[3])[0, 0]
        return Point2D(float(out[0]), float(out[1]))

    def project_3d(self, point: Point3D) -> Point2D:
        if self.rvec is None or self.tvec is None:
            raise RuntimeError("3D projection requires successful 11-point calibration")
        projected, _ = cv2.projectPoints(
            np.asarray([[point.x, point.y, point.z]], np.float64),
            self.rvec, self.tvec, self.camera_matrix, self.distortion,
        )
        x, y = projected.reshape(2)
        return Point2D(float(x), float(y))

    def camera_center(self) -> np.ndarray:
        if self.rvec is None or self.tvec is None:
            raise RuntimeError("Camera center requires successful 11-point calibration")
        R, _ = cv2.Rodrigues(self.rvec)
        return (-R.T @ self.tvec).reshape(3)

    def image_ray(self, point: Point2D) -> tuple[np.ndarray, np.ndarray]:
        if self.rvec is None or self.tvec is None:
            raise RuntimeError("Image rays require successful 11-point calibration")
        R, _ = cv2.Rodrigues(self.rvec)
        uv = np.asarray([[[point.x, point.y]]], dtype=np.float64)
        und = cv2.undistortPoints(uv, self.camera_matrix, self.distortion).reshape(2)
        ray_cam = np.asarray([und[0], und[1], 1.0])
        ray_world = R.T @ ray_cam
        ray_world /= np.linalg.norm(ray_world)
        return self.camera_center(), ray_world

    def is_inside(self, point: Point2D, margin_ft: float = 1.5) -> bool:
        return -margin_ft <= point.x <= self.width_ft + margin_ft and -margin_ft <= point.y <= self.length_ft + margin_ft

    def side(self, point: Point2D) -> str:
        return "far" if point.y < self.net_y else "near"

    def zone(self, point: Point2D) -> str:
        distance_from_net = abs(point.y - self.net_y)
        if distance_from_net <= self.kitchen_ft:
            return "kitchen"
        if distance_from_net <= self.kitchen_ft * 2:
            return "transition"
        return "baseline"

    def expanded_image_roi(self, frame_shape: tuple[int, ...], extra_top_ratio: float = 0.38) -> np.ndarray:
        corners = np.asarray([[p.x, p.y] for p in self.image_points[:4]], dtype=np.float32)
        h, w = frame_shape[:2]
        top = max(0.0, float(corners[:, 1].min()) - h * extra_top_ratio)
        return np.asarray([
            [max(0.0, corners[:, 0].min() - w * 0.10), top],
            [min(w - 1.0, corners[:, 0].max() + w * 0.10), top],
            [min(w - 1.0, corners[:, 0].max() + w * 0.12), min(h - 1.0, corners[:, 1].max() + h * 0.08)],
            [max(0.0, corners[:, 0].min() - w * 0.12), min(h - 1.0, corners[:, 1].max() + h * 0.08)],
        ], np.float32)

    def image_point_in_roi(self, point: Point2D, frame_shape: tuple[int, ...]) -> bool:
        polygon = self.expanded_image_roi(frame_shape)
        return cv2.pointPolygonTest(polygon, point.as_tuple(), False) >= 0
