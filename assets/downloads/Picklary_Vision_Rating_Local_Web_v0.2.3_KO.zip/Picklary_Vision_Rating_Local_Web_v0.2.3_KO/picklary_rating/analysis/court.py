from __future__ import annotations

from picklary_rating.analysis.camera import FullCameraCalibration
from picklary_rating.models import Point2D


class CourtCalibration(FullCameraCalibration):
    """Compatibility facade for the v0.2 camera model."""

    def __init__(
        self,
        image_points: list[Point2D],
        width_ft: float = 20.0,
        length_ft: float = 44.0,
        kitchen_ft: float = 7.0,
        image_size: tuple[int, int] | None = None,
    ):
        super().__init__(
            image_points=image_points,
            image_size=image_size,
            width_ft=width_ft,
            length_ft=length_ft,
            kitchen_ft=kitchen_ft,
        )

    def image_to_court(self, point: Point2D) -> Point2D:
        return self.image_to_ground(point)

    def court_to_image(self, point: Point2D) -> Point2D:
        return self.ground_to_image(point)
