from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
import os
import platform
import subprocess
from typing import Any

import cv2


@dataclass(slots=True)
class RuntimeCapabilities:
    cpu_name: str
    nvidia_gpus: list[str]
    opencv_cuda_devices: int
    opencv_cuda_available: bool
    onnxruntime_providers: list[str]
    requested_device: str = "auto"

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["directml_available"] = "DmlExecutionProvider" in self.onnxruntime_providers
        data["cuda_provider_reported"] = "CUDAExecutionProvider" in self.onnxruntime_providers
        data["cuda_opt_in"] = os.getenv("PVR_ALLOW_CUDA", "0") == "1"
        return data

    @property
    def hardware_summary(self) -> str:
        gpu_text = ", ".join(self.nvidia_gpus) if self.nvidia_gpus else "감지되지 않음"
        dml = "사용 가능" if "DmlExecutionProvider" in self.onnxruntime_providers else "사용 불가"
        cuda_reported = "보고됨" if "CUDAExecutionProvider" in self.onnxruntime_providers else "없음"
        cv_cuda = f"사용 가능({self.opencv_cuda_devices}개)" if self.opencv_cuda_available else "사용 불가"
        return (
            f"CPU: {self.cpu_name} · NVIDIA GPU: {gpu_text} · "
            f"ONNX Runtime DirectML: {dml} · CUDA provider: {cuda_reported} · OpenCV CUDA: {cv_cuda}"
        )


@dataclass(slots=True)
class OrtSessionResult:
    session: Any
    input_name: str
    backend_key: str
    device_label: str
    active_provider: str
    attempts: list[str]
    fallback_reason: str | None = None


def _cpu_name() -> str:
    name = platform.processor().strip()
    if name:
        return name
    return os.environ.get("PROCESSOR_IDENTIFIER", "알 수 없음")


def _nvidia_gpu_names() -> list[str]:
    try:
        completed = subprocess.run(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            capture_output=True,
            text=True,
            timeout=3,
            check=False,
        )
        if completed.returncode == 0:
            return [line.strip() for line in completed.stdout.splitlines() if line.strip()]
    except (OSError, subprocess.SubprocessError):
        pass
    return []


def _onnxruntime_providers() -> list[str]:
    try:
        import onnxruntime as ort  # type: ignore

        return list(ort.get_available_providers())
    except Exception:
        return []


def inspect_runtime_capabilities(requested_device: str = "auto") -> RuntimeCapabilities:
    cuda_devices = 0
    try:
        if hasattr(cv2, "cuda"):
            cuda_devices = int(cv2.cuda.getCudaEnabledDeviceCount())
    except Exception:
        cuda_devices = 0
    return RuntimeCapabilities(
        cpu_name=_cpu_name(),
        nvidia_gpus=_nvidia_gpu_names(),
        opencv_cuda_devices=cuda_devices,
        opencv_cuda_available=cuda_devices > 0,
        onnxruntime_providers=_onnxruntime_providers(),
        requested_device=requested_device,
    )


def _short_error(exc: BaseException, limit: int = 240) -> str:
    text = " ".join(str(exc).replace("\r", " ").replace("\n", " ").split())
    if len(text) > limit:
        text = text[: limit - 3] + "..."
    return f"{type(exc).__name__}: {text}"


def _session_options(ort: Any, provider: str) -> Any:
    options = ort.SessionOptions()
    if provider == "DmlExecutionProvider":
        # DirectML requires sequential execution and disabled memory patterns.
        options.enable_mem_pattern = False
        options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
    return options


def create_ort_session_with_fallback(
    model_path: str | Path,
    requested_device: str = "auto",
    *,
    prefer_directml: bool = True,
) -> OrtSessionResult:
    """Create an ONNX Runtime session without allowing a GPU failure to end the app.

    Windows local builds prefer DirectML because it uses the installed graphics
    driver and does not require separate CUDA/cuDNN DLLs. CUDA is opt-in through
    PVR_ALLOW_CUDA=1. CPU is always the final fallback.
    """

    import onnxruntime as ort  # type: ignore

    path = str(Path(model_path))
    requested = requested_device.lower().strip()
    if requested not in {"auto", "cpu", "gpu"}:
        requested = "auto"
    available = list(ort.get_available_providers())
    attempts: list[str] = []
    candidates: list[tuple[str, str, str]] = []
    allow_cuda = os.getenv("PVR_ALLOW_CUDA", "0") == "1"

    if requested != "cpu":
        if prefer_directml and "DmlExecutionProvider" in available:
            candidates.append(("DmlExecutionProvider", "onnxruntime_dml", "GPU · ONNX Runtime DirectML"))
        if allow_cuda and "CUDAExecutionProvider" in available:
            candidates.append(("CUDAExecutionProvider", "onnxruntime_cuda", "GPU · ONNX Runtime CUDA"))
        if not prefer_directml and "DmlExecutionProvider" in available:
            candidates.append(("DmlExecutionProvider", "onnxruntime_dml", "GPU · ONNX Runtime DirectML"))

    candidates.append(("CPUExecutionProvider", "cpu", "CPU · ONNX Runtime"))
    first_gpu_error: str | None = None

    for provider, backend_key, base_label in candidates:
        try:
            options = _session_options(ort, provider)
            providers = [provider]
            if provider != "CPUExecutionProvider" and "CPUExecutionProvider" in available:
                providers.append("CPUExecutionProvider")
            session = ort.InferenceSession(path, sess_options=options, providers=providers)
            active = session.get_providers()[0] if session.get_providers() else "unknown"
            input_name = session.get_inputs()[0].name
            if provider != "CPUExecutionProvider" and active != provider:
                raise RuntimeError(f"requested {provider}, active provider is {active}")
            fallback_reason = first_gpu_error if backend_key == "cpu" else None
            label = base_label
            if backend_key == "cpu" and requested != "cpu":
                if first_gpu_error:
                    label = f"CPU fallback · GPU 초기화 실패: {first_gpu_error}"
                elif "DmlExecutionProvider" not in available:
                    label = "CPU fallback · DirectML GPU provider가 설치되지 않음"
            return OrtSessionResult(
                session=session,
                input_name=input_name,
                backend_key=backend_key,
                device_label=label,
                active_provider=active,
                attempts=attempts,
                fallback_reason=fallback_reason,
            )
        except Exception as exc:
            error = f"{provider}: {_short_error(exc)}"
            attempts.append(error)
            if provider != "CPUExecutionProvider" and first_gpu_error is None:
                first_gpu_error = error

    raise RuntimeError("ONNX Runtime session initialization failed; " + " | ".join(attempts))


def choose_dnn_device(requested_device: str = "auto") -> tuple[str, str]:
    """Return the safest available candidate backend and a user-facing label.

    This is a capability preview only. The detector reports the verified active
    provider after the model session is actually created.
    """

    requested = requested_device.lower().strip()
    if requested not in {"auto", "cpu", "gpu"}:
        requested = "auto"
    caps = inspect_runtime_capabilities(requested)
    gpu_name = caps.nvidia_gpus[0] if caps.nvidia_gpus else "Windows GPU"
    providers = caps.onnxruntime_providers

    if requested != "cpu" and "DmlExecutionProvider" in providers:
        return "onnxruntime_dml", f"GPU · {gpu_name} · ONNX Runtime DirectML"
    if requested != "cpu" and os.getenv("PVR_ALLOW_CUDA", "0") == "1" and "CUDAExecutionProvider" in providers:
        return "onnxruntime_cuda", f"GPU · {gpu_name} · ONNX Runtime CUDA (advanced opt-in)"
    if requested == "gpu":
        if caps.nvidia_gpus:
            return "cpu", "CPU fallback · GPU는 감지됐지만 안전한 DirectML 실행 백엔드가 설치되지 않음"
        return "cpu", "CPU fallback · GPU 실행 백엔드가 감지되지 않음"
    return "cpu", f"CPU · {caps.cpu_name}"


def combined_processing_summary(person_device: str, ball_device: str | None) -> str:
    if ball_device is None:
        return f"CPU · 사람 검출: {person_device} · 공 검출: 비활성"
    person_gpu = "GPU" in person_device and "CPU fallback" not in person_device
    ball_gpu = "GPU" in ball_device and "CPU fallback" not in ball_device
    if person_gpu and ball_gpu:
        prefix = "GPU"
    elif person_gpu or ball_gpu:
        prefix = "혼합"
    else:
        prefix = "CPU"
    return f"{prefix} · 사람 검출: {person_device} · 공 검출: {ball_device}"
