from __future__ import annotations

import math
from bisect import bisect_left, bisect_right
from collections import defaultdict
from statistics import median

from picklary_rating.analysis.court import CourtCalibration
from picklary_rating.analysis.rally_state import DoublesScoreState
from picklary_rating.models import BallEvent, BallObservation, HitEvent, PlayerObservation, Point2D, Rally, ShotEvent


def _distance(a: Point2D, b: Point2D) -> float:
    return math.hypot(a.x-b.x, a.y-b.y)


def _velocity(a: BallObservation, b: BallObservation) -> tuple[float, float] | None:
    dt = b.time_s - a.time_s
    if dt <= 0:
        return None
    return ((b.image_position.x-a.image_position.x)/dt, (b.image_position.y-a.image_position.y)/dt)


def _angle_change(v1: tuple[float, float], v2: tuple[float, float]) -> float:
    n1, n2 = math.hypot(*v1), math.hypot(*v2)
    if n1 < 1e-6 or n2 < 1e-6:
        return 0.0
    cosine = max(-1.0, min(1.0, (v1[0]*v2[0]+v1[1]*v2[1])/(n1*n2)))
    return math.degrees(math.acos(cosine))


def _anchor_speed_mph(a: Point2D | None, at: float, b: Point2D | None, bt: float) -> tuple[float | None, bool]:
    if a is None or b is None or bt <= at:
        return None, False
    mph = _distance(a, b)/(bt-at)*0.681818
    return mph, not (1.0 <= mph <= 90.0)


def _nearest_player(players_by_frame: dict[int, list[PlayerObservation]], frame: int, ball: Point2D) -> tuple[PlayerObservation | None, float]:
    candidates = players_by_frame.get(frame, [])
    if not candidates:
        frames = sorted(players_by_frame, key=lambda x: abs(x-frame))[:3]
        candidates = [p for f in frames if abs(f-frame) <= 3 for p in players_by_frame[f]]
    best: tuple[PlayerObservation | None, float] = (None, float("inf"))
    for p in candidates:
        height = max(20.0, (p.bbox[3]-p.bbox[1]) if p.bbox else 100.0)
        distance_norm = math.hypot(ball.x-p.image_center.x, ball.y-p.image_center.y)/height
        if distance_norm < best[1]:
            best = (p, distance_norm)
    return best


def detect_ball_events(
    balls: list[BallObservation],
    players: list[PlayerObservation],
    calibration: CourtCalibration,
    window_s: float = 0.05,
    min_hit_gap_s: float = 0.10,
    audio_onsets_s: list[float] | None = None,
    audio_match_window_s: float = 0.045,
) -> list[BallEvent]:
    balls = sorted([b for b in balls if not b.predicted], key=lambda x: x.time_s)
    if len(balls) < 5:
        return []
    times = [b.time_s for b in balls]
    players_by_frame: dict[int, list[PlayerObservation]] = defaultdict(list)
    for p in players:
        players_by_frame[p.frame_index].append(p)
    events: list[BallEvent] = []
    last_hit_by_player: dict[str, float] = {}
    last_any_event = -999.0
    onset_times = sorted(audio_onsets_s or [])

    def audio_match(t: float) -> tuple[bool, float | None]:
        if not onset_times:
            return False, None
        pos = bisect_left(onset_times, t)
        candidates = onset_times[max(0, pos-1): min(len(onset_times), pos+2)]
        if not candidates:
            return False, None
        nearest = min(candidates, key=lambda x: abs(x-t))
        delta = abs(nearest-t)
        return delta <= audio_match_window_s, delta

    for idx, current in enumerate(balls):
        left_start = bisect_left(times, current.time_s-window_s)
        right_end = bisect_right(times, current.time_s+window_s)
        before = [x for x in balls[left_start:idx] if x.tracklet_id == current.tracklet_id]
        after = [x for x in balls[idx+1:right_end] if x.tracklet_id == current.tracklet_id]
        if len(before) < 2 or len(after) < 2:
            continue
        v_in = _velocity(before[0], before[-1]); v_out = _velocity(after[0], after[-1])
        if v_in is None or v_out is None:
            continue
        angle = _angle_change(v_in, v_out)
        player, player_distance = _nearest_player(players_by_frame, current.frame_index, current.image_position)
        onset_match, onset_delta = audio_match(current.time_s)

        downward_to_upward = v_in[1] > 10 and v_out[1] < -10
        horizontal_continuity = (v_in[0] == 0 or v_out[0] == 0 or v_in[0]*v_out[0] >= 0) and abs(v_out[0]-v_in[0]) < max(250.0, abs(v_in[0])*1.8)
        away_from_players = player is None or player_distance > 0.85
        bounce_score = 0.0
        if downward_to_upward: bounce_score += 0.50
        if horizontal_continuity: bounce_score += 0.20
        if away_from_players: bounce_score += 0.20
        if 20 <= angle <= 150: bounce_score += 0.10
        if onset_match: bounce_score -= 0.12
        elif onset_times: bounce_score += 0.04

        speed_in, speed_out = math.hypot(*v_in), math.hypot(*v_out)
        speed_jump = speed_out/max(speed_in, 1.0)
        direction_reversal = angle >= 38.0
        near_player = player is not None and player_distance <= 0.75
        departure_ok = False
        side_ok = False
        if player is not None:
            out_vec = (v_out[0], v_out[1])
            from_player = (current.image_position.x-player.image_center.x, current.image_position.y-player.image_center.y)
            departure_ok = out_vec[0]*from_player[0]+out_vec[1]*from_player[1] >= 0
            try:
                weak_ground = calibration.image_to_ground(current.image_position)
                side_ok = calibration.side(weak_ground) == calibration.side(player.court_position) if player.court_position else True
            except Exception:
                side_ok = True
        hit_score = 0.0
        if near_player: hit_score += 0.38
        if direction_reversal or speed_jump >= 1.25: hit_score += 0.28
        if departure_ok: hit_score += 0.20
        if side_ok: hit_score += 0.14
        if onset_match: hit_score += 0.18
        elif onset_times: hit_score -= 0.06

        if current.time_s-last_any_event < 0.045:
            continue
        if bounce_score >= 0.65 and bounce_score > hit_score+0.08:
            court = calibration.image_to_ground(current.image_position)
            current.court_position = court
            current.court_position_source = "bounce_anchor"
            events.append(BallEvent(current.frame_index, current.time_s, "bounce", min(0.98, bounce_score), current.image_position, court, None,
                                    {"angle_deg": angle, "player_distance_norm": player_distance, "tracklet_id": current.tracklet_id, "audio_onset_match": onset_match, "audio_delta_s": onset_delta}))
            last_any_event = current.time_s
        elif hit_score >= 0.58 and player is not None:
            previous_same = last_hit_by_player.get(player.label, -999.0)
            if current.time_s-previous_same < 0.18:
                continue
            if events and events[-1].event_type == "hit" and current.time_s-events[-1].time_s < min_hit_gap_s and events[-1].player_label == player.label:
                continue
            contact = player.court_position
            if contact is not None:
                net_y = calibration.length_ft/2
                offset = 1.0 if contact.y < net_y else -1.0
                contact = Point2D(contact.x, contact.y+offset)
            current.court_position = contact
            current.court_position_source = "hit_contact"
            events.append(BallEvent(current.frame_index, current.time_s, "hit", min(0.98, hit_score), current.image_position, contact, player.label,
                                    {"angle_deg": angle, "speed_ratio": speed_jump, "player_distance_norm": player_distance, "tracklet_id": current.tracklet_id, "audio_onset_match": onset_match, "audio_delta_s": onset_delta}))
            last_hit_by_player[player.label] = current.time_s
            last_any_event = current.time_s
        elif max(bounce_score, hit_score) >= 0.50:
            events.append(BallEvent(current.frame_index, current.time_s, "ambiguous", max(bounce_score, hit_score), current.image_position, None,
                                    player.label if player else None, {"bounce_score": bounce_score, "hit_score": hit_score, "tracklet_id": current.tracklet_id, "audio_onset_match": onset_match, "audio_delta_s": onset_delta}))
            last_any_event = current.time_s
    return events


def detect_hit_events(
    balls: list[BallObservation],
    players: list[PlayerObservation],
    min_hit_gap_s: float = 0.10,
    calibration: CourtCalibration | None = None,
    window_s: float = 0.05,
) -> list[HitEvent]:
    if calibration is None:
        return []
    events = detect_ball_events(balls, players, calibration, window_s, min_hit_gap_s)
    hits = []
    for e in events:
        if e.event_type != "hit" or not e.player_label:
            continue
        hits.append(HitEvent(e.frame_index, e.time_s, e.player_label, e.court_position, None, None,
                             e.diagnostics.get("angle_deg"), e.confidence, image_position=e.image_position,
                             tracklet_id=int(e.diagnostics.get("tracklet_id", 0))))
    return hits


def _trajectory_profile(speed: float | None, start: Point2D | None, end: Point2D | None, duration_s: float) -> str:
    if speed is None:
        return "unknown"
    if speed >= 38: return "flat-fast"
    if start and end and duration_s >= 1.2 and _distance(start, end) >= 20: return "high-arc/lob-like"
    if speed <= 18: return "soft-arc"
    return "neutral-arc"


def _classify_shot(role: str, hitter_pos: Point2D | None, end_pos: Point2D | None, speed: float | None, calibration: CourtCalibration) -> str:
    if role == "serve": return "serve"
    if role == "return": return "return"
    if role == "third":
        if speed is not None and speed >= 30: return "third_drive"
        if end_pos is not None and abs(end_pos.y-calibration.length_ft/2) <= calibration.kitchen_ft+2: return "third_drop"
        return "unknown"
    if hitter_pos is None: return "unknown"
    zone = calibration.zone(hitter_pos)
    if zone == "kitchen":
        if speed is not None and speed >= 35: return "speedup"
        if speed is not None and speed <= 18: return "dink"
        return "volley"
    if zone == "transition":
        return "reset" if speed is not None and speed <= 20 else "drive"
    if speed is not None and speed >= 32: return "drive"
    if end_pos is not None and abs(end_pos.y-calibration.length_ft/2) <= calibration.kitchen_ft+2: return "drop"
    return "unknown"


def build_rallies_and_shots(
    hits: list[HitEvent],
    balls: list[BallObservation],
    calibration: CourtCalibration,
    rally_gap_s: float = 3.0,
    ball_events: list[BallEvent] | None = None,
    initial_state: DoublesScoreState | None = None,
) -> list[Rally]:
    if not hits:
        return []
    events = sorted(ball_events or [], key=lambda e: e.time_s)
    groups: list[list[HitEvent]] = [[]]
    for hit in sorted(hits, key=lambda h: h.time_s):
        if groups[-1] and hit.time_s-groups[-1][-1].time_s > rally_gap_s:
            groups.append([])
        groups[-1].append(hit)
    state = initial_state or DoublesScoreState()
    rallies = []
    for rally_idx, group in enumerate(groups, 1):
        shots = []
        rally_end = group[-1].time_s+1.5
        bounces = [e for e in events if e.event_type == "bounce" and group[0].time_s <= e.time_s <= rally_end]
        for i, hit in enumerate(group, 1):
            end_time = group[i].time_s if i < len(group) else rally_end
            anchors = [e for e in bounces if hit.time_s < e.time_s <= end_time and e.court_position is not None]
            end_pos = anchors[0].court_position if anchors else (group[i].court_position if i < len(group) else None)
            if calibration.speed_metrics_enabled:
                speed, outlier = _anchor_speed_mph(hit.court_position, hit.time_s, end_pos, anchors[0].time_s if anchors else end_time)
            else:
                speed, outlier = None, False
            role = state.expected_role(i)
            shot_type = _classify_shot(role, hit.court_position, end_pos, None if outlier else speed, calibration)
            stroke_side = "unknown"
            if hit.court_position and end_pos:
                stroke_side = "crosscourt" if abs(end_pos.x-hit.court_position.x) >= calibration.width_ft*0.30 else "middle_or_line"
            outcome = "in_play" if end_pos is not None else "unknown_tracking_loss"
            shots.append(ShotEvent(
                rally_index=rally_idx, shot_index=i, time_s=hit.time_s, player_label=hit.player_label,
                shot_type=shot_type, stroke_side=stroke_side, start_position=hit.court_position, end_position=end_pos,
                estimated_speed_mph=None if outlier else speed, trajectory_profile=_trajectory_profile(None if outlier else speed, hit.court_position, end_pos, end_time-hit.time_s),
                outcome=outcome, confidence=min(hit.confidence, 0.82 if speed is not None and not outlier else 0.55),
                speed_source="hit_to_bounce_horizontal" if anchors else None, speed_outlier=outlier,
            ))
        rallies.append(Rally(rally_idx, max(0.0, group[0].time_s-0.5), rally_end, shots, None, None, bounces))
    return rallies
