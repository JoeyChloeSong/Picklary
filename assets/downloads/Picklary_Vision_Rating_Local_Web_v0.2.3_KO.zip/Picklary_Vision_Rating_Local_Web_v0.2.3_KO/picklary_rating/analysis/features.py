from __future__ import annotations

from bisect import bisect_left, bisect_right
import math
from collections import Counter
from statistics import median
from typing import Any

import numpy as np

from picklary_rating.models import PlayerObservation, Rally, ShotEvent


def _clip(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def _distance(a: tuple[float, float], b: tuple[float, float]) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])




def _robust_motion_path(
    obs: list[PlayerObservation],
    sample_hz: float = 5.0,
    max_speed_ft_s: float = 24.0,
) -> tuple[float, list[float], int]:
    """Estimate path length without accumulating detector jitter every frame.

    v0.1.5 summed 15 Hz foot-point noise directly, which inflated the benchmark
    player's 1,356 ft path to more than 3,300 ft. This version bins observations
    to 5 Hz, uses per-bin medians, applies a short median smoother, and removes a
    small distance deadband before summing.
    """
    valid = [o for o in obs if o.court_position is not None]
    if len(valid) < 2:
        return 0.0, [], 0
    bins: dict[int, list[tuple[float, float, float]]] = {}
    for o in valid:
        key = int(math.floor(o.time_s * sample_hz))
        bins.setdefault(key, []).append((o.time_s, o.court_position.x, o.court_position.y))
    points: list[tuple[float, float, float]] = []
    for key in sorted(bins):
        values = bins[key]
        points.append((
            float(np.median([v[0] for v in values])),
            float(np.median([v[1] for v in values])),
            float(np.median([v[2] for v in values])),
        ))
    if len(points) >= 5:
        arr = np.asarray([[p[1], p[2]] for p in points], float)
        padded = np.pad(arr, ((2, 2), (0, 0)), mode="edge")
        smooth = np.stack([np.median(padded[i:i + 5], axis=0) for i in range(len(arr))])
        points = [(points[i][0], float(smooth[i, 0]), float(smooth[i, 1])) for i in range(len(points))]
    total = 0.0
    speeds: list[float] = []
    accepted = 0
    deadband_ft = 0.07
    for prev, cur in zip(points, points[1:]):
        dt = cur[0] - prev[0]
        if dt <= 0 or dt > 0.65:
            continue
        dist = math.hypot(cur[1] - prev[1], cur[2] - prev[2])
        adjusted = max(0.0, dist - deadband_ft)
        speed = adjusted / dt
        if speed <= max_speed_ft_s:
            total += adjusted
            speeds.append(speed)
            accepted += 1
    return total, speeds, accepted


def _positioning_metrics(obs: list[PlayerObservation], net_y: float, kitchen_ft: float) -> dict[str, Any]:
    if not obs:
        return {
            "observed_position_seconds": 0.0,
            "lateral_coverage_ft": None,
            "depth_coverage_ft": None,
            "nvz_line_distance_median_ft": None,
            "active_movement_rate": None,
            "high_intensity_movement_rate": None,
            "movement_burst_count": 0,
            "position_samples": 0,
        }
    xy = np.asarray(
        [[o.court_position.x, o.court_position.y] for o in obs if o.court_position is not None],
        float,
    )
    if len(xy) == 0:
        return {"observed_position_seconds": 0.0, "position_samples": 0}
    lateral = float(np.quantile(xy[:, 0], 0.90) - np.quantile(xy[:, 0], 0.10)) if len(xy) >= 5 else 0.0
    depth = float(np.quantile(xy[:, 1], 0.90) - np.quantile(xy[:, 1], 0.10)) if len(xy) >= 5 else 0.0
    line_y = np.where(xy[:, 1] < net_y, net_y - kitchen_ft, net_y + kitchen_ft)
    line_dist = np.abs(xy[:, 1] - line_y)
    speeds: list[float] = []
    burst_count = 0
    active = False
    for prev, cur in zip(obs, obs[1:]):
        if prev.court_position is None or cur.court_position is None:
            continue
        dt = cur.time_s - prev.time_s
        if dt <= 0 or dt > 0.75:
            continue
        speed = _distance(prev.court_position.as_tuple(), cur.court_position.as_tuple()) / dt
        if speed > 24.0:
            continue
        speeds.append(speed)
        now_active = speed >= 5.0
        if now_active and not active:
            burst_count += 1
        active = now_active
    observed_seconds = max(0.0, obs[-1].time_s - obs[0].time_s) if len(obs) >= 2 else 0.0
    return {
        "observed_position_seconds": round(observed_seconds, 2),
        "lateral_coverage_ft": round(lateral, 2),
        "depth_coverage_ft": round(depth, 2),
        "nvz_line_distance_median_ft": round(float(np.median(line_dist)), 2),
        "nvz_ready_rate": round(float(np.mean(line_dist <= 2.5)), 4),
        "active_movement_rate": round(sum(1 for v in speeds if v >= 1.5) / len(speeds), 4) if speeds else None,
        "high_intensity_movement_rate": round(sum(1 for v in speeds if v >= 7.0) / len(speeds), 4) if speeds else None,
        "movement_burst_count": burst_count,
        "position_samples": len(xy),
    }


def _is_in(shot: ShotEvent) -> bool:
    return shot.outcome in {"in_play", "winner"}


def _depth_bucket(shot: ShotEvent, court_length_ft: float) -> str | None:
    """Classify landing depth by distance from the receiving baseline.

    The thresholds are transparent Picklary heuristics, not PB Vision thresholds:
    deep <= 7 ft from baseline, medium <= 14 ft, otherwise shallow.
    """
    if shot.end_position is None:
        return None
    d = min(float(shot.end_position.y), float(court_length_ft - shot.end_position.y))
    if d <= 7.0:
        return "deep"
    if d <= 14.0:
        return "medium"
    return "shallow"


def _depth_distribution(shots: list[ShotEvent], court_length_ft: float) -> dict[str, Any]:
    counts = Counter()
    accepted: list[ShotEvent] = []
    for shot in shots:
        bucket = _depth_bucket(shot, court_length_ft)
        if bucket is not None and _is_in(shot):
            counts[bucket] += 1
            accepted.append(shot)
    total = sum(counts.values())
    estimated_count = sum(
        1 for shot in accepted if shot.trajectory_profile.startswith("franklin-hybrid-estimated")
    )
    return {
        "counts": {k: int(counts.get(k, 0)) for k in ("deep", "medium", "shallow")},
        "rates": {
            k: (round(counts.get(k, 0) / total, 4) if total else None)
            for k in ("deep", "medium", "shallow")
        },
        "sample_count": int(total),
        "estimated_sample_count": int(estimated_count),
        "visual_sample_count": int(total - estimated_count),
        "source": (
            "hybrid_estimate" if estimated_count and estimated_count < total
            else "receiver_geometry_estimate" if estimated_count
            else "visual_landing" if total
            else "none"
        ),
    }


def _shot_group_speed(shots: list[ShotEvent]) -> dict[str, Any]:
    accepted = [
        s for s in shots
        if s.estimated_speed_mph is not None and not s.speed_outlier
    ]
    values = [float(s.estimated_speed_mph) for s in accepted]
    estimated_count = sum(1 for s in accepted if s.speed_source == "contact_interval_physics_estimate")
    visual_count = len(accepted) - estimated_count
    return {
        "median_mph": round(median(values), 1) if values else None,
        "top_mph": round(max(values), 1) if values else None,
        "sample_count": len(values),
        "estimated_sample_count": estimated_count,
        "visual_sample_count": visual_count,
        "source": (
            "hybrid_estimate" if estimated_count and visual_count
            else "contact_interval_estimate" if estimated_count
            else "visual_trajectory" if visual_count
            else "none"
        ),
    }


def _third_shot_quality(shots: list[ShotEvent], court_length_ft: float, net_y: float, kitchen_ft: float) -> float | None:
    """Independent third-shot quality proxy on a 0-100 scale.

    This intentionally does not reproduce PB Vision's proprietary model. It rewards
    an in-play third shot, a drop landing near the opponent NVZ, a deep drive, and
    sufficient confidence. Tracking loss is excluded rather than treated as an error.
    """
    third = [s for s in shots if s.shot_type in {"third_drop", "third_drive"}]
    if not third:
        return None
    values: list[float] = []
    for shot in third:
        if shot.outcome == "unknown_tracking_loss":
            continue
        if shot.outcome in {"error_net", "error_out", "error_kitchen"}:
            values.append(0.0)
            continue
        score = 55.0
        if shot.outcome == "winner":
            score += 20.0
        if shot.shot_type == "third_drop" and shot.end_position is not None:
            target_line = net_y - kitchen_ft if shot.end_position.y < net_y else net_y + kitchen_ft
            miss = abs(shot.end_position.y - target_line)
            score += max(0.0, 25.0 - miss * 4.0)
        elif shot.shot_type == "third_drive":
            if shot.estimated_speed_mph is not None:
                score += _clip((shot.estimated_speed_mph - 20.0) * 0.8, 0.0, 18.0)
            bucket = _depth_bucket(shot, court_length_ft)
            score += {"deep": 12.0, "medium": 6.0, "shallow": 0.0}.get(bucket or "", 0.0)
        score *= 0.75 + 0.25 * _clip(float(shot.confidence), 0.0, 1.0)
        values.append(_clip(score, 0.0, 100.0))
    return round(sum(values) / len(values), 1) if values else None


def _trajectory_export(shots: list[ShotEvent], limit: int = 300) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for shot in shots[:limit]:
        if shot.start_position is None or shot.end_position is None:
            continue
        output.append(
            {
                "rally_index": shot.rally_index,
                "shot_index": shot.shot_index,
                "time_s": round(float(shot.time_s), 3),
                "shot_type": shot.shot_type,
                "start": [round(shot.start_position.x, 3), round(shot.start_position.y, 3)],
                "end": [round(shot.end_position.x, 3), round(shot.end_position.y, 3)],
                "speed_mph": shot.estimated_speed_mph,
                "trajectory_profile": shot.trajectory_profile,
                "outcome": shot.outcome,
                "confidence": round(float(shot.confidence), 3),
            }
        )
    return output


def extract_player_metrics(
    player_label: str,
    observations: list[PlayerObservation],
    rallies: list[Rally],
    duration_s: float,
    fps: float,
    person_stride: int,
    net_y: float = 22.0,
    kitchen_ft: float = 7.0,
    max_speed_ft_s: float = 24.0,
) -> dict[str, Any]:
    obs = sorted(
        [o for o in observations if o.label == player_label and o.court_position is not None],
        key=lambda x: x.time_s,
    )
    times = [o.time_s for o in obs]
    shots = [s for rally in rallies for s in rally.shots if s.player_label == player_label]
    shot_types = Counter(s.shot_type for s in shots)
    speeds = [s.estimated_speed_mph for s in shots if s.estimated_speed_mph is not None and not s.speed_outlier]
    confidences = [s.confidence for s in shots]

    total_distance, movement_speeds, motion_segments = _robust_motion_path(
        obs, sample_hz=5.0, max_speed_ft_s=max_speed_ft_s
    )

    kitchen_frames = sum(1 for o in obs if o.court_position and abs(o.court_position.y - net_y) <= kitchen_ft)
    stable_scores: list[float] = []
    for shot in shots:
        lo, hi = bisect_left(times, shot.time_s - 0.15), bisect_right(times, shot.time_s + 0.15)
        window = [o.court_position for o in obs[lo:hi] if o.court_position is not None]
        if len(window) < 3:
            continue
        xy = np.asarray([[p.x, p.y] for p in window], float)
        variance = float(np.mean(np.var(xy, axis=0)))
        stable_scores.append(1.0 if variance <= 0.18 else max(0.0, 1.0 - variance / 1.5))

    observed_outcomes = [s for s in shots if s.outcome != "unknown_tracking_loss"]
    errors = sum(1 for s in observed_outcomes if s.outcome in {"error_net", "error_out", "error_kitchen"})
    in_count = sum(1 for s in observed_outcomes if _is_in(s))
    third_total = sum(shot_types[k] for k in ("third_drive", "third_drop"))
    attack_total = sum(shot_types[k] for k in ("drive", "speedup", "overhead_smash", "third_drive"))
    soft_total = sum(shot_types[k] for k in ("dink", "drop", "reset", "third_drop"))
    tactical_opportunities = attack_total + soft_total
    directional = [s for s in shots if s.stroke_side != "unknown"]
    crosscourt = sum(1 for s in directional if s.stroke_side == "crosscourt")
    expected_obs = duration_s * fps / max(1, person_stride)
    coverage = len(obs) / max(1.0, expected_obs)
    positioning = _positioning_metrics(obs, net_y, kitchen_ft)

    serve_shots = [s for s in shots if s.shot_type == "serve"]
    return_shots = [s for s in shots if s.shot_type == "return"]
    drive_shots = [s for s in shots if s.shot_type in {"drive", "third_drive", "speedup", "overhead_smash"}]
    court_length_ft = net_y * 2.0
    serve_observed = [s for s in serve_shots if s.outcome != "unknown_tracking_loss"]
    return_observed = [s for s in return_shots if s.outcome != "unknown_tracking_loss"]
    serve_in = sum(1 for s in serve_observed if _is_in(s))
    return_in = sum(1 for s in return_observed if _is_in(s))

    return {
        "shot_count": len(shots),
        "rally_count": sum(1 for rally in rallies if any(s.player_label == player_label for s in rally.shots)),
        "shot_evidence_source": (
            "franklin_audio_motion_hybrid"
            if any(
                s.speed_source in {"audio_motion_proxy", "contact_interval_physics_estimate"}
                or s.trajectory_profile.startswith("franklin-hybrid-estimated")
                for s in shots
            )
            else ("franklin_visual_trajectory" if shots else "none")
        ),
        "proxy_shot_count": sum(
            1 for s in shots
            if s.speed_source in {"audio_motion_proxy", "contact_interval_physics_estimate"}
            or s.trajectory_profile.startswith("franklin-hybrid-estimated")
        ),
        "trajectory_estimated_count": sum(
            1 for s in shots if s.trajectory_profile.startswith("franklin-hybrid-estimated")
        ),
        "speed_estimated_count": sum(
            1 for s in shots if s.speed_source == "contact_interval_physics_estimate"
        ),
        "depth_estimated_count": sum(
            1 for s in shots
            if s.shot_type in {"serve", "return"}
            and s.end_position is not None
            and s.trajectory_profile.startswith("franklin-hybrid-estimated")
        ),
        "observable_shot_count": len(observed_outcomes),
        "shot_in_count": in_count,
        "shot_in_rate": round(in_count / len(observed_outcomes), 4) if observed_outcomes else None,
        "shot_type_counts": dict(shot_types),
        "median_speed_mph": round(median(speeds), 1) if speeds else None,
        "max_speed_mph": round(max(speeds), 1) if speeds else None,
        "speed_sample_count": len(speeds),
        "speed_outlier_count": sum(1 for s in shots if s.speed_outlier),
        "serve_total": len(serve_observed),
        "serve_in_count": serve_in,
        "serve_in_rate": round(serve_in / len(serve_observed), 4) if serve_observed else None,
        "return_total": len(return_observed),
        "return_in_count": return_in,
        "return_in_rate": round(return_in / len(return_observed), 4) if return_observed else None,
        "serve_depth": _depth_distribution(serve_shots, court_length_ft),
        "return_depth": _depth_distribution(return_shots, court_length_ft),
        "serve_speed": _shot_group_speed(serve_shots),
        "drive_speed": _shot_group_speed(drive_shots),
        "third_shot_quality": _third_shot_quality(shots, court_length_ft, net_y, kitchen_ft),
        "error_proxy_rate": round(errors / len(observed_outcomes), 4) if observed_outcomes else None,
        "third_drop_rate": round(shot_types["third_drop"] / third_total, 4) if third_total else None,
        "third_drive_rate": round(shot_types["third_drive"] / third_total, 4) if third_total else None,
        "attack_rate": round(attack_total / tactical_opportunities, 4) if tactical_opportunities else None,
        "soft_game_rate": round(soft_total / tactical_opportunities, 4) if tactical_opportunities else None,
        "crosscourt_rate": round(crosscourt / len(directional), 4) if directional else None,
        "distance_covered_ft": round(total_distance, 1) if obs else None,
        "distance_method": "5hz_median_smoothed_deadband_v2",
        "distance_motion_segments": motion_segments,
        "median_movement_speed_ft_s": round(median(movement_speeds), 2) if movement_speeds else None,
        "peak_movement_speed_ft_s": round(max(movement_speeds), 2) if movement_speeds else None,
        "kitchen_presence_rate": round(kitchen_frames / len(obs), 4) if obs else None,
        "stable_at_contact_rate": round(sum(stable_scores) / len(stable_scores), 4) if stable_scores else None,
        "tracking_coverage": round(_clip(coverage, 0, 1), 4),
        "mean_identity_confidence": round(sum(o.identity_confidence for o in obs) / len(obs), 4) if obs else None,
        "mean_shot_confidence": round(sum(confidences) / len(confidences), 4) if confidences else None,
        "side_observation_counts": {
            "far": sum(1 for o in obs if o.court_position and o.court_position.y < net_y),
            "near": sum(1 for o in obs if o.court_position and o.court_position.y >= net_y),
        },
        "shot_trajectories": _trajectory_export(shots),
        **positioning,
    }


def all_player_metrics(
    observations: list[PlayerObservation],
    rallies: list[Rally],
    duration_s: float,
    fps: float,
    person_stride: int,
    net_y: float = 22.0,
    kitchen_ft: float = 7.0,
    max_speed_ft_s: float = 24.0,
) -> dict[str, dict[str, Any]]:
    return {
        label: extract_player_metrics(
            label,
            observations,
            rallies,
            duration_s,
            fps,
            person_stride,
            net_y,
            kitchen_ft,
            max_speed_ft_s,
        )
        for label in "ABCD"
    }
