from __future__ import annotations

from dataclasses import dataclass, field
import math

import cv2
import numpy as np
from scipy.optimize import linear_sum_assignment

from picklary_rating.models import Point2D


@dataclass(slots=True)
class IdentityPrototype:
    label: str
    embedding: np.ndarray
    samples: int = 1
    last_side: str | None = None

    def update(self, embedding: np.ndarray, side: str) -> None:
        alpha = min(0.25, 1.0 / (self.samples + 1))
        self.embedding = (1 - alpha) * self.embedding + alpha * embedding
        norm = np.linalg.norm(self.embedding)
        if norm > 0:
            self.embedding /= norm
        self.samples += 1
        self.last_side = side


def appearance_embedding(frame: np.ndarray, xyxy: tuple[float, float, float, float]) -> np.ndarray:
    x1, y1, x2, y2 = map(int, xyxy)
    h, w = frame.shape[:2]
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(w, x2), min(h, y2)
    crop = frame[y1:max(y1 + 1, int(y1 + (y2 - y1) * 0.70)), x1:x2]
    if crop.size == 0:
        return np.zeros(96, dtype=np.float32)
    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    hist = cv2.calcHist([hsv], [0, 1], None, [16, 6], [0, 180, 0, 256]).reshape(-1).astype(np.float32)
    norm = np.linalg.norm(hist)
    return hist / norm if norm > 0 else hist


class PlayerIdentityManager:
    """Maintains A/B/C/D identity independent of transient detector track IDs."""

    def __init__(self, net_y: float = 22.0):
        self.net_y = net_y
        self.prototypes: dict[str, IdentityPrototype] = {}
        self.track_to_label: dict[int, str] = {}
        self.last_positions: dict[str, Point2D] = {}
        self.id_switches = 0
        self.court_side_swapped = False


    def seed_prototype(self, label: str, embedding: np.ndarray, position: Point2D) -> None:
        side = "far" if position.y < self.net_y else "near"
        emb = embedding.astype(np.float32, copy=True)
        norm = np.linalg.norm(emb)
        if norm > 0:
            emb /= norm
        self.prototypes[label] = IdentityPrototype(label, emb, 1, side)
        self.last_positions[label] = position

    def bind_track(self, track_id: int, label: str) -> None:
        previous = self.track_to_label.get(track_id)
        if previous is not None and previous != label:
            self.id_switches += 1
        self.track_to_label[track_id] = label

    def _initial_labels(self, detections: list[tuple[int, Point2D, np.ndarray]]) -> dict[int, str]:
        far = sorted([d for d in detections if d[1].y < self.net_y], key=lambda d: d[1].x)
        near = sorted([d for d in detections if d[1].y >= self.net_y], key=lambda d: d[1].x)
        mapping: dict[int, str] = {}
        for group, labels in ((far, ("A", "B")), (near, ("C", "D"))):
            for item, label in zip(group[:2], labels):
                track_id, pos, emb = item
                mapping[track_id] = label
                self.prototypes[label] = IdentityPrototype(label, emb.copy(), 1, "far" if pos.y < self.net_y else "near")
                self.last_positions[label] = pos
        return mapping

    def assign(self, detections: list[tuple[int, Point2D, np.ndarray]]) -> dict[int, tuple[str, float]]:
        if not detections:
            return {}
        if len(self.prototypes) < 4 and len(detections) >= 4:
            self.track_to_label.update(self._initial_labels(detections))

        labels = sorted(self.prototypes)
        unassigned = [d for d in detections if d[0] not in self.track_to_label]
        available = [l for l in labels if l not in {self.track_to_label.get(d[0]) for d in detections}]
        if unassigned and available:
            cost = np.zeros((len(unassigned), len(available)), float)
            for i, (_, pos, emb) in enumerate(unassigned):
                side = "far" if pos.y < self.net_y else "near"
                for j, label in enumerate(available):
                    proto = self.prototypes[label]
                    appearance = 1.0 - float(np.clip(np.dot(emb, proto.embedding), 0, 1))
                    last = self.last_positions.get(label)
                    position_cost = min(1.5, math.hypot(pos.x-last.x, pos.y-last.y) / 20.0) if last else 0.5
                    team_side_penalty = 0.0
                    if proto.last_side and proto.last_side != side:
                        team_side_penalty = 0.35
                    cost[i, j] = 0.62 * appearance + 0.28 * position_cost + team_side_penalty
            rows, cols = linear_sum_assignment(cost)
            for i, j in zip(rows, cols):
                if cost[i, j] <= 1.25:
                    track_id = unassigned[i][0]
                    self.track_to_label[track_id] = available[j]

        output: dict[int, tuple[str, float]] = {}
        seen: set[str] = set()
        for track_id, pos, emb in detections:
            label = self.track_to_label.get(track_id)
            if label is None or label in seen:
                continue
            seen.add(label)
            proto = self.prototypes.get(label)
            similarity = float(np.clip(np.dot(emb, proto.embedding), 0, 1)) if proto is not None else 0.3
            side = "far" if pos.y < self.net_y else "near"
            if proto is not None:
                proto.update(emb, side)
            self.last_positions[label] = pos
            output[track_id] = (label, similarity)
        return output
