from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any

import cv2
import numpy as np
from scipy.optimize import differential_evolution

from picklary_rating.models import Point2D


@dataclass(slots=True)
class LensProfile:
    profile_id: str
    distortion: np.ndarray | None
    requires_user_calibration: bool
    camera_matrix: np.ndarray | None = None
    source: str = "profile"
    notes: str | None = None


class LensCorrector:
    """Cached-map lens correction.

    `cv2.undistort` recalculates maps for every frame. This class calculates the
    map once and reuses `cv2.remap`, which is necessary for long videos.
    """

    def __init__(self, camera_matrix: np.ndarray, distortion: np.ndarray | None, image_size: tuple[int, int]):
        self.camera_matrix = camera_matrix.astype(np.float64)
        self.distortion = None if distortion is None else distortion.astype(np.float64).reshape(-1, 1)
        self.image_size = (int(image_size[0]), int(image_size[1]))
        self.map1: np.ndarray | None = None
        self.map2: np.ndarray | None = None
        if self.active:
            self.map1, self.map2 = cv2.initUndistortRectifyMap(
                self.camera_matrix,
                self.distortion,
                None,
                self.camera_matrix,
                self.image_size,
                cv2.CV_32FC1,
            )

    @property
    def active(self) -> bool:
        return self.distortion is not None and bool(np.any(np.abs(self.distortion) > 1e-10))

    def undistort_frame(self, frame: np.ndarray) -> np.ndarray:
        if not self.active or self.map1 is None or self.map2 is None:
            return frame
        return cv2.remap(frame, self.map1, self.map2, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)

    def undistort_points(self, points: list[Point2D]) -> list[Point2D]:
        if not self.active or not points:
            return list(points)
        arr = np.asarray([[[p.x, p.y]] for p in points], dtype=np.float64)
        corrected = cv2.undistortPoints(arr, self.camera_matrix, self.distortion, P=self.camera_matrix).reshape(-1, 2)
        return [Point2D(float(x), float(y)) for x, y in corrected]

    def diagnostics(self) -> dict[str, Any]:
        return {
            "active": self.active,
            "camera_matrix": self.camera_matrix.tolist(),
            "distortion": None if self.distortion is None else self.distortion.reshape(-1).tolist(),
            "cached_remap": self.map1 is not None,
        }


def _default_camera_matrix(image_size: tuple[int, int], focal_px: float | None = None) -> np.ndarray:
    width, height = image_size
    focal = float(focal_px if focal_px is not None else width * 0.70)
    return np.asarray([[focal, 0, width / 2], [0, focal, height / 2], [0, 0, 1]], dtype=np.float64)


def load_lens_profile(profile_id: str, image_size: tuple[int, int], profiles_path: str | Path) -> tuple[LensCorrector, LensProfile]:
    payload = json.loads(Path(profiles_path).read_text(encoding="utf-8"))
    entry = next((x for x in payload.get("profiles", []) if x.get("id") == profile_id), None)
    if entry is None:
        raise KeyError(f"Unknown lens profile: {profile_id}")
    coeffs = entry.get("distortion")
    distortion = None if coeffs is None else np.asarray(coeffs, dtype=np.float64)
    focal_ratio = entry.get("focal_ratio")
    K = _default_camera_matrix(image_size, image_size[0] * float(focal_ratio) if focal_ratio else None)
    profile = LensProfile(
        profile_id=profile_id,
        distortion=distortion,
        requires_user_calibration=bool(entry.get("requires_user_calibration", False)),
        camera_matrix=K,
        source="profile",
        notes=entry.get("notes"),
    )
    return LensCorrector(K, distortion, image_size), profile


def load_user_calibration(path: str | Path, image_size: tuple[int, int]) -> tuple[LensCorrector, LensProfile]:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    K = np.asarray(payload["camera_matrix"], dtype=np.float64)
    coeffs = np.asarray(payload["distortion"], dtype=np.float64)
    source_size = payload.get("image_size")
    if source_size and tuple(source_size) != tuple(image_size):
        sx = image_size[0] / float(source_size[0])
        sy = image_size[1] / float(source_size[1])
        K = K.copy()
        K[0, 0] *= sx; K[0, 2] *= sx
        K[1, 1] *= sy; K[1, 2] *= sy
    profile = LensProfile("user_checkerboard", coeffs, False, K, "user", payload.get("notes"))
    return LensCorrector(K, coeffs, image_size), profile


def _point_line_dist(points: np.ndarray, line: np.ndarray) -> np.ndarray:
    vx, vy, x0, y0 = [float(v) for v in line.reshape(-1)]
    norm = max(1e-9, (vx * vx + vy * vy) ** 0.5)
    return np.abs(vy * (points[:, 0] - x0) - vx * (points[:, 1] - y0)) / norm


def court_line_residual_rms(frame: np.ndarray) -> tuple[float, int]:
    """Return RMS perpendicular residual of long straight line point clouds."""
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) if frame.ndim == 3 else frame
    edges = cv2.Canny(gray, 60, 160)
    min_len = max(45, gray.shape[1] // 14)
    segments = cv2.HoughLinesP(edges, 1, np.pi / 360, threshold=45, minLineLength=min_len, maxLineGap=25)
    if segments is None:
        return float("inf"), 0
    yy, xx = np.nonzero(edges)
    all_points = np.column_stack([xx, yy]).astype(np.float32)
    residuals: list[float] = []
    used = 0
    candidates = sorted(
        segments[:, 0, :],
        key=lambda s: float(np.hypot(s[2] - s[0], s[3] - s[1])),
        reverse=True,
    )[:24]
    for x1, y1, x2, y2 in candidates:
        dx, dy = float(x2 - x1), float(y2 - y1)
        length = max(1.0, math_hypot(dx, dy))
        # Select edge points near the finite Hough segment.
        relx, rely = all_points[:, 0] - x1, all_points[:, 1] - y1
        along = (relx * dx + rely * dy) / (length * length)
        perp = np.abs(relx * dy - rely * dx) / length
        mask = (along >= -0.05) & (along <= 1.05) & (perp <= 4.0)
        pts = all_points[mask]
        if len(pts) < 20:
            continue
        line = cv2.fitLine(pts, cv2.DIST_L2, 0, 0.01, 0.01)
        d = _point_line_dist(pts, line)
        residuals.extend(np.clip(d, 0, 10).tolist())
        used += 1
    if used < 4 or not residuals:
        return float("inf"), used
    return float(np.sqrt(np.mean(np.square(residuals)))), used


def math_hypot(x: float, y: float) -> float:
    return float(np.hypot(x, y))


def estimate_radial_distortion_from_lines(frame: np.ndarray) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    """Fallback joint focal/k1/k2 estimate using line-fit residual RMS.

    This is intentionally a fallback, not a substitute for a checkerboard. The
    objective measures perpendicular residuals of court-line point clouds after
    correction, rather than total Hough segment length.
    """
    h, w = frame.shape[:2]

    def evaluate(params: np.ndarray) -> tuple[float, int]:
        focal = float(np.exp(params[0]))
        coeffs = np.asarray([params[1], params[2], 0.0, 0.0, 0.0], dtype=np.float64)
        K = _default_camera_matrix((w, h), focal)
        corrected = cv2.undistort(frame, K, coeffs)
        return court_line_residual_rms(corrected)

    def objective(params: np.ndarray) -> float:
        rms, line_count = evaluate(params)
        if not np.isfinite(rms):
            return 1e5
        return rms + max(0, 8 - line_count) * 0.5

    result = differential_evolution(
        objective,
        bounds=[(np.log(w * 0.28), np.log(w * 1.50)), (-0.50, 0.18), (-0.30, 0.40)],
        seed=19,
        popsize=7,
        maxiter=12,
        polish=True,
        workers=1,
    )
    focal = float(np.exp(result.x[0]))
    coeffs = np.asarray([result.x[1], result.x[2], 0.0, 0.0, 0.0], dtype=np.float64)
    K = _default_camera_matrix((w, h), focal)
    corrected = cv2.undistort(frame, K, coeffs)
    residual, lines = court_line_residual_rms(corrected)
    return K, coeffs, {
        "method": "court_line_residual_joint_focal_k1_k2",
        "residual_rms_px": residual,
        "line_groups": lines,
        "optimizer_success": bool(result.success),
        "objective": float(result.fun),
    }


def build_lens_corrector(
    mode: str,
    image_size: tuple[int, int],
    profiles_path: str | Path,
    profile_id: str,
    user_path: str | Path,
    first_frame: np.ndarray | None = None,
) -> tuple[LensCorrector, LensProfile, dict[str, Any]]:
    if mode == "none":
        K = _default_camera_matrix(image_size)
        profile = LensProfile("none", np.zeros(5), False, K, "none", "Lens correction disabled by user")
        return LensCorrector(K, np.zeros(5), image_size), profile, {"mode": "none", "residual_rms_px": None}
    if mode == "user":
        corrector, profile = load_user_calibration(user_path, image_size)
        return corrector, profile, {"mode": "user", "residual_rms_px": None}
    if mode == "auto":
        if first_frame is None:
            raise ValueError("first_frame is required for automatic lens estimation")
        K, coeffs, diagnostics = estimate_radial_distortion_from_lines(first_frame)
        profile = LensProfile("auto_court_lines", coeffs, False, K, "auto", "Fallback line-based estimate")
        return LensCorrector(K, coeffs, image_size), profile, diagnostics
    corrector, profile = load_lens_profile(profile_id, image_size, profiles_path)
    return corrector, profile, {"mode": "profile", "residual_rms_px": None}
