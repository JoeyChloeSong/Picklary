from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol
import math

import cv2
import numpy as np
from scipy.optimize import linear_sum_assignment

from picklary_rating.analysis.court import CourtCalibration
from picklary_rating.analysis.device import create_ort_session_with_fallback
from picklary_rating.analysis.identity import PlayerIdentityManager, appearance_embedding
from picklary_rating.models import PlayerObservation, Point2D


@dataclass(slots=True)
class PlayerDetection:
    track_id: int
    xyxy: tuple[float, float, float, float]
    confidence: float
    appearance: np.ndarray | None = None


@dataclass(slots=True)
class _RawDetection:
    xyxy: tuple[float, float, float, float]
    confidence: float


class _Detector(Protocol):
    device_label: str
    backend_label: str
    license_label: str

    @property
    def available(self) -> bool: ...
    def detect(self, frame: np.ndarray, calibration: CourtCalibration | None = None) -> list[_RawDetection]: ...


def _iou(a: tuple[float, float, float, float], b: tuple[float, float, float, float]) -> float:
    x1, y1 = max(a[0], b[0]), max(a[1], b[1])
    x2, y2 = min(a[2], b[2]), min(a[3], b[3])
    inter = max(0.0, x2 - x1) * max(0.0, y2 - y1)
    aa = max(0.0, a[2] - a[0]) * max(0.0, a[3] - a[1])
    bb = max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])
    return inter / max(1e-9, aa + bb - inter)


def _nms(dets: list[_RawDetection], threshold: float) -> list[_RawDetection]:
    if not dets:
        return []
    order = sorted(range(len(dets)), key=lambda i: dets[i].confidence, reverse=True)
    keep: list[_RawDetection] = []
    while order:
        i = order.pop(0)
        keep.append(dets[i])
        order = [j for j in order if _iou(dets[i].xyxy, dets[j].xyxy) < threshold]
    return keep


class YoloXOnnxPersonDetector:
    """Apache-2.0 YOLOX ONNX person detector with a far-court tile pass.

    The detector accepts the official YOLOX release format. It tries ONNX Runtime
    first and falls back to OpenCV DNN. No image is forcibly reduced to 960 px;
    the full frame is letterboxed to the model input and the far half of the court
    receives a second enlarged inference pass.
    """

    backend_label = "YOLOX-Nano ONNX + far-court tile"
    license_label = "YOLOX code/weights: Apache-2.0; COCO attribution required"

    def __init__(
        self,
        model_path: str | Path,
        input_size: int = 416,
        confidence: float = 0.22,
        nms_iou: float = 0.45,
        requested_device: str = "auto",
        decoded_output: bool = False,
        tile_enabled: bool = True,
        tile_overlap: float = 0.10,
    ):
        self.model_path = Path(model_path)
        self.input_size = int(input_size)
        self.confidence = float(confidence)
        self.nms_iou = float(nms_iou)
        self.decoded_output = bool(decoded_output)
        self.tile_enabled = bool(tile_enabled)
        self.tile_overlap = float(tile_overlap)
        self.requested_device = requested_device
        self.session = None
        self.net = None
        self.input_name: str | None = None
        self.session_backend = "unavailable"
        self.device_label = "unavailable"
        self.error: str | None = None
        self.runtime_fallbacks: list[str] = []
        if not self.model_path.exists():
            self.error = f"YOLOX ONNX model not found: {self.model_path}"
            return
        try:
            result = create_ort_session_with_fallback(self.model_path, requested_device)
            self.session = result.session
            self.input_name = result.input_name
            self.session_backend = result.backend_key
            self.device_label = result.device_label
            self.runtime_fallbacks.extend(result.attempts)
        except Exception as ort_exc:
            # OpenCV DNN CPU is the last-resort path. The pip OpenCV build does
            # not promise CUDA support, so we never select its CUDA backend here.
            try:
                self.net = cv2.dnn.readNetFromONNX(str(self.model_path))
                self.net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
                self.net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
                self.session_backend = "opencv_cpu"
                self.device_label = f"CPU fallback · ONNX Runtime 초기화 실패: {type(ort_exc).__name__}"
                self.runtime_fallbacks.append(str(ort_exc))
            except Exception as cv_exc:
                self.error = f"ONNX Runtime: {ort_exc}; OpenCV DNN: {cv_exc}"

    @property
    def available(self) -> bool:
        return self.session is not None or self.net is not None

    def _letterbox(self, image: np.ndarray) -> tuple[np.ndarray, float, tuple[int, int]]:
        h, w = image.shape[:2]
        ratio = min(self.input_size / max(1, h), self.input_size / max(1, w))
        nh, nw = max(1, int(round(h * ratio))), max(1, int(round(w * ratio)))
        resized = cv2.resize(image, (nw, nh), interpolation=cv2.INTER_LINEAR)
        canvas = np.full((self.input_size, self.input_size, 3), 114, dtype=np.uint8)
        canvas[:nh, :nw] = resized
        blob = canvas.transpose(2, 0, 1).astype(np.float32)[None]
        return blob, ratio, (w, h)

    @staticmethod
    def _decode_yolox(outputs: np.ndarray, input_size: int) -> np.ndarray:
        # Official YOLOX export without --decode_in_inference.
        strides = [8, 16, 32]
        grids, expanded = [], []
        hsizes = [input_size // s for s in strides]
        wsizes = [input_size // s for s in strides]
        for hsize, wsize, stride in zip(hsizes, wsizes, strides):
            xv, yv = np.meshgrid(np.arange(wsize), np.arange(hsize))
            grid = np.stack((xv, yv), 2).reshape(1, -1, 2)
            grids.append(grid)
            expanded.append(np.full((*grid.shape[:2], 1), stride))
        grid = np.concatenate(grids, 1)
        expanded_stride = np.concatenate(expanded, 1)
        decoded = outputs.copy()
        decoded[..., :2] = (decoded[..., :2] + grid) * expanded_stride
        decoded[..., 2:4] = np.exp(decoded[..., 2:4]) * expanded_stride
        return decoded

    def _infer_crop(self, image: np.ndarray, offset: tuple[int, int] = (0, 0)) -> list[_RawDetection]:
        blob, ratio, (orig_w, orig_h) = self._letterbox(image)
        if self.session is not None:
            try:
                output = self.session.run(None, {self.input_name: blob})[0]
            except Exception as exc:
                if self.session_backend != "cpu":
                    self.runtime_fallbacks.append(f"inference failure: {type(exc).__name__}: {exc}")
                    cpu_result = create_ort_session_with_fallback(self.model_path, "cpu")
                    self.session = cpu_result.session
                    self.input_name = cpu_result.input_name
                    self.session_backend = "cpu"
                    self.device_label = f"CPU fallback · GPU 추론 실패: {type(exc).__name__}"
                    output = self.session.run(None, {self.input_name: blob})[0]
                else:
                    raise
        elif self.net is not None:
            try:
                self.net.setInput(blob)
                output = self.net.forward()
            except cv2.error as exc:
                self.net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
                self.net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
                self.device_label = f"CPU fallback · OpenCV DNN 재시도: {type(exc).__name__}"
                self.net.setInput(blob)
                output = self.net.forward()
        else:
            return []
        output = np.asarray(output)
        if output.ndim == 2:
            output = output[None]
        if output.shape[-1] < 6:
            raise RuntimeError(f"Unexpected YOLOX output shape: {output.shape}")
        if not self.decoded_output:
            expected = sum((self.input_size // s) ** 2 for s in (8, 16, 32))
            if output.shape[1] == expected:
                output = self._decode_yolox(output, self.input_size)
        rows = output[0]
        boxes = rows[:, :4]
        objectness = rows[:, 4]
        class_scores = rows[:, 5:]
        if class_scores.shape[1] == 0:
            return []
        scores = objectness * class_scores[:, 0]  # COCO person class
        dets: list[_RawDetection] = []
        ox, oy = offset
        for box, score in zip(boxes, scores):
            if float(score) < self.confidence:
                continue
            cx, cy, bw, bh = [float(v) / ratio for v in box]
            x1, y1 = max(0.0, cx - bw / 2), max(0.0, cy - bh / 2)
            x2, y2 = min(float(orig_w - 1), cx + bw / 2), min(float(orig_h - 1), cy + bh / 2)
            if x2 <= x1 or y2 <= y1:
                continue
            dets.append(_RawDetection((x1 + ox, y1 + oy, x2 + ox, y2 + oy), float(score)))
        return _nms(dets, self.nms_iou)

    def _far_tile(self, frame: np.ndarray, calibration: CourtCalibration) -> tuple[np.ndarray, tuple[int, int]] | None:
        # Far half plus a small overlap around the net. The polygon is derived from
        # calibration, so it works for different camera heights and crop sizes.
        pts: list[tuple[float, float]] = []
        for x in (0.0, calibration.width_ft):
            for y in (0.0, calibration.length_ft * (0.56 + self.tile_overlap)):
                p = calibration.ground_to_image(Point2D(x, y))
                pts.append((p.x, p.y))
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        h, w = frame.shape[:2]
        pad_x, pad_y = int(w * 0.04), int(h * 0.04)
        x1 = max(0, int(math.floor(min(xs))) - pad_x)
        x2 = min(w, int(math.ceil(max(xs))) + pad_x)
        y1 = max(0, int(math.floor(min(ys))) - pad_y)
        y2 = min(h, int(math.ceil(max(ys))) + pad_y)
        if x2 - x1 < 32 or y2 - y1 < 32:
            return None
        return frame[y1:y2, x1:x2], (x1, y1)

    def detect(self, frame: np.ndarray, calibration: CourtCalibration | None = None) -> list[_RawDetection]:
        if not self.available:
            raise RuntimeError(self.error or "YOLOX detector unavailable")
        dets = self._infer_crop(frame)
        if self.tile_enabled and calibration is not None:
            tile = self._far_tile(frame, calibration)
            if tile is not None:
                crop, offset = tile
                dets.extend(self._infer_crop(crop, offset))
        return _nms(dets, self.nms_iou)


class SyntheticSilhouetteDetector:
    """Deterministic detector for generated CI video only.

    It is deliberately blocked by AnalysisConfig in production. Its sole purpose
    is to verify the pipeline, calibration convention, tracking, and evaluation
    gates without pretending a synthetic color rule is a real-player detector.
    """

    backend_label = "Synthetic silhouette detector (CI only)"
    license_label = "Picklary internal test code"
    device_label = "CPU · OpenCV test detector"

    @property
    def available(self) -> bool:
        return True

    def detect(self, frame: np.ndarray, calibration: CourtCalibration | None = None) -> list[_RawDetection]:
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        sat = hsv[:, :, 1]
        val = hsv[:, :, 2]
        # Player silhouettes are highly saturated and large; ball/lines are too small.
        mask = ((sat > 155) & (val > 100)).astype(np.uint8) * 255
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
        n, _, stats, _ = cv2.connectedComponentsWithStats(mask)
        out: list[_RawDetection] = []
        for i in range(1, n):
            x, y, w, h, area = [int(v) for v in stats[i]]
            if area < 120 or h < 22 or h < w * 1.05:
                continue
            out.append(_RawDetection((float(x), float(y), float(x + w), float(y + h)), 0.99))
        return out


@dataclass(slots=True)
class _Track:
    track_id: int
    xyxy: tuple[float, float, float, float]
    confidence: float
    velocity: tuple[float, float] = (0.0, 0.0)
    missed: int = 0
    age: int = 1


class ByteTrackLite:
    """Independent two-stage high/low-score association inspired by ByteTrack.

    The implementation keeps the core public algorithmic idea (associate strong
    detections first, then recover tracks with low-score detections) without an
    AGPL dependency. It is not represented as the upstream implementation.
    """

    def __init__(self, high_threshold: float = 0.35, low_threshold: float = 0.08, iou_threshold: float = 0.18, max_missed: int = 20):
        self.high_threshold = high_threshold
        self.low_threshold = low_threshold
        self.iou_threshold = iou_threshold
        self.max_missed = max_missed
        self.next_id = 1
        self.tracks: list[_Track] = []

    @staticmethod
    def _predict_box(track: _Track) -> tuple[float, float, float, float]:
        vx, vy = track.velocity
        return (track.xyxy[0] + vx, track.xyxy[1] + vy, track.xyxy[2] + vx, track.xyxy[3] + vy)

    def _associate(self, track_ids: list[int], detections: list[_RawDetection], det_ids: list[int]) -> tuple[list[tuple[int, int]], list[int], list[int]]:
        if not track_ids or not det_ids:
            return [], track_ids[:], det_ids[:]
        cost = np.ones((len(track_ids), len(det_ids)), dtype=float)
        for r, ti in enumerate(track_ids):
            pred = self._predict_box(self.tracks[ti])
            for c, di in enumerate(det_ids):
                cost[r, c] = 1.0 - _iou(pred, detections[di].xyxy)
        rows, cols = linear_sum_assignment(cost)
        matches: list[tuple[int, int]] = []
        used_t, used_d = set(), set()
        for r, c in zip(rows, cols):
            iou = 1.0 - float(cost[r, c])
            if iou >= self.iou_threshold:
                matches.append((track_ids[r], det_ids[c]))
                used_t.add(track_ids[r]); used_d.add(det_ids[c])
        return matches, [i for i in track_ids if i not in used_t], [i for i in det_ids if i not in used_d]

    def update(self, detections: list[_RawDetection]) -> list[tuple[int, _RawDetection]]:
        high = [i for i, d in enumerate(detections) if d.confidence >= self.high_threshold]
        low = [i for i, d in enumerate(detections) if self.low_threshold <= d.confidence < self.high_threshold]
        active = list(range(len(self.tracks)))
        m1, unmatched_tracks, unmatched_high = self._associate(active, detections, high)
        m2, unmatched_tracks, _ = self._associate(unmatched_tracks, detections, low)
        matches = m1 + m2
        matched_tracks = {ti for ti, _ in matches}
        output: list[tuple[int, _RawDetection]] = []
        for ti, di in matches:
            track = self.tracks[ti]
            old_c = ((track.xyxy[0] + track.xyxy[2]) / 2, (track.xyxy[1] + track.xyxy[3]) / 2)
            new = detections[di]
            new_c = ((new.xyxy[0] + new.xyxy[2]) / 2, (new.xyxy[1] + new.xyxy[3]) / 2)
            track.velocity = (new_c[0] - old_c[0], new_c[1] - old_c[1])
            track.xyxy = new.xyxy
            track.confidence = new.confidence
            track.missed = 0
            track.age += 1
            output.append((track.track_id, new))
        for ti, track in enumerate(self.tracks):
            if ti not in matched_tracks:
                track.missed += 1
                track.age += 1
                if track.missed <= self.max_missed:
                    track.xyxy = self._predict_box(track)
        self.tracks = [t for t in self.tracks if t.missed <= self.max_missed]
        # New tracks only come from unmatched high-confidence detections.
        for di in unmatched_high:
            det = detections[di]
            track = _Track(self.next_id, det.xyxy, det.confidence)
            self.next_id += 1
            self.tracks.append(track)
            output.append((track.track_id, det))
        return output


class PlayerTracker:
    """Permissively licensed person detection plus persistent identity tracking."""

    def __init__(
        self,
        model_name: str = "yolox_onnx",
        tracker: str = "bytetrack_lite",
        confidence: float = 0.22,
        failure_limit: int = 30,
        model_path: str | Path = "models/yolox_nano.onnx",
        input_size: int = 416,
        nms_iou: float = 0.45,
        requested_device: str = "auto",
        decoded_output: bool = False,
        tile_enabled: bool = True,
    ):
        self.model_name = model_name
        self.tracker = tracker
        self.confidence = confidence
        self.backend_error: str | None = None
        self.failure_limit = failure_limit
        self.consecutive_failures = 0
        self.total_calls = 0
        self.failed_calls = 0
        self.identity: PlayerIdentityManager | None = None
        self.manual_seed_count = 0
        self.manual_seed_labels: list[str] = []
        self.calibration: CourtCalibration | None = None
        if model_name == "synthetic_silhouette":
            self.detector: _Detector = SyntheticSilhouetteDetector()
        elif model_name == "yolox_onnx":
            self.detector = YoloXOnnxPersonDetector(
                model_path=model_path,
                input_size=input_size,
                confidence=confidence,
                nms_iou=nms_iou,
                requested_device=requested_device,
                decoded_output=decoded_output,
                tile_enabled=tile_enabled,
            )
        else:
            raise ValueError(f"Unsupported person detector: {model_name}")
        self.track_engine = ByteTrackLite(high_threshold=max(0.25, confidence), low_threshold=max(0.05, confidence * 0.35))

    @property
    def device_label(self) -> str:
        return self.detector.device_label

    @property
    def available(self) -> bool:
        return self.detector.available

    def set_calibration(self, calibration: CourtCalibration) -> None:
        self.calibration = calibration

    def set_manual_seeds(self, frame: np.ndarray, seed_points: dict[str, Point2D], calibration: CourtCalibration) -> None:
        if not seed_points:
            return
        if self.identity is None:
            self.identity = PlayerIdentityManager(calibration.length_ft / 2)
        h, w = frame.shape[:2]
        crop_w = max(36.0, w * 0.07)
        crop_h = max(90.0, h * 0.30)
        seeded: list[str] = []
        for label in "ABCD":
            foot = seed_points.get(label)
            if foot is None:
                continue
            bbox = (max(0.0, foot.x - crop_w / 2), max(0.0, foot.y - crop_h), min(float(w - 1), foot.x + crop_w / 2), min(float(h - 1), foot.y))
            embedding = appearance_embedding(frame, bbox)
            court = calibration.image_to_ground(foot)
            self.identity.seed_prototype(label, embedding, court)
            seeded.append(label)
        self.manual_seed_count = len(seeded)
        self.manual_seed_labels = seeded

    def detect(self, frame: np.ndarray) -> list[PlayerDetection]:
        self.total_calls += 1
        try:
            raw = self.detector.detect(frame, self.calibration)
            tracked = self.track_engine.update(raw)
            self.consecutive_failures = 0
            return [PlayerDetection(track_id, det.xyxy, det.confidence, appearance_embedding(frame, det.xyxy)) for track_id, det in tracked]
        except Exception as exc:
            self.failed_calls += 1
            self.consecutive_failures += 1
            self.backend_error = f"Tracking failed: {type(exc).__name__}: {exc}"
            if self.consecutive_failures >= self.failure_limit:
                raise RuntimeError(f"Player tracker failed {self.consecutive_failures} consecutive times: {exc}") from exc
            return []

    def observations(self, detections: list[PlayerDetection], calibration: CourtCalibration, frame_index: int, time_s: float) -> list[PlayerObservation]:
        if self.identity is None:
            self.identity = PlayerIdentityManager(calibration.length_ft / 2)
        candidates: list[tuple[int, Point2D, np.ndarray]] = []
        court_by_id: dict[int, Point2D] = {}
        for det in detections:
            x1, _, x2, y2 = det.xyxy
            foot = Point2D((x1 + x2) / 2, y2)
            court = calibration.image_to_ground(foot)
            if calibration.is_inside(court, margin_ft=4.0):
                emb = det.appearance if det.appearance is not None else np.zeros(96, np.float32)
                candidates.append((det.track_id, court, emb))
                court_by_id[det.track_id] = court
        assignments = self.identity.assign(candidates)
        output: list[PlayerObservation] = []
        for det in detections:
            assignment = assignments.get(det.track_id)
            court = court_by_id.get(det.track_id)
            if assignment is None or court is None:
                continue
            label, identity_conf = assignment
            x1, y1, x2, y2 = det.xyxy
            output.append(PlayerObservation(
                frame_index=frame_index,
                time_s=time_s,
                track_id=det.track_id,
                label=label,
                image_center=Point2D((x1 + x2) / 2, (y1 + y2) / 2),
                image_foot=Point2D((x1 + x2) / 2, y2),
                court_position=court,
                confidence=det.confidence,
                bbox=det.xyxy,
                identity_confidence=identity_conf,
            ))
        return output

    def diagnostics(self) -> dict[str, Any]:
        detector_error = getattr(self.detector, "error", None)
        return {
            "backend": self.detector.backend_label + " + two-stage ByteTrack-style association",
            "license": self.detector.license_label + "; tracker implementation: Picklary",
            "device": self.detector.device_label,
            "available": self.detector.available,
            "model_path": str(getattr(self.detector, "model_path", "")),
            "total_calls": self.total_calls,
            "failed_calls": self.failed_calls,
            "failure_rate": self.failed_calls / self.total_calls if self.total_calls else 0.0,
            "backend_error": self.backend_error or detector_error,
            "runtime_fallbacks": list(getattr(self.detector, "runtime_fallbacks", [])),
            "session_backend": getattr(self.detector, "session_backend", None),
            "id_switches": self.identity.id_switches if self.identity else 0,
            "manual_seed_count": self.manual_seed_count,
            "manual_seed_labels": self.manual_seed_labels,
            "far_court_tile_enabled": bool(getattr(self.detector, "tile_enabled", False)),
        }
