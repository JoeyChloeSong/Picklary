from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
from typing import Any

import cv2


@dataclass(slots=True)
class BallModelCheck:
    model_path: str
    exists: bool
    loadable: bool
    manifest_path: str | None
    manifest_valid: bool
    input_size: tuple[int, int]
    stack_frames: int
    license_id: str | None
    dataset_id: str | None
    validation_f1: float | None
    validation_precision: float | None
    validation_recall: float | None
    validation_sample_count: int
    split_method: str | None
    release_approved: bool
    expected_sha256: str | None
    sha256_match: bool | None
    error: str | None = None

    @property
    def production_ready(self) -> bool:
        return (
            self.exists
            and self.loadable
            and self.manifest_valid
            and self.release_approved
            and self.validation_f1 is not None
            and self.validation_f1 >= 0.85
            and self.validation_precision is not None
            and self.validation_precision >= 0.90
            and self.validation_sample_count >= 100
            and self.split_method == "video_group"
            and self.sha256_match is True
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"production_ready": self.production_ready}


@dataclass(slots=True)
class AnalysisPreflight:
    requested_mode: str
    resolved_mode: str
    model: BallModelCheck
    warning: str | None

    @property
    def uses_ball_analysis(self) -> bool:
        return self.resolved_mode in {"full", "full_experimental"}

    @property
    def positioning_only(self) -> bool:
        return self.resolved_mode == "positioning"

    def to_dict(self) -> dict[str, Any]:
        return {
            "requested_mode": self.requested_mode,
            "resolved_mode": self.resolved_mode,
            "uses_ball_analysis": self.uses_ball_analysis,
            "positioning_only": self.positioning_only,
            "warning": self.warning,
            "ball_model": self.model.to_dict(),
        }


def _manifest_for(model_path: Path) -> Path:
    return model_path.with_suffix(".json")


def inspect_ball_model(model_path: str | Path) -> BallModelCheck:
    path = Path(model_path)
    manifest_path = _manifest_for(path)
    input_size = (640, 360)
    stack_frames = 3
    license_id = None
    dataset_id = None
    manifest_valid = False
    manifest_error = None
    validation_f1 = None
    validation_precision = None
    validation_recall = None
    validation_sample_count = 0
    split_method = None
    release_approved = False
    expected_sha256 = None
    sha256_match = None

    if manifest_path.exists():
        try:
            data = json.loads(manifest_path.read_text(encoding="utf-8"))
            width = int(data.get("input_width", 640))
            height = int(data.get("input_height", 360))
            frames = int(data.get("stack_frames", 3))
            license_id = str(data.get("license", "")).strip() or None
            dataset_id = str(data.get("dataset_id", "")).strip() or None
            validation = data.get("validation", {}) or {}
            validation_f1 = float(validation["f1"]) if validation.get("f1") is not None else None
            validation_precision = float(validation["precision"]) if validation.get("precision") is not None else None
            validation_recall = float(validation["recall"]) if validation.get("recall") is not None else None
            validation_sample_count = int(data.get("validation_sample_count", 0))
            split_method = str(data.get("split_method", "")).strip() or None
            release_approved = bool(data.get("release_approved", False))
            expected_sha256 = str(data.get("sha256", "")).strip().lower() or None
            model_family = str(data.get("model_family", "")).lower()
            input_size = (width, height)
            stack_frames = frames
            manifest_valid = (
                width > 0
                and height > 0
                and frames in {3, 5}
                and model_family in {"picklary_tracknet", "tracknet", "tracknet_heatmap"}
                and bool(license_id)
            )
            if not manifest_valid:
                manifest_error = "모델 메타데이터 필수값 또는 형식이 올바르지 않습니다."
        except Exception as exc:  # noqa: BLE001 - surfaced to UI
            manifest_error = f"모델 메타데이터 읽기 실패: {type(exc).__name__}: {exc}"

    if not path.exists():
        return BallModelCheck(
            str(path), False, False, str(manifest_path) if manifest_path.exists() else None,
            manifest_valid, input_size, stack_frames, license_id, dataset_id,
            validation_f1, validation_precision, validation_recall, validation_sample_count, split_method,
            release_approved, expected_sha256, sha256_match,
            "공 ONNX 모델 파일이 없습니다.",
        )

    if expected_sha256:
        actual_sha256 = hashlib.sha256(path.read_bytes()).hexdigest().lower()
        sha256_match = actual_sha256 == expected_sha256

    loadable = False
    load_error = None
    try:
        cv2.dnn.readNetFromONNX(str(path))
        loadable = True
    except Exception as exc:  # noqa: BLE001 - OpenCV error varies by build
        load_error = f"ONNX 로드 실패: {type(exc).__name__}: {exc}"

    error = load_error or manifest_error
    if loadable and not manifest_path.exists():
        error = "ONNX는 열리지만 동반 메타데이터 JSON이 없어 입력 형식과 라이선스를 검증할 수 없습니다."
    elif loadable and manifest_valid and not release_approved:
        error = "모델은 로드되지만 홀드아웃 검증 후 release_approved=true 승인이 필요합니다."
    elif loadable and manifest_valid and validation_f1 is not None and validation_f1 < 0.85:
        error = f"홀드아웃 F1 {validation_f1:.3f}가 배포 기준 0.85에 미달합니다."
    elif loadable and manifest_valid and validation_precision is not None and validation_precision < 0.90:
        error = f"홀드아웃 Precision {validation_precision:.3f}가 배포 기준 0.90에 미달합니다."
    elif loadable and manifest_valid and split_method != "video_group":
        error = "영상 단위 홀드아웃 분리가 확인되지 않았습니다."
    elif loadable and manifest_valid and validation_sample_count < 100:
        error = f"홀드아웃 표본 {validation_sample_count}개로 배포 기준 100개에 미달합니다."
    elif loadable and manifest_valid and sha256_match is not True:
        error = "ONNX SHA-256이 메타데이터와 일치하지 않습니다."

    return BallModelCheck(
        str(path), True, loadable, str(manifest_path) if manifest_path.exists() else None,
        manifest_valid, input_size, stack_frames, license_id, dataset_id,
        validation_f1, validation_precision, validation_recall, validation_sample_count, split_method,
        release_approved, expected_sha256, sha256_match, error,
    )


def resolve_analysis_preflight(
    requested_mode: str,
    model_path: str | Path,
    enable_classical_fallback: bool = False,
) -> AnalysisPreflight:
    if requested_mode not in {"auto", "full", "positioning"}:
        raise ValueError(f"Unsupported analysis mode: {requested_mode}")
    model = inspect_ball_model(model_path)

    if requested_mode == "positioning":
        return AnalysisPreflight("positioning", "positioning", model, None)

    if model.production_ready:
        return AnalysisPreflight(requested_mode, "full", model, None)

    if enable_classical_fallback:
        warning = (
            "검증된 공 ONNX 모델이 없어 Franklin X-40(74mm·26g·40홀) 고정 프로필 기반 "
            "시각 추적기로 실행합니다. 연속 궤적이 부족하면 오디오 transient와 선수 동작을 결합하고, "
            "여전히 표본이 부족한 선수는 Franklin 프로필 기반 저신뢰 샷 추정으로 표시합니다."
        )
        return AnalysisPreflight(requested_mode, "full_experimental", model, warning)

    reason = model.error or "검증된 공 모델이 준비되지 않았습니다."
    warning = (
        "검증된 공 모델이 없어 선수 움직임 기반 fallback으로 분석합니다. "
        f"공 기반 샷 지표는 제한되지만 Picklary DUPR 근사치는 반드시 표시됩니다. 원인: {reason}"
    )
    return AnalysisPreflight(requested_mode, "positioning", model, warning)
