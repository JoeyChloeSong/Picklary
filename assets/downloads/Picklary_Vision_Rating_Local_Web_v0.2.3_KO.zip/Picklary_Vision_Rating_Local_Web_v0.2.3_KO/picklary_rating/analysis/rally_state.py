from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class DoublesScoreState:
    serving_team: str = "near"
    serving_score: int = 0
    receiving_score: int = 0
    server_number: int = 1

    @property
    def server_side(self) -> str:
        return "right" if self.serving_score % 2 == 0 else "left"

    def expected_role(self, shot_index: int) -> str:
        if shot_index == 1:
            return "serve"
        if shot_index == 2:
            return "return"
        if shot_index == 3:
            return "third"
        return "open_play"

    def requires_bounce_before(self, shot_index: int) -> bool:
        return shot_index in (2, 3)

    def apply_rally_winner(self, winner_team: str | None) -> None:
        if winner_team not in ("near", "far"):
            return
        if winner_team == self.serving_team:
            self.serving_score += 1
            return
        if self.server_number == 1:
            self.server_number = 2
            return
        self.serving_team = "far" if self.serving_team == "near" else "near"
        self.serving_score, self.receiving_score = self.receiving_score, self.serving_score
        self.server_number = 1
