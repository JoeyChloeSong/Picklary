from __future__ import annotations

from typing import Any
import math

from picklary_rating.models import PlayerReport, SkillScores
from picklary_rating.analysis.reference import compare_with_reference


def _clip(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


def _metric(metrics: dict[str, Any], key: str) -> float | None:
    value = metrics.get(key)
    return None if value is None else float(value)


def _nested_metric(metrics: dict[str, Any], group: str, key: str) -> float | None:
    value = (metrics.get(group) or {}).get(key)
    return None if value is None else float(value)


def _scaled(value: float | None, low: float, high: float) -> float | None:
    if value is None:
        return None
    if high <= low:
        return 0.0
    return _clip((value - low) / (high - low) * 100.0)


def _weighted_with_neutral(components: list[tuple[float | None, float]]) -> tuple[float, float]:
    """Return an always-available index and the measured-weight ratio.

    Missing observations are filled with a neutral 50 only for the user-requested
    fallback estimate. The measured-weight ratio is exposed through confidence so
    missing evidence cannot look as trustworthy as measured evidence.
    """
    total_weight = sum(weight for _, weight in components) or 1.0
    measured_weight = sum(weight for value, weight in components if value is not None)
    value = sum((50.0 if item is None else float(item)) * weight for item, weight in components) / total_weight
    return round(_clip(value), 3), measured_weight / total_weight


class IndependentRatingEngine:
    """Transparent Picklary performance model.

    The full path uses observed shot evidence. When a validated ball model or usable
    shot events are unavailable, the engine still returns a conservative motion-based
    DUPR input index because the product requirement is to always show an estimate.
    Every fallback result is explicitly marked as a Picklary estimate, not official DUPR.
    """

    VERSION = "PVR-franklin-x40-benchmark-hybrid-0.1.8"

    def evaluate(
        self,
        label: str,
        metrics: dict[str, Any],
        display_name: str | None = None,
        measurement_mode: str = "full",
    ) -> PlayerReport:
        if measurement_mode in {"positioning", "motion_fallback", "experimental"}:
            return self.evaluate_motion_fallback(label, metrics, display_name, measurement_mode)
        return self.evaluate_full(label, metrics, display_name)

    def evaluate_motion_fallback(
        self,
        label: str,
        metrics: dict[str, Any],
        display_name: str | None = None,
        source_mode: str = "motion_fallback",
    ) -> PlayerReport:
        coverage = _metric(metrics, "tracking_coverage")
        identity = _metric(metrics, "mean_identity_confidence")
        samples = int(metrics.get("position_samples", 0))
        observed_seconds = _metric(metrics, "observed_position_seconds")
        move_speed = _metric(metrics, "median_movement_speed_ft_s")
        lateral = _metric(metrics, "lateral_coverage_ft")
        depth = _metric(metrics, "depth_coverage_ft")
        nvz_ready = _metric(metrics, "nvz_ready_rate")
        active = _metric(metrics, "active_movement_rate")
        high_intensity = _metric(metrics, "high_intensity_movement_rate")
        nvz_distance = _metric(metrics, "nvz_line_distance_median_ft")

        mobility = _scaled(move_speed, 1.0, 8.0)
        lateral_score = _scaled(lateral, 2.0, 12.0)
        depth_score = _scaled(depth, 2.0, 16.0)
        nvz_score = None if nvz_ready is None else _clip(nvz_ready * 100.0)
        activity_score = None if active is None else _clip(active * 100.0)
        intensity_score = None if high_intensity is None else _clip(high_intensity * 100.0)
        identity_score = None if identity is None else _clip(identity * 100.0)
        coverage_score = None if coverage is None else _clip(coverage * 100.0)

        components = [
            (mobility, 0.20),
            (lateral_score, 0.14),
            (depth_score, 0.10),
            (nvz_score, 0.20),
            (activity_score, 0.11),
            (intensity_score, 0.05),
            (identity_score, 0.10),
            (coverage_score, 0.10),
        ]
        index, measured_ratio = _weighted_with_neutral(components)

        # Six categories remain visible in fallback mode, but they are explicitly
        # motion-derived estimates rather than ball-derived shot measurements.
        serve = _clip(index * 0.88 + (depth_score if depth_score is not None else 50.0) * 0.12)
        return_skill = _clip(index * 0.84 + (nvz_score if nvz_score is not None else 50.0) * 0.16)
        offense = _clip(index * 0.78 + (activity_score if activity_score is not None else 50.0) * 0.14 + (intensity_score if intensity_score is not None else 50.0) * 0.08)
        defense = _clip(index * 0.78 + (nvz_score if nvz_score is not None else 50.0) * 0.16 + (lateral_score if lateral_score is not None else 50.0) * 0.06)
        agility = _clip(index)
        consistency = _clip(index * 0.72 + (identity_score if identity_score is not None else 50.0) * 0.14 + (coverage_score if coverage_score is not None else 50.0) * 0.14)
        scores = SkillScores(*[round(v, 1) for v in (serve, return_skill, offense, defense, agility, consistency)])

        coverage_v = coverage or 0.0
        identity_v = identity or 0.0
        observed_v = observed_seconds or 0.0
        confidence = min(
            0.72,
            0.08
            + 0.30 * _clip(coverage_v, 0.0, 1.0)
            + 0.14 * _clip(identity_v, 0.0, 1.0)
            + 0.10 * min(1.0, observed_v / 120.0)
            + 0.10 * measured_ratio,
        )
        if samples < 25 or observed_v < 3.0:
            confidence = min(confidence, 0.18)

        strengths: list[str] = []
        priorities: list[str] = []
        if lateral is not None and lateral >= 7.0:
            strengths.append(f"좌우 커버 범위 {lateral:.1f}ft")
        elif lateral is not None:
            priorities.append(f"좌우 커버 범위 확대 필요 ({lateral:.1f}ft)")
        if nvz_ready is not None and nvz_ready >= 0.45:
            strengths.append(f"NVZ 라인 준비 위치 {nvz_ready * 100:.0f}%")
        elif nvz_distance is not None:
            priorities.append(f"NVZ 라인 중앙거리 {nvz_distance:.1f}ft")
        if move_speed is not None and move_speed >= 3.0:
            strengths.append(f"관측 이동속도 중앙값 {move_speed:.1f}ft/s")
        elif move_speed is not None:
            priorities.append(f"능동적 이동 비율 개선 필요 ({move_speed:.1f}ft/s)")

        franklin_low_evidence = source_mode in {"experimental", "franklin_profile"}
        source_text = (
            "Franklin X-40 샷 증거 품질 게이트 미통과"
            if franklin_low_evidence
            else "포지셔닝 전용 분석"
        )
        basis = "franklin_low_evidence" if franklin_low_evidence else "motion_fallback"
        priority_default = (
            "Franklin X-40 시각·오디오 샷 증거를 더 확보해야 합니다"
            if franklin_low_evidence
            else "포지셔닝·풋워크 표본을 더 확보해야 합니다"
        )
        return PlayerReport(
            label=label,
            display_name=display_name or f"Player {label}",
            status="fallback_rating",
            dupr_estimate=None,
            dupr_low=None,
            dupr_high=None,
            confidence=round(max(0.05, confidence), 3),
            skill_scores=scores,
            metrics=metrics,
            strengths=(strengths[:2] or [f"포지셔닝 기반 내부지수 {index:.0f}점"]),
            priorities=(priorities[:2] or [priority_default]),
            warnings=[
                (
                    f"{source_text}: Franklin X-40(74mm) 후보, 오디오 transient, 선수 동작 중 확보된 근거만 사용하고 "
                    "부족한 샷 항목은 움직임 지수로 보완합니다."
                    if franklin_low_evidence
                    else f"{source_text}: 선수 이동·코트 점유·NVZ 접근·추적 품질로 DUPR 근사치를 산출합니다."
                ),
                (
                    "연속 공 궤적 표본이 부족하므로 서브·리턴·샷 선택 지표의 신뢰구간을 넓게 표시합니다."
                    if franklin_low_evidence
                    else "포지셔닝 전용 모드이므로 공 기반 샷 지표는 산출하지 않습니다."
                ),
                "입력한 기존 DUPR는 강한 기준값으로 사용되며 영상 기반 조정폭은 제한됩니다.",
                "본 수치는 Picklary 독립 근사치이며 공식 DUPR가 아닙니다.",
            ],
            relative_score=index,
            rating_basis=basis,
            reference_comparison=compare_with_reference(metrics, label),
        )

    def evaluate_positioning(
        self,
        label: str,
        metrics: dict[str, Any],
        display_name: str | None = None,
    ) -> PlayerReport:
        return self.evaluate_motion_fallback(label, metrics, display_name, "positioning")

    def evaluate_full(self, label: str, metrics: dict[str, Any], display_name: str | None = None) -> PlayerReport:
        shot_count = int(metrics.get("shot_count", 0))
        observable_shots = int(metrics.get("observable_shot_count", 0))
        rally_count = int(metrics.get("rally_count", 0))
        coverage = _metric(metrics, "tracking_coverage") or 0.0
        mean_conf = _metric(metrics, "mean_shot_confidence") or 0.0
        shot_in = _metric(metrics, "shot_in_rate")
        error = _metric(metrics, "error_proxy_rate")
        kitchen = _metric(metrics, "kitchen_presence_rate")
        stable = _metric(metrics, "stable_at_contact_rate")
        move_speed = _metric(metrics, "median_movement_speed_ft_s")
        attack = _metric(metrics, "attack_rate")
        soft = _metric(metrics, "soft_game_rate")
        third_drop = _metric(metrics, "third_drop_rate")
        third_quality = _metric(metrics, "third_shot_quality")
        crosscourt = _metric(metrics, "crosscourt_rate")
        serve_in = _metric(metrics, "serve_in_rate")
        return_in = _metric(metrics, "return_in_rate")
        serve_deep = _nested_metric(metrics.get("serve_depth") or {}, "rates", "deep")
        return_deep = _nested_metric(metrics.get("return_depth") or {}, "rates", "deep")
        serve_speed = _nested_metric(metrics, "serve_speed", "median_mph")
        drive_speed = _nested_metric(metrics, "drive_speed", "median_mph")
        counts = metrics.get("shot_type_counts", {})
        evidence_source = str(metrics.get("shot_evidence_source") or "none")
        proxy_shots = int(metrics.get("proxy_shot_count", 0))

        # Invalid or sparse shot evidence falls back to movement-based estimation,
        # rather than producing an empty report or trusting classical false positives.
        proxy_mode = evidence_source in {"franklin_audio_motion_hybrid", "franklin_audio_motion_hybrid_completed"} and proxy_shots >= 8
        min_confidence = 0.36 if proxy_mode else 0.45
        if coverage < 0.12 or observable_shots < 8 or rally_count < 2 or mean_conf < min_confidence:
            fallback = self.evaluate_motion_fallback(label, metrics, display_name, "franklin_profile")
            fallback.warnings.insert(
                0,
                f"Franklin 샷 증거 품질 게이트 미통과: 관측 샷 {observable_shots}, 랠리 {rally_count}, 평균 신뢰도 {mean_conf*100:.0f}%.",
            )
            return fallback

        serve = None
        if int(counts.get("serve", 0)) > 0 and serve_in is not None:
            serve = 25 + serve_in * 42 + (serve_deep or 0.0) * 18
            if serve_speed is not None:
                serve += _clip((serve_speed - 18.0) * 0.35, 0.0, 10.0)

        return_skill = None
        if int(counts.get("return", 0)) > 0 and return_in is not None:
            return_skill = 24 + return_in * 40 + (return_deep or 0.0) * 20 + (crosscourt or 0.0) * 5
            if drive_speed is not None:
                return_skill += _clip((drive_speed - 18.0) * 0.18, 0.0, 6.0)

        offense = None
        if attack is not None and error is not None:
            offense = 36 + attack * 24 - error * 24
            if third_quality is not None:
                offense += third_quality * 0.18
            elif proxy_mode:
                offense += min(8.0, math.log1p(max(0, shot_count)) * 1.3)

        defense = None
        if soft is not None and error is not None:
            defense = 38 + soft * 22 + (third_drop or 0.0) * 10 + (kitchen or 0.0) * 8 - error * 23
            if stable is not None:
                defense += stable * 10

        agility = None
        if move_speed is not None and stable is not None:
            agility = 37 + min(move_speed, 12.0) * 2.8 + stable * 18 + (kitchen or 0.0) * 8

        consistency = None
        if shot_in is not None and stable is not None:
            consistency = 18 + shot_in * 62 + stable * 18
        elif error is not None and stable is not None:
            consistency = 80 - error * 70 + stable * 12

        scores = SkillScores(
            *[
                round(_clip(x), 1) if x is not None else None
                for x in (serve, return_skill, offense, defense, agility, consistency)
            ]
        )
        score_dict = scores.as_dict()
        weights = {
            "serve": 0.12,
            "return": 0.17,
            "offense": 0.20,
            "defense": 0.20,
            "agility": 0.14,
            "consistency": 0.17,
        }
        available = [(score_dict[k], w) for k, w in weights.items() if score_dict[k] is not None]
        if not available:
            return self.evaluate_motion_fallback(label, metrics, display_name, "franklin_profile")
        relative = sum(v * w for v, w in available) / sum(w for _, w in available)
        confidence = min(0.90, 0.18 + 0.30 * min(1, shot_count / 35) + 0.27 * coverage + 0.25 * mean_conf)
        ranked = sorted([(k, v) for k, v in score_dict.items() if v is not None], key=lambda kv: kv[1], reverse=True)
        names = {
            "serve": "서브",
            "return": "리턴",
            "offense": "공격 전개",
            "defense": "수비·리셋",
            "agility": "포지셔닝·풋워크",
            "consistency": "일관성",
        }
        strengths = [f"{names[k]} {v:.0f}점" for k, v in ranked[:2]]
        priorities = [f"{names[k]} {v:.0f}점 개선" for k, v in ranked[-2:]]
        basis = "franklin_hybrid" if proxy_mode else "shot_and_motion"
        evidence_warning = (
            "Franklin X-40 시각 후보, 패들형 오디오 transient, 선수 동작을 결합한 하이브리드 샷 추정입니다. "
            "공 속도와 착지점은 연속 시각 궤적이 확인된 샷에만 표시합니다."
            if proxy_mode
            else "검출된 Franklin X-40 궤적과 선수 움직임을 결합한 Picklary 독립 경기력 지수입니다."
        )
        return PlayerReport(
            label=label,
            display_name=display_name or f"Player {label}",
            status="relative_only",
            dupr_estimate=None,
            dupr_low=None,
            dupr_high=None,
            confidence=round(confidence, 3),
            skill_scores=scores,
            metrics=metrics,
            strengths=strengths,
            priorities=priorities,
            warnings=[
                evidence_warning,
                "본 평가는 공식 DUPR 또는 PB Vision 결과가 아닙니다.",
                "단일 카메라에서는 RPM·패들 임팩트 순간속도·정확한 3D 타점 높이를 산출하지 않습니다.",
            ],
            relative_score=round(relative, 3),
            rating_basis=basis,
            reference_comparison=compare_with_reference(metrics, label),
        )

    def rank(self, reports: list[PlayerReport]) -> list[PlayerReport]:
        ordered = sorted(
            [r for r in reports if r.relative_score is not None],
            key=lambda r: r.relative_score or -1,
            reverse=True,
        )
        ranks = {r.label: i + 1 for i, r in enumerate(ordered)}
        for report in reports:
            report.relative_rank = ranks.get(report.label)
        return reports
