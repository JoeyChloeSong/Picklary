from __future__ import annotations

import json
from pathlib import Path
from typing import Any


_FALLBACK_REFERENCE: dict[str, Any] = {
    "reference_id": "pbvision_user_0729_v2_2_0",
    "subject_mapping": {
        "picklary_label": "B",
        "single_game_rating": 4.60,
        "skill_ratings": {
            "serve": 4.56,
            "return": 4.72,
            "offense": 4.70,
            "defense": 4.55,
            "agility": 4.49,
            "consistency": 4.61,
        },
    },
    "subject_metrics": {
        "shot_total": 183,
        "shot_in_rate": 0.9454,
        "distance_covered_ft": 1356.12,
        "serve_total": 21,
        "serve_in_rate": 0.9524,
        "return_total": 18,
        "return_in_rate": 0.9444,
        "serve_median_mph": 41.51,
        "serve_average_mph": 41.94,
        "serve_top_mph": 48.20,
        "drive_median_mph": 29.87,
        "drive_average_mph": 30.02,
        "drive_top_mph": 55.76,
        "average_shot_quality": 0.77,
        "third_count": 30,
        "third_average_quality": 0.78,
        "volley_count": 46,
        "ground_stroke_count": 137,
    },
}


def _load_reference() -> dict[str, Any]:
    root = Path(__file__).resolve().parents[2]
    path = root / "config" / "pbvision_reference_0729_full.json"
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return _FALLBACK_REFERENCE


PBV_USER_REFERENCE_V2 = _load_reference()


def _current_metrics(metrics: dict[str, Any]) -> dict[str, Any]:
    return {
        "shot_total": metrics.get("shot_count"),
        "shot_in_rate": metrics.get("shot_in_rate"),
        "distance_covered_ft": metrics.get("distance_covered_ft"),
        "serve_total": metrics.get("serve_total"),
        "serve_in_rate": metrics.get("serve_in_rate"),
        "return_total": metrics.get("return_total"),
        "return_in_rate": metrics.get("return_in_rate"),
        "serve_deep_rate": ((metrics.get("serve_depth") or {}).get("rates") or {}).get("deep"),
        "serve_medium_rate": ((metrics.get("serve_depth") or {}).get("rates") or {}).get("medium"),
        "serve_shallow_rate": ((metrics.get("serve_depth") or {}).get("rates") or {}).get("shallow"),
        "return_deep_rate": ((metrics.get("return_depth") or {}).get("rates") or {}).get("deep"),
        "return_medium_rate": ((metrics.get("return_depth") or {}).get("rates") or {}).get("medium"),
        "return_shallow_rate": ((metrics.get("return_depth") or {}).get("rates") or {}).get("shallow"),
        "serve_median_mph": (metrics.get("serve_speed") or {}).get("median_mph"),
        "serve_top_mph": (metrics.get("serve_speed") or {}).get("top_mph"),
        "drive_median_mph": (metrics.get("drive_speed") or {}).get("median_mph"),
        "drive_top_mph": (metrics.get("drive_speed") or {}).get("top_mph"),
        "third_shot_quality": metrics.get("third_shot_quality"),
    }


def compare_with_reference(metrics: dict[str, Any], label: str | None = None) -> dict[str, Any]:
    subject = PBV_USER_REFERENCE_V2.get("subject_mapping") or {}
    subject_label = str(subject.get("picklary_label") or "B")
    active_id = metrics.get("reference_benchmark_id")
    reference_id = PBV_USER_REFERENCE_V2.get("reference_id")
    if active_id != reference_id or (label is not None and label != subject_label):
        return {
            "reference_id": reference_id,
            "applicable": False,
            "subject_label": subject_label,
            "disclaimer": "The user-provided PB Vision benchmark applies only to the recognized 0729 reference video and Picklary player B.",
        }

    ref = dict(PBV_USER_REFERENCE_V2.get("subject_metrics") or {})
    current = _current_metrics(metrics)
    rows: dict[str, Any] = {}
    normalized_errors: list[float] = []
    tolerances = {
        "shot_total": 35.0,
        "distance_covered_ft": 250.0,
        "serve_total": 6.0,
        "return_total": 6.0,
        "shot_in_rate": 0.08,
        "serve_in_rate": 0.10,
        "return_in_rate": 0.10,
        "serve_median_mph": 8.0,
        "serve_top_mph": 10.0,
        "drive_median_mph": 8.0,
        "drive_top_mph": 12.0,
    }
    for key, value in current.items():
        reference = ref.get(key)
        delta = None
        if value is not None and reference is not None:
            delta = round(float(value) - float(reference), 4)
            if key in tolerances:
                normalized_errors.append(min(2.0, abs(float(delta)) / tolerances[key]))
        rows[key] = {"current": value, "reference": reference, "delta": delta}
    similarity = None
    if normalized_errors:
        similarity = max(0.0, 1.0 - sum(normalized_errors) / len(normalized_errors))
    reference_outcome = (PBV_USER_REFERENCE_V2.get("game") or {}).get("game_outcome")
    current_outcome = [metrics.get("analysis_final_score_near"), metrics.get("analysis_final_score_far")]
    score_warning = None
    if reference_outcome and all(value is not None for value in current_outcome):
        if [int(current_outcome[0]), int(current_outcome[1])] != [int(reference_outcome[0]), int(reference_outcome[1])]:
            score_warning = (
                f"현재 입력 점수 {int(current_outcome[0])}:{int(current_outcome[1])}와 "
                f"사용자 제공 PB Vision export의 game_outcome {int(reference_outcome[0])}:{int(reference_outcome[1])}가 다릅니다. "
                "샷 지표 비교는 계속하지만 점수 차이는 벤치마크 유사도에 사용하지 않습니다."
            )
    return {
        "reference_id": PBV_USER_REFERENCE_V2.get("reference_id"),
        "applicable": True,
        "subject_label": subject_label,
        "reference_single_game_rating": subject.get("single_game_rating"),
        "reference_skill_ratings": subject.get("skill_ratings") or {},
        "metrics": rows,
        "benchmark_similarity": None if similarity is None else round(similarity, 4),
        "score_warning": score_warning,
        "disclaimer": (
            "User-supplied one-game benchmark used for independent cross-validation. "
            "It is not a reconstruction of PB Vision's proprietary formula or population percentile."
        ),
    }
