from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass(slots=True)
class AnalysisConfig:
    # Sampling / runtime
    person_stride: int = 2
    ball_stride: int = 1
    analysis_mode: str = "full"
    processing_device: str = "gpu"
    max_video_minutes: int = 45
    output_root: Path = field(default_factory=lambda: Path.home() / "PicklaryVisionResults")

    # Person detection. HOG is intentionally no longer supported.
    detector_model: str = "yolox_onnx"
    person_model_path: str = "models/yolox_nano.onnx"
    person_model_input_size: int = 416
    person_model_decoded_output: bool = False
    person_tile_enabled: bool = True
    person_tile_overlap: float = 0.10
    person_tile_min_height_px: int = 640
    detector_confidence: float = 0.22
    detector_nms_iou: float = 0.45
    tracker: str = "bytetrack_lite"
    consecutive_tracker_failures_limit: int = 30

    # Ball model
    ball_model_path: str = "models/tracknet_pickleball.onnx"
    ball_profile_id: str = "franklin_x40_outdoor"
    ball_max_gap_frames: int = 6
    enable_classical_ball_fallback: bool = True
    use_ball_profile_for_shot_rating: bool = True

    # Lens correction
    lens_mode: str = "auto"  # none | profile | user | auto
    lens_profile_id: str = "generic_linear"
    lens_profiles_path: str = "calibration/lens_profiles.json"
    user_lens_calibration_path: str = "calibration/user_camera.json"
    auto_lens_max_frames: int = 1
    lens_line_residual_warn_px: float = 2.0

    # Court / event policy
    court_width_ft: float = 20.0
    court_length_ft: float = 44.0
    kitchen_line_from_net_ft: float = 7.0
    min_rally_gap_seconds: float = 3.0
    min_hit_gap_seconds: float = 0.10
    event_window_seconds: float = 0.05
    max_player_speed_ft_s: float = 24.0
    calibration_warn_rmse_px: float = 8.0
    calibration_reject_rmse_px: float = 20.0

    # Audio onset is an independent evidence channel.
    enable_audio_onset: bool = True
    audio_onset_threshold_z: float = 5.0
    audio_onset_min_gap_s: float = 0.09
    audio_match_window_s: float = 0.045
    audio_onset_quantile: float = 0.99

    # Game/session context. These values are evidence supplied by the user and
    # are stored in diagnostics even before score reconstruction is enabled.
    game_target_points: int = 15
    initial_server_label: str | None = None
    final_score_near: int | None = None
    final_score_far: int | None = None
    first_server_side: str | None = None  # near_right | near_left | far_left | far_right
    session_preset_id: str | None = None
    reference_benchmark_id: str | None = None

    # Output / integrity
    emit_evaluation_tracks: bool = False
    require_anchor_for_absolute_rating: bool = False
    analysis_start_s: float = 0.0

    # Internal test-only detector. Never exposed as production default.
    allow_test_detector: bool = False

    @property
    def sample_stride(self) -> int:
        return self.person_stride

    def validate(self) -> None:
        if self.analysis_mode not in {"auto", "full", "positioning"}:
            raise ValueError("analysis_mode must be auto, full, or positioning")
        if self.processing_device not in {"auto", "cpu", "gpu"}:
            raise ValueError("processing_device must be auto, cpu, or gpu")
        if self.person_stride < 1:
            raise ValueError("person_stride must be >= 1")
        if self.ball_stride != 1:
            raise ValueError("ball_stride must remain 1; ball frames cannot be skipped")
        if self.ball_profile_id not in {"franklin_x40_outdoor"}:
            raise ValueError("ball_profile_id must be franklin_x40_outdoor")
        if self.detector_model not in {"yolox_onnx", "synthetic_silhouette"}:
            raise ValueError("detector_model must be yolox_onnx or synthetic_silhouette")
        if self.detector_model == "synthetic_silhouette" and not self.allow_test_detector:
            raise ValueError("synthetic_silhouette is test-only; set allow_test_detector=True")
        if not (0.01 <= self.detector_confidence <= 0.99):
            raise ValueError("detector_confidence must be between 0.01 and 0.99")
        if not (0.05 <= self.detector_nms_iou <= 0.95):
            raise ValueError("detector_nms_iou must be between 0.05 and 0.95")
        if self.person_model_input_size < 256:
            raise ValueError("person_model_input_size is too small")
        if self.max_video_minutes < 1:
            raise ValueError("max_video_minutes must be >= 1")
        if self.court_width_ft <= 0 or self.court_length_ft <= 0:
            raise ValueError("court dimensions must be positive")
        if not (0 < self.kitchen_line_from_net_ft < self.court_length_ft / 2):
            raise ValueError("kitchen_line_from_net_ft is outside the court")
        if self.lens_mode not in {"none", "profile", "user", "auto"}:
            raise ValueError("lens_mode must be none, profile, user, or auto")
        if self.analysis_start_s < 0:
            raise ValueError("analysis_start_s must be >= 0")
        if not (0.90 <= self.audio_onset_quantile <= 0.999):
            raise ValueError("audio_onset_quantile must be between 0.90 and 0.999")
        if self.game_target_points not in {11, 15}:
            raise ValueError("game_target_points must be 11 or 15")
        if self.initial_server_label is not None and self.initial_server_label not in {"A", "B", "C", "D"}:
            raise ValueError("initial_server_label must be A, B, C, D, or None")
        if self.first_server_side is not None and self.first_server_side not in {"near_right", "near_left", "far_left", "far_right"}:
            raise ValueError("first_server_side is invalid")
        for score in (self.final_score_near, self.final_score_far):
            if score is not None and score < 0:
                raise ValueError("final scores must be non-negative")
