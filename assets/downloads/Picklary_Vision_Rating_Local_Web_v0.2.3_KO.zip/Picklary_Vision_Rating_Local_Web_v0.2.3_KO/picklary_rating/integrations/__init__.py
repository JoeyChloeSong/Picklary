"""Optional third-party provider integrations.

No external upload occurs unless a future provider adapter is explicitly configured.
"""
