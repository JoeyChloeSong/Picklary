from __future__ import annotations

from pathlib import Path
from typing import Any

from picklary_rating.integrations.provider import ProviderJob


class PBVisionPartnerAdapter:
    """Non-operational placeholder for an approved PB Vision partner API integration.

    The public partner guide requires account approval and an API add-on. This
    class intentionally contains no guessed endpoint, token, or upload behavior.
    Implement only after receiving official credentials, SDK and license terms.
    """

    name = "pbvision"

    def __init__(self, api_key: str | None = None):
        self.api_key = api_key

    def submit(self, video_path: Path, metadata: dict[str, Any]) -> ProviderJob:
        raise RuntimeError(
            "PB Vision partner access is not configured. Obtain approval and use the official partner SDK."
        )

    def status(self, job_id: str) -> ProviderJob:
        raise RuntimeError("PB Vision partner access is not configured.")

    def fetch_result(self, job_id: str) -> dict[str, Any]:
        raise RuntimeError("PB Vision partner access is not configured.")
