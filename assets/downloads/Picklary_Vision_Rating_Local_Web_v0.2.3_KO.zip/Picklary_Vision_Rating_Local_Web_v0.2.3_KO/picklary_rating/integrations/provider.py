from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol


@dataclass(slots=True)
class ProviderJob:
    provider: str
    job_id: str
    status: str
    metadata: dict[str, Any]


class AnalysisProvider(Protocol):
    name: str

    def submit(self, video_path: Path, metadata: dict[str, Any]) -> ProviderJob:
        """Submit a video. Must require explicit user action and consent."""
        ...

    def status(self, job_id: str) -> ProviderJob:
        ...

    def fetch_result(self, job_id: str) -> dict[str, Any]:
        ...
