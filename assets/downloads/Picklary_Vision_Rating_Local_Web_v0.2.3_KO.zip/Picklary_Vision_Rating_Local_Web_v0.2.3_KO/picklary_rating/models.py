from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Literal


@dataclass(slots=True)
class Point2D:
    x: float
    y: float

    def as_tuple(self) -> tuple[float, float]:
        return self.x, self.y


@dataclass(slots=True)
class Point3D:
    x: float
    y: float
    z: float

    def as_tuple(self) -> tuple[float, float, float]:
        return self.x, self.y, self.z


@dataclass(slots=True)
class PlayerObservation:
    frame_index: int
    time_s: float
    track_id: int
    label: str
    image_center: Point2D
    image_foot: Point2D
    court_position: Point2D | None
    confidence: float
    bbox: tuple[float, float, float, float] | None = None
    identity_confidence: float = 0.0


@dataclass(slots=True)
class BallObservation:
    frame_index: int
    time_s: float
    image_position: Point2D
    court_position: Point2D | None = None
    confidence: float = 0.0
    source: str = "unknown"
    court_position_source: Literal["bounce_anchor", "hit_contact", "ballistic_fit"] | None = None
    tracklet_id: int = 0
    visible: bool = True
    predicted: bool = False


@dataclass(slots=True)
class BallEvent:
    frame_index: int
    time_s: float
    event_type: Literal["hit", "bounce", "ambiguous"]
    confidence: float
    image_position: Point2D
    court_position: Point2D | None = None
    player_label: str | None = None
    diagnostics: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class HitEvent:
    frame_index: int
    time_s: float
    player_label: str
    court_position: Point2D | None
    incoming_speed_mph: float | None
    outgoing_speed_mph: float | None
    direction_change_deg: float | None
    confidence: float
    event_type: str = "hit"
    image_position: Point2D | None = None
    tracklet_id: int = 0


@dataclass(slots=True)
class ShotEvent:
    rally_index: int
    shot_index: int
    time_s: float
    player_label: str
    shot_type: str
    stroke_side: str
    start_position: Point2D | None
    end_position: Point2D | None
    estimated_speed_mph: float | None
    trajectory_profile: str
    outcome: Literal[
        "in_play", "winner", "error_net", "error_out", "error_kitchen", "unknown_tracking_loss"
    ]
    confidence: float
    speed_source: str | None = None
    speed_outlier: bool = False


@dataclass(slots=True)
class Rally:
    rally_index: int
    start_s: float
    end_s: float
    shots: list[ShotEvent] = field(default_factory=list)
    winner_team: str | None = None
    end_cause: str | None = None
    bounces: list[BallEvent] = field(default_factory=list)


@dataclass(slots=True)
class SkillScores:
    serve: float | None
    return_skill: float | None
    offense: float | None
    defense: float | None
    agility: float | None
    consistency: float | None

    def as_dict(self) -> dict[str, float | None]:
        return {
            "serve": self.serve,
            "return": self.return_skill,
            "offense": self.offense,
            "defense": self.defense,
            "agility": self.agility,
            "consistency": self.consistency,
        }


@dataclass(slots=True)
class PlayerReport:
    label: str
    display_name: str
    status: Literal["ok", "relative_only", "positioning_only", "fallback_rating", "insufficient_data"]
    dupr_estimate: float | None
    dupr_low: float | None
    dupr_high: float | None
    confidence: float
    skill_scores: SkillScores
    metrics: dict[str, Any]
    strengths: list[str]
    priorities: list[str]
    warnings: list[str]
    relative_rank: int | None = None
    relative_score: float | None = None
    anchor_dupr: float | None = None
    single_game_skill_rating: float | None = None
    skill_rating_estimates: SkillScores | None = None
    reference_comparison: dict[str, Any] = field(default_factory=dict)
    rating_basis: str = "unknown"


@dataclass(slots=True)
class AnalysisResult:
    video_path: str
    created_at: str
    duration_s: float
    fps: float
    frame_count: int
    calibration_points: list[Point2D]
    player_reports: list[PlayerReport]
    rallies: list[Rally]
    diagnostics: dict[str, Any]
    output_dir: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @property
    def output_path(self) -> Path:
        if not self.output_dir:
            raise ValueError("output_dir has not been assigned")
        return Path(self.output_dir)
