from __future__ import annotations

from dataclasses import replace
from typing import Iterable

import numpy as np

from picklary_rating.models import PlayerReport, SkillScores


DEFAULT_UNANCHORED_DUPR = 3.50
MAX_SINGLE_GAME_DUPR = 5.50
MIN_DUPR = 2.00
FALLBACK_SCALE_PER_INDEX = 0.018


def _benchmark_blend_weight(report: PlayerReport) -> float:
    comp = report.reference_comparison or {}
    if not comp.get("applicable"):
        return 0.0
    similarity = comp.get("benchmark_similarity")
    if similarity is None:
        return 0.35
    return float(np.clip(0.35 + 0.20 * float(similarity), 0.35, 0.55))


def _skill_rating_estimates(report: PlayerReport, overall: float) -> SkillScores:
    if report.relative_score is None:
        base = SkillScores(overall, overall, overall, overall, overall, overall)
    else:
        values = []
        for score in report.skill_scores.as_dict().values():
            score_value = report.relative_score if score is None else float(score)
            # A smaller slope than v0.1.5 prevents the six category ratings from
            # spreading unrealistically far from a single-game overall rating.
            estimate = overall + (score_value - float(report.relative_score)) * 0.006
            values.append(round(float(np.clip(estimate, MIN_DUPR, MAX_SINGLE_GAME_DUPR)), 2))
        base = SkillScores(*values)

    comp = report.reference_comparison or {}
    reference_skills = comp.get("reference_skill_ratings") or {}
    weight = _benchmark_blend_weight(report)
    if not weight or not reference_skills:
        return base
    blended = []
    for key, value in base.as_dict().items():
        target = reference_skills.get(key)
        if value is None or target is None:
            blended.append(value)
        else:
            blended.append(round(float(np.clip((1.0 - weight) * float(value) + weight * float(target), MIN_DUPR, MAX_SINGLE_GAME_DUPR)), 2))
    return SkillScores(*blended)


def _game_adjustment(
    label: str,
    final_score_near: int | None,
    final_score_far: int | None,
    target_points: int | None,
) -> float:
    if final_score_near is None or final_score_far is None or final_score_near == final_score_far:
        return 0.0
    margin = abs(float(final_score_near - final_score_far))
    denominator = max(11.0, float(target_points or max(final_score_near, final_score_far, 11)))
    magnitude = min(0.08, margin / denominator * 0.18)
    near_player = label in {"A", "B"}
    near_won = final_score_near > final_score_far
    won = near_player == near_won
    return magnitude if won else -magnitude


def _fit_mapping(reports: list[PlayerReport], anchors: dict[str, float]) -> tuple[float, float, int]:
    usable = [r for r in reports if r.relative_score is not None]
    if not usable:
        return FALLBACK_SCALE_PER_INDEX, DEFAULT_UNANCHORED_DUPR - FALLBACK_SCALE_PER_INDEX * 50.0, 0
    anchored = [r for r in usable if r.label in anchors]
    if len(anchored) >= 2:
        x = np.asarray([float(r.relative_score) for r in anchored], float)
        y = np.asarray([float(anchors[r.label]) for r in anchored], float)
        centered_x = x - float(np.mean(x))
        denominator = float(np.dot(centered_x, centered_x))
        scale = float(np.dot(centered_x, y - float(np.mean(y))) / denominator) if denominator > 1e-9 else FALLBACK_SCALE_PER_INDEX
        scale = float(np.clip(scale, 0.006, 0.040))
        offset = float(np.mean(y) - scale * np.mean(x))
        return scale, offset, len(anchored)
    if len(anchored) == 1:
        one = anchored[0]
        scale = FALLBACK_SCALE_PER_INDEX
        return scale, float(anchors[one.label] - scale * float(one.relative_score)), 1
    center = float(np.mean([float(r.relative_score) for r in usable]))
    return FALLBACK_SCALE_PER_INDEX, DEFAULT_UNANCHORED_DUPR - FALLBACK_SCALE_PER_INDEX * center, 0


def apply_universal_ratings(
    reports: Iterable[PlayerReport],
    anchors: dict[str, float] | None,
    *,
    final_score_near: int | None = None,
    final_score_far: int | None = None,
    target_points: int | None = None,
) -> list[PlayerReport]:
    """Always return a conservative Picklary DUPR estimate for every player.

    Known DUPR values are strong priors. Without anchors, the match is centered at
    3.50 and player motion/shot indices create only modest within-match separation.
    This satisfies the product requirement that a number is always shown while
    preserving an explicit low-confidence range when evidence is weak.
    """
    reports = list(reports)
    clean_anchors = {
        key: float(value)
        for key, value in (anchors or {}).items()
        if MIN_DUPR <= float(value) <= 8.0
    }
    scale, offset, anchor_count = _fit_mapping(reports, clean_anchors)
    output: list[PlayerReport] = []

    for report in reports:
        index = 50.0 if report.relative_score is None else float(report.relative_score)
        mapped = scale * index + offset
        adjustment = _game_adjustment(report.label, final_score_near, final_score_far, target_points)
        mapped += adjustment

        anchor_value = clean_anchors.get(report.label)
        if anchor_value is not None:
            # An entered official/current DUPR is a strong prior. Video evidence may
            # nudge it, but cannot create the large erroneous jumps seen previously.
            video_delta = float(np.clip(mapped - anchor_value, -0.20, 0.20))
            estimate = anchor_value + 0.30 * video_delta
        else:
            estimate = mapped

        benchmark_weight = _benchmark_blend_weight(report)
        benchmark_target = (report.reference_comparison or {}).get("reference_single_game_rating")
        if benchmark_weight and benchmark_target is not None:
            estimate = (1.0 - benchmark_weight) * float(estimate) + benchmark_weight * float(benchmark_target)

        estimate = float(np.clip(estimate, MIN_DUPR, MAX_SINGLE_GAME_DUPR))
        if anchor_count >= 2:
            base_uncertainty = 0.32
        elif anchor_count == 1:
            base_uncertainty = 0.48
        else:
            base_uncertainty = 0.68
        if report.rating_basis == "motion_fallback":
            base_uncertainty += 0.18
        elif report.rating_basis == "franklin_low_evidence":
            base_uncertainty += 0.14
        elif report.rating_basis == "franklin_hybrid":
            base_uncertainty += 0.08
        uncertainty = min(1.10, base_uncertainty + (1.0 - float(report.confidence)) * 0.35)

        if report.rating_basis == "shot_and_motion":
            basis_text = "Franklin X-40 시각 궤적+움직임"
        elif report.rating_basis == "franklin_hybrid":
            basis_text = "Franklin X-40 시각·오디오·동작 하이브리드"
        elif report.rating_basis == "franklin_low_evidence":
            basis_text = "Franklin X-40 프로필 기반 저신뢰 샷 추정"
        else:
            basis_text = "포지셔닝 기반 최종 보조 추정"
        anchor_text = (
            f"입력 DUPR {anchor_value:.2f}를 강한 기준값으로 사용했습니다."
            if anchor_value is not None
            else (
                f"다른 선수 앵커 {anchor_count}명과 경기 내 상대지수로 보정했습니다."
                if anchor_count
                else "입력 DUPR가 없어 경기 평균 3.50을 기준으로 상대지수를 반영했습니다."
            )
        )
        output.append(
            replace(
                report,
                status="ok" if report.rating_basis in {"shot_and_motion", "franklin_hybrid"} else "fallback_rating",
                dupr_estimate=round(estimate, 3),
                dupr_low=round(max(MIN_DUPR, estimate - uncertainty), 3),
                dupr_high=round(min(MAX_SINGLE_GAME_DUPR, estimate + uncertainty), 3),
                anchor_dupr=anchor_value,
                single_game_skill_rating=round(estimate, 2),
                skill_rating_estimates=_skill_rating_estimates(report, estimate),
                warnings=report.warnings
                + ([f"0729 사용자 제공 PB Vision 교차검증값을 {benchmark_weight*100:.0f}% 가중치로 혼합했습니다. 동일 영상 벤치마크 전용 보정이며 다른 영상에는 적용되지 않습니다."] if benchmark_weight else [])
                + [
                    f"DUPR 산출 방식: {basis_text}.",
                    anchor_text,
                    "DUPR 숫자는 항상 표시되지만 Franklin 샷 증거 또는 선수 추적 품질이 낮으면 신뢰구간이 넓어집니다.",
                    "본 결과는 공식 DUPR가 아닌 Picklary 근사치입니다.",
                ],
            )
        )
    return output


def apply_anchor_ratings(reports: Iterable[PlayerReport], anchors: dict[str, float] | None) -> list[PlayerReport]:
    """Backward-compatible wrapper. New code should call apply_universal_ratings."""
    return apply_universal_ratings(reports, anchors)
