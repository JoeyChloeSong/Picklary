from __future__ import annotations

import math

import cv2
from PySide6.QtCore import QPointF, Qt, Signal
from PySide6.QtGui import QImage, QMouseEvent, QPainter, QPen, QPixmap, QWheelEvent
from PySide6.QtWidgets import QLabel

from picklary_rating.analysis.camera import normalize_calibration_points
from picklary_rating.models import Point2D


class CourtCalibrationLabel(QLabel):
    points_changed = Signal(int)
    player_points_changed = Signal(int)
    zoom_changed = Signal(int)
    MAX_POINTS = 11
    MAX_PLAYERS = 4

    def __init__(self):
        super().__init__()
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setMinimumSize(720, 430)
        self.setStyleSheet("background:#020813;border:1px solid #233857;border-radius:14px;")
        self._image: QImage | None = None
        self._points: list[Point2D] = []
        self._player_points: list[Point2D] = []
        self._display_rect = (0.0, 0.0, 1.0, 1.0)
        self._source_rect = (0.0, 0.0, 1.0, 1.0)
        self._drag_index: int | None = None
        self._drag_kind: str | None = None
        self._highlighted_index: int | None = None
        self._interaction_mode = "calibration"
        self._zoom = 1.0
        self._view_center = QPointF(0.0, 0.0)
        self._pan_start: QPointF | None = None
        self._pan_center_start: QPointF | None = None
        self._zoom_drag_start_y: float | None = None
        self._zoom_drag_start_value = 1.0
        self.setMouseTracking(True)
        self.setText("영상을 선택하면 첫 프레임이 표시됩니다.")

    def set_frame(self, frame_bgr) -> None:
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        self._image = QImage(rgb.data, w, h, ch * w, QImage.Format.Format_RGB888).copy()
        self._view_center = QPointF(w / 2, h / 2)
        self._zoom = 1.0
        self._points.clear()
        self._player_points.clear()
        self._drag_index = None
        self._drag_kind = None
        self._highlighted_index = None
        self.points_changed.emit(0)
        self.player_points_changed.emit(0)
        self.zoom_changed.emit(100)
        self.update()

    def set_interaction_mode(self, mode: str) -> None:
        if mode not in {"calibration", "players", "pan"}:
            raise ValueError(f"Unknown interaction mode: {mode}")
        self._interaction_mode = mode
        if mode == "pan":
            self.setCursor(Qt.CursorShape.OpenHandCursor)
        elif mode == "players":
            self.setCursor(Qt.CursorShape.CrossCursor)
        else:
            self.setCursor(Qt.CursorShape.CrossCursor)

    def interaction_mode(self) -> str:
        return self._interaction_mode

    def reset_points(self) -> None:
        self._points.clear()
        self._drag_index = None
        self._drag_kind = None
        self._highlighted_index = None
        self.points_changed.emit(0)
        self.update()

    def reset_player_points(self) -> None:
        self._player_points.clear()
        self._drag_index = None
        self._drag_kind = None
        self.player_points_changed.emit(0)
        self.update()

    def points(self) -> list[Point2D]:
        return list(self._points)

    def player_points(self) -> list[Point2D]:
        return list(self._player_points)

    def image_size(self) -> tuple[int, int] | None:
        if self._image is None:
            return None
        return self._image.width(), self._image.height()

    def zoom_percent(self) -> int:
        return int(round(self._zoom * 100))

    def set_zoom(self, zoom: float, anchor_screen: QPointF | None = None) -> None:
        if self._image is None:
            return
        new_zoom = min(8.0, max(1.0, float(zoom)))
        if abs(new_zoom - self._zoom) < 1e-6:
            return
        if anchor_screen is not None:
            x, y, w, h = self._display_rect
            if w > 1 and h > 1 and x <= anchor_screen.x() <= x + w and y <= anchor_screen.y() <= y + h:
                anchor_image = self._image_position(anchor_screen)
                rx = (anchor_screen.x() - x) / w
                ry = (anchor_screen.y() - y) / h
                source_w = self._image.width() / new_zoom
                source_h = self._image.height() / new_zoom
                self._view_center = QPointF(
                    anchor_image.x - (rx - 0.5) * source_w,
                    anchor_image.y - (ry - 0.5) * source_h,
                )
        self._zoom = new_zoom
        self._clamp_view_center()
        self.zoom_changed.emit(self.zoom_percent())
        self.update()

    def zoom_in(self) -> None:
        self.set_zoom(self._zoom * 1.25)

    def zoom_out(self) -> None:
        self.set_zoom(self._zoom / 1.25)

    def reset_view(self) -> None:
        if self._image is None:
            return
        self._zoom = 1.0
        self._view_center = QPointF(self._image.width() / 2, self._image.height() / 2)
        self.zoom_changed.emit(100)
        self.update()

    def set_highlighted_point(self, index: int | None) -> None:
        self._highlighted_index = index if index is not None and 0 <= index < len(self._points) else None
        self.update()

    def _clamp_view_center(self) -> None:
        if self._image is None:
            return
        sw = self._image.width() / self._zoom
        sh = self._image.height() / self._zoom
        self._view_center = QPointF(
            min(max(self._view_center.x(), sw / 2), self._image.width() - sw / 2),
            min(max(self._view_center.y(), sh / 2), self._image.height() - sh / 2),
        )

    def _update_source_rect(self) -> None:
        if self._image is None:
            return
        self._clamp_view_center()
        sw = self._image.width() / self._zoom
        sh = self._image.height() / self._zoom
        self._source_rect = (
            self._view_center.x() - sw / 2,
            self._view_center.y() - sh / 2,
            sw,
            sh,
        )

    def _screen_position(self, point: Point2D) -> QPointF:
        x, y, w, h = self._display_rect
        sx, sy, sw, sh = self._source_rect
        return QPointF(x + (point.x - sx) * w / sw, y + (point.y - sy) * h / sh)

    def _image_position(self, pos: QPointF) -> Point2D:
        x, y, w, h = self._display_rect
        sx, sy, sw, sh = self._source_rect
        assert self._image is not None
        return Point2D(
            float(min(max(sx + (pos.x() - x) * sw / w, 0.0), self._image.width() - 1.0)),
            float(min(max(sy + (pos.y() - y) * sh / h, 0.0), self._image.height() - 1.0)),
        )

    def _nearest_index(self, pos: QPointF, items: list[Point2D], radius_px: float = 20.0) -> int | None:
        best: tuple[float, int] | None = None
        for idx, point in enumerate(items):
            screen = self._screen_position(point)
            dist = math.hypot(screen.x() - pos.x(), screen.y() - pos.y())
            if dist <= radius_px and (best is None or dist < best[0]):
                best = (dist, idx)
        return None if best is None else best[1]

    def paintEvent(self, event) -> None:  # noqa: N802
        super().paintEvent(event)
        if self._image is None:
            return
        self._update_source_rect()
        sx, sy, sw, sh = self._source_rect
        crop = self._image.copy(int(round(sx)), int(round(sy)), max(1, int(round(sw))), max(1, int(round(sh))))
        scaled = QPixmap.fromImage(crop).scaled(
            self.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation
        )
        x = (self.width() - scaled.width()) / 2
        y = (self.height() - scaled.height()) / 2
        self._display_rect = (x, y, scaled.width(), scaled.height())
        painter = QPainter(self)
        painter.drawPixmap(int(x), int(y), scaled)

        screen: list[QPointF] = []
        for idx, point in enumerate(self._points, 1):
            pixel = self._screen_position(point)
            screen.append(pixel)
            highlighted = self._highlighted_index == idx - 1
            if highlighted:
                painter.setPen(QPen(Qt.GlobalColor.magenta, 4))
                painter.setBrush(Qt.GlobalColor.yellow)
                radius = 11
            else:
                painter.setPen(QPen(Qt.GlobalColor.white, 2))
                painter.setBrush(Qt.GlobalColor.red if idx <= 8 else Qt.GlobalColor.yellow)
                radius = 7
            painter.drawEllipse(pixel, radius, radius)
            painter.drawText(QPointF(pixel.x() + 10, pixel.y() - 8), str(idx))

        painter.setPen(QPen(Qt.GlobalColor.green, 3))
        line_screen = screen
        if len(self._points) in (4, 8, 11):
            try:
                normalized, _ = normalize_calibration_points(self._points)
                line_screen = [self._screen_position(point) for point in normalized]
            except (ValueError, cv2.error):
                line_screen = screen
        if len(line_screen) >= 4:
            for a, b in zip(line_screen[:4], line_screen[1:4]):
                painter.drawLine(a, b)
            painter.drawLine(line_screen[3], line_screen[0])
        if len(line_screen) >= 6:
            painter.drawLine(line_screen[4], line_screen[5])
        if len(line_screen) >= 8:
            painter.drawLine(line_screen[6], line_screen[7])
        if len(line_screen) >= 10:
            painter.drawLine(line_screen[8], line_screen[9])

        player_colors = [Qt.GlobalColor.cyan, Qt.GlobalColor.yellow, Qt.GlobalColor.magenta, Qt.GlobalColor.green]
        for idx, point in enumerate(self._player_points):
            pixel = self._screen_position(point)
            painter.setPen(QPen(Qt.GlobalColor.white, 3))
            painter.setBrush(player_colors[idx])
            painter.drawEllipse(pixel, 10, 10)
            painter.drawText(QPointF(pixel.x() + 13, pixel.y() - 10), f"P{idx + 1}")

        if self._zoom > 1.001:
            painter.setPen(QPen(Qt.GlobalColor.white, 1))
            painter.drawText(QPointF(x + 12, y + 24), f"확대 {self.zoom_percent()}%")
        painter.end()

    def _inside_display(self, pos: QPointF) -> bool:
        x, y, w, h = self._display_rect
        return x <= pos.x() <= x + w and y <= pos.y() <= y + h

    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if self._image is None:
            return
        pos = event.position()
        if event.button() == Qt.MouseButton.MiddleButton or (
            event.button() == Qt.MouseButton.LeftButton and self._interaction_mode == "pan"
        ):
            self._pan_start = pos
            self._pan_center_start = QPointF(self._view_center)
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
            return
        if event.button() == Qt.MouseButton.LeftButton and event.modifiers() & Qt.KeyboardModifier.ControlModifier:
            self._zoom_drag_start_y = pos.y()
            self._zoom_drag_start_value = self._zoom
            return
        if event.button() == Qt.MouseButton.RightButton:
            if self._interaction_mode == "players" and self._player_points:
                self._player_points.pop()
                self.player_points_changed.emit(len(self._player_points))
            elif self._interaction_mode == "calibration" and self._points:
                self._points.pop()
                self._highlighted_index = None
                self.points_changed.emit(len(self._points))
            self.update()
            return
        if event.button() != Qt.MouseButton.LeftButton or not self._inside_display(pos):
            return

        if self._interaction_mode == "players":
            nearest = self._nearest_index(pos, self._player_points)
            if nearest is not None:
                self._drag_index = nearest
                self._drag_kind = "player"
                return
            if len(self._player_points) < self.MAX_PLAYERS:
                self._player_points.append(self._image_position(pos))
                self.player_points_changed.emit(len(self._player_points))
                self.update()
            return

        nearest = self._nearest_index(pos, self._points)
        if nearest is not None:
            self._drag_index = nearest
            self._drag_kind = "calibration"
            self._highlighted_index = nearest
            return
        if len(self._points) < self.MAX_POINTS:
            self._points.append(self._image_position(pos))
            self._highlighted_index = None
            self.points_changed.emit(len(self._points))
            self.update()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if self._image is None:
            return
        pos = event.position()
        if self._zoom_drag_start_y is not None:
            factor = math.exp((self._zoom_drag_start_y - pos.y()) / 180.0)
            self.set_zoom(self._zoom_drag_start_value * factor, pos)
            return
        if self._pan_start is not None and self._pan_center_start is not None:
            _, _, dw, dh = self._display_rect
            _, _, sw, sh = self._source_rect
            dx = pos.x() - self._pan_start.x()
            dy = pos.y() - self._pan_start.y()
            self._view_center = QPointF(
                self._pan_center_start.x() - dx * sw / max(1.0, dw),
                self._pan_center_start.y() - dy * sh / max(1.0, dh),
            )
            self._clamp_view_center()
            self.update()
            return
        if self._drag_index is None or not self._inside_display(pos):
            return
        image_pos = self._image_position(pos)
        if self._drag_kind == "player":
            self._player_points[self._drag_index] = image_pos
            self.player_points_changed.emit(len(self._player_points))
        else:
            self._points[self._drag_index] = image_pos
            self.points_changed.emit(len(self._points))
        self.update()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.button() in {Qt.MouseButton.LeftButton, Qt.MouseButton.MiddleButton}:
            self._drag_index = None
            self._drag_kind = None
            self._pan_start = None
            self._pan_center_start = None
            self._zoom_drag_start_y = None
            if self._interaction_mode == "pan":
                self.setCursor(Qt.CursorShape.OpenHandCursor)

    def wheelEvent(self, event: QWheelEvent) -> None:  # noqa: N802
        if self._image is None:
            return
        factor = 1.25 if event.angleDelta().y() > 0 else 1 / 1.25
        self.set_zoom(self._zoom * factor, event.position())
        event.accept()
