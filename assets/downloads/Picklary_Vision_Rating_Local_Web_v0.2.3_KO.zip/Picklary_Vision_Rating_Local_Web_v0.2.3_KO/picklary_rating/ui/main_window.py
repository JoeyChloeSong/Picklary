from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from PySide6.QtCore import QThread, Signal, Slot
from PySide6.QtWidgets import (
    QButtonGroup, QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog, QFormLayout, QFrame,
    QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox, QPlainTextEdit, QProgressBar,
    QPushButton, QSpinBox, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from picklary_rating.analysis.court import CourtCalibration
from picklary_rating.analysis.device import choose_dnn_device, inspect_runtime_capabilities
from picklary_rating.analysis.pipeline import VideoAnalysisPipeline, read_first_frame
from picklary_rating.analysis.preflight import inspect_ball_model, resolve_analysis_preflight
from picklary_rating.config import AnalysisConfig
from picklary_rating.models import AnalysisResult, Point2D
from picklary_rating.ui.calibration_widget import CourtCalibrationLabel
from picklary_rating.ui.style import APP_STYLE


class AnalysisWorker(QThread):
    progress_changed = Signal(int, str)
    result_ready = Signal(object)
    failed = Signal(str)

    def __init__(
        self,
        video_path: str,
        points: list[Point2D],
        player_seed_points: dict[str, Point2D],
        player_names: dict[str, str],
        anchors: dict[str, float],
        config: AnalysisConfig,
    ):
        super().__init__()
        self.video_path = video_path
        self.points = points
        self.player_seed_points = player_seed_points
        self.player_names = player_names
        self.anchors = anchors
        self.config = config

    def run(self) -> None:
        try:
            result = VideoAnalysisPipeline(self.config).analyze(
                self.video_path,
                self.points,
                self.player_names,
                self.anchors,
                lambda p, m: self.progress_changed.emit(p, m),
                self.player_seed_points,
            )
            self.result_ready.emit(result)
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Picklary Vision Rating v0.5.0 · G1.5 Reference Validation")
        self.resize(1480, 920)
        self.setStyleSheet(APP_STYLE)
        self.video_path = ""
        self.last_result: AnalysisResult | None = None
        self.worker: AnalysisWorker | None = None
        self._calibration_ok = True
        self._expanded_calibration = False
        self._model_mode_ok = True

        root = QWidget()
        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(20, 18, 20, 18)
        root_layout.setSpacing(14)
        title = QLabel("Picklary Vision Rating v0.5.0 · G1.5")
        title.setObjectName("Title")
        subtitle = QLabel("실제 참조경기 검증 빌드 · 선수 앵커·첫 서버·최종점수·오디오 진단")
        subtitle.setObjectName("Subtitle")
        root_layout.addWidget(title)
        root_layout.addWidget(subtitle)
        body = QHBoxLayout()
        body.setSpacing(14)
        root_layout.addLayout(body, 1)

        self.left_card = QFrame()
        self.left_card.setObjectName("Card")
        ll = QVBoxLayout(self.left_card)
        instruction = QLabel(
            "1–11 코트점은 그룹별로 지정합니다. 플레이어 선택 모드에서는 각 선수의 발 중앙을 P1→P4 순서로 클릭합니다. "
            "마우스 휠 또는 +/-로 확대·축소하고, 화면 이동 모드에서 왼쪽 드래그합니다. Ctrl+왼쪽 위아래 드래그로도 확대할 수 있습니다."
        )
        instruction.setWordWrap(True)
        instruction.setObjectName("Section")
        ll.addWidget(instruction)

        tool_row = QHBoxLayout()
        self.mode_group = QButtonGroup(self)
        self.mode_group.setExclusive(True)
        self.calibration_mode_button = QPushButton("코트점 1–11")
        self.player_mode_button = QPushButton("플레이어 P1–P4")
        self.pan_mode_button = QPushButton("화면 이동")
        for button, mode in (
            (self.calibration_mode_button, "calibration"),
            (self.player_mode_button, "players"),
            (self.pan_mode_button, "pan"),
        ):
            button.setCheckable(True)
            self.mode_group.addButton(button)
            button.clicked.connect(lambda checked=False, m=mode: self.set_interaction_mode(m))
            tool_row.addWidget(button)
        self.calibration_mode_button.setChecked(True)
        tool_row.addSpacing(10)
        self.zoom_out_button = QPushButton("−")
        self.zoom_in_button = QPushButton("+")
        self.zoom_reset_button = QPushButton("화면 맞춤")
        self.zoom_label = QLabel("100%")
        self.expand_button = QPushButton("크게 보기")
        tool_row.addWidget(self.zoom_out_button)
        tool_row.addWidget(self.zoom_label)
        tool_row.addWidget(self.zoom_in_button)
        tool_row.addWidget(self.zoom_reset_button)
        tool_row.addStretch(1)
        tool_row.addWidget(self.expand_button)
        ll.addLayout(tool_row)

        self.next_point_label = QLabel("다음: 베이스라인 모서리 1/4 · 네 모서리를 아무 순서로 클릭")
        self.next_point_label.setWordWrap(True)
        ll.addWidget(self.next_point_label)
        self.video_label = CourtCalibrationLabel()
        ll.addWidget(self.video_label, 1)

        controls = QHBoxLayout()
        self.select_button = QPushButton("영상 선택")
        self.reset_button = QPushButton("코트점 초기화")
        self.reset_players_button = QPushButton("플레이어 초기화")
        self.point_status = QLabel("코트 0/11 · 플레이어 0/4")
        controls.addWidget(self.select_button)
        controls.addWidget(self.reset_button)
        controls.addWidget(self.reset_players_button)
        controls.addStretch(1)
        controls.addWidget(self.point_status)
        ll.addLayout(controls)
        body.addWidget(self.left_card, 3)

        self.calibration_status = QLabel("지면 8점을 권장합니다. 네트 9~11번은 선택 입력이며 G1에서는 지면·선수 추적 검증에 사용합니다.")
        self.calibration_status.setWordWrap(True)
        ll.addWidget(self.calibration_status)
        self.player_status = QLabel("플레이어 선택은 선택 사항입니다. 사용하면 P1~P4 정체성 유지 정확도가 향상됩니다.")
        self.player_status.setWordWrap(True)
        ll.addWidget(self.player_status)

        self.right_card = QFrame()
        self.right_card.setObjectName("Card")
        rl = QVBoxLayout(self.right_card)
        sec = QLabel("선수 및 앵커 설정")
        sec.setObjectName("Section")
        rl.addWidget(sec)
        self.load_reference_preset_button = QPushButton("0729 참조경기 설정 적용")
        self.load_reference_preset_button.setToolTip("업로드된 0727_1_Picklary_Clips.mp4의 시작 위치와 DUPR 앵커를 적용합니다.")
        rl.addWidget(self.load_reference_preset_button)

        self.device_summary = QLabel()
        self.device_summary.setWordWrap(True)
        self.device_summary.setStyleSheet("color:#65dfbd;font-weight:700;")
        rl.addWidget(self.device_summary)

        form = QFormLayout()
        self.name_edits = {}
        self.anchor_edits = {}
        for idx, label in enumerate("ABCD", 1):
            row = QHBoxLayout()
            name = QLineEdit(f"Player {idx}")
            anchor = QDoubleSpinBox()
            anchor.setRange(0.0, 8.0)
            anchor.setDecimals(2)
            anchor.setSingleStep(0.05)
            anchor.setSpecialValueText("없음")
            self.name_edits[label] = name
            self.anchor_edits[label] = anchor
            row.addWidget(name, 2)
            row.addWidget(QLabel("DUPR"))
            row.addWidget(anchor, 1)
            form.addRow(f"플레이어 {idx}", row)


        self.game_format_combo = QComboBox()
        self.game_format_combo.addItem("15점 경기", 15)
        self.game_format_combo.addItem("11점 경기", 11)
        form.addRow("게임 형식", self.game_format_combo)

        self.initial_server_combo = QComboBox()
        for label, text in (("A", "A · 가까운쪽 오른쪽"), ("B", "B · 가까운쪽 왼쪽"), ("C", "C · 먼쪽 왼쪽"), ("D", "D · 먼쪽 오른쪽")):
            self.initial_server_combo.addItem(text, label)
        form.addRow("첫 서버", self.initial_server_combo)

        final_score_row = QHBoxLayout()
        self.final_score_near = QSpinBox()
        self.final_score_near.setRange(0, 99)
        self.final_score_near.setValue(15)
        self.final_score_far = QSpinBox()
        self.final_score_far.setRange(0, 99)
        self.final_score_far.setValue(13)
        final_score_row.addWidget(QLabel("가까운쪽"))
        final_score_row.addWidget(self.final_score_near)
        final_score_row.addWidget(QLabel(":"))
        final_score_row.addWidget(QLabel("먼쪽"))
        final_score_row.addWidget(self.final_score_far)
        form.addRow("최종 점수", final_score_row)

        self.analysis_start = QDoubleSpinBox()
        self.analysis_start.setRange(0.0, 3600.0)
        self.analysis_start.setDecimals(1)
        self.analysis_start.setSuffix(" s")
        self.analysis_start.setValue(0.0)
        form.addRow("분석 시작 · 워밍업 제외", self.analysis_start)

        self.analysis_mode_combo = QComboBox()
        self.analysis_mode_combo.addItem("자동 · 모델 없으면 포지셔닝 전용", "auto")
        self.analysis_mode_combo.addItem("전체 샷/DUPR · 검증 모델 필수", "full")
        self.analysis_mode_combo.addItem("포지셔닝·풋워크만", "positioning")
        form.addRow("분석 모드", self.analysis_mode_combo)

        self.device_combo = QComboBox()
        self.device_combo.addItem("자동 선택", "auto")
        self.device_combo.addItem("GPU 우선", "gpu")
        self.device_combo.addItem("CPU 강제", "cpu")
        form.addRow("처리 장치", self.device_combo)

        self.person_model = QLineEdit("models/yolox_nano.onnx")
        person_row = QHBoxLayout()
        person_row.addWidget(self.person_model, 1)
        self.browse_person_model_button = QPushButton("찾기")
        person_row.addWidget(self.browse_person_model_button)
        form.addRow("사람 YOLOX 모델", person_row)

        self.lens_mode_combo = QComboBox()
        self.lens_mode_combo.addItem("코트선 자동 추정 · fallback", "auto")
        self.lens_mode_combo.addItem("체커보드 사용자 보정", "user")
        self.lens_mode_combo.addItem("검증 프로파일", "profile")
        self.lens_mode_combo.addItem("보정 안 함", "none")
        form.addRow("렌즈 보정", self.lens_mode_combo)
        self.lens_profile_combo = QComboBox()
        self.lens_profile_combo.addItem("직선/일반 렌즈", "generic_linear")
        self.lens_profile_combo.addItem("GoPro · 사용자 보정 필요", "gopro_user_calibrated")
        self.lens_profile_combo.addItem("스마트폰 초광각 · 사용자 보정 필요", "phone_ultrawide_user_calibrated")
        form.addRow("렌즈 프로파일", self.lens_profile_combo)
        self.user_lens_path = QLineEdit("calibration/user_camera.json")
        form.addRow("사용자 보정 파일", self.user_lens_path)

        self.stride = QSpinBox()
        self.stride.setRange(1, 6)
        self.stride.setValue(2)
        self.stride.setToolTip("사람 검출에만 적용됩니다. 공 검출은 항상 모든 프레임을 처리합니다.")
        form.addRow("사람 검출 간격", self.stride)
        self.ball_model = QLineEdit("models/tracknet_pickleball.onnx")
        model_row = QHBoxLayout()
        model_row.addWidget(self.ball_model, 1)
        self.browse_model_button = QPushButton("찾기")
        self.validate_model_button = QPushButton("검사")
        model_row.addWidget(self.browse_model_button)
        model_row.addWidget(self.validate_model_button)
        form.addRow("공 ONNX 모델", model_row)
        self.classical = QCheckBox("모델 없이 실험용 공 검출 사용 · DUPR 정확도 검증 불가")
        form.addRow("실험 Fallback", self.classical)
        rl.addLayout(form)
        self.model_status = QLabel()
        self.model_status.setWordWrap(True)
        rl.addWidget(self.model_status)

        self.analyze_button = QPushButton("분석 시작")
        self.analyze_button.setObjectName("Primary")
        self.analyze_button.setEnabled(False)
        self.open_report_button = QPushButton("결과 폴더 열기")
        self.open_report_button.setEnabled(False)
        rl.addWidget(self.analyze_button)
        rl.addWidget(self.open_report_button)
        self.progress = QProgressBar()
        self.status_label = QLabel("영상과 코트 기준점을 지정해 주세요.")
        self.status_label.setWordWrap(True)
        rl.addWidget(self.progress)
        rl.addWidget(self.status_label)
        self.results_table = QTableWidget(0, 9)
        self.results_table.setHorizontalHeaderLabels(["선수", "평가", "범위/상대점수", "신뢰도", "서브", "리턴", "공격", "수비", "풋워크"])
        self.results_table.horizontalHeader().setStretchLastSection(True)
        rl.addWidget(self.results_table, 1)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumBlockCount(500)
        self.log.setPlaceholderText("분석 로그")
        rl.addWidget(self.log, 1)
        body.addWidget(self.right_card, 2)
        self.setCentralWidget(root)

        self.select_button.clicked.connect(self.select_video)
        self.load_reference_preset_button.clicked.connect(self.apply_reference_preset)
        self.reset_button.clicked.connect(self.video_label.reset_points)
        self.reset_players_button.clicked.connect(self.video_label.reset_player_points)
        self.video_label.points_changed.connect(self.on_points_changed)
        self.video_label.player_points_changed.connect(self.on_player_points_changed)
        self.video_label.zoom_changed.connect(lambda value: self.zoom_label.setText(f"{value}%"))
        self.zoom_out_button.clicked.connect(self.video_label.zoom_out)
        self.zoom_in_button.clicked.connect(self.video_label.zoom_in)
        self.zoom_reset_button.clicked.connect(self.video_label.reset_view)
        self.expand_button.clicked.connect(self.toggle_calibration_size)
        self.device_combo.currentIndexChanged.connect(self.refresh_device_summary)
        self.analysis_mode_combo.currentIndexChanged.connect(self.refresh_model_status)
        self.ball_model.textChanged.connect(self.refresh_model_status)
        self.classical.toggled.connect(self.refresh_model_status)
        self.browse_model_button.clicked.connect(self.browse_ball_model)
        self.browse_person_model_button.clicked.connect(self.browse_person_model)
        self.validate_model_button.clicked.connect(self.refresh_model_status)
        self.analyze_button.clicked.connect(self.start_analysis)
        self.open_report_button.clicked.connect(self.open_result_folder)
        self.refresh_device_summary()
        self.refresh_model_status()

    @Slot()
    def apply_reference_preset(self) -> None:
        """Apply the user-supplied 0729 reference-game context.

        A/B/C/D correspond to the order in which player foot points are clicked.
        The score is stored as near-side : far-side; the UI keeps it editable.
        """
        values = {
            "A": ("가까운쪽 오른쪽", 5.00),
            "B": ("가까운쪽 왼쪽", 4.70),
            "C": ("먼쪽 왼쪽", 4.60),
            "D": ("먼쪽 오른쪽", 5.10),
        }
        for label, (name, rating) in values.items():
            self.name_edits[label].setText(name)
            self.anchor_edits[label].setValue(rating)
        self.initial_server_combo.setCurrentIndex(self.initial_server_combo.findData("A"))
        self.game_format_combo.setCurrentIndex(self.game_format_combo.findData(15))
        self.final_score_near.setValue(15)
        self.final_score_far.setValue(13)
        self.analysis_start.setValue(0.0)
        self.status_label.setText(
            "0729 참조경기 설정 적용 · A 가까운쪽 오른쪽 첫 서버 · 최종점수는 가까운쪽 15 : 먼쪽 13으로 입력되었습니다."
        )
        self.log.appendPlainText(
            "[PRESET] reference_game_0729 · A near-right 5.00, B near-left 4.70, "
            "C far-left 4.60, D far-right 5.10 · first server A · score near 15 : far 13 · warm-up 0s"
        )

    def set_interaction_mode(self, mode: str) -> None:
        self.video_label.set_interaction_mode(mode)
        if mode == "calibration":
            self.next_point_label.setText("코트점 지정 모드 · 기존 점은 끌어서 수정할 수 있습니다.")
        elif mode == "players":
            count = len(self.video_label.player_points())
            self.next_point_label.setText(f"플레이어 선택 모드 · 다음 P{min(count + 1, 4)}의 발 중앙을 클릭하세요.")
        else:
            self.next_point_label.setText("화면 이동 모드 · 왼쪽 드래그로 이동하고 휠로 확대·축소하세요.")

    @Slot()
    def toggle_calibration_size(self) -> None:
        self._expanded_calibration = not self._expanded_calibration
        self.right_card.setVisible(not self._expanded_calibration)
        self.expand_button.setText("설정창 보이기" if self._expanded_calibration else "크게 보기")

    @Slot()
    def refresh_device_summary(self) -> None:
        requested = self.device_combo.currentData() if hasattr(self, "device_combo") else "auto"
        caps = inspect_runtime_capabilities(str(requested))
        mode = str(self.analysis_mode_combo.currentData()) if hasattr(self, "analysis_mode_combo") else "auto"
        model_ready = False
        if hasattr(self, "ball_model"):
            model_ready = inspect_ball_model(self._resolved_model_path()).production_ready
        fallback_checked = bool(hasattr(self, "classical") and self.classical.isChecked())
        if mode == "positioning" or (mode == "auto" and not model_ready and not fallback_checked):
            ball_label = "비활성 · 포지셔닝 전용"
        else:
            _, ball_label = choose_dnn_device(str(requested))
        self.device_summary.setText(
            f"감지 상태: {caps.hardware_summary}\n"
            f"예상 실행: 사람 검출은 YOLOX ONNX · 공 분석은 {ball_label}. 분석 시작 후 실제 장치가 기록됩니다."
        )

    def _resolved_model_path(self) -> Path:
        path = Path(self.ball_model.text().strip() or "models/tracknet_pickleball.onnx")
        return path if path.is_absolute() else Path.cwd() / path

    @Slot()
    def browse_person_model(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "YOLOX ONNX 사람 모델 선택", "", "ONNX Model (*.onnx)")
        if path:
            self.person_model.setText(path)

    @Slot()
    def browse_ball_model(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Picklary TrackNet ONNX 모델 선택", "", "ONNX Model (*.onnx)")
        if path:
            self.ball_model.setText(path)

    @Slot()
    def refresh_model_status(self) -> None:
        mode = str(self.analysis_mode_combo.currentData()) if hasattr(self, "analysis_mode_combo") else "auto"
        model = inspect_ball_model(self._resolved_model_path())
        if model.production_ready:
            self._model_mode_ok = True
            self.model_status.setStyleSheet("color:#65dfbd;font-weight:700;")
            self.model_status.setText(
                f"공 모델 준비됨 · 입력 {model.input_size[0]}×{model.input_size[1]} · {model.stack_frames}프레임 · "
                f"홀드아웃 F1 {model.validation_f1:.3f} / Precision {model.validation_precision:.3f} · "
                f"라이선스 {model.license_id} · 전체 샷 분석 가능"
            )
        elif mode == "full" and not self.classical.isChecked():
            self._model_mode_ok = False
            self.model_status.setStyleSheet("color:#ff7b7b;font-weight:700;")
            self.model_status.setText(
                "전체 샷/DUPR 모드는 검증된 ONNX와 같은 이름의 JSON 메타데이터가 필요합니다. "
                + (model.error or "모델을 찾을 수 없습니다.")
            )
        elif self.classical.isChecked() and mode != "positioning":
            self._model_mode_ok = True
            self.model_status.setStyleSheet("color:#ffd166;font-weight:700;")
            self.model_status.setText(
                "실험용 공 검출 모드입니다. 샷 결과가 생성될 수 있으나 DUPR 정확도나 공 검출 정확도를 보장하지 않습니다."
            )
        else:
            self._model_mode_ok = True
            self.model_status.setStyleSheet("color:#79aefc;font-weight:700;")
            self.model_status.setText(
                "검증된 공 모델 없음 · 포지셔닝·풋워크 전용 분석은 즉시 사용할 수 있습니다. "
                "서브·리턴·샷 선택·속도·DUPR는 표시하지 않습니다."
            )
        full_capable = mode == "full" or (mode == "auto" and (model.production_ready or self.classical.isChecked()))
        for anchor in self.anchor_edits.values():
            anchor.setEnabled(full_capable)
            anchor.setToolTip("전체 샷 분석에서만 사용됩니다." if not full_capable else "알려진 실제 DUPR 앵커")
        self.refresh_device_summary()
        self.update_ready_state()

    @Slot()
    def select_video(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "피클볼 경기 영상 선택", "", "Video Files (*.mp4 *.mov *.m4v *.mkv *.avi *.webm)")
        if not path:
            return
        try:
            frame = read_first_frame(path)
        except Exception as exc:
            QMessageBox.critical(self, "영상 오류", str(exc))
            return
        self.video_path = path
        self.video_label.set_frame(frame)
        self.calibration_mode_button.setChecked(True)
        self.set_interaction_mode("calibration")
        self.status_label.setText(f"선택됨: {Path(path).name} · 지면 기준점 8개를 지정하세요. 네트 3점은 선택 사항입니다.")
        self.log.appendPlainText(f"[VIDEO] {path}")
        self.update_ready_state()

    @Slot(int)
    def on_points_changed(self, count: int) -> None:
        mode = "지면보정" if count == 8 else "선택 3D 보정" if count == 11 else "입력 중"
        self.point_status.setText(f"코트 {count}/11 · {mode} · 플레이어 {len(self.video_label.player_points())}/4")
        if self.video_label.interaction_mode() == "calibration":
            self._update_next_point_text(count)
        self._validate_calibration_preview(count)
        self.update_ready_state()

    @Slot(int)
    def on_player_points_changed(self, count: int) -> None:
        self.point_status.setText(f"코트 {len(self.video_label.points())}/11 · 플레이어 {count}/4")
        if count == 0:
            self.player_status.setText("플레이어 선택 없음 · 자동 배정을 사용합니다.")
            self.player_status.setStyleSheet("")
        elif count < 4:
            self.player_status.setText(f"P{count + 1}의 발 중앙을 클릭하세요. 4명 선택이 끝나야 분석할 수 있습니다.")
            self.player_status.setStyleSheet("color:#ffd166;font-weight:700;")
        else:
            self.player_status.setText("P1~P4 수동 선택 완료 · 첫 프레임의 위치와 복장 특징으로 정체성을 초기화합니다.")
            self.player_status.setStyleSheet("color:#65dfbd;font-weight:700;")
        if self.video_label.interaction_mode() == "players":
            self.next_point_label.setText("플레이어 P1~P4 선택 완료" if count == 4 else f"다음: P{count + 1}의 발 중앙")
        self.update_ready_state()

    def _update_next_point_text(self, count: int) -> None:
        if count < 4:
            self.next_point_label.setText(f"다음: 베이스라인 모서리 {count + 1}/4 · 네 모서리를 아무 순서로 클릭")
        elif count < 8:
            self.next_point_label.setText(f"다음: 키친라인 모서리 {count - 3}/4 · 먼쪽/가까운쪽과 좌우 순서는 자동 정렬")
        elif count < 10:
            self.next_point_label.setText(f"다음: 네트 포스트 상단 {count - 7}/2 · 좌우 순서는 자동 정렬")
        elif count == 10:
            self.next_point_label.setText("다음: 네트 중앙 상단 1/1")
        else:
            self.next_point_label.setText("11점 입력 완료 · 플레이어 P1~P4를 선택하거나 바로 분석할 수 있습니다.")

    def _validate_calibration_preview(self, count: int) -> None:
        self._calibration_ok = True
        self.video_label.set_highlighted_point(None)
        if count not in (8, 11):
            self.calibration_status.setText("지면 기준점 8개가 필수입니다. 네트 3점은 선택 사항입니다.")
            self.calibration_status.setStyleSheet("")
            return
        image_size = self.video_label.image_size()
        if image_size is None:
            return
        try:
            cal = CourtCalibration(self.video_label.points(), image_size=image_size)
        except Exception as exc:
            self._calibration_ok = False
            self.calibration_status.setText(f"캘리브레이션 계산 실패: {type(exc).__name__}: {exc}")
            self.calibration_status.setStyleSheet("color:#ff7b7b;font-weight:700;")
            return
        diag = cal.diagnostics
        if count < 11:
            order_note = " · 클릭 순서 자동 정렬됨" if diag.input_order_adjusted else ""
            self.calibration_status.setText(f"지면 보정 준비 완료{order_note}. 네트 3점은 선택 사항입니다.")
            self.calibration_status.setStyleSheet("color:#65dfbd;font-weight:700;")
            return
        order_note = " · 클릭 순서 자동 정렬됨" if diag.input_order_adjusted else ""
        if diag.mode == "ground_piecewise_8pt_fallback":
            self._calibration_ok = True
            full_text = "측정 불가" if diag.full_model_rmse_px is None else f"{diag.full_model_rmse_px:.1f}px"
            global_text = "–" if diag.ground_global_rmse_px is None else f"{diag.ground_global_rmse_px:.1f}px"
            if diag.systematic_distortion_detected:
                self.video_label.set_highlighted_point(None)
                self.calibration_status.setText(
                    "1–8번 지면 기준점은 구간별 보정으로 통과했습니다. "
                    f"광각/렌즈 왜곡으로 단일 카메라 모델 오차가 {global_text}이며 3D 오차는 {full_text}입니다. "
                    "5번과 8번을 더 움직일 필요가 없습니다. 위치·풋워크 분석은 진행하고, 공 속도·탄도만 자동 비활성화합니다."
                )
            else:
                if diag.worst_point_index >= 0:
                    self.video_label.set_highlighted_point(diag.worst_point_index)
                self.calibration_status.setText(
                    f"11점 3D 보정은 통과하지 못했지만 위치·풋워크 분석은 진행할 수 있습니다. "
                    f"지면 오차 {diag.ground_rmse_px:.1f}px · 3D 오차 {full_text}. "
                    "이 모드에서는 공 속도·탄도만 자동 비활성화됩니다."
                )
            self.calibration_status.setStyleSheet("color:#ffd166;font-weight:700;")
        elif diag.reprojection_rmse_px > 20.0:
            self._calibration_ok = False
            self.video_label.set_highlighted_point(diag.worst_point_index)
            self.calibration_status.setText(
                f"지면 기준점 오차 {diag.reprojection_rmse_px:.1f}px · 허용 한도 20px 초과{order_note}. "
                f"강조된 #{diag.worst_point_index + 1} 점을 정확한 코트 선 교차점으로 끌어 조정하세요."
            )
            self.calibration_status.setStyleSheet("color:#ff7b7b;font-weight:700;")
        elif diag.reprojection_rmse_px > 8.0:
            self.video_label.set_highlighted_point(diag.worst_point_index)
            self.calibration_status.setText(
                f"오차 {diag.reprojection_rmse_px:.1f}px · 분석은 가능하지만 정확도 경고{order_note}. "
                f"#{diag.worst_point_index + 1} 점을 조금 조정하면 좋습니다."
            )
            self.calibration_status.setStyleSheet("color:#ffd166;font-weight:700;")
        else:
            offset_note = "" if diag.net_post_offset_ft is None else f" · 네트 포스트 오프셋 {diag.net_post_offset_ft:.2f}ft"
            self.calibration_status.setText(f"전체 카메라 보정 통과 · RMSE {diag.reprojection_rmse_px:.1f}px{offset_note}{order_note}")
            self.calibration_status.setStyleSheet("color:#65dfbd;font-weight:700;")

    def update_ready_state(self) -> None:
        player_count = len(self.video_label.player_points())
        players_ready = player_count in (0, 4)
        self.analyze_button.setEnabled(
            bool(self.video_path)
            and len(self.video_label.points()) in (8, 11)
            and self._calibration_ok
            and players_ready
            and self._model_mode_ok
            and not self.worker
        )

    @Slot()
    def start_analysis(self) -> None:
        if not self.video_path or len(self.video_label.points()) not in (8, 11):
            return
        player_points = self.video_label.player_points()
        if player_points and len(player_points) != 4:
            QMessageBox.warning(self, "플레이어 선택 미완료", "플레이어를 P1부터 P4까지 모두 선택하거나 플레이어 초기화를 눌러 주세요.")
            return
        requested_device = str(self.device_combo.currentData())
        requested_mode = str(self.analysis_mode_combo.currentData())
        try:
            preflight = resolve_analysis_preflight(
                requested_mode,
                self._resolved_model_path(),
                self.classical.isChecked(),
            )
        except Exception as exc:
            QMessageBox.warning(self, "분석 준비 실패", str(exc))
            self.refresh_model_status()
            return
        if preflight.warning:
            self.log.appendPlainText(f"[PREFLIGHT] {preflight.warning}")
        person_path = Path(self.person_model.text().strip() or "models/yolox_nano.onnx")
        if not person_path.is_absolute():
            person_path = Path.cwd() / person_path
        cfg = AnalysisConfig(
            person_stride=self.stride.value(),
            detector_model="yolox_onnx",
            person_model_path=str(person_path),
            analysis_mode=requested_mode,
            processing_device=requested_device,
            ball_model_path=str(self._resolved_model_path()),
            enable_classical_ball_fallback=self.classical.isChecked(),
            lens_mode=str(self.lens_mode_combo.currentData()),
            lens_profile_id=str(self.lens_profile_combo.currentData()),
            user_lens_calibration_path=self.user_lens_path.text().strip() or "calibration/user_camera.json",
            output_root=Path.home() / "PicklaryVisionResults",
            analysis_start_s=self.analysis_start.value(),
            game_target_points=int(self.game_format_combo.currentData()),
            initial_server_label=str(self.initial_server_combo.currentData()),
            first_server_side={"A": "near_right", "B": "near_left", "C": "far_left", "D": "far_right"}.get(str(self.initial_server_combo.currentData())),
            final_score_near=self.final_score_near.value(),
            final_score_far=self.final_score_far.value(),
            session_preset_id="reference_game_0729" if Path(self.video_path).name == "0727_1_Picklary_Clips.mp4" else None,
        )
        names = {label: edit.text().strip() or f"Player {idx}" for idx, (label, edit) in enumerate(self.name_edits.items(), 1)}
        anchors = {label: edit.value() for label, edit in self.anchor_edits.items() if edit.value() >= 2.0}
        seed_map = {label: point for label, point in zip("ABCD", player_points)}
        self.worker = AnalysisWorker(self.video_path, self.video_label.points(), seed_map, names, anchors, cfg)
        self.worker.progress_changed.connect(self.on_progress)
        self.worker.result_ready.connect(self.on_result)
        self.worker.failed.connect(self.on_failed)
        self.worker.finished.connect(self.on_worker_finished)
        self.select_button.setEnabled(False)
        self.analyze_button.setEnabled(False)
        self.progress.setValue(0)
        self.log.appendPlainText(
            f"[START] 영상 분석 시작 · 모드: {preflight.resolved_mode} · 장치 요청: {requested_device} · "
            f"수동 플레이어: {len(seed_map)}명 · 첫 서버: {cfg.initial_server_label} · "
            f"최종점수 가까운쪽 {cfg.final_score_near}:먼쪽 {cfg.final_score_far}"
        )
        self.worker.start()

    @Slot(int, str)
    def on_progress(self, value: int, message: str) -> None:
        self.progress.setValue(value)
        self.status_label.setText(message)
        self.log.appendPlainText(f"[{value:03d}%] {message}")
        if message.startswith("처리 장치:"):
            self.device_summary.setText(f"실제 실행: {message.removeprefix('처리 장치:').strip()}")

    @Slot(object)
    def on_result(self, result: AnalysisResult) -> None:
        self.last_result = result
        self.results_table.setRowCount(len(result.player_reports))

        def fmt(value, decimals=0):
            return "–" if value is None else f"{value:.{decimals}f}"

        for row, report in enumerate(result.player_reports):
            scores = report.skill_scores
            if report.dupr_estimate is not None:
                assessment = f"{report.dupr_estimate:.3f}"
            elif report.status == "relative_only":
                assessment = f"상대 #{report.relative_rank}"
            elif report.status == "positioning_only":
                assessment = f"포지셔닝 {fmt(report.skill_scores.agility)}"
            else:
                assessment = "측정 불가"
            span = f"{report.dupr_low:.3f}–{report.dupr_high:.3f}" if report.dupr_low is not None else (
                f"상대 #{report.relative_rank} · 지수 {fmt(report.relative_score, 1)}"
                if report.status == "positioning_only" and report.relative_score is not None
                else f"점수 {fmt(report.relative_score, 1)}" if report.relative_score is not None else "–"
            )
            values = [
                report.display_name, assessment, span, f"{report.confidence * 100:.0f}%",
                fmt(scores.serve), fmt(scores.return_skill), fmt(scores.offense), fmt(scores.defense), fmt(scores.agility),
            ]
            for col, value in enumerate(values):
                self.results_table.setItem(row, col, QTableWidgetItem(value))
        runtime = result.diagnostics.get("processing_device", {})
        if runtime:
            self.device_summary.setText(f"실제 실행: {runtime.get('summary', '알 수 없음')}")
        self.open_report_button.setEnabled(True)
        self.status_label.setText(f"분석 완료 · 결과: {result.output_dir}")
        self.log.appendPlainText(f"[DONE] {result.output_dir}")

    @Slot(str)
    def on_failed(self, message: str) -> None:
        self.status_label.setText("분석 실패")
        self.log.appendPlainText(f"[ERROR] {message}")
        QMessageBox.critical(self, "분석 실패", message)

    @Slot()
    def on_worker_finished(self) -> None:
        self.worker = None
        self.select_button.setEnabled(True)
        self.update_ready_state()

    @Slot()
    def open_result_folder(self) -> None:
        if self.last_result is None:
            return
        path = Path(self.last_result.output_dir)
        if not path.exists():
            return
        if sys.platform.startswith("win"):
            os.startfile(path)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
