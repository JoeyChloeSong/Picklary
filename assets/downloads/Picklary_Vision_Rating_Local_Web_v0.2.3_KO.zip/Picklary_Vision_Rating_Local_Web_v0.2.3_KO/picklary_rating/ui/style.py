APP_STYLE = r"""
QMainWindow, QWidget { background: #07101f; color: #f7fbff; font-family: 'Segoe UI'; font-size: 13px; }
QFrame#Card { background: #0f1b31; border: 1px solid #233857; border-radius: 18px; }
QLabel#Title { font-size: 26px; font-weight: 800; color: #f7fbff; }
QLabel#Subtitle { color: #9fb0c8; font-size: 13px; }
QLabel#Section { color: #64e3bb; font-weight: 700; font-size: 14px; }
QPushButton { background: #17345a; color: #f7fbff; border: 1px solid #31577f; border-radius: 11px; padding: 10px 14px; font-weight: 700; }
QPushButton:hover { border-color: #64e3bb; background: #1b416a; }
QPushButton:pressed { background: #102a48; }
QPushButton:checked { background: #64e3bb; color: #062018; border-color: #64e3bb; }
QPushButton#Primary { background: #64e3bb; color: #062018; border-color: #64e3bb; }
QPushButton#Primary:hover { background: #86ebca; }
QPushButton:disabled { background: #132238; color: #64758e; border-color: #203149; }
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox { background: #081527; border: 1px solid #294564; border-radius: 9px; padding: 8px; color: #f7fbff; }
QProgressBar { background: #081527; border: 1px solid #294564; border-radius: 7px; height: 14px; text-align: center; }
QProgressBar::chunk { background: #64e3bb; border-radius: 6px; }
QPlainTextEdit { background: #081527; color: #c7d6ea; border: 1px solid #294564; border-radius: 10px; padding: 8px; }
QTableWidget { background: #081527; alternate-background-color: #0d1b30; gridline-color: #203754; border: 1px solid #294564; border-radius: 10px; }
QHeaderView::section { background: #132640; color: #f7fbff; padding: 8px; border: none; }
"""
