from __future__ import annotations

from pathlib import Path
import hashlib
import os
import sys
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
MODELS = ROOT / "models"
MODELS.mkdir(parents=True, exist_ok=True)

MODELS_TO_FETCH = [
    {
        "name": "YOLOX-Nano person detector",
        "url": "https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0/yolox_nano.onnx",
        "path": MODELS / "yolox_nano.onnx",
        "minimum_size": 3_000_000,
    }
]


def fetch(item: dict[str, object]) -> None:
    path = Path(item["path"])
    minimum = int(item["minimum_size"])
    if path.exists() and path.stat().st_size >= minimum:
        print(f"[model] ready: {path.name} ({path.stat().st_size:,} bytes)")
        return
    tmp = path.with_suffix(path.suffix + ".download")
    print(f"[model] downloading {item['name']}...")
    request = urllib.request.Request(str(item["url"]), headers={"User-Agent": "PicklaryVisionRating/0.1"})
    with urllib.request.urlopen(request, timeout=180) as response, tmp.open("wb") as out:
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            out.write(chunk)
    if tmp.stat().st_size < minimum:
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f"downloaded model is too small: {tmp.stat().st_size}")
    os.replace(tmp, path)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    print(f"[model] saved: {path.name} sha256={digest}")


def main() -> int:
    try:
        for item in MODELS_TO_FETCH:
            fetch(item)
        return 0
    except Exception as exc:
        print(f"[model] ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
