#!/usr/bin/env sh
set -eu
export PVR_DATA_ROOT="${PVR_DATA_ROOT:-$(pwd)/data/jobs}"
python scripts/fetch_models.py
exec uvicorn backend.app.main:app --host 0.0.0.0 --port "${PORT:-8080}" --reload
