from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_korean_edition_is_pinned_to_korean_locale_and_port():
    launcher = (ROOT / "local_launcher.py").read_text(encoding="utf-8")
    start = (ROOT / "START_HERE.cmd").read_text(encoding="ascii")
    assert 'PACKAGE_LOCALE = "ko"' in launcher
    assert 'PACKAGE_PORT = 8765' in launcher
    assert 'set "PVR_LOCALE=ko"' in start
    assert 'set "PVR_LOCAL_PORT=8765"' in start


def test_korean_report_keeps_full_analytics_with_hexagon():
    report = (ROOT / "frontend" / "sample_report.html").read_text(encoding="utf-8")
    required = [
        "6개 역량의 강점과 약점",
        "서브·리턴의 성공률, 깊이와 속도",
        "샷 구성과 경기 운영 성향",
        "포지셔닝·풋워크·코트 커버리지",
        "샷 궤적과 타구 위치",
        "사용자 제공 PB Vision 경기와 교차검증",
        "skill-radar",
    ]
    for text in required:
        assert text in report


def test_korean_and_english_editions_use_separate_data_directories():
    launcher = (ROOT / "local_launcher.py").read_text(encoding="utf-8")
    assert 'PACKAGE_DATA_DIR = "PicklaryVisionLocal_KO"' in launcher
