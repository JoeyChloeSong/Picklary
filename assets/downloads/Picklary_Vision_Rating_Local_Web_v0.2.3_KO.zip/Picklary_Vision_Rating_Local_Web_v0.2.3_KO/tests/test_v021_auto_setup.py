from pathlib import Path

import cv2
import numpy as np

from picklary_rating.analysis.auto_setup import detect_court

ROOT = Path(__file__).resolve().parents[1]


def _synthetic_court() -> np.ndarray:
    image = np.zeros((720, 1280, 3), dtype=np.uint8)
    quad = np.float32([[430, 130], [850, 130], [1100, 650], [180, 650]])
    H = cv2.getPerspectiveTransform(
        np.float32([[0, 0], [20, 0], [20, 44], [0, 44]]), quad
    )
    lines = [
        ((0, 0), (20, 0)), ((20, 0), (20, 44)),
        ((20, 44), (0, 44)), ((0, 44), (0, 0)),
        ((0, 15), (20, 15)), ((0, 22), (20, 22)),
        ((0, 29), (20, 29)), ((10, 0), (10, 15)),
        ((10, 29), (10, 44)),
    ]
    for start, end in lines:
        pts = cv2.perspectiveTransform(np.float32([[start, end]]), H)[0].astype(int)
        cv2.line(image, tuple(pts[0]), tuple(pts[1]), (255, 255, 255), 5)
    return image


def test_auto_court_detector_returns_eight_ordered_points():
    result = detect_court(_synthetic_court())
    assert result.status in {"automatic", "semi_auto"}
    assert result.confidence >= 0.65
    assert len(result.points) == 8
    assert result.points[0]["y"] < result.points[2]["y"]


def test_auto_setup_endpoint_and_assisted_guide_are_wired():
    main_source = (ROOT / "backend" / "app" / "main.py").read_text(encoding="utf-8")
    html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
    js = (ROOT / "frontend" / "app.js").read_text(encoding="utf-8")
    assert '/api/jobs/{job_id}/auto-setup' in main_source
    assert 'id="runAutoSetup"' in html
    assert 'id="setupGuide"' in html
    assert 'id="setupActionList"' in html
    assert 'id="confirmCourt"' in html
    assert 'id="confirmPlayers"' in html
    assert '/auto-setup' in js
    assert 'required_actions' in js


def test_completed_points_are_auto_verified_without_extra_clicks():
    js = (ROOT / "frontend" / "app.js").read_text(encoding="utf-8")
    assert 'function syncAutoVerification()' in js
    assert 'state.courtConfirmed=state.court.length===8' in js
    assert 'state.playersConfirmed=playerCount()===4' in js
    assert '$("toStep3").disabled=!(state.courtConfirmed&&state.playersConfirmed)' in js
    assert 'setTimeout(()=>{if(state.file&&!state.uploadedComplete)$("runAutoSetup").click();},250)' in js


def test_low_confidence_paths_use_manual_input_without_guess_points():
    source = (ROOT / "picklary_rating" / "analysis" / "auto_setup.py").read_text(encoding="utf-8")
    html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
    js = (ROOT / "frontend" / "app.js").read_text(encoding="utf-8")
    assert 'status = "manual" if manual' in source
    assert 'points = []' in source
    assert 'manualSetupNotice' in html
    assert 'enterManualSetup' in js
    assert 'applyBrowserRecommendations' not in js
    assert 'court_slot_recommendation' not in source
