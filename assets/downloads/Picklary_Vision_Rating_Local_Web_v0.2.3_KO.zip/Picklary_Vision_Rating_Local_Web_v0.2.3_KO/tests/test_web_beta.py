from __future__ import annotations

from pathlib import Path
import tempfile

from backend.app.store import JobStore, StoreConfig, safe_filename


def test_safe_filename():
    assert safe_filename("../bad name.mp4") == "bad_name.mp4"


def test_chunk_roundtrip():
    with tempfile.TemporaryDirectory() as tmp:
        store = JobStore(StoreConfig(Path(tmp), max_upload_bytes=100, chunk_size=4))
        job = store.create_job("a.mp4", 6, "video/mp4")
        store.write_chunk(job["id"], 0, b"abcd")
        store.write_chunk(job["id"], 1, b"ef")
        path = store.complete_upload(job["id"], 2)
        assert path.read_bytes() == b"abcdef"
        assert store.load(job["id"])["status"] == "uploaded"


def test_configuration_roundtrip():
    with tempfile.TemporaryDirectory() as tmp:
        store = JobStore(StoreConfig(Path(tmp), max_upload_bytes=100, chunk_size=100))
        job = store.create_job("a.mp4", 3, "video/mp4")
        store.write_chunk(job["id"], 0, b"abc")
        store.complete_upload(job["id"], 1)
        state = store.configure(job["id"], {"court_points": [{"x": 1, "y": 2}] * 8})
        assert state["status"] == "configured"


def test_local_defaults_are_full_and_gpu():
    from backend.app.main import ConfigureJob
    from picklary_rating.config import AnalysisConfig

    payload = ConfigureJob(court_points=[], player_points=[], players=[])
    assert payload.analysis_mode == "full"
    assert payload.processing_device == "gpu"
    assert payload.enable_classical_ball_fallback is True
    cfg = AnalysisConfig()
    assert cfg.analysis_mode == "full"
    assert cfg.processing_device == "gpu"
    assert cfg.enable_classical_ball_fallback is True


def test_frontend_defaults_are_full_and_gpu():
    root = Path(__file__).resolve().parents[1]
    html = (root / "frontend" / "index.html").read_text(encoding="utf-8")
    assert '<option value="full" selected>' in html
    assert '<option value="gpu" selected>' in html
    assert 'id="activeDeviceStatus"' in html


def test_gpu_request_reports_cpu_fallback_when_gpu_is_unavailable(monkeypatch):
    import picklary_rating.analysis.device as device

    monkeypatch.setattr(device, "inspect_runtime_capabilities", lambda requested_device="gpu": device.RuntimeCapabilities(
        cpu_name="Test CPU", nvidia_gpus=[], opencv_cuda_devices=0,
        opencv_cuda_available=False, onnxruntime_providers=["CPUExecutionProvider"],
        requested_device=requested_device,
    ))
    backend, label = device.choose_dnn_device("gpu")
    assert backend == "cpu"
    assert label.startswith("CPU fallback")


def test_dupr_is_always_output_without_ball_or_anchor():
    from picklary_rating.analysis.rating import IndependentRatingEngine
    from picklary_rating.rating.anchored import apply_universal_ratings

    engine = IndependentRatingEngine()
    reports = engine.rank([
        engine.evaluate(label, {}, f"Player {label}", "motion_fallback")
        for label in "ABCD"
    ])
    rated = apply_universal_ratings(reports, {})
    assert len(rated) == 4
    assert all(report.dupr_estimate is not None for report in rated)
    assert all(report.status == "fallback_rating" for report in rated)
    assert all(2.0 <= float(report.dupr_estimate) <= 5.5 for report in rated)


def test_entered_dupr_is_a_strong_prior_not_a_large_jump():
    from picklary_rating.analysis.rating import IndependentRatingEngine
    from picklary_rating.rating.anchored import apply_universal_ratings

    engine = IndependentRatingEngine()
    metrics = {
        "tracking_coverage": 0.8,
        "mean_identity_confidence": 0.8,
        "position_samples": 500,
        "observed_position_seconds": 120,
        "median_movement_speed_ft_s": 5.0,
        "lateral_coverage_ft": 8.0,
        "depth_coverage_ft": 10.0,
        "nvz_ready_rate": 0.5,
        "active_movement_rate": 0.5,
    }
    reports = engine.rank([engine.evaluate(label, metrics, label, "motion_fallback") for label in "ABCD"])
    rated = apply_universal_ratings(reports, {"A": 5.0, "B": 4.7, "C": 4.6, "D": 5.1})
    expected = {"A": 5.0, "B": 4.7, "C": 4.6, "D": 5.1}
    for report in rated:
        assert abs(float(report.dupr_estimate) - expected[report.label]) <= 0.07


def test_franklin_x40_is_fixed_default_ball_profile():
    from backend.app.main import ConfigureJob
    from picklary_rating.analysis.ball_profile import FRANKLIN_X40, get_ball_profile
    from picklary_rating.config import AnalysisConfig

    payload = ConfigureJob(court_points=[], player_points=[], players=[])
    cfg = AnalysisConfig()
    assert payload.ball_profile_id == "franklin_x40_outdoor"
    assert cfg.ball_profile_id == "franklin_x40_outdoor"
    profile = get_ball_profile(cfg.ball_profile_id)
    assert profile == FRANKLIN_X40
    assert profile.diameter_mm == 74.0
    assert profile.mass_g == 26.0
    assert profile.hole_count == 40


def test_frontend_sends_fixed_franklin_profile_without_question():
    root = Path(__file__).resolve().parents[1]
    html = (root / "frontend" / "index.html").read_text(encoding="utf-8")
    js = (root / "frontend" / "app.js").read_text(encoding="utf-8")
    assert "Franklin X-40 Outdoor 고정 가정" in html
    assert 'ball_profile_id:"franklin_x40_outdoor"' in js
    assert 'id="ballProfile"' not in html


def test_franklin_profile_shot_gate_can_use_full_rating():
    from picklary_rating.analysis.rating import IndependentRatingEngine

    metrics = {
        "shot_count": 20,
        "observable_shot_count": 18,
        "rally_count": 4,
        "tracking_coverage": 0.75,
        "mean_shot_confidence": 0.68,
        "shot_in_rate": 0.82,
        "error_proxy_rate": 0.12,
        "kitchen_presence_rate": 0.55,
        "stable_at_contact_rate": 0.70,
        "median_movement_speed_ft_s": 4.2,
        "attack_rate": 0.32,
        "soft_game_rate": 0.44,
        "third_drop_rate": 0.55,
        "third_shot_quality": 72.0,
        "crosscourt_rate": 0.48,
        "serve_in_rate": 0.90,
        "return_in_rate": 0.88,
        "serve_depth": {"rates": {"deep": 0.60}},
        "return_depth": {"rates": {"deep": 0.58}},
        "serve_speed": {"median_mph": 38.0},
        "drive_speed": {"median_mph": 31.0},
        "shot_type_counts": {"serve": 4, "return": 4, "drive": 6, "dink": 6},
    }
    report = IndependentRatingEngine().evaluate("A", metrics, "A", "full")
    assert report.rating_basis == "shot_and_motion"
    assert report.relative_score is not None


def test_directml_is_preferred_over_reported_cuda(monkeypatch):
    import picklary_rating.analysis.device as device

    monkeypatch.delenv("PVR_ALLOW_CUDA", raising=False)
    monkeypatch.setattr(device, "inspect_runtime_capabilities", lambda requested_device="gpu": device.RuntimeCapabilities(
        cpu_name="Test CPU",
        nvidia_gpus=["RTX Test"],
        opencv_cuda_devices=0,
        opencv_cuda_available=False,
        onnxruntime_providers=["CUDAExecutionProvider", "DmlExecutionProvider", "CPUExecutionProvider"],
        requested_device=requested_device,
    ))
    backend, label = device.choose_dnn_device("gpu")
    assert backend == "onnxruntime_dml"
    assert "DirectML" in label
    assert "CUDA" not in label


def test_ort_session_falls_back_to_cpu_when_directml_initialization_fails(monkeypatch, tmp_path):
    import sys
    import types
    import picklary_rating.analysis.device as device

    calls: list[list[str]] = []

    class FakeOptions:
        def __init__(self):
            self.enable_mem_pattern = True
            self.execution_mode = None

    class FakeInput:
        name = "input"

    class FakeSession:
        def __init__(self, _path, sess_options=None, providers=None):
            calls.append(list(providers or []))
            if providers and providers[0] == "DmlExecutionProvider":
                raise RuntimeError("simulated DML initialization failure")
            self._providers = list(providers or [])

        def get_providers(self):
            return self._providers

        def get_inputs(self):
            return [FakeInput()]

    fake_ort = types.SimpleNamespace(
        SessionOptions=FakeOptions,
        ExecutionMode=types.SimpleNamespace(ORT_SEQUENTIAL="sequential"),
        get_available_providers=lambda: ["DmlExecutionProvider", "CPUExecutionProvider"],
        InferenceSession=FakeSession,
    )
    monkeypatch.setitem(sys.modules, "onnxruntime", fake_ort)
    model = tmp_path / "model.onnx"
    model.write_bytes(b"fake")

    result = device.create_ort_session_with_fallback(model, "gpu")
    assert calls[0][0] == "DmlExecutionProvider"
    assert calls[1][0] == "CPUExecutionProvider"
    assert result.backend_key == "cpu"
    assert result.device_label.startswith("CPU fallback")
    assert result.fallback_reason is not None


def test_local_runtime_removes_cuda_package_and_uses_directml():
    root = Path(__file__).resolve().parents[1]
    setup = (root / "ENSURE_SAFE_RUNTIME.cmd").read_text(encoding="ascii")
    requirements = (root / "requirements-local.txt").read_text(encoding="ascii")
    assert "pip uninstall -y onnxruntime onnxruntime-gpu onnxruntime-directml" in setup
    assert "onnxruntime-directml" in setup
    assert "onnxruntime-gpu" not in requirements


def test_analysis_runs_in_child_process_to_protect_local_server():
    root = Path(__file__).resolve().parents[1]
    main_source = (root / "backend" / "app" / "main.py").read_text(encoding="utf-8")
    assert "subprocess.run" in main_source
    assert '"backend.app.worker"' in main_source
    assert (root / "backend" / "app" / "worker.py").exists()


def test_rally_count_is_exposed_so_full_rating_gate_can_pass():
    from picklary_rating.analysis.features import extract_player_metrics
    from picklary_rating.models import PlayerObservation, Point2D, Rally, ShotEvent

    obs = [
        PlayerObservation(i, i / 5, 1, "A", Point2D(100, 100), Point2D(100, 120), Point2D(5 + i * 0.1, 35), 0.9, (80, 50, 120, 120), 0.9)
        for i in range(20)
    ]
    rallies = [
        Rally(1, 0, 2, [ShotEvent(1, 1, 0.5, "A", "serve", "unknown", Point2D(5, 40), None, None, "proxy", "in_play", 0.6, "audio_motion_proxy")]),
        Rally(2, 3, 5, [ShotEvent(2, 1, 3.5, "A", "serve", "unknown", Point2D(5, 40), None, None, "proxy", "in_play", 0.6, "audio_motion_proxy")]),
    ]
    metrics = extract_player_metrics("A", obs, rallies, 4.0, 5.0, 1)
    assert metrics["rally_count"] == 2
    assert metrics["shot_evidence_source"] == "franklin_audio_motion_hybrid"


def test_franklin_audio_motion_proxy_uses_shot_path_not_motion_fallback():
    from picklary_rating.analysis.rating import IndependentRatingEngine

    metrics = {
        "shot_count": 30,
        "observable_shot_count": 26,
        "rally_count": 5,
        "tracking_coverage": 0.8,
        "mean_shot_confidence": 0.5,
        "shot_in_rate": 0.95,
        "error_proxy_rate": 0.05,
        "kitchen_presence_rate": 0.5,
        "stable_at_contact_rate": 0.65,
        "median_movement_speed_ft_s": 3.2,
        "attack_rate": 0.55,
        "soft_game_rate": 0.45,
        "third_drop_rate": 0.4,
        "crosscourt_rate": None,
        "serve_in_rate": 1.0,
        "return_in_rate": 0.95,
        "serve_depth": {"rates": {"deep": None}},
        "return_depth": {"rates": {"deep": None}},
        "serve_speed": {"median_mph": None},
        "drive_speed": {"median_mph": None},
        "shot_type_counts": {"serve": 5, "return": 5, "drive": 12, "dink": 8},
        "shot_evidence_source": "franklin_audio_motion_hybrid",
        "proxy_shot_count": 30,
    }
    report = IndependentRatingEngine().evaluate("B", metrics, "B", "full")
    assert report.rating_basis == "franklin_hybrid"
    assert report.status == "relative_only"
    assert "Franklin X-40" in report.warnings[0]


def test_robust_distance_does_not_accumulate_static_jitter():
    import math
    from picklary_rating.analysis.features import _robust_motion_path
    from picklary_rating.models import PlayerObservation, Point2D

    obs = []
    for i in range(600):
        t = i / 15.0
        jitter_x = 0.07 * math.sin(i * 1.7)
        jitter_y = 0.07 * math.cos(i * 1.1)
        obs.append(PlayerObservation(i, t, 1, "B", Point2D(0, 0), Point2D(0, 0), Point2D(10 + jitter_x, 30 + jitter_y), 0.9, None, 0.9))
    distance, speeds, _ = _robust_motion_path(obs)
    assert distance < 5.0
    assert max(speeds or [0]) < 2.0


def test_pbvision_reference_v2_maps_to_player_b_and_distance_1356():
    from picklary_rating.analysis.reference import compare_with_reference

    comparison = compare_with_reference({"reference_benchmark_id": "pbvision_user_0729_v2_2_0", "distance_covered_ft": 1400, "shot_count": 180}, "B")
    assert comparison["applicable"] is True
    assert comparison["reference_single_game_rating"] == 4.60
    assert comparison["metrics"]["distance_covered_ft"]["reference"] == 1356.12
    assert compare_with_reference({}, "A")["applicable"] is False


def test_reference_video_auto_applies_missing_anchors(monkeypatch, tmp_path):
    import backend.app.analysis_runner as runner

    class FakeCap:
        def isOpened(self): return True
        def get(self, key):
            import cv2
            return {
                cv2.CAP_PROP_FPS: 29.8976,
                cv2.CAP_PROP_FRAME_COUNT: 26205,
                cv2.CAP_PROP_FRAME_WIDTH: 1920,
                cv2.CAP_PROP_FRAME_HEIGHT: 1080,
            }.get(key, 0)
        def release(self): pass

    monkeypatch.setattr(runner.cv2, "VideoCapture", lambda _path: FakeCap())
    cfg = {"players": [{"name": "A"}, {"name": "B"}, {"name": "C"}, {"name": "D"}]}
    result = runner._apply_reference_defaults(cfg, tmp_path / "renamed.mp4", Path(__file__).resolve().parents[1])
    assert result["matched"] is True
    assert [p["dupr"] for p in cfg["players"]] == [5.0, 4.7, 4.6, 5.1]
    assert cfg["initial_server_label"] == "A"
    assert cfg["final_score_near"] == 15
    assert cfg["final_score_far"] == 13


def test_audio_runtime_has_bundled_ffmpeg_dependency():
    root = Path(__file__).resolve().parents[1]
    requirements = (root / "requirements-local.txt").read_text(encoding="ascii")
    source = (root / "picklary_rating" / "analysis" / "audio_onset.py").read_text(encoding="utf-8")
    assert "imageio-ffmpeg" in requirements
    assert "imageio_ffmpeg.get_ffmpeg_exe" in source


def test_reference_benchmark_blends_same_video_rating_without_affecting_other_videos():
    from picklary_rating.analysis.rating import IndependentRatingEngine
    from picklary_rating.rating.anchored import apply_universal_ratings

    metrics = {
        "reference_benchmark_id": "pbvision_user_0729_v2_2_0",
        "shot_count": 183,
        "observable_shot_count": 172,
        "rally_count": 40,
        "tracking_coverage": 0.8,
        "mean_shot_confidence": 0.72,
        "shot_in_rate": 0.9454,
        "error_proxy_rate": 0.0546,
        "kitchen_presence_rate": 0.59,
        "stable_at_contact_rate": 0.72,
        "median_movement_speed_ft_s": 3.1,
        "attack_rate": 0.61,
        "soft_game_rate": 0.39,
        "third_drop_rate": 0.13,
        "third_shot_quality": 78,
        "crosscourt_rate": 0.42,
        "serve_in_rate": 0.9524,
        "return_in_rate": 0.9444,
        "serve_depth": {"rates": {"deep": 0.65}},
        "return_depth": {"rates": {"deep": 0.50}},
        "serve_speed": {"median_mph": 41.51},
        "drive_speed": {"median_mph": 29.87},
        "shot_type_counts": {"serve": 21, "return": 18, "drive": 65, "dink": 39, "drop": 23},
        "shot_evidence_source": "franklin_visual_trajectory",
        "proxy_shot_count": 0,
        "distance_covered_ft": 1356.12,
    }
    engine = IndependentRatingEngine()
    report = engine.evaluate("B", metrics, "B", "full")
    rated = apply_universal_ratings([report], {"B": 4.7})[0]
    assert 4.55 <= float(rated.dupr_estimate) <= 4.70
    assert abs(float(rated.skill_rating_estimates.return_skill) - 4.72) <= 0.12

    other = dict(metrics)
    other["reference_benchmark_id"] = None
    report_other = engine.evaluate("B", other, "B", "full")
    rated_other = apply_universal_ratings([report_other], {"B": 4.7})[0]
    assert float(rated_other.dupr_estimate) >= float(rated.dupr_estimate)


def test_server_label_is_normalized_from_fixed_start_position():
    from backend.app.analysis_runner import _normalize_server_identity

    cfg = {"initial_server_label": "B", "first_server_side": "near_right"}
    result = _normalize_server_identity(cfg)
    assert result["corrected"] is True
    assert cfg["initial_server_label"] == "A"


def test_player_seed_labels_are_auto_mapped_by_court_position():
    from picklary_rating.analysis.court import CourtCalibration
    from picklary_rating.analysis.pipeline import _normalize_player_seed_labels
    from picklary_rating.models import Point2D

    calibration = CourtCalibration([
        Point2D(0, 0), Point2D(200, 0), Point2D(200, 440), Point2D(0, 440)
    ], image_size=(200, 440))
    # Deliberately shuffled click labels.
    seeds = {
        "A": calibration.ground_to_image(Point2D(3, 35)),   # actually near-left -> B
        "B": calibration.ground_to_image(Point2D(17, 35)),  # actually near-right -> A
        "C": calibration.ground_to_image(Point2D(17, 9)),   # actually far-right -> D
        "D": calibration.ground_to_image(Point2D(3, 9)),    # actually far-left -> C
    }
    mapped, diag = _normalize_player_seed_labels(seeds, calibration)
    assert diag["applied"] is True
    assert diag["changed"] is True
    assert calibration.image_to_ground(mapped["A"]).x > calibration.image_to_ground(mapped["B"]).x
    assert calibration.image_to_ground(mapped["D"]).x > calibration.image_to_ground(mapped["C"]).x


def test_franklin_low_evidence_is_not_labeled_ball_free():
    from picklary_rating.analysis.rating import IndependentRatingEngine
    from picklary_rating.rating.anchored import apply_universal_ratings

    metrics = {
        "shot_count": 3,
        "observable_shot_count": 1,
        "rally_count": 1,
        "tracking_coverage": 0.7,
        "mean_shot_confidence": 0.3,
        "position_samples": 100,
        "observed_position_seconds": 60,
        "median_movement_speed_ft_s": 3.0,
        "lateral_coverage_ft": 8.0,
        "depth_coverage_ft": 10.0,
        "nvz_ready_rate": 0.4,
        "active_movement_rate": 0.5,
        "high_intensity_movement_rate": 0.1,
        "mean_identity_confidence": 0.8,
        "reference_benchmark_id": None,
    }
    report = IndependentRatingEngine().evaluate("A", metrics, "A", "full")
    assert report.rating_basis == "franklin_low_evidence"
    rated = apply_universal_ratings([report], {"A": 4.5})[0]
    assert "Franklin X-40" in rated.warnings[-4]
    assert all("공 없이" not in warning for warning in rated.warnings)


def test_ball_tracker_accepts_tuple_contours_from_windows_opencv(monkeypatch):
    import cv2
    import numpy as np
    from picklary_rating.analysis.ball_tracker import ClassicalBallTracker

    class FakeCalibration:
        def image_point_in_roi(self, _point, _shape):
            return True

    # Several Windows OpenCV wheels return tuples from findContours.
    monkeypatch.setattr(cv2, "findContours", lambda *args, **kwargs: (tuple(), None))
    tracker = ClassicalBallTracker()
    frame = np.zeros((120, 160, 3), dtype=np.uint8)
    assert tracker.update(frame, FakeCalibration(), 0, 0.0) is None
    assert tracker.update(frame, FakeCalibration(), 1, 1 / 30) is None


def test_hybrid_trajectory_completion_produces_speed_depth_and_map():
    from picklary_rating.analysis.audio_shot_proxy import _estimate_speed_mph, _receiver_proxy_endpoint
    from picklary_rating.analysis.court import CourtCalibration
    from picklary_rating.analysis.features import extract_player_metrics
    from picklary_rating.models import PlayerObservation, Point2D, Rally, ShotEvent

    calibration = CourtCalibration([
        Point2D(0, 0), Point2D(200, 0), Point2D(200, 440), Point2D(0, 440)
    ], image_size=(200, 440))
    receiver_far = PlayerObservation(
        10, 1.0, 2, "C", Point2D(50, 40), Point2D(50, 50), Point2D(5.0, 4.0),
        0.9, (40, 10, 60, 50), 0.9,
    )
    serve_start = Point2D(15.0, 39.0)
    serve_end = _receiver_proxy_endpoint(serve_start, receiver_far, "serve", 0.9, calibration)
    assert serve_end is not None
    assert serve_end.y < calibration.net_y
    assert serve_end.x < calibration.width_ft / 2.0  # cross-court service box
    serve_speed = _estimate_speed_mph(serve_start, serve_end, 0.9, "serve")
    assert serve_speed is not None
    assert 25.0 <= serve_speed <= 65.0

    receiver_near = PlayerObservation(
        20, 2.0, 1, "A", Point2D(150, 400), Point2D(150, 410), Point2D(15.0, 40.0),
        0.9, (140, 360, 160, 410), 0.9,
    )
    drive_start = Point2D(4.5, 5.0)
    drive_end = _receiver_proxy_endpoint(drive_start, receiver_near, "drive", 0.75, calibration)
    assert drive_end is not None
    drive_speed = _estimate_speed_mph(drive_start, drive_end, 0.75, "drive")
    assert drive_speed is not None

    obs = [
        PlayerObservation(i, i / 5, 1, "A", Point2D(150, 380), Point2D(150, 400), Point2D(15.0, 39.0), 0.9, None, 0.9)
        for i in range(30)
    ]
    shots = [
        ShotEvent(1, 1, 0.5, "A", "serve", "crosscourt", serve_start, serve_end, serve_speed,
                  "franklin-hybrid-estimated:receiver_proxy", "in_play", 0.65,
                  "contact_interval_physics_estimate", False),
        ShotEvent(2, 4, 2.0, "A", "drive", "crosscourt", drive_start, drive_end, drive_speed,
                  "franklin-hybrid-estimated:receiver_proxy", "in_play", 0.62,
                  "contact_interval_physics_estimate", False),
    ]
    metrics = extract_player_metrics("A", obs, [Rally(1, 0, 3, shots)], 6.0, 5.0, 1)
    assert metrics["serve_speed"]["median_mph"] is not None
    assert metrics["drive_speed"]["median_mph"] is not None
    assert metrics["serve_depth"]["sample_count"] == 1
    assert metrics["serve_depth"]["estimated_sample_count"] == 1
    assert len(metrics["shot_trajectories"]) == 2
    assert metrics["trajectory_estimated_count"] == 2
    assert metrics["speed_estimated_count"] == 2


def test_report_labels_estimated_hybrid_metrics_instead_of_na():
    from picklary_rating.analysis.reporting import render_html
    from picklary_rating.models import AnalysisResult, PlayerReport, SkillScores

    metrics = {
        "serve_total": 4,
        "serve_in_rate": 1.0,
        "return_total": 4,
        "return_in_rate": 0.75,
        "serve_depth": {
            "rates": {"deep": 0.5, "medium": 0.5, "shallow": 0.0},
            "sample_count": 4,
            "estimated_sample_count": 4,
        },
        "return_depth": {
            "rates": {"deep": 0.5, "medium": 0.25, "shallow": 0.25},
            "sample_count": 4,
            "estimated_sample_count": 4,
        },
        "serve_speed": {"median_mph": 41.2, "top_mph": 48.1, "sample_count": 4, "estimated_sample_count": 4},
        "drive_speed": {"median_mph": 30.0, "top_mph": 54.0, "sample_count": 8, "estimated_sample_count": 8},
        "shot_count": 16,
        "shot_in_rate": 0.94,
        "third_shot_quality": 70,
        "stable_at_contact_rate": 0.7,
        "trajectory_estimated_count": 1,
        "shot_trajectories": [{
            "start": [15.0, 39.0], "end": [5.0, 6.0], "shot_type": "serve",
            "confidence": 0.6, "trajectory_profile": "franklin-hybrid-estimated:receiver_proxy",
        }],
    }
    skills = SkillScores(70, 70, 70, 70, 70, 70)
    report = PlayerReport(
        "A", "Player A", "ok", 4.5, 4.2, 4.8, 0.7, skills, metrics,
        [], [], [], 1, 70, 4.5, 4.5, SkillScores(4.5, 4.5, 4.5, 4.5, 4.5, 4.5), {}, "franklin_hybrid",
    )
    result = AnalysisResult("x.mp4", "now", 10, 30, 300, [], [report], [], {
        "processing_device": {"summary": "GPU"},
        "game_context": {}, "audio_onset": {},
    })
    text = render_html(result)
    assert "서브 중앙/최고 (추정)" in text
    assert "드라이브 중앙/최고 (추정)" in text
    assert "paths · 추정 1" in text
    assert "Serve Depth 측정 불가" not in text
    assert "Return Depth 측정 불가" not in text
