from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def _load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _player_b(data: dict[str, Any]) -> dict[str, Any]:
    for player in data.get("player_reports", []):
        if player.get("label") == "B":
            return player
    raise ValueError("analysis.json does not contain player B")


def compare(analysis: dict[str, Any], reference: dict[str, Any]) -> dict[str, Any]:
    player = _player_b(analysis)
    metrics = player.get("metrics") or {}
    target = reference.get("subject_metrics") or {}
    current = {
        "single_game_rating": player.get("single_game_skill_rating") or player.get("dupr_estimate"),
        "shot_total": metrics.get("shot_count"),
        "distance_covered_ft": metrics.get("distance_covered_ft"),
        "serve_total": metrics.get("serve_total"),
        "return_total": metrics.get("return_total"),
        "serve_in_rate": metrics.get("serve_in_rate"),
        "return_in_rate": metrics.get("return_in_rate"),
        "serve_median_mph": (metrics.get("serve_speed") or {}).get("median_mph"),
        "drive_median_mph": (metrics.get("drive_speed") or {}).get("median_mph"),
    }
    expected = {
        "single_game_rating": (reference.get("subject_mapping") or {}).get("single_game_rating"),
        **{k: target.get(k) for k in current if k != "single_game_rating"},
    }
    tolerances = {
        "single_game_rating": 0.15,
        "shot_total": 35,
        "distance_covered_ft": 270,
        "serve_total": 6,
        "return_total": 6,
        "serve_in_rate": 0.10,
        "return_in_rate": 0.10,
        "serve_median_mph": 8,
        "drive_median_mph": 8,
    }
    rows = {}
    passed = True
    measured = 0
    for key, value in current.items():
        ref = expected.get(key)
        delta = None if value is None or ref is None else float(value) - float(ref)
        row_pass = None if delta is None else abs(delta) <= tolerances[key]
        if row_pass is not None:
            measured += 1
            passed = passed and row_pass
        rows[key] = {
            "current": value,
            "reference": ref,
            "delta": None if delta is None else round(delta, 4),
            "tolerance": tolerances[key],
            "pass": row_pass,
        }
    return {
        "benchmark_id": reference.get("reference_id"),
        "player_label": "B",
        "measurement_basis": player.get("rating_basis"),
        "measured_gate_count": measured,
        "pass": bool(passed and measured >= 5),
        "rows": rows,
        "disclaimer": "One user-supplied match benchmark; not PB Vision formula replication.",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("analysis_json", type=Path)
    parser.add_argument("--reference", type=Path, default=Path(__file__).resolve().parents[1] / "config" / "pbvision_reference_0729_full.json")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = compare(_load(args.analysis_json), _load(args.reference))
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(text, encoding="utf-8")
    print(text)
    return 0 if result["pass"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
