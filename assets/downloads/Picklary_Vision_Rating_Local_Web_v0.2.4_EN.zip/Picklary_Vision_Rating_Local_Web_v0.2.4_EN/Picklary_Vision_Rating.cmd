@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Picklary Vision Rating v0.2.4 EN
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"

if not exist "%~dp0unified_bootstrap.py" (
  echo.
  echo [ERROR] Extract the ZIP completely before running Picklary_Vision_Rating.cmd.
  pause
  exit /b 2
)

set "PYEXE="
set "PYARG="
call :find_python
if defined PYEXE goto run_bootstrap

where winget.exe >nul 2>&1
if errorlevel 1 goto no_python
echo Installing Python 3.11 for the current Windows user...
winget install --id Python.Python.3.11 -e --scope user --silent --accept-package-agreements --accept-source-agreements
call :find_python
if not defined PYEXE goto no_python

:run_bootstrap
"%PYEXE%" %PYARG% "%~dp0unified_bootstrap.py" %*
set "RC=%ERRORLEVEL%"
if "%RC%"=="0" exit /b 0
echo.
echo Startup did not complete. See logs\unified_launcher.log.
pause
exit /b %RC%

:find_python
if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
  set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
  goto :eof
)
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
  set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
  goto :eof
)
where py.exe >nul 2>&1
if not errorlevel 1 (
  py.exe -3.11 -c "import sys" >nul 2>&1
  if not errorlevel 1 (
    set "PYEXE=py.exe"
    set "PYARG=-3.11"
    goto :eof
  )
  py.exe -3.12 -c "import sys" >nul 2>&1
  if not errorlevel 1 (
    set "PYEXE=py.exe"
    set "PYARG=-3.12"
    goto :eof
  )
)
where python.exe >nul 2>&1
if not errorlevel 1 (
  python.exe -c "import sys; raise SystemExit(0 if (3,11) <= sys.version_info[:2] <= (3,12) else 1)" >nul 2>&1
  if not errorlevel 1 set "PYEXE=python.exe"
)
goto :eof

:no_python
echo.
echo [ERROR] Python 3.11 or 3.12 could not be installed automatically.
echo Install Python 3.11 and enable Add python.exe to PATH.
start "" "https://www.python.org/downloads/release/python-3119/"
pause
exit /b 1
