from __future__ import annotations

from pathlib import Path
from typing import Any
import json
import os
import shutil
import traceback

import cv2

from picklary_rating.analysis.device import choose_dnn_device, inspect_runtime_capabilities
from picklary_rating.analysis.pipeline import VideoAnalysisPipeline
from picklary_rating.config import AnalysisConfig
from picklary_rating.models import Point2D

from .store import JobStore


def video_metadata(video_path: Path) -> dict[str, Any]:
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError("The uploaded video could not be opened.")
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    duration = frame_count / fps if fps > 0 else 0.0
    ok, frame = cap.read()
    cap.release()
    if not ok:
        raise RuntimeError("The first video frame could not be read.")
    return {
        "fps": fps,
        "frame_count": frame_count,
        "width": width,
        "height": height,
        "duration_s": duration,
        "first_frame": frame,
    }


def create_preview(video_path: Path, output_path: Path) -> dict[str, Any]:
    meta = video_metadata(video_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(output_path), meta.pop("first_frame"), [cv2.IMWRITE_JPEG_QUALITY, 88]):
        raise RuntimeError("The preview image could not be saved.")
    return meta


def _load_reference_preset(project_root: Path) -> dict[str, Any] | None:
    path = project_root / "config" / "reference_game_0729.json"
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _normalize_server_identity(cfg: dict[str, Any]) -> dict[str, Any]:
    side_to_label = {
        "near_right": "A",
        "near_left": "B",
        "far_left": "C",
        "far_right": "D",
    }
    side = cfg.get("first_server_side")
    selected = cfg.get("initial_server_label")
    expected = side_to_label.get(str(side)) if side else None
    if expected and selected and selected != expected:
        cfg["initial_server_label"] = expected
        return {"corrected": True, "from": selected, "to": expected, "reason": f"{side} is fixed to player {expected}"}
    if expected and not selected:
        cfg["initial_server_label"] = expected
        return {"corrected": True, "from": None, "to": expected, "reason": f"derived from {side}"}
    return {"corrected": False, "selected": selected, "side": side}


def _apply_reference_defaults(cfg: dict[str, Any], video_path: Path, project_root: Path) -> dict[str, Any]:
    """Apply known 0729 anchors when the exact reference video is recognized.

    Explicit user inputs are never overwritten. This prevents the empty-anchor
    3.5-centered result that appeared in v0.1.5 while keeping the UI editable.
    """
    preset = _load_reference_preset(project_root)
    if not preset:
        return {"matched": False}
    expected = preset.get("video_expected") or {}
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        return {"matched": False}
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
    frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    cap.release()
    duration = frames / fps if fps > 0 else 0.0
    filename_match = video_path.name.lower() == str(preset.get("video_filename", "")).lower()
    signature_match = (
        width == int(expected.get("width", width))
        and height == int(expected.get("height", height))
        and abs(duration - float(expected.get("duration_s_approx", duration))) <= 3.0
        and abs(fps - float(expected.get("fps_approx", fps))) <= 1.0
    )
    if not (filename_match or signature_match):
        return {"matched": False}

    players = list(cfg.get("players") or [])
    while len(players) < 4:
        players.append({})
    preset_players = preset.get("players") or []
    applied_anchors: dict[str, float] = {}
    for idx, item in enumerate(preset_players[:4]):
        if players[idx].get("dupr") in (None, ""):
            value = item.get("anchor_dupr")
            if value is not None:
                players[idx]["dupr"] = float(value)
                applied_anchors[str(item.get("label") or "ABCD"[idx])] = float(value)
    cfg["players"] = players
    game = preset.get("game") or {}
    final_score = game.get("final_score") or {}
    defaults = {
        "initial_server_label": game.get("initial_server_label"),
        "first_server_side": game.get("initial_server_position"),
        "final_score_near": final_score.get("near"),
        "final_score_far": final_score.get("far"),
        "game_target_points": game.get("target_points"),
    }
    for key, value in defaults.items():
        if cfg.get(key) in (None, "") and value is not None:
            cfg[key] = value
    cfg["reference_benchmark_id"] = "pbvision_user_0729_v2_2_0"
    server_normalization = _normalize_server_identity(cfg)
    return {
        "matched": True,
        "preset_id": preset.get("preset_id"),
        "filename_match": filename_match,
        "signature_match": signature_match,
        "applied_anchors": applied_anchors,
        "explicit_values_preserved": True,
        "server_identity_normalization": server_normalization,
    }


def _points(items: list[dict[str, Any]], expected: int) -> list[Point2D]:
    if len(items) != expected:
        raise ValueError(f"{expected} reference points are required.")
    points = [Point2D(float(item["x"]), float(item["y"])) for item in items]
    if any(p.x < 0 or p.y < 0 for p in points):
        raise ValueError("Reference-point coordinates are invalid.")
    return points


def run_job(store: JobStore, job_id: str, project_root: Path) -> None:
    try:
        state = store.update(job_id, status="analyzing", progress=1, message="Preparing analysis engine", error=None)
        cfg = dict(state.get("configuration") or {})
        video_path = Path(state["video_path"])
        reference_defaults = _apply_reference_defaults(cfg, video_path, project_root)
        if not reference_defaults.get("matched"):
            reference_defaults["server_identity_normalization"] = _normalize_server_identity(cfg)
        output_root = store.job_dir(job_id) / "results"
        output_root.mkdir(parents=True, exist_ok=True)

        calibration_points = _points(cfg.get("court_points") or [], 8)
        player_points = _points(cfg.get("player_points") or [], 4)
        labels = "ABCD"
        player_seed_points = dict(zip(labels, player_points))
        players = cfg.get("players") or []
        player_names = {label: str((players[i] if i < len(players) else {}).get("name") or f"Player {label}") for i, label in enumerate(labels)}
        anchors: dict[str, float] = {}
        for i, label in enumerate(labels):
            value = (players[i] if i < len(players) else {}).get("dupr")
            if value not in (None, ""):
                anchors[label] = float(value)

        requested_device = str(cfg.get("processing_device") or "gpu")
        backend_key, device_label = choose_dnn_device(requested_device)
        runtime_caps = inspect_runtime_capabilities(requested_device)
        store.update(
            job_id,
            reference_preset=reference_defaults,
            resolved_configuration=cfg,
            analysis_device={
                "requested": requested_device,
                "backend": backend_key,
                "summary": device_label,
                "is_gpu": device_label.startswith("GPU"),
                "fallback": "fallback" in device_label.lower(),
                "detail": runtime_caps.hardware_summary,
                "phase": "engine_initialization",
            },
            message=f"Preparing processing device: {device_label}",
        )

        analysis_cfg = AnalysisConfig(
            analysis_mode=str(cfg.get("analysis_mode") or "full"),
            processing_device=requested_device,
            person_stride=int(cfg.get("person_stride") or 2),
            output_root=output_root,
            person_model_path=str(project_root / "models" / "yolox_nano.onnx"),
            ball_model_path=str(project_root / "models" / "tracknet_pickleball.onnx"),
            ball_profile_id=str(cfg.get("ball_profile_id") or "franklin_x40_outdoor"),
            use_ball_profile_for_shot_rating=True,
            enable_classical_ball_fallback=bool(cfg.get("enable_classical_ball_fallback", True)),
            lens_mode=str(cfg.get("lens_mode") or "none"),
            lens_profiles_path=str(project_root / "calibration" / "lens_profiles.json"),
            enable_audio_onset=bool(cfg.get("enable_audio_onset", True)),
            analysis_start_s=float(cfg.get("analysis_start_s") or 0.0),
            game_target_points=int(cfg.get("game_target_points") or 15),
            initial_server_label=cfg.get("initial_server_label"),
            first_server_side=cfg.get("first_server_side"),
            final_score_near=int(cfg["final_score_near"]) if cfg.get("final_score_near") not in (None, "") else None,
            final_score_far=int(cfg["final_score_far"]) if cfg.get("final_score_far") not in (None, "") else None,
            session_preset_id="reference_game_0729" if reference_defaults.get("matched") else "local_web_v0.2.4_franklin_x40",
            reference_benchmark_id=str(cfg.get("reference_benchmark_id") or "") or None,
        )

        def progress(value: int, message: str) -> None:
            updates: dict[str, Any] = {
                "status": "analyzing",
                "progress": max(1, min(99, int(value))),
                "message": message,
            }
            prefix = "Processing device:"
            if message.startswith(prefix):
                summary = message[len(prefix):].strip()
                updates["analysis_device"] = {
                    "requested": requested_device,
                    "summary": summary,
                    "is_gpu": summary.startswith("GPU") or summary.startswith("Hybrid"),
                    "fallback": "fallback" in summary.lower(),
                    "phase": "active_analysis",
                }
            store.update(job_id, **updates)

        result = VideoAnalysisPipeline(analysis_cfg).analyze(
            video_path=video_path,
            calibration_points=calibration_points,
            player_names=player_names,
            anchor_duprs=anchors,
            progress=progress,
            player_seed_points=player_seed_points,
        )
        report_src = result.output_path / "report.html"
        json_src = result.output_path / "analysis.json"
        csv_src = result.output_path / "shots.csv"
        stable_dir = store.job_dir(job_id) / "published"
        stable_dir.mkdir(parents=True, exist_ok=True)
        for src, name in ((report_src, "report.html"), (json_src, "analysis.json"), (csv_src, "shots.csv")):
            if src.exists():
                shutil.copy2(src, stable_dir / name)
        store.update(
            job_id,
            status="complete",
            progress=100,
            message="Analysis complete",
            report_ready=(stable_dir / "report.html").exists(),
            analysis_device=result.diagnostics.get("processing_device"),
            analysis_summary={
                "measurement_mode": result.diagnostics.get("measurement_mode"),
                "processing_device": result.diagnostics.get("processing_device"),
                "player_observations": result.diagnostics.get("player_observations"),
                "ball_observations": result.diagnostics.get("ball_observations"),
                "shots": result.diagnostics.get("shots"),
            },
        )
    except Exception as exc:
        error_text = f"{type(exc).__name__}: {exc}"
        trace_path = store.job_dir(job_id) / "error_trace.txt"
        trace_path.write_text(traceback.format_exc(), encoding="utf-8")
        store.update(job_id, status="failed", progress=0, message="Analysis failed", error=error_text, report_ready=False)
