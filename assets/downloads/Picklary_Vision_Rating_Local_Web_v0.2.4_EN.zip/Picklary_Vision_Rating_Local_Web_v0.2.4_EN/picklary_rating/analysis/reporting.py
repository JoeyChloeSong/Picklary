from __future__ import annotations

import csv
import html
import json
import math
import os
import re
from collections import Counter
from pathlib import Path
from typing import Any, Iterable

from picklary_rating.models import AnalysisResult, PlayerReport, Rally

VERSION = "0.2.4"
PLAYER_DISPLAY = {"A": "P1", "B": "P2", "C": "P3", "D": "P4"}
SKILL_ORDER = ["serve", "return", "offense", "defense", "agility", "consistency"]
SKILL_LABELS = {
    "ko": {"serve": "서브", "return": "리턴", "offense": "공격", "defense": "수비", "agility": "민첩성", "consistency": "일관성"},
    "en": {"serve": "Serve", "return": "Return", "offense": "Offense", "defense": "Defense", "agility": "Agility", "consistency": "Consistency"},
}
SKILL_DESCRIPTIONS = {
    "ko": {
        "serve": "서브 성공률·깊이·속도와 첫 구 안정성",
        "return": "리턴 성공률·깊이·방향 전환 능력",
        "offense": "드라이브·3구 전개·공격 선택의 효율",
        "defense": "소프트게임·리셋·실점 억제와 NVZ 대응",
        "agility": "좌우·전후 커버와 이동 반응성",
        "consistency": "샷 성공률·타구 안정·반복 수행 능력",
    },
    "en": {
        "serve": "Serve success, depth, speed, and first-ball stability",
        "return": "Return success, depth, and directional response",
        "offense": "Drive, third-shot development, and attacking efficiency",
        "defense": "Soft game, resets, error control, and NVZ defense",
        "agility": "Lateral/depth coverage and movement responsiveness",
        "consistency": "Shot success, contact stability, and repeatability",
    },
}
SHOT_TYPE_LABELS = {
    "ko": {
        "serve": "서브", "return": "리턴", "drive": "드라이브", "third_drive": "3구 드라이브",
        "third_drop": "3구 드롭", "drop": "드롭", "dink": "딍크", "reset": "리셋",
        "speedup": "스피드업", "overhead_smash": "오버헤드", "lob": "로브", "volley": "발리",
        "unknown": "기타",
    },
    "en": {
        "serve": "Serve", "return": "Return", "drive": "Drive", "third_drive": "Third-shot drive",
        "third_drop": "Third-shot drop", "drop": "Drop", "dink": "Dink", "reset": "Reset",
        "speedup": "Speed-up", "overhead_smash": "Overhead", "lob": "Lob", "volley": "Volley",
        "unknown": "Other",
    },
}
REFERENCE_LABELS = {
    "ko": {
        "shot_total": "전체 샷", "shot_in_rate": "샷 성공률", "serve_total": "서브 수", "serve_in_rate": "서브 성공률",
        "return_total": "리턴 수", "return_in_rate": "리턴 성공률", "serve_deep_rate": "서브 Deep", "serve_medium_rate": "서브 Medium",
        "serve_shallow_rate": "서브 Shallow", "return_deep_rate": "리턴 Deep", "return_medium_rate": "리턴 Medium",
        "return_shallow_rate": "리턴 Shallow", "serve_median_mph": "서브 중앙속도", "serve_top_mph": "서브 최고속도",
        "drive_median_mph": "드라이브 중앙속도", "drive_top_mph": "드라이브 최고속도", "third_shot_quality": "3구 품질 지수",
        "distance_covered_ft": "이동 거리",
    },
    "en": {
        "shot_total": "Total shots", "shot_in_rate": "Shot success", "serve_total": "Serves", "serve_in_rate": "Serve success",
        "return_total": "Returns", "return_in_rate": "Return success", "serve_deep_rate": "Serve deep", "serve_medium_rate": "Serve medium",
        "serve_shallow_rate": "Serve shallow", "return_deep_rate": "Return deep", "return_medium_rate": "Return medium",
        "return_shallow_rate": "Return shallow", "serve_median_mph": "Median serve speed", "serve_top_mph": "Top serve speed",
        "drive_median_mph": "Median drive speed", "drive_top_mph": "Top drive speed", "third_shot_quality": "Third-shot quality index",
        "distance_covered_ft": "Distance covered",
    },
}
RATE_KEYS = {
    "shot_in_rate", "serve_in_rate", "return_in_rate", "serve_deep_rate", "serve_medium_rate",
    "serve_shallow_rate", "return_deep_rate", "return_medium_rate", "return_shallow_rate",
}


def _locale() -> str:
    value = os.getenv("PVR_LOCALE", os.getenv("PVR_PACKAGE_LOCALE", "en")).strip().lower()
    return "en" if value.startswith("en") else "ko"


def _t(ko: str, en: str) -> str:
    return en if _locale() == "en" else ko


def _fmt(value: Any, digits: int = 1, suffix: str = "") -> str:
    if value is None:
        return _t("측정 불가", "Not available")
    try:
        return f"{float(value):.{digits}f}{suffix}"
    except (TypeError, ValueError):
        return html.escape(str(value))


def _count(value: Any) -> str:
    try:
        return f"{int(value or 0):,}"
    except (TypeError, ValueError):
        return "0"


def _percent(value: Any, digits: int = 0, invert: bool = False) -> str:
    if value is None:
        return _t("측정 불가", "Not available")
    number = 1.0 - float(value) if invert else float(value)
    return f"{number * 100:.{digits}f}%"


def _safe_rate(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        return None


def _skill_values(report: PlayerReport) -> tuple[dict[str, float | None], bool]:
    if report.skill_rating_estimates is not None:
        return report.skill_rating_estimates.as_dict(), True
    return report.skill_scores.as_dict(), False


def _skill_ratio(value: float | None, ratings: bool) -> float:
    if value is None:
        return 0.08
    if ratings:
        return max(0.08, min(1.0, (float(value) - 2.0) / 4.0))
    return max(0.08, min(1.0, float(value) / 100.0))


def _radar_svg(report: PlayerReport) -> str:
    labels = SKILL_LABELS[_locale()]
    values, ratings = _skill_values(report)
    cx, cy, radius = 210.0, 190.0, 128.0
    angles = [-90, -30, 30, 90, 150, 210]

    def point(ratio: float, deg: float) -> tuple[float, float]:
        angle = math.radians(deg)
        return cx + math.cos(angle) * radius * ratio, cy + math.sin(angle) * radius * ratio

    rings: list[str] = []
    for level in (0.2, 0.4, 0.6, 0.8, 1.0):
        points = " ".join(f"{x:.1f},{y:.1f}" for x, y in (point(level, angle) for angle in angles))
        rings.append(f'<polygon points="{points}" fill="none" stroke="rgba(155,193,226,{0.09 + level * 0.13:.2f})" stroke-width="1"/>')
    axes = "".join(
        f'<line x1="{cx}" y1="{cy}" x2="{x:.1f}" y2="{y:.1f}" stroke="rgba(155,193,226,.20)"/>'
        for x, y in (point(1.0, angle) for angle in angles)
    )
    polygon = " ".join(
        f"{x:.1f},{y:.1f}"
        for x, y in (point(_skill_ratio(values.get(key), ratings), angle) for key, angle in zip(SKILL_ORDER, angles))
    )
    nodes: list[str] = []
    labels_svg: list[str] = []
    for key, angle in zip(SKILL_ORDER, angles):
        ratio = _skill_ratio(values.get(key), ratings)
        x, y = point(ratio, angle)
        nodes.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="5" fill="#76f0cb" stroke="#effffa" stroke-width="2"/>')
        lx, ly = point(1.25, angle)
        anchor = "middle"
        if lx < cx - 18:
            anchor = "end"
        elif lx > cx + 18:
            anchor = "start"
        value = values.get(key)
        value_text = "–" if value is None else (f"{float(value):.2f}" if ratings else f"{float(value):.0f}")
        labels_svg.append(
            f'<text x="{lx:.1f}" y="{ly:.1f}" text-anchor="{anchor}" dominant-baseline="middle">'
            f'<tspan class="radar-label">{html.escape(labels[key])}</tspan>'
            f'<tspan class="radar-value" x="{lx:.1f}" dy="18">{value_text}</tspan></text>'
        )
    return (
        '<div class="radar-shell"><svg class="skill-radar" viewBox="0 0 420 380" '
        f'role="img" aria-label="{html.escape(_t("6개 역량 육각형 차트", "Six-dimension performance radar"))}">'
        '<defs><linearGradient id="radarFill" x1="0" y1="0" x2="1" y2="1">'
        '<stop stop-color="#53e6bc" stop-opacity=".62"/><stop offset=".58" stop-color="#53c9ee" stop-opacity=".42"/>'
        '<stop offset="1" stop-color="#8979ff" stop-opacity=".30"/></linearGradient>'
        '<filter id="radarGlow"><feGaussianBlur stdDeviation="5" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>'
        f'{"".join(rings)}{axes}<polygon points="{polygon}" fill="url(#radarFill)" stroke="#6ce9c5" stroke-width="3" filter="url(#radarGlow)"/>'
        f'{"".join(nodes)}{"".join(labels_svg)}</svg></div>'
    )


def _depth_rate(metrics: dict[str, Any], group: str, bucket: str) -> float | None:
    value = (((metrics.get(group) or {}).get("rates") or {}).get(bucket))
    return _safe_rate(value)


def _skill_evidence(report: PlayerReport, key: str) -> list[tuple[str, str]]:
    m = report.metrics
    serve_speed = m.get("serve_speed") or {}
    drive_speed = m.get("drive_speed") or {}
    evidence: dict[str, list[tuple[str, str]]] = {
        "serve": [
            (_t("서브 성공", "Serve success"), _percent(m.get("serve_in_rate"))),
            (_t("Deep 비율", "Deep rate"), _percent(_depth_rate(m, "serve_depth", "deep"))),
            (_t("중앙 속도", "Median speed"), _fmt(serve_speed.get("median_mph"), 1, " mph")),
        ],
        "return": [
            (_t("리턴 성공", "Return success"), _percent(m.get("return_in_rate"))),
            (_t("Deep 비율", "Deep rate"), _percent(_depth_rate(m, "return_depth", "deep"))),
            (_t("크로스코트", "Cross-court"), _percent(m.get("crosscourt_rate"))),
        ],
        "offense": [
            (_t("공격 선택", "Attack selection"), _percent(m.get("attack_rate"))),
            (_t("3구 품질", "Third-shot quality"), _fmt(m.get("third_shot_quality"), 0)),
            (_t("드라이브 중앙", "Median drive"), _fmt(drive_speed.get("median_mph"), 1, " mph")),
        ],
        "defense": [
            (_t("소프트게임", "Soft-game share"), _percent(m.get("soft_game_rate"))),
            (_t("오류 억제", "Error control"), _percent(m.get("error_proxy_rate"), invert=True)),
            (_t("NVZ 활동", "NVZ presence"), _percent(m.get("kitchen_presence_rate"))),
        ],
        "agility": [
            (_t("이동 거리", "Distance"), _fmt(m.get("distance_covered_ft"), 1, " ft")),
            (_t("이동속도 중앙", "Median movement"), _fmt(m.get("median_movement_speed_ft_s"), 1, " ft/s")),
            (_t("좌우 커버", "Lateral coverage"), _fmt(m.get("lateral_coverage_ft"), 1, " ft")),
        ],
        "consistency": [
            (_t("샷 성공", "Shot success"), _percent(m.get("shot_in_rate"))),
            (_t("타구 안정", "Contact stability"), _percent(m.get("stable_at_contact_rate"))),
            (_t("샷 신뢰도", "Shot confidence"), _percent(m.get("mean_shot_confidence"))),
        ],
    }
    return evidence[key]


def _skill_dashboard(report: PlayerReport) -> str:
    values, ratings = _skill_values(report)
    labels = SKILL_LABELS[_locale()]
    valid = [(key, value) for key, value in values.items() if value is not None]
    strongest = max(valid, key=lambda item: item[1])[0] if valid else None
    weakest = min(valid, key=lambda item: item[1])[0] if valid else None
    cards: list[str] = []
    for key in SKILL_ORDER:
        value = values.get(key)
        classes = ["skill-card", f"skill-{key}"]
        flag = ""
        if key == strongest:
            classes.append("is-strength")
            flag = _t("대표 강점", "Top strength")
        elif key == weakest:
            classes.append("is-focus")
            flag = _t("우선 보완", "Priority focus")
        evidence = "".join(
            f'<span><b>{html.escape(label)}</b>{html.escape(value_text)}</span>'
            for label, value_text in _skill_evidence(report, key)
        )
        score_text = _fmt(value, 2 if ratings else 0)
        cards.append(
            f'<article class="{" ".join(classes)}"><div class="skill-card__head"><div><p>{html.escape(labels[key])}</p>'
            f'<small>{html.escape(SKILL_DESCRIPTIONS[_locale()][key])}</small></div>{f"<em>{html.escape(flag)}</em>" if flag else ""}</div>'
            f'<strong>{score_text}</strong><div class="skill-evidence">{evidence}</div></article>'
        )
    return (
        '<section class="performance-signature"><div class="radar-column"><p class="mini-kicker">PERFORMANCE SIGNATURE</p>'
        f'<h3>{_t("6개 역량의 강점과 약점", "Six-dimension strengths and weaknesses")}</h3>'
        f'<p class="fine">{_t("육각형의 돌출된 축은 상대적 강점, 안쪽으로 들어간 축은 우선 보완 영역입니다.", "Axes extending outward indicate relative strengths; recessed axes identify priority development areas.")}</p>'
        f'{_radar_svg(report)}</div><div class="skill-card-grid">{"".join(cards)}</div></section>'
    )


def _accuracy_bar(title: str, total: int, in_rate: float | None) -> str:
    safe = _safe_rate(in_rate)
    if total <= 0 or safe is None:
        return f'<div class="accuracy"><div class="section-title"><h4>{html.escape(title)}</h4><span>{_t("표본 없음", "No samples")}</span></div><div class="na-box">{_t("측정 불가", "Not available")}</div></div>'
    out = 1.0 - safe
    return (
        f'<div class="accuracy"><div class="section-title"><h4>{html.escape(title)}</h4><span>n={total}</span></div>'
        f'<div class="stacked"><div class="in" style="width:{safe*100:.2f}%">{_t("성공", "In")} {safe*100:.0f}%</div>'
        f'<div class="out" style="width:{out*100:.2f}%">{_t("실패", "Out")}</div></div></div>'
    )


def _depth_donut(label: str, depth: dict[str, Any] | None) -> str:
    depth = depth or {}
    rates = depth.get("rates") or {}
    deep = _safe_rate(rates.get("deep")) or 0.0
    medium = _safe_rate(rates.get("medium")) or 0.0
    shallow = _safe_rate(rates.get("shallow")) or 0.0
    total = int(depth.get("sample_count") or 0)
    estimated = int(depth.get("estimated_sample_count") or 0)
    visual = int(depth.get("visual_sample_count") or max(0, total - estimated))
    if total <= 0:
        return f'<div class="donut-card"><div class="na-box">{html.escape(label)} · {_t("표본 없음", "No samples")}</div></div>'
    d1 = deep * 360.0
    d2 = (deep + medium) * 360.0
    style = f"background:conic-gradient(#2edb78 0deg {d1:.2f}deg,#f6c453 {d1:.2f}deg {d2:.2f}deg,#ff775f {d2:.2f}deg 360deg)"
    source = _t(f"실측 {visual} · 추정 {estimated}", f"observed {visual} · estimated {estimated}")
    return (
        f'<article class="donut-card"><div class="donut" style="{style}"><div><strong>{html.escape(label)}</strong><small>n={total}</small></div></div>'
        f'<p class="source-note">{source}</p><div class="legend"><span><i class="deep"></i>Deep {_percent(deep)}</span>'
        f'<span><i class="medium"></i>Medium {_percent(medium)}</span><span><i class="shallow"></i>Shallow {_percent(shallow,1)}</span></div></article>'
    )


def _trajectory_svg(metrics: dict[str, Any]) -> str:
    shots = metrics.get("shot_trajectories") or []
    if not shots:
        return f'<div class="na-box">{_t("유효한 시작·종료 좌표가 없어 샷 맵을 만들 수 없습니다.", "A shot map cannot be created because valid start/end coordinates are unavailable.")}</div>'
    palette = {
        "serve": "#2edb78", "return": "#62a8ff", "third_drop": "#48d9e5", "third_drive": "#ff6f73",
        "drive": "#ff6f73", "dink": "#aa8cff", "drop": "#54d5bb", "reset": "#f6c453",
        "speedup": "#ff9f58", "overhead_smash": "#ff5579",
    }
    paths: list[str] = []
    for shot in shots[:220]:
        try:
            sx, sy = shot["start"]
            ex, ey = shot["end"]
        except (KeyError, TypeError, ValueError):
            continue
        x1, y1 = 24 + float(sx) * 12.1, 14 + float(sy) * 8.0
        x2, y2 = 24 + float(ex) * 12.1, 14 + float(ey) * 8.0
        color = palette.get(str(shot.get("shot_type")), "#8fa9c5")
        opacity = max(0.18, min(0.86, float(shot.get("confidence") or 0.3)))
        estimated = str(shot.get("trajectory_profile") or "").startswith("franklin-hybrid-estimated")
        dash = ' stroke-dasharray="5 4"' if estimated else ""
        control_y = min(y1, y2) - min(42.0, 12.0 + abs(x2 - x1) * 0.12)
        paths.append(
            f'<path d="M{x1:.1f},{y1:.1f} Q{(x1+x2)/2:.1f},{control_y:.1f} {x2:.1f},{y2:.1f}" fill="none" '
            f'stroke="{color}" stroke-opacity="{opacity:.2f}" stroke-width="1.75"{dash}/>'
        )
    return (
        '<svg class="court-map" viewBox="0 0 315 380" role="img" '
        f'aria-label="{html.escape(_t("샷 궤적 코트 맵", "Shot trajectory court map"))}">'
        '<defs><linearGradient id="courtBg" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#eaf2f7"/><stop offset="1" stop-color="#d7e3ec"/></linearGradient></defs>'
        '<rect x="24" y="14" width="266" height="352" rx="10" fill="url(#courtBg)" stroke="#52647a" stroke-width="2"/>'
        '<rect x="24" y="126" width="266" height="128" fill="#c9d8e4" fill-opacity=".55"/>'
        '<line x1="24" y1="190" x2="290" y2="190" stroke="#1d2b3b" stroke-width="5"/>'
        '<line x1="24" y1="126" x2="290" y2="126" stroke="#586a7f" stroke-width="2"/>'
        '<line x1="24" y1="254" x2="290" y2="254" stroke="#586a7f" stroke-width="2"/>'
        '<line x1="157" y1="14" x2="157" y2="126" stroke="#586a7f" stroke-width="2"/>'
        '<line x1="157" y1="254" x2="157" y2="366" stroke="#586a7f" stroke-width="2"/>'
        f'{"".join(paths)}</svg>'
    )


def _contact_map_svg(metrics: dict[str, Any]) -> str:
    shots = metrics.get("shot_trajectories") or []
    points: list[tuple[float, float, str, float]] = []
    for shot in shots[:300]:
        start = shot.get("start")
        if not start or len(start) != 2:
            continue
        try:
            points.append((float(start[0]), float(start[1]), str(shot.get("shot_type") or "unknown"), float(shot.get("confidence") or 0.3)))
        except (TypeError, ValueError):
            continue
    if not points:
        return f'<div class="na-box">{_t("타구 위치 표본이 없습니다.", "No contact-location samples are available.")}</div>'
    palette = {"serve": "#2edb78", "return": "#62a8ff", "third_drop": "#48d9e5", "third_drive": "#ff6f73", "drive": "#ff6f73", "dink": "#aa8cff", "reset": "#f6c453"}
    circles = []
    for x, y, shot_type, confidence in points:
        px, py = 24 + x * 12.1, 14 + y * 8.0
        color = palette.get(shot_type, "#78d8c5")
        radius = 2.2 + max(0.0, min(1.0, confidence)) * 2.8
        circles.append(f'<circle cx="{px:.1f}" cy="{py:.1f}" r="{radius:.1f}" fill="{color}" fill-opacity=".42"/>')
    return (
        '<svg class="court-map" viewBox="0 0 315 380" role="img" '
        f'aria-label="{html.escape(_t("타구 위치 분포", "Contact-location distribution"))}">'
        '<rect x="24" y="14" width="266" height="352" rx="10" fill="#0f2941" stroke="#5f7892" stroke-width="2"/>'
        '<rect x="24" y="126" width="266" height="128" fill="#153852"/>'
        '<line x1="24" y1="190" x2="290" y2="190" stroke="#a6bad0" stroke-width="4"/>'
        '<line x1="24" y1="126" x2="290" y2="126" stroke="#5f7892" stroke-width="2"/>'
        '<line x1="24" y1="254" x2="290" y2="254" stroke="#5f7892" stroke-width="2"/>'
        '<line x1="157" y1="14" x2="157" y2="126" stroke="#5f7892" stroke-width="2"/>'
        '<line x1="157" y1="254" x2="157" y2="366" stroke="#5f7892" stroke-width="2"/>'
        f'{"".join(circles)}</svg>'
    )


def _shot_type_breakdown(metrics: dict[str, Any]) -> str:
    counts = Counter(metrics.get("shot_type_counts") or {})
    if not counts:
        return f'<div class="na-box">{_t("샷 유형 표본이 없습니다.", "No shot-type samples are available.")}</div>'
    max_count = max(counts.values()) or 1
    rows = []
    for shot_type, count in counts.most_common(10):
        width = max(2.0, float(count) / max_count * 100.0)
        label = SHOT_TYPE_LABELS[_locale()].get(shot_type, shot_type.replace("_", " ").title())
        rows.append(
            f'<div class="shot-type-row"><span>{html.escape(label)}</span><div class="shot-type-track"><i style="width:{width:.1f}%"></i></div><strong>{int(count)}</strong></div>'
        )
    return '<div class="shot-type-list">' + "".join(rows) + '</div>'


def _metric_tile(label: str, value: str, note: str = "", cls: str = "") -> str:
    return (
        f'<article class="metric-tile {html.escape(cls)}"><span>{html.escape(label)}</span><strong>{html.escape(value)}</strong>'
        f'{f"<small>{html.escape(note)}</small>" if note else ""}</article>'
    )


def _positioning_panel(metrics: dict[str, Any]) -> str:
    tiles = [
        _metric_tile(_t("총 이동 거리", "Distance covered"), _fmt(metrics.get("distance_covered_ft"), 1, " ft"), _t("5Hz 중앙값·노이즈 보정", "5 Hz median-smoothed")),
        _metric_tile(_t("이동속도 중앙", "Median movement speed"), _fmt(metrics.get("median_movement_speed_ft_s"), 1, " ft/s")),
        _metric_tile(_t("최고 이동속도", "Peak movement speed"), _fmt(metrics.get("peak_movement_speed_ft_s"), 1, " ft/s")),
        _metric_tile(_t("좌우 커버", "Lateral coverage"), _fmt(metrics.get("lateral_coverage_ft"), 1, " ft")),
        _metric_tile(_t("전후 커버", "Depth coverage"), _fmt(metrics.get("depth_coverage_ft"), 1, " ft")),
        _metric_tile(_t("NVZ 준비율", "NVZ-ready rate"), _percent(metrics.get("nvz_ready_rate"))),
        _metric_tile(_t("NVZ 활동률", "Kitchen presence"), _percent(metrics.get("kitchen_presence_rate"))),
        _metric_tile(_t("능동 이동률", "Active movement"), _percent(metrics.get("active_movement_rate"))),
        _metric_tile(_t("고강도 이동률", "High-intensity movement"), _percent(metrics.get("high_intensity_movement_rate"))),
        _metric_tile(_t("추적 커버리지", "Tracking coverage"), _percent(metrics.get("tracking_coverage"))),
        _metric_tile(_t("선수 ID 신뢰도", "Identity confidence"), _percent(metrics.get("mean_identity_confidence"))),
        _metric_tile(_t("타구 시 안정", "Stable at contact"), _percent(metrics.get("stable_at_contact_rate"))),
    ]
    return '<div class="positioning-grid">' + "".join(tiles) + '</div>'


def _tactical_panel(metrics: dict[str, Any]) -> str:
    tiles = [
        _metric_tile(_t("공격 선택 비율", "Attack selection"), _percent(metrics.get("attack_rate"))),
        _metric_tile(_t("소프트게임 비율", "Soft-game share"), _percent(metrics.get("soft_game_rate"))),
        _metric_tile(_t("3구 드롭 비율", "Third-shot drop share"), _percent(metrics.get("third_drop_rate"))),
        _metric_tile(_t("3구 드라이브 비율", "Third-shot drive share"), _percent(metrics.get("third_drive_rate"))),
        _metric_tile(_t("크로스코트 비율", "Cross-court share"), _percent(metrics.get("crosscourt_rate"))),
        _metric_tile(_t("오류 추정률", "Estimated error rate"), _percent(metrics.get("error_proxy_rate"))),
        _metric_tile(_t("관측 샷", "Observable shots"), _count(metrics.get("observable_shot_count"))),
        _metric_tile(_t("평균 샷 신뢰도", "Mean shot confidence"), _percent(metrics.get("mean_shot_confidence"))),
    ]
    return '<div class="tactical-grid">' + "".join(tiles) + '</div>'


def _reference_table(report: PlayerReport) -> str:
    comparison = report.reference_comparison or {}
    rows = comparison.get("metrics") or {}
    if not rows:
        return ""
    body = []
    for key, values in rows.items():
        current = values.get("current")
        reference = values.get("reference")
        delta = values.get("delta")
        if current is None:
            continue
        if key in RATE_KEYS:
            current_text = _percent(current, 1)
            reference_text = _percent(reference, 1)
            delta_text = f"{float(delta) * 100:+.1f}pp" if delta is not None else "–"
        elif "mph" in key:
            current_text = _fmt(current, 1, " mph")
            reference_text = _fmt(reference, 1, " mph")
            delta_text = f"{float(delta):+.1f} mph" if delta is not None else "–"
        else:
            current_text = _fmt(current, 1)
            reference_text = _fmt(reference, 1)
            delta_text = f"{float(delta):+.1f}" if delta is not None else "–"
        body.append(
            f'<tr><td>{html.escape(REFERENCE_LABELS[_locale()].get(key, key))}</td><td>{current_text}</td><td>{reference_text}</td><td>{delta_text}</td></tr>'
        )
    if not body:
        return ""
    warning = comparison.get("score_warning")
    warning_html = f'<p class="fine">{html.escape(_translate_engine_text(str(warning)))}</p>' if warning else ""
    return (
        f'<details class="reference"><summary>{_t("사용자 제공 PB Vision 경기와 교차검증", "Cross-check against the user-provided PB Vision match")}</summary>'
        f'<p>{_t("아래 값은 한 경기 export와의 단순 교차검증입니다. 비공개 산식이나 모집단 백분위를 재현하지 않습니다.", "This is a one-match cross-check. It does not reproduce proprietary formulas or population percentiles.")}</p>{warning_html}'
        f'<table><thead><tr><th>{_t("항목", "Metric")}</th><th>{_t("현재", "Current")}</th><th>{_t("참조", "Reference")}</th><th>{_t("차이", "Delta")}</th></tr></thead><tbody>{"".join(body)}</tbody></table></details>'
    )


def _rating_basis(report: PlayerReport) -> str:
    mapping = {
        "motion_fallback": (_t("포지셔닝 기반 보조 추정", "Positioning-based supplemental estimate")),
        "franklin_low_evidence": (_t("Franklin X-40 저신뢰 샷 추정", "Franklin X-40 low-evidence shot estimate")),
        "franklin_hybrid": (_t("Franklin X-40 시각·오디오·동작 하이브리드", "Franklin X-40 visual/audio/motion hybrid")),
        "shot_and_motion": (_t("Franklin X-40 시각 궤적+움직임", "Franklin X-40 visual trajectory + movement")),
    }
    return mapping.get(report.rating_basis, _t("Picklary 독립 영상 분석", "Independent Picklary video analysis"))


def _rating_tier(value: float | None) -> str:
    if value is None:
        return _t("평가 보류", "Unrated")
    if value >= 5.0:
        return _t("상급 경쟁 수준", "Advanced competitive")
    if value >= 4.5:
        return _t("상급자 수준", "Advanced")
    if value >= 4.0:
        return _t("중상급 수준", "Upper intermediate")
    if value >= 3.5:
        return _t("중급 수준", "Intermediate")
    return _t("기초·성장 구간", "Developing")


def _translate_engine_text(text: str) -> str:
    if _locale() != "en":
        return text
    exact = {
        "측정 가능한 항목 부족": "Not enough measurable evidence",
        "Franklin X-40 시각·오디오 샷 증거를 더 확보해야 합니다": "More Franklin X-40 visual/audio shot evidence is needed.",
        "포지셔닝·풋워크 표본을 더 확보해야 합니다": "More positioning and footwork samples are needed.",
        "본 수치는 Picklary 독립 근사치이며 공식 DUPR가 아닙니다.": "This is an independent Picklary estimate, not an official DUPR rating.",
        "본 평가는 공식 DUPR 또는 PB Vision 결과가 아닙니다.": "This is not an official DUPR or PB Vision result.",
        "한 경기 교차검증이며 PB Vision 비공개 산식을 재현하지 않습니다.": "This is a one-match cross-check and does not reproduce PB Vision proprietary formulas.",
        "입력한 기존 DUPR는 강한 기준값으로 사용되며 영상 기반 조정폭은 제한됩니다.": "Entered DUPR values are used as strong anchors, with limited video-based adjustment.",
        "단일 카메라에서는 RPM·패들 임팩트 순간속도·정확한 3D 타점 높이를 산출하지 않습니다.": "A single camera does not estimate RPM, instantaneous paddle-impact speed, or exact 3D contact height.",
    }
    if text in exact:
        return exact[text]
    patterns = [
        (r"^서브 ([\d.]+)점(?: 개선)?$", lambda m: f"Serve {m.group(1)}"),
        (r"^리턴 ([\d.]+)점(?: 개선)?$", lambda m: f"Return {m.group(1)}"),
        (r"^공격 전개 ([\d.]+)점(?: 개선)?$", lambda m: f"Offense {m.group(1)}"),
        (r"^수비·리셋 ([\d.]+)점(?: 개선)?$", lambda m: f"Defense / reset {m.group(1)}"),
        (r"^포지셔닝·풋워크 ([\d.]+)점(?: 개선)?$", lambda m: f"Positioning / footwork {m.group(1)}"),
        (r"^일관성 ([\d.]+)점(?: 개선)?$", lambda m: f"Consistency {m.group(1)}"),
        (r"^좌우 커버 범위 ([\d.]+)ft$", lambda m: f"Lateral coverage {m.group(1)} ft"),
        (r"^좌우 커버 범위 확대 필요 \(([\d.]+)ft\)$", lambda m: f"Expand lateral coverage ({m.group(1)} ft)"),
        (r"^NVZ 라인 준비 위치 ([\d.]+)%$", lambda m: f"NVZ-ready positioning {m.group(1)}%"),
        (r"^NVZ 라인 중앙거리 ([\d.]+)ft$", lambda m: f"Median distance from the NVZ line {m.group(1)} ft"),
        (r"^관측 이동속도 중앙값 ([\d.]+)ft/s$", lambda m: f"Median observed movement speed {m.group(1)} ft/s"),
        (r"^능동적 이동 비율 개선 필요 \(([\d.]+)ft/s\)$", lambda m: f"Increase active movement ({m.group(1)} ft/s)"),
        (r"^포지셔닝 기반 내부지수 ([\d.]+)점$", lambda m: f"Positioning index {m.group(1)}"),
    ]
    for pattern, converter in patterns:
        match = re.match(pattern, text)
        if match:
            return converter(match)
    replacements = {
        "Franklin 샷 증거 품질 게이트 미통과": "Franklin shot-evidence quality gate not passed",
        "관측 샷": "observable shots", "랠리": "rallies", "평균 신뢰도": "mean confidence",
        "시각 후보": "visual candidates", "패들형 오디오 transient": "paddle-like audio transients",
        "선수 동작": "player motion", "하이브리드 샷 추정": "hybrid shot estimation",
        "공 속도와 착지점": "ball speed and landing points", "연속 시각 궤적": "continuous visual trajectories",
        "검출된": "detected", "궤적과 선수 움직임": "trajectories and player movement",
        "결합한 Picklary 독립 경기력 지수입니다": "are combined into an independent Picklary performance index.",
        "본 수치는": "This value is", "공식 DUPR가 아닙니다": "not an official DUPR rating.",
    }
    out = text
    for source, target in replacements.items():
        out = out.replace(source, target)
    return out


def _generated_insights(report: PlayerReport) -> tuple[list[str], list[str]]:
    values, ratings = _skill_values(report)
    valid = sorted([(key, value) for key, value in values.items() if value is not None], key=lambda item: item[1], reverse=True)
    strengths: list[str] = []
    priorities: list[str] = []
    labels = SKILL_LABELS[_locale()]
    if valid:
        for key, value in valid[:2]:
            evidence = _skill_evidence(report, key)
            evidence_text = " · ".join(f"{label} {val}" for label, val in evidence[:2])
            score = f"{float(value):.2f}" if ratings else f"{float(value):.0f}"
            strengths.append(f"{labels[key]} {score} — {evidence_text}")
        for key, value in reversed(valid[-2:]):
            evidence = _skill_evidence(report, key)
            evidence_text = " · ".join(f"{label} {val}" for label, val in evidence[:2])
            score = f"{float(value):.2f}" if ratings else f"{float(value):.0f}"
            priorities.append(f"{labels[key]} {score} — {evidence_text}")
    m = report.metrics
    if _safe_rate(m.get("shot_in_rate")) is not None and float(m.get("shot_in_rate")) >= 0.9:
        strengths.append(_t(f"전체 샷 성공률 {_percent(m.get('shot_in_rate'))}로 안정적인 랠리 유지", f"Stable rally maintenance with {_percent(m.get('shot_in_rate'))} overall shot success"))
    if _safe_rate(m.get("error_proxy_rate")) is not None and float(m.get("error_proxy_rate")) > 0.12:
        priorities.append(_t(f"추정 오류율 {_percent(m.get('error_proxy_rate'))} — 장기 랠리에서 선택 안정화 필요", f"Estimated error rate {_percent(m.get('error_proxy_rate'))} — improve selection stability in extended rallies"))
    if not strengths:
        strengths = [_translate_engine_text(item) for item in report.strengths[:3]] or [_t("측정 가능한 강점 표본이 부족합니다.", "Not enough measurable evidence to identify a strength.")]
    if not priorities:
        priorities = [_translate_engine_text(item) for item in report.priorities[:3]] or [_t("추가 표본 후 우선 개선 항목을 확정합니다.", "Collect more samples before confirming the top development priority.")]
    return strengths[:4], priorities[:4]


def _rating_header(report: PlayerReport) -> str:
    rating_value = report.single_game_skill_rating or report.dupr_estimate
    if rating_value is None and report.relative_score is not None:
        rating_value = 2.0 + max(0.0, min(100.0, float(report.relative_score))) / 100.0 * 4.0
    if rating_value is None:
        return f'<div class="rating-block"><span>{_t("Picklary 레이팅", "Picklary Rating")}</span><strong class="na">–</strong><small>{_t("유효 데이터 부족", "Insufficient valid evidence")}</small></div>'
    low = report.dupr_low if report.dupr_low is not None else max(2.0, rating_value - 0.45)
    high = report.dupr_high if report.dupr_high is not None else min(8.0, rating_value + 0.45)
    return (
        f'<div class="rating-block"><span>{_t("Picklary DUPR 근사치", "Picklary DUPR Estimate")}</span>'
        f'<strong>{rating_value:.2f}</strong><em>{html.escape(_rating_tier(rating_value))}</em>'
        f'<small>{html.escape(_rating_basis(report))}</small><div class="range-line"><b>{low:.2f}</b><i></i><b>{high:.2f}</b></div></div>'
    )


def _player_card(report: PlayerReport) -> str:
    m = report.metrics
    strengths, priorities = _generated_insights(report)
    strengths_html = "".join(f'<li>{html.escape(item)}</li>' for item in strengths)
    priorities_html = "".join(f'<li>{html.escape(item)}</li>' for item in priorities)
    warnings_html = "".join(f'<li>{html.escape(_translate_engine_text(item))}</li>' for item in report.warnings)
    serve_speed = m.get("serve_speed") or {}
    drive_speed = m.get("drive_speed") or {}
    trajectory_count = len(m.get("shot_trajectories") or [])
    trajectory_estimated = int(m.get("trajectory_estimated_count") or 0)
    proxy_count = int(m.get("proxy_shot_count") or 0)
    visual_count = max(0, int(m.get("shot_count") or 0) - proxy_count)
    confidence_deg = max(0.0, min(360.0, report.confidence * 360.0))

    summary_tiles = "".join([
        _metric_tile(_t("전체 샷", "Total shots"), _count(m.get("shot_count")), _t(f"관측 가능 {_count(m.get('observable_shot_count'))}", f"observable {_count(m.get('observable_shot_count'))}")),
        _metric_tile(_t("샷 성공률", "Shot success"), _percent(m.get("shot_in_rate"))),
        _metric_tile(_t("서브 / 리턴", "Serves / returns"), f"{_count(m.get('serve_total'))} / {_count(m.get('return_total'))}"),
        _metric_tile(_t("랠리 참여", "Rallies involved"), _count(m.get("rally_count"))),
        _metric_tile(_t("이동 거리", "Distance covered"), _fmt(m.get("distance_covered_ft"), 1, " ft")),
        _metric_tile(_t("추적 커버리지", "Tracking coverage"), _percent(m.get("tracking_coverage"))),
    ])

    serve_estimated = int(serve_speed.get("estimated_sample_count") or 0) > 0
    drive_estimated = int(drive_speed.get("estimated_sample_count") or 0) > 0
    serve_speed_label = _t("서브 중앙/최고 (추정)" if serve_estimated else "서브 중앙/최고", "Serve median/top (estimated)" if serve_estimated else "Serve median/top")
    drive_speed_label = _t("드라이브 중앙/최고 (추정)" if drive_estimated else "드라이브 중앙/최고", "Drive median/top (estimated)" if drive_estimated else "Drive median/top")
    shot_speed_tiles = "".join([
        _metric_tile(serve_speed_label, f"{_fmt(serve_speed.get('median_mph'), 1)} / {_fmt(serve_speed.get('top_mph'), 1)} mph", f"n={_count(serve_speed.get('sample_count'))}"),
        _metric_tile(drive_speed_label, f"{_fmt(drive_speed.get('median_mph'), 1)} / {_fmt(drive_speed.get('top_mph'), 1)} mph", f"n={_count(drive_speed.get('sample_count'))}"),
        _metric_tile(_t("3구 품질 지수", "Third-shot quality"), _fmt(m.get("third_shot_quality"), 0), _t("Picklary 독립 지수", "Independent Picklary index")),
        _metric_tile(_t("타구 시 안정", "Stable at contact"), _percent(m.get("stable_at_contact_rate"))),
        _metric_tile(_t("속도 실측 표본", "Observed speed samples"), _count(int(serve_speed.get("visual_sample_count") or 0) + int(drive_speed.get("visual_sample_count") or 0))),
        _metric_tile(_t("속도 추정 표본", "Estimated speed samples"), _count(int(serve_speed.get("estimated_sample_count") or 0) + int(drive_speed.get("estimated_sample_count") or 0))),
    ])

    return f'''
    <section class="player-card">
      <div class="player-head">
        <div class="player-identity"><span class="badge">{html.escape(PLAYER_DISPLAY.get(report.label, report.label))}</span><div><p class="mini-kicker">PLAYER PERFORMANCE DOSSIER</p><h2>{html.escape(report.display_name)}</h2><p class="fine">{_t("경기 내 상대 순위", "In-match relative rank")} #{report.relative_rank or "–"}</p></div></div>
        <div class="head-score">{_rating_header(report)}<div class="confidence-ring" style="--confidence:{confidence_deg:.1f}deg"><div><strong>{report.confidence*100:.0f}%</strong><span>{_t("분석 신뢰도", "Analysis confidence")}</span></div></div></div>
      </div>
      <div class="summary-strip">{summary_tiles}</div>
      {_skill_dashboard(report)}
      <section class="report-section"><div class="section-heading"><div><p class="mini-kicker">SERVE & RETURN LAB</p><h3>{_t("서브·리턴의 성공률, 깊이와 속도", "Serve and return success, depth, and speed")}</h3></div><span>{_t("실측과 추정 표본을 분리 표시", "Observed and estimated samples are disclosed")}</span></div>
        <div class="analytics-grid"><div class="panel">{_accuracy_bar(_t("서브 성공/실패", "Serve in / out"), int(m.get("serve_total") or 0), m.get("serve_in_rate"))}{_accuracy_bar(_t("리턴 성공/실패", "Return in / out"), int(m.get("return_total") or 0), m.get("return_in_rate"))}</div><div class="panel metric-panel">{shot_speed_tiles}</div></div>
        <div class="donut-row">{_depth_donut(_t("서브 깊이", "Serve depth"), m.get("serve_depth"))}{_depth_donut(_t("리턴 깊이", "Return depth"), m.get("return_depth"))}</div>
      </section>
      <section class="report-section"><div class="section-heading"><div><p class="mini-kicker">TACTICAL BLUEPRINT</p><h3>{_t("샷 구성과 경기 운영 성향", "Shot composition and tactical tendencies")}</h3></div><span>{_t(f"시각 샷 {visual_count} · 하이브리드/추정 {proxy_count}", f"visual shots {visual_count} · hybrid/estimated {proxy_count}")}</span></div>
        <div class="analytics-grid"><div class="panel"><h4>{_t("샷 유형 분포", "Shot-type distribution")}</h4>{_shot_type_breakdown(m)}</div><div class="panel"><h4>{_t("전술 지표", "Tactical indicators")}</h4>{_tactical_panel(m)}</div></div>
      </section>
      <section class="report-section"><div class="section-heading"><div><p class="mini-kicker">MOVEMENT INTELLIGENCE</p><h3>{_t("포지셔닝·풋워크·코트 커버리지", "Positioning, footwork, and court coverage")}</h3></div><span>{_t("움직임과 추적 품질을 함께 해석", "Movement is interpreted with tracking quality")}</span></div><div class="panel">{_positioning_panel(m)}</div></section>
      <section class="report-section"><div class="section-heading"><div><p class="mini-kicker">COURT STORY</p><h3>{_t("샷 궤적과 타구 위치", "Shot trajectories and contact locations")}</h3></div><span>{trajectory_count} paths · {_t("추정", "estimated")} {trajectory_estimated}</span></div>
        <div class="court-story-grid"><article class="panel"><h4>{_t("샷 궤적", "Shot trajectories")}</h4>{_trajectory_svg(m)}<p class="fine">{_t("실선은 시각 착지 앵커, 점선은 Franklin 공 후보·다음 타격자 위치·코트 기하를 결합한 추정 경로입니다.", "Solid paths use visual landing anchors; dashed paths are inferred from Franklin candidates, the next hitter, and court geometry.")}</p></article><article class="panel"><h4>{_t("타구 위치 분포", "Contact-location distribution")}</h4>{_contact_map_svg(m)}<p class="fine">{_t("색상은 샷 유형, 원 크기는 해당 이벤트의 신뢰도를 나타냅니다.", "Color identifies shot type; circle size reflects event confidence.")}</p></article></div>
      </section>
      <div class="insight-grid"><article class="insight-card strength"><p class="mini-kicker">PERFORMANCE EDGE</p><h3>{_t("강점", "Strengths")}</h3><ul>{strengths_html}</ul></article><article class="insight-card focus"><p class="mini-kicker">NEXT LEVEL</p><h3>{_t("우선 개선", "Priority improvements")}</h3><ul>{priorities_html}</ul></article></div>
      {_reference_table(report)}
      <details><summary>{_t("분석 근거와 해석상 주의사항", "Evidence and interpretation notes")}</summary><ul>{warnings_html}</ul><div class="evidence-grid">{_metric_tile(_t("샷 근거 방식", "Shot evidence source"), str(m.get("shot_evidence_source") or "none"))}{_metric_tile(_t("추정 궤적", "Estimated trajectories"), _count(m.get("trajectory_estimated_count")))}{_metric_tile(_t("추정 속도", "Estimated speeds"), _count(m.get("speed_estimated_count")))}{_metric_tile(_t("거리 산식", "Distance method"), str(m.get("distance_method") or "–"))}</div></details>
    </section>'''


def render_html(result: AnalysisResult) -> str:
    cards = "".join(_player_card(report) for report in result.player_reports)
    diagnostics = html.escape(json.dumps(result.diagnostics, ensure_ascii=False, indent=2))
    device = result.diagnostics.get("processing_device") or {}
    device_summary = device.get("summary") if isinstance(device, dict) else str(device)
    device_summary = _translate_engine_text(str(device_summary or _t("미확인", "unknown")))
    game = result.diagnostics.get("game_context") or {}
    audio = result.diagnostics.get("audio_onset") or {}
    proxy = result.diagnostics.get("audio_motion_shot_proxy") or {}
    score = _t(
        f"가까운쪽 {game.get('final_score_near', '–')} : 먼쪽 {game.get('final_score_far', '–')}",
        f"Near {game.get('final_score_near', '–')} : Far {game.get('final_score_far', '–')}",
    )
    first_server = game.get("initial_server_label") or _t("미입력", "not entered")
    notices = [
        _t(f"실제 처리 장치 · {device_summary}", f"Active processing device · {device_summary}"),
        _t("공 프로필 · Franklin X-40 Outdoor · 74mm · 26g · 40홀", "Ball profile · Franklin X-40 Outdoor · 74 mm · 26 g · 40 holes"),
        _t(f"게임 설정 · {game.get('game_target_points', '–')}점 경기 · 첫 서버 {first_server} · 최종점수 {score}", f"Match setup · play to {game.get('game_target_points', '–')} · first server {first_server} · final score {score}"),
        _t(f"오디오 후보 {audio.get('count', 0):,}개 · 방식 {audio.get('method', '미실행')}", f"Audio candidates {audio.get('count', 0):,} · method {audio.get('method', 'not run')}"),
    ]
    if proxy:
        notices.append(
            _t(
                f"하이브리드 증거 · 입력 {proxy.get('input_onsets',0):,} · 채택 {proxy.get('accepted_onsets',0):,} · 샷 배정 {proxy.get('assigned_shots',0):,} · 궤적 복원 {proxy.get('completed_trajectories',0):,}",
                f"Hybrid evidence · input {proxy.get('input_onsets',0):,} · accepted {proxy.get('accepted_onsets',0):,} · assigned shots {proxy.get('assigned_shots',0):,} · completed trajectories {proxy.get('completed_trajectories',0):,}",
            )
        )
    notice_html = "".join(f'<div class="notice">{html.escape(str(item))}</div>' for item in notices)
    lang = _locale()
    title = _t("픽클러리 비전 레이팅", "Picklary Vision Rating")
    return f'''<!doctype html><html lang="{lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title} v{VERSION} Report</title><style>
:root{{--bg:#050d1b;--bg2:#0a1930;--card:#0c1b32;--card2:#102743;--text:#f7fbff;--muted:#9eb2c8;--mint:#69e9c2;--cyan:#54cdec;--blue:#7a93ff;--coral:#ff7b86;--gold:#f5c75b;--violet:#ad8dff;--line:rgba(145,184,222,.18);--shadow:0 22px 65px rgba(0,0,0,.30)}}
*{{box-sizing:border-box}}body{{margin:0;background:radial-gradient(circle at 90% 3%,rgba(77,117,255,.22),transparent 30%),radial-gradient(circle at 8% 18%,rgba(65,221,185,.15),transparent 25%),linear-gradient(150deg,var(--bg),var(--bg2));color:var(--text);font-family:Inter,'Noto Sans KR',system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;min-height:100vh}}main{{max-width:1500px;margin:auto;padding:24px}}.report-hero,.player-card{{border:1px solid var(--line);border-radius:28px;background:linear-gradient(145deg,rgba(17,39,69,.96),rgba(7,21,40,.97));box-shadow:var(--shadow);overflow:hidden}}.report-hero{{position:relative;padding:30px;margin-bottom:20px}}.report-hero:after{{content:'';position:absolute;width:520px;height:520px;border:1px solid rgba(105,233,194,.14);border-radius:50%;right:-220px;top:-330px;box-shadow:0 0 0 55px rgba(105,233,194,.025),0 0 0 110px rgba(122,147,255,.022)}}.brand-line{{display:flex;align-items:center;gap:14px;position:relative;z-index:1}}.brand-glyph{{width:54px;height:54px;border-radius:18px;display:grid;place-items:center;background:linear-gradient(145deg,var(--mint),var(--blue));color:#041420;font-size:27px;font-weight:950;box-shadow:0 13px 30px rgba(105,233,194,.22)}}h1{{margin:0;font-size:clamp(30px,4vw,50px);letter-spacing:-.045em}}h2,h3,h4{{letter-spacing:-.025em}}.sub,.fine{{color:var(--muted)}}.sub{{margin:.38rem 0 0;line-height:1.55}}.notice-grid{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:23px;position:relative;z-index:1}}.notice{{padding:12px 14px;border:1px solid var(--line);border-radius:14px;background:rgba(5,18,36,.56);color:#bed0e4;font-size:13px;line-height:1.45}}.player-card{{padding:25px;margin:20px 0}}.player-head{{display:flex;justify-content:space-between;gap:24px;align-items:flex-start}}.player-identity{{display:flex;align-items:center;gap:13px}}.player-identity h2{{margin:3px 0 0;font-size:30px}}.badge{{display:grid;place-items:center;width:51px;height:51px;border-radius:16px;background:linear-gradient(145deg,var(--mint),var(--cyan));color:#06221a;font-weight:950}}.mini-kicker{{margin:0;color:var(--mint);font-size:11px;font-weight:850;letter-spacing:.15em}}.head-score{{display:flex;gap:20px;align-items:center}}.rating-block{{text-align:right;max-width:460px}}.rating-block span,.rating-block small{{display:block;color:var(--muted)}}.rating-block strong{{display:block;margin:2px 0;font-size:58px;color:var(--mint);letter-spacing:-.055em}}.rating-block strong.na{{color:var(--gold)}}.rating-block em{{display:inline-block;font-style:normal;color:#07241b;background:linear-gradient(90deg,var(--gold),#ffe79c);padding:4px 9px;border-radius:999px;font-size:11px;font-weight:900;margin-bottom:6px}}.range-line{{display:flex;align-items:center;gap:8px;color:#c6d8ea;font-size:11px;margin-top:8px}}.range-line i{{display:block;width:130px;height:5px;border-radius:999px;background:linear-gradient(90deg,var(--mint),var(--blue))}}.confidence-ring{{--confidence:180deg;width:112px;height:112px;border-radius:50%;background:conic-gradient(var(--mint) 0 var(--confidence),rgba(124,154,184,.17) var(--confidence) 360deg);display:grid;place-items:center}}.confidence-ring>div{{width:78px;height:78px;border-radius:50%;background:#0a1a30;display:grid;place-items:center;text-align:center}}.confidence-ring strong,.confidence-ring span{{display:block}}.confidence-ring strong{{font-size:22px}}.confidence-ring span{{font-size:9px;color:var(--muted)}}.summary-strip{{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin-top:20px}}.metric-tile{{padding:14px;border:1px solid var(--line);border-radius:15px;background:linear-gradient(145deg,rgba(12,30,54,.96),rgba(8,20,38,.96));min-width:0}}.metric-tile span,.metric-tile small{{display:block;color:var(--muted);font-size:11px}}.metric-tile strong{{display:block;margin:6px 0 2px;font-size:20px;overflow-wrap:anywhere}}.performance-signature{{display:grid;grid-template-columns:minmax(390px,.9fr) minmax(620px,1.35fr);gap:18px;margin-top:20px}}.radar-column,.skill-card,.panel,.insight-card,details{{border:1px solid var(--line);background:linear-gradient(145deg,rgba(12,29,52,.97),rgba(8,20,38,.97));border-radius:20px}}.radar-column{{padding:19px;text-align:center}}.radar-column h3{{margin:5px 0 4px}}.radar-shell{{max-width:470px;margin:auto}}.skill-radar{{width:100%;height:auto;overflow:visible}}.skill-radar text{{fill:#c8d8e8;font-size:12px;font-weight:760}}.skill-radar .radar-value{{fill:var(--mint);font-size:11px}}.skill-card-grid{{display:grid;grid-template-columns:repeat(2,1fr);gap:11px;align-content:stretch}}.skill-card{{padding:17px;min-height:170px;position:relative;overflow:hidden}}.skill-card:after{{content:'';position:absolute;width:105px;height:105px;border-radius:50%;background:rgba(103,151,255,.08);right:-42px;bottom:-50px}}.skill-card__head{{display:flex;justify-content:space-between;gap:10px}}.skill-card__head p{{margin:0;font-weight:850;font-size:17px}}.skill-card__head small{{display:block;margin-top:4px;color:var(--muted);font-size:10px;line-height:1.45}}.skill-card>strong{{display:block;margin:8px 0 9px;font-size:31px;color:#86b4ff}}.skill-card em{{font-style:normal;font-size:10px;height:max-content;padding:4px 7px;border-radius:999px;white-space:nowrap}}.skill-card.is-strength{{border-color:rgba(105,233,194,.48);background:linear-gradient(145deg,rgba(30,89,76,.38),rgba(8,27,40,.97))}}.skill-card.is-strength em{{color:#baffeb;background:rgba(105,233,194,.14)}}.skill-card.is-focus{{border-color:rgba(255,123,134,.44);background:linear-gradient(145deg,rgba(90,39,53,.32),rgba(18,24,43,.97))}}.skill-card.is-focus em{{color:#ffd0d4;background:rgba(255,123,134,.13)}}.skill-evidence{{display:grid;gap:5px;position:relative;z-index:1}}.skill-evidence span{{display:flex;justify-content:space-between;gap:8px;color:#d8e5f1;font-size:10px}}.skill-evidence b{{color:#829bb4;font-weight:650}}.report-section{{margin-top:18px}}.section-heading{{display:flex;justify-content:space-between;gap:15px;align-items:flex-end;margin:0 2px 10px}}.section-heading h3{{margin:5px 0 0;font-size:22px}}.section-heading>span{{color:var(--muted);font-size:11px;text-align:right}}.analytics-grid,.court-story-grid{{display:grid;grid-template-columns:1fr 1fr;gap:14px}}.panel{{padding:18px}}.panel h4{{margin:3px 0 13px}}.metric-panel{{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}}.metric-panel .metric-tile{{background:#09172a}}.section-title{{display:flex;justify-content:space-between;align-items:flex-start;gap:12px}}.section-title h4{{margin:4px 0 10px}}.section-title>span{{color:var(--muted);font-size:11px}}.accuracy{{margin:2px 0 19px}}.stacked{{height:43px;border-radius:13px;display:flex;overflow:hidden;background:#26364b;font-weight:850;font-size:12px}}.stacked div{{display:flex;align-items:center;justify-content:center;min-width:0;overflow:hidden}}.stacked .in{{background:linear-gradient(90deg,#1edb60,#5ce197);color:#041a0d}}.stacked .out{{background:#ff626b;color:white}}.na-box{{padding:18px;background:#09172a;color:var(--muted);border-radius:12px;text-align:center}}.donut-row{{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px}}.donut-card{{padding:17px;border:1px solid var(--line);border-radius:20px;background:linear-gradient(145deg,rgba(12,29,52,.97),rgba(8,20,38,.97))}}.donut{{width:172px;height:172px;margin:6px auto;border-radius:50%;display:grid;place-items:center}}.donut>div{{width:94px;height:94px;background:#09172a;border-radius:50%;display:grid;place-items:center;text-align:center}}.donut strong,.donut small{{display:block}}.donut small{{color:var(--muted);font-size:10px}}.source-note{{text-align:center;color:var(--muted);font-size:10px}}.legend{{display:grid;gap:6px;font-size:12px}}.legend i{{display:inline-block;width:11px;height:11px;border-radius:3px;margin-right:6px}}i.deep{{background:#2edb78}}i.medium{{background:#f6c453}}i.shallow{{background:#ff775f}}.shot-type-list{{display:grid;gap:9px}}.shot-type-row{{display:grid;grid-template-columns:minmax(100px,1fr) 2.4fr 42px;gap:10px;align-items:center;font-size:12px}}.shot-type-track{{height:8px;background:#14263b;border-radius:999px;overflow:hidden}}.shot-type-track i{{display:block;height:100%;background:linear-gradient(90deg,var(--mint),var(--blue));border-radius:999px}}.shot-type-row strong{{text-align:right}}.tactical-grid,.positioning-grid,.evidence-grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:9px}}.tactical-grid .metric-tile,.positioning-grid .metric-tile,.evidence-grid .metric-tile{{background:#09172a}}.court-map{{display:block;width:100%;max-height:530px;border-radius:16px;padding:8px}}.insight-grid{{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:16px}}.insight-card{{padding:19px}}.insight-card h3{{margin:5px 0 10px}}.insight-card li{{margin:8px 0;line-height:1.5}}.insight-card.strength{{border-color:rgba(105,233,194,.36);background:linear-gradient(145deg,rgba(16,75,66,.36),rgba(8,22,40,.97))}}.insight-card.focus{{border-color:rgba(255,123,134,.34);background:linear-gradient(145deg,rgba(78,36,52,.32),rgba(12,22,42,.97))}}details{{padding:16px;margin-top:14px}}details summary{{cursor:pointer;font-weight:830}}table{{width:100%;border-collapse:collapse;margin-top:12px}}th,td{{padding:9px;border-bottom:1px solid rgba(143,172,205,.18);text-align:right}}th:first-child,td:first-child{{text-align:left}}pre{{white-space:pre-wrap;color:#b9c9dd;overflow:auto}}footer{{padding:20px 4px;color:#7188a2;font-size:12px}}
@media(max-width:1180px){{.performance-signature{{grid-template-columns:1fr}}.summary-strip{{grid-template-columns:repeat(3,1fr)}}}}@media(max-width:900px){{.analytics-grid,.court-story-grid{{grid-template-columns:1fr}}.tactical-grid,.positioning-grid,.evidence-grid{{grid-template-columns:repeat(2,1fr)}}.notice-grid{{grid-template-columns:1fr}}}}@media(max-width:720px){{main{{padding:10px}}.player-card,.report-hero{{padding:16px;border-radius:20px}}.player-head,.head-score{{display:block}}.rating-block{{text-align:left;margin-top:14px}}.confidence-ring{{margin-top:14px}}.skill-card-grid,.metric-panel,.insight-grid,.donut-row,.summary-strip{{grid-template-columns:1fr}}.tactical-grid,.positioning-grid,.evidence-grid{{grid-template-columns:1fr}}}}
</style></head><body><main><header class="report-hero"><div class="brand-line"><div class="brand-glyph">P</div><div><h1>{title}</h1><p class="sub">{_t('AI 영상 기반 피클볼 퍼포먼스 인텔리전스 리포트','AI-powered pickleball performance intelligence report')} · v{VERSION}</p></div></div><div class="notice-grid">{notice_html}</div></header>{cards}<section class="player-card"><details><summary>{_t('전체 분석 진단 데이터','Full analysis diagnostics')}</summary><pre>{diagnostics}</pre></details></section><footer>{_t('영상','Video')}: {html.escape(result.video_path)} · {result.duration_s:.1f}s · {result.fps:.2f}fps · {_t('본 결과는 공식 DUPR가 아닌 Picklary 독립 근사치입니다.','This is an independent Picklary estimate, not an official DUPR rating.')}</footer></main></body></html>'''


def write_shots_csv(rallies: Iterable[Rally], path: Path) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.writer(file)
        writer.writerow([
            "rally_index", "shot_index", "time_s", "player", "shot_type", "direction", "speed_mph_est",
            "speed_source", "speed_outlier", "trajectory_profile", "outcome", "confidence",
            "start_x_ft", "start_y_ft", "end_x_ft", "end_y_ft",
        ])
        for rally in rallies:
            for shot in rally.shots:
                writer.writerow([
                    shot.rally_index, shot.shot_index, round(shot.time_s, 3), shot.player_label, shot.shot_type,
                    shot.stroke_side, shot.estimated_speed_mph, shot.speed_source, shot.speed_outlier,
                    shot.trajectory_profile, shot.outcome, round(shot.confidence, 3),
                    getattr(shot.start_position, "x", None), getattr(shot.start_position, "y", None),
                    getattr(shot.end_position, "x", None), getattr(shot.end_position, "y", None),
                ])


def save_result(result: AnalysisResult, output_dir: Path) -> dict[str, str]:
    output_dir.mkdir(parents=True, exist_ok=True)
    result.output_dir = str(output_dir)
    json_path = output_dir / "analysis.json"
    html_path = output_dir / "report.html"
    csv_path = output_dir / "shots.csv"
    json_path.write_text(json.dumps(result.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
    html_path.write_text(render_html(result), encoding="utf-8")
    write_shots_csv(result.rallies, csv_path)
    return {"json": str(json_path), "html": str(html_path), "shots_csv": str(csv_path)}
