import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_english_edition_is_pinned_to_english_locale_and_port():
    launcher = (ROOT / "local_launcher.py").read_text(encoding="utf-8")
    bootstrap = (ROOT / "unified_bootstrap.py").read_text(encoding="utf-8")
    start = (ROOT / "Picklary_Vision_Rating.cmd").read_text(encoding="ascii")
    assert 'PACKAGE_LOCALE = "en"' in launcher
    assert 'PACKAGE_PORT = 8865' in launcher
    assert 'PACKAGE_LOCALE = "en"' in bootstrap
    assert 'PACKAGE_PORT = 8865' in bootstrap
    assert 'unified_bootstrap.py' in start


def test_english_ui_and_sample_report_have_no_korean_text():
    paths = [
        ROOT / "frontend" / "index.html",
        ROOT / "frontend" / "app.js",
        ROOT / "frontend" / "sample_report.html",
        ROOT / "README_EN.md",
        ROOT / "QUICK_START_EN.txt",
    ]
    for path in paths:
        text = path.read_text(encoding="utf-8")
        assert re.search(r"[가-힣]", text) is None, path


def test_english_report_keeps_full_analytics_with_hexagon():
    report = (ROOT / "frontend" / "sample_report.html").read_text(encoding="utf-8")
    required = [
        "Six-dimension strengths and weaknesses",
        "Serve and return success, depth, and speed",
        "Shot composition and tactical tendencies",
        "Positioning, footwork, and court coverage",
        "Shot trajectories and contact locations",
        "Cross-check against the user-provided PB Vision match",
        "skill-radar",
    ]
    for text in required:
        assert text in report


def test_korean_and_english_editions_use_separate_data_directories():
    launcher = (ROOT / "local_launcher.py").read_text(encoding="utf-8")
    assert 'PACKAGE_DATA_DIR = "PicklaryVisionLocal_EN"' in launcher


def test_english_runtime_generated_report_has_no_korean_text(monkeypatch):
    monkeypatch.setenv("PVR_LOCALE", "en")
    monkeypatch.setenv("PVR_PACKAGE_LOCALE", "en")
    from picklary_rating.analysis.rating import IndependentRatingEngine
    from picklary_rating.analysis.reporting import render_html
    from picklary_rating.models import AnalysisResult

    metrics = {
        "shot_count": 30, "observable_shot_count": 25, "rally_count": 5,
        "tracking_coverage": 0.8, "mean_shot_confidence": 0.7,
        "shot_in_rate": 0.9, "error_proxy_rate": 0.08,
        "kitchen_presence_rate": 0.5, "stable_at_contact_rate": 0.75,
        "median_movement_speed_ft_s": 3.1, "attack_rate": 0.5,
        "soft_game_rate": 0.4, "third_drop_rate": 0.3,
        "third_shot_quality": 70, "crosscourt_rate": 0.55,
        "serve_in_rate": 0.95, "return_in_rate": 0.9,
        "serve_depth": {"rates": {"deep": 0.5}},
        "return_depth": {"rates": {"deep": 0.45}},
        "serve_speed": {"median_mph": 40}, "drive_speed": {"median_mph": 30},
        "shot_type_counts": {"serve": 10, "return": 10},
        "shot_evidence_source": "visual", "proxy_shot_count": 0,
    }
    report = IndependentRatingEngine().evaluate("A", metrics, "Player A", "full")
    result = AnalysisResult(
        "x.mp4", "now", 10, 30, 300, [], [report], [],
        {"processing_device": {"summary": "CPU fallback · no GPU execution backend detected"}, "game_context": {}, "audio_onset": {}},
    )
    output = render_html(result)
    assert re.search(r"[가-힣]", output) is None
