from __future__ import annotations

from pathlib import Path
import sys
import traceback

from picklary_rating.analysis.auto_setup import run_auto_setup
from .store import JobStore, StoreConfig


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if len(args) != 7:
        print("usage: auto_setup_worker JOB_ID DATA_ROOT MAX_UPLOAD_BYTES CHUNK_SIZE PROJECT_ROOT TIME_S DEVICE", file=sys.stderr)
        return 2
    job_id, data_root, max_upload, chunk_size, project_root, time_s, device = args
    store = JobStore(StoreConfig(Path(data_root), int(max_upload), int(chunk_size)))
    try:
        state = store.load(job_id)
        video_path = state.get("video_path")
        if not video_path:
            raise RuntimeError("video upload is incomplete")
        result = run_auto_setup(
            video_path=video_path,
            time_s=float(time_s),
            project_root=Path(project_root),
            requested_device=device,
        )
        state["auto_setup"] = result
        store.save(job_id, state)
        return 0
    except BaseException:
        error_path = store.job_dir(job_id) / "auto_setup_error.txt"
        error_path.write_text(traceback.format_exc(), encoding="utf-8", errors="replace")
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
