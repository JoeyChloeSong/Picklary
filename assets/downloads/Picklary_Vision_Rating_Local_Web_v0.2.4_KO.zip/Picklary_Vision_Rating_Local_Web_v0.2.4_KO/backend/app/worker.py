from __future__ import annotations

from pathlib import Path
import os
import sys
import threading
import time

from .analysis_runner import run_job
from .store import JobStore, StoreConfig


def _heartbeat(lock_path: Path, stop: threading.Event) -> None:
    while not stop.wait(5.0):
        try:
            lock_path.touch()
        except OSError:
            return


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if len(args) != 5:
        print("usage: worker JOB_ID DATA_ROOT MAX_UPLOAD_BYTES CHUNK_SIZE PROJECT_ROOT", file=sys.stderr)
        return 2
    job_id, data_root, max_upload, chunk_size, project_root = args
    store = JobStore(StoreConfig(Path(data_root), int(max_upload), int(chunk_size)))
    lock_path = store.job_dir(job_id) / "worker.lock"
    try:
        fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        with os.fdopen(fd, "w", encoding="ascii") as handle:
            handle.write(str(os.getpid()))
    except FileExistsError:
        try:
            age = time.time() - lock_path.stat().st_mtime
        except OSError:
            age = 0.0
        if age < 90.0:
            print("analysis worker is already active")
            return 0
        lock_path.unlink(missing_ok=True)
        fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        with os.fdopen(fd, "w", encoding="ascii") as handle:
            handle.write(str(os.getpid()))

    stop = threading.Event()
    thread = threading.Thread(target=_heartbeat, args=(lock_path, stop), daemon=True)
    thread.start()
    try:
        run_job(store, job_id, Path(project_root))
        try:
            state = store.load(job_id)
        except Exception:
            return 3
        return 0 if state.get("status") == "complete" else 1
    finally:
        stop.set()
        thread.join(timeout=1.0)
        lock_path.unlink(missing_ok=True)


if __name__ == "__main__":
    raise SystemExit(main())
