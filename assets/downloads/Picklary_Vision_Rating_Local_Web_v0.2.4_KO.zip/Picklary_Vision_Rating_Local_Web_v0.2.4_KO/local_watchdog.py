from __future__ import annotations

from collections import deque
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parent
PACKAGE_VERSION = "0.2.4"
PACKAGE_LOCALE = "ko"
PACKAGE_PORT = 8765
RUNTIME = ROOT / ".runtime"
LOGS = ROOT / "logs"
RUNTIME.mkdir(parents=True, exist_ok=True)
LOGS.mkdir(parents=True, exist_ok=True)
WATCHDOG_PID = RUNTIME / "watchdog.pid"
SERVER_PID = RUNTIME / "server.pid"
PORT_PATH = RUNTIME / "server_port.txt"
STOP_REQUEST = RUNTIME / "stop.request"
WATCHDOG_LOG = LOGS / "watchdog.log"
SERVER_LOG = LOGS / "local_server.log"


def log(message: str) -> None:
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    with WATCHDOG_LOG.open("a", encoding="utf-8", errors="replace") as handle:
        handle.write(f"{stamp} {message}\n")


def health_payload(port: int) -> dict | None:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=1.5) as response:
            return json.loads(response.read().decode("utf-8"))
    except Exception:
        return None


def find_existing() -> int | None:
    preferred = int(os.getenv("PVR_LOCAL_PORT", str(PACKAGE_PORT)))
    for port in range(preferred, preferred + 30):
        payload = health_payload(port)
        if payload and payload.get("status") == "ok" and payload.get("locale") == PACKAGE_LOCALE and str(payload.get("version", "")).endswith(PACKAGE_VERSION):
            return port
    return None


def child_python() -> Path:
    current = Path(sys.executable)
    if current.name.lower() == "pythonw.exe":
        candidate = current.with_name("python.exe")
        if candidate.exists():
            return candidate
    return current


def wait_ready(process: subprocess.Popen[bytes], timeout_s: float = 120.0) -> int | None:
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        if STOP_REQUEST.exists() or process.poll() is not None:
            return None
        if PORT_PATH.exists():
            try:
                port = int(PORT_PATH.read_text(encoding="ascii").strip())
            except Exception:
                port = 0
            payload = health_payload(port) if port else None
            if payload and payload.get("status") == "ok" and payload.get("locale") == PACKAGE_LOCALE and str(payload.get("version", "")).endswith(PACKAGE_VERSION):
                return port
        time.sleep(0.5)
    return None


def start_child() -> subprocess.Popen[bytes]:
    for path in (SERVER_PID, PORT_PATH):
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass
    env = os.environ.copy()
    env["PVR_LOCALE"] = PACKAGE_LOCALE
    env["PVR_PACKAGE_LOCALE"] = PACKAGE_LOCALE
    env["PVR_LOCAL_PORT"] = str(PACKAGE_PORT)
    env["PVR_OPEN_BROWSER"] = "0"
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    log_handle = SERVER_LOG.open("ab", buffering=0)
    process = subprocess.Popen(
        [str(child_python()), str(ROOT / "local_launcher.py")],
        cwd=str(ROOT),
        env=env,
        stdout=log_handle,
        stderr=subprocess.STDOUT,
        creationflags=creationflags,
    )
    process._picklary_log_handle = log_handle  # type: ignore[attr-defined]
    log(f"Started local server process PID={process.pid}")
    return process


def stop_child(process: subprocess.Popen[bytes] | None) -> None:
    if process is None:
        return
    try:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                process.kill()
    finally:
        handle = getattr(process, "_picklary_log_handle", None)
        if handle is not None:
            try:
                handle.close()
            except Exception:
                pass


def main() -> int:
    existing = find_existing()
    if existing is not None:
        webbrowser.open(f"http://127.0.0.1:{existing}/?lang={PACKAGE_LOCALE}")
        log(f"Existing healthy server found on port {existing}")
        return 0
    STOP_REQUEST.unlink(missing_ok=True)
    WATCHDOG_PID.write_text(str(os.getpid()), encoding="ascii")

    crashes: deque[float] = deque(maxlen=8)
    browser_opened = False
    process: subprocess.Popen[bytes] | None = None
    try:
        while not STOP_REQUEST.exists():
            process = start_child()
            port = wait_ready(process)
            if port is not None and not browser_opened:
                webbrowser.open(f"http://127.0.0.1:{port}/?lang={PACKAGE_LOCALE}")
                browser_opened = True
                log(f"Server ready on port {port}")
            while process.poll() is None and not STOP_REQUEST.exists():
                time.sleep(1.0)
            if STOP_REQUEST.exists():
                break
            code = process.poll()
            crashes.append(time.time())
            recent = [stamp for stamp in crashes if time.time() - stamp <= 120]
            log(f"Server exited unexpectedly with code={code}; recent crashes={len(recent)}")
            stop_child(process)
            process = None
            if len(recent) >= 5:
                (RUNTIME / "fatal_startup.txt").write_text(
                    "The local engine stopped repeatedly. Run Picklary_Vision_Rating.cmd again and inspect logs/local_server.log and logs/local_server_fault.log.",
                    encoding="utf-8",
                )
                log("Restart limit reached")
                return 2
            time.sleep(min(8.0, 1.5 * len(recent)))
        return 0
    finally:
        stop_child(process)
        WATCHDOG_PID.unlink(missing_ok=True)
        if STOP_REQUEST.exists():
            STOP_REQUEST.unlink(missing_ok=True)
        log("Watchdog stopped")


if __name__ == "__main__":
    raise SystemExit(main())
