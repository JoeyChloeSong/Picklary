from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_frontend_retries_and_resume_button() -> None:
    app = (ROOT / "frontend" / "app.js").read_text(encoding="utf-8")
    html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
    assert "LocalEngineConnectionError" in app
    assert "retryBudget" in app
    assert "startOrResumeAnalysis" in app
    assert 'id="resumeButton"' in html


def test_background_watchdog_and_logs_are_packaged() -> None:
    watchdog = (ROOT / "local_watchdog.py").read_text(encoding="utf-8")
    launcher = (ROOT / "local_launcher.py").read_text(encoding="utf-8")
    assert "Server exited unexpectedly" in watchdog
    assert "local_server_fault.log" in launcher
    assert (ROOT / "Picklary_Vision_Rating.cmd").exists()


def test_native_work_is_isolated_from_api_server() -> None:
    main = (ROOT / "backend" / "app" / "main.py").read_text(encoding="utf-8")
    assert "backend.app.auto_setup_worker" in main
    assert "backend.app.worker" in main
    assert "run_auto_setup(" not in main


def test_manifest_declares_recovery_features() -> None:
    manifest = json.loads((ROOT / "package_manifest.json").read_text(encoding="utf-8"))
    assert manifest["version"] == "0.2.4"
    assert manifest["persistent_background_engine"] is True
    assert manifest["automatic_engine_restart"] is True
    assert manifest["browser_api_reconnect"] is True
    assert manifest["auto_setup_process_isolation"] is True
