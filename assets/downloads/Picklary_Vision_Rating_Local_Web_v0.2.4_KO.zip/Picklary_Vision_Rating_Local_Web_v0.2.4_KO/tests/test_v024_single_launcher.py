from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]

def test_only_one_windows_launcher_is_exposed():
    launchers = sorted(path.name for path in ROOT.glob("*.cmd"))
    assert launchers == ["Picklary_Vision_Rating.cmd"]

def test_manifest_uses_single_launcher():
    manifest = json.loads((ROOT / "package_manifest.json").read_text(encoding="utf-8"))
    assert manifest["entrypoint"] == "Picklary_Vision_Rating.cmd"
    assert manifest["single_launcher"] is True
    assert manifest["locale"] == "ko"

def test_unified_bootstrap_matches_locale():
    source = (ROOT / "unified_bootstrap.py").read_text(encoding="utf-8")
    assert 'PACKAGE_LOCALE = "ko"' in source
