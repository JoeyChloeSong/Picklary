from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parent
PACKAGE_VERSION = "0.2.4"
PACKAGE_LOCALE = "ko"
PACKAGE_PORT = 8765
PACKAGE_DATA_DIR = "PicklaryVisionLocal_KO"
MESSAGES = {'setup_start': 'Picklary Vision Rating을 준비합니다. 최초 실행은 몇 분이 걸릴 수 있습니다.', 'venv': '전용 Python 환경을 생성하고 있습니다...', 'packages': '필수 패키지를 설치하거나 복구하고 있습니다...', 'runtime': '안전한 Windows GPU 런타임을 준비하고 있습니다...', 'model': '선수 인식 모델을 확인하고 있습니다...', 'ready': 'Picklary Vision Rating 준비가 완료되었습니다. 브라우저를 엽니다...', 'existing': '로컬 엔진이 이미 실행 중입니다. 브라우저를 엽니다...', 'failed': '실행 준비를 완료하지 못했습니다. logs\\unified_launcher.log를 확인하세요.', 'stopped': '로컬 엔진을 종료했습니다.', 'repair': '복구 모드: 로컬 Python 환경을 다시 구성합니다.'}
RUNTIME = ROOT / ".runtime"
LOGS = ROOT / "logs"
RUNTIME.mkdir(parents=True, exist_ok=True)
LOGS.mkdir(parents=True, exist_ok=True)
LOG_PATH = LOGS / "unified_launcher.log"
SETUP_MARKER = RUNTIME / "unified_setup_v024.ok"
RUNTIME_MARKER = RUNTIME / "safe_runtime_v024_unified.ok"
MODEL_PATH = ROOT / "models" / "yolox_nano.onnx"
MODEL_URL = "https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0/yolox_nano.onnx"


def emit(message: str) -> None:
    print(message, flush=True)
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    with LOG_PATH.open("a", encoding="utf-8", errors="replace") as handle:
        handle.write(f"{stamp} {message}\n")


def run(command: list[str], *, check: bool = True, capture: bool = False) -> subprocess.CompletedProcess[str]:
    emit("$ " + " ".join(command))
    result = subprocess.run(
        command,
        cwd=str(ROOT),
        text=True,
        encoding="utf-8",
        errors="replace",
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.STDOUT if capture else None,
        check=False,
    )
    if capture and result.stdout:
        with LOG_PATH.open("a", encoding="utf-8", errors="replace") as handle:
            handle.write(result.stdout)
            if not result.stdout.endswith("\n"):
                handle.write("\n")
    if check and result.returncode != 0:
        raise RuntimeError(f"Command failed with exit code {result.returncode}: {' '.join(command)}")
    return result


def documents_dir() -> Path:
    docs = Path.home() / "Documents"
    return docs if docs.exists() else Path.home()


def venv_python() -> Path:
    if os.name == "nt":
        return ROOT / ".venv" / "Scripts" / "python.exe"
    return ROOT / ".venv" / "bin" / "python"


def venv_pythonw() -> Path:
    candidate = ROOT / ".venv" / "Scripts" / "pythonw.exe"
    return candidate if candidate.exists() else venv_python()


def health_payload(port: int) -> dict | None:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=1.5) as response:
            return json.loads(response.read().decode("utf-8"))
    except Exception:
        return None


def healthy_port() -> int | None:
    for port in range(PACKAGE_PORT, PACKAGE_PORT + 30):
        payload = health_payload(port)
        if (
            payload
            and payload.get("status") == "ok"
            and payload.get("locale") == PACKAGE_LOCALE
            and str(payload.get("version", "")).endswith(PACKAGE_VERSION)
        ):
            return port
    return None


def open_browser(port: int) -> None:
    webbrowser.open(f"http://127.0.0.1:{port}/?lang={PACKAGE_LOCALE}")


def base_environment_ready(python: Path) -> bool:
    code = (
        "import fastapi,uvicorn,cv2,numpy,scipy,psutil,multipart,imageio_ffmpeg; "
        "print('base environment ready')"
    )
    return run([str(python), "-c", code], check=False, capture=True).returncode == 0


def runtime_state(python: Path) -> tuple[bool, list[str]]:
    code = "import json,onnxruntime as o; print(json.dumps(o.get_available_providers()))"
    result = run([str(python), "-c", code], check=False, capture=True)
    if result.returncode != 0 or not result.stdout:
        return False, []
    try:
        providers = json.loads(result.stdout.strip().splitlines()[-1])
    except Exception:
        providers = []
    return True, [str(item) for item in providers]


def has_gpu_ort_package(python: Path) -> bool:
    return run([str(python), "-m", "pip", "show", "onnxruntime-gpu"], check=False, capture=True).returncode == 0


def ensure_base_environment(*, repair: bool = False) -> Path:
    python = venv_python()
    if repair and (ROOT / ".venv").exists():
        shutil.rmtree(ROOT / ".venv", ignore_errors=True)
        SETUP_MARKER.unlink(missing_ok=True)
        RUNTIME_MARKER.unlink(missing_ok=True)
    if not python.exists():
        emit(MESSAGES["venv"])
        run([sys.executable, "-m", "venv", str(ROOT / ".venv")])
    python = venv_python()
    if not python.exists():
        raise RuntimeError("The private Python environment was not created.")
    if repair or not SETUP_MARKER.exists() or not base_environment_ready(python):
        emit(MESSAGES["packages"])
        run([str(python), "-m", "pip", "install", "--upgrade", "pip", "--disable-pip-version-check", "--timeout", "120", "--retries", "3"])
        run([str(python), "-m", "pip", "install", "-r", str(ROOT / "requirements-local.txt"), "--disable-pip-version-check", "--timeout", "180", "--retries", "3"])
        if not base_environment_ready(python):
            raise RuntimeError("Required Python packages are not ready after installation.")
        SETUP_MARKER.write_text("ok\n", encoding="ascii")
    return python


def ensure_safe_runtime(python: Path, *, repair: bool = False) -> list[str]:
    emit(MESSAGES["runtime"])
    ort_ok, providers = runtime_state(python)
    gpu_package = has_gpu_ort_package(python)
    needs_migration = repair or gpu_package or not ort_ok
    if RUNTIME_MARKER.exists() and ort_ok and not gpu_package:
        return providers
    if not needs_migration and ("DmlExecutionProvider" in providers or "CPUExecutionProvider" in providers):
        RUNTIME_MARKER.write_text("directml\n" if "DmlExecutionProvider" in providers else "cpu\n", encoding="ascii")
        return providers

    uninstall = [str(python), "-m", "pip", "uninstall", "-y", "onnxruntime", "onnxruntime-gpu", "onnxruntime-directml"]
    run(uninstall, check=False)
    directml = run(
        [str(python), "-m", "pip", "install", "onnxruntime-directml>=1.19,<2", "--disable-pip-version-check", "--timeout", "240", "--retries", "3"],
        check=False,
    )
    ort_ok, providers = runtime_state(python)
    if directml.returncode == 0 and ort_ok and "DmlExecutionProvider" in providers:
        RUNTIME_MARKER.write_text("directml\n", encoding="ascii")
        return providers

    emit("DirectML was not available. Installing the CPU-safe ONNX Runtime fallback.")
    run(uninstall, check=False)
    run([str(python), "-m", "pip", "install", "onnxruntime>=1.19,<2", "--disable-pip-version-check", "--timeout", "180", "--retries", "3"])
    ort_ok, providers = runtime_state(python)
    if not ort_ok or "CPUExecutionProvider" not in providers:
        raise RuntimeError("ONNX Runtime installation did not complete.")
    RUNTIME_MARKER.write_text("cpu\n", encoding="ascii")
    return providers


def ensure_person_model() -> bool:
    emit(MESSAGES["model"])
    if MODEL_PATH.exists() and MODEL_PATH.stat().st_size > 3_000_000:
        return True
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    temp = MODEL_PATH.with_suffix(".onnx.download")
    try:
        request = urllib.request.Request(MODEL_URL, headers={"User-Agent": "Picklary-Vision-Rating/0.2.4"})
        with urllib.request.urlopen(request, timeout=90) as response, temp.open("wb") as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)
        if temp.stat().st_size <= 3_000_000:
            raise RuntimeError("Downloaded person model is incomplete.")
        temp.replace(MODEL_PATH)
        return True
    except Exception as exc:
        temp.unlink(missing_ok=True)
        emit(f"WARNING: Person model download did not complete: {exc}")
        emit(f"The app can still open. Save yolox_nano.onnx in {MODEL_PATH.parent} to enable person detection.")
        return False


def read_pid(path: Path) -> int | None:
    try:
        return int(path.read_text(encoding="ascii").strip())
    except Exception:
        return None


def stop_engine() -> None:
    RUNTIME.mkdir(parents=True, exist_ok=True)
    (RUNTIME / "stop.request").write_text("stop\n", encoding="ascii")
    for name in ("watchdog.pid", "server.pid"):
        pid = read_pid(RUNTIME / name)
        if pid and os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    for name in ("watchdog.pid", "server.pid", "server_port.txt", "stop.request"):
        (RUNTIME / name).unlink(missing_ok=True)
    emit(MESSAGES["stopped"])


def start_engine(python: Path) -> int:
    existing = healthy_port()
    if existing is not None:
        emit(MESSAGES["existing"])
        open_browser(existing)
        return 0

    for name in ("watchdog.pid", "server.pid", "server_port.txt", "stop.request"):
        (RUNTIME / name).unlink(missing_ok=True)
    env = os.environ.copy()
    env.update({
        "PYTHONUTF8": "1",
        "PYTHONIOENCODING": "utf-8",
        "PVR_ALLOW_CUDA": "0",
        "PVR_LOCALE": PACKAGE_LOCALE,
        "PVR_PACKAGE_LOCALE": PACKAGE_LOCALE,
        "PVR_LOCAL_PORT": str(PACKAGE_PORT),
    })
    creationflags = 0
    if os.name == "nt":
        creationflags = (
            getattr(subprocess, "CREATE_NO_WINDOW", 0)
            | getattr(subprocess, "DETACHED_PROCESS", 0)
            | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        )
    subprocess.Popen(
        [str(venv_pythonw()), str(ROOT / "local_watchdog.py")],
        cwd=str(ROOT),
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=creationflags,
        close_fds=True,
    )
    deadline = time.time() + 120
    while time.time() < deadline:
        port = healthy_port()
        if port is not None:
            emit(MESSAGES["ready"])
            return 0
        time.sleep(0.5)
    raise RuntimeError("The local engine did not become ready within 120 seconds.")


def show_logs() -> None:
    LOGS.mkdir(parents=True, exist_ok=True)
    if os.name == "nt":
        os.startfile(LOGS)  # type: ignore[attr-defined]
    else:
        emit(str(LOGS))


def show_data() -> None:
    target = documents_dir() / PACKAGE_DATA_DIR
    target.mkdir(parents=True, exist_ok=True)
    if os.name == "nt":
        os.startfile(target)  # type: ignore[attr-defined]
    else:
        emit(str(target))


def main() -> int:
    parser = argparse.ArgumentParser(description="Picklary Vision Rating unified launcher")
    parser.add_argument("--repair", action="store_true", help="Rebuild the private Python environment")
    parser.add_argument("--stop", action="store_true", help="Stop the local engine")
    parser.add_argument("--logs", action="store_true", help="Open the diagnostic logs folder")
    parser.add_argument("--data", action="store_true", help="Open the local data folder")
    args = parser.parse_args()

    try:
        if args.logs:
            show_logs()
            return 0
        if args.data:
            show_data()
            return 0
        if args.stop:
            stop_engine()
            return 0
        if args.repair:
            emit(MESSAGES["repair"])
            stop_engine()
        emit(MESSAGES["setup_start"])
        python = ensure_base_environment(repair=args.repair)
        providers = ensure_safe_runtime(python, repair=args.repair)
        emit("ONNX Runtime providers: " + ", ".join(providers))
        ensure_person_model()
        return start_engine(python)
    except Exception as exc:
        emit(f"ERROR: {exc}")
        emit(MESSAGES["failed"])
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
