@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Picklary Clip Lite v0.5.12 Windows

echo.
echo ================================================
echo   Picklary Clip Lite Windows v0.5.12
echo ================================================
echo.

set "PY_CMD="
py -3 -c "import sys; assert sys.version_info >= (3,10)" >nul 2>nul
if not errorlevel 1 set "PY_CMD=py -3"

if not defined PY_CMD (
  python -c "import sys; assert sys.version_info >= (3,10)" >nul 2>nul
  if not errorlevel 1 set "PY_CMD=python"
)

if not defined PY_CMD goto :python_missing

if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -c "import sys; assert sys.version_info >= (3,10)" >nul 2>nul
  if errorlevel 1 (
    echo [Repair] Removing an incomplete Python environment...
    rmdir /s /q ".venv"
  )
)

if not exist ".venv\Scripts\python.exe" (
  echo [Setup 1/2] Creating the private Python environment...
  %PY_CMD% -m venv ".venv"
  if errorlevel 1 goto :venv_failed
)

".venv\Scripts\python.exe" -c "import PySide6" >nul 2>nul
if errorlevel 1 (
  echo [Setup 2/2] Installing the Windows interface components...
  ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --upgrade pip
  if errorlevel 1 goto :install_failed
  ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r "requirements.txt"
  if errorlevel 1 goto :install_failed
)

echo [Start] Opening Picklary Clip Lite...
".venv\Scripts\python.exe" "clip_lite_native.py"
set "APP_RC=%errorlevel%"
if not "%APP_RC%"=="0" goto :app_failed
exit /b 0

:python_missing
echo [ERROR] Python 3.10 or newer was not found.
echo.
echo Install Python from the official page and enable "Add python.exe to PATH".
start "" "https://www.python.org/downloads/windows/"
pause
exit /b 1

:venv_failed
echo [ERROR] Could not create the private Python environment.
echo Delete the .venv folder if it exists, then run this file again.
pause
exit /b 1

:install_failed
echo [ERROR] Could not install PySide6.
echo Check the internet connection, antivirus settings, and available disk space.
pause
exit /b 1

:app_failed
echo [ERROR] The application closed with error code %APP_RC%.
echo Run 01_TEST_NATIVE_WINDOWS.bat and review the displayed message.
pause
exit /b %APP_RC%
