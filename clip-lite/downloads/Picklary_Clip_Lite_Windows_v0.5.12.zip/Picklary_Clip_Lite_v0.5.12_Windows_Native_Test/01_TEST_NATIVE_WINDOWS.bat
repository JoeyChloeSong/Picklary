@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Picklary Clip Lite Diagnostics

echo === Picklary Clip Lite Diagnostics ===
echo Folder: %CD%
echo.
where py
where python
echo.
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" --version
  ".venv\Scripts\python.exe" -c "import PySide6; print('PySide6', PySide6.__version__)"
  ".venv\Scripts\python.exe" -m py_compile "clip_core.py" "clip_lite_native.py"
) else (
  echo Private environment not found. Run 00_RUN_PICKLARY_CLIP_LITE_NATIVE_WINDOWS.bat first.
)
echo.
pause
