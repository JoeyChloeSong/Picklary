@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run 00_RUN_PICKLARY_CLIP_LITE_NATIVE_WINDOWS.bat once first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pip install pyinstaller
".venv\Scripts\pyinstaller.exe" --noconfirm --clean --windowed --name PicklaryClipLiteNative clip_lite_native.py
pause
