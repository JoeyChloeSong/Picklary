# Picklary Clip Lite v0.4 Native

- 개발자 버전과 같은 QMediaPlayer 네이티브 로딩 경로 적용
- 로컬 파일 경로를 즉시 재생기에 연결
- QAudioOutput 연결로 영상 소리 재생
- 하나의 타임라인에서 I/O 방식으로 복수 구간 지정
- 랠리 종료 시 장면 목록에 즉시 추가
- 통합본, 개별본, 통합본+개별본 내보내기
- FFmpeg는 내보내기 시점에만 실행
- 라이트 테마 UI 적용
