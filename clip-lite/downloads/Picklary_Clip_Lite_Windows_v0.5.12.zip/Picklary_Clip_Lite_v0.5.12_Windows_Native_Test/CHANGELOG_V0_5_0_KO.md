# Picklary Clip Lite v0.5.0 Windows Native Test

- Windows QMediaPlayer가 로컬 파일 경로를 직접 재생합니다.
- 영상 불러오기 시 파일 전체 복사, 웹 FFmpeg 로딩, 자동 프록시 변환을 하지 않습니다.
- 마스터 디자인의 네이비·민트 계열로 UI를 정리했습니다.
- -5/-3/-1/재생/+1/+3/+5 이동과 오디오 복원 기능을 유지합니다.
- FFmpeg는 내보내기 때만 필요합니다.
