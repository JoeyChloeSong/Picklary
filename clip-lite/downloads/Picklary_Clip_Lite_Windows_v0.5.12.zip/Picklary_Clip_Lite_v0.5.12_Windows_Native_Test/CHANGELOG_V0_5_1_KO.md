# Picklary Clip Lite v0.5.3 Windows

- 웹 마스터 디자인에 맞춘 네이비·민트 UI
- 웹과 동일한 1초·3초·5초 이동 버튼
- 지정 중 구간 블루→민트 그라데이션
- 저장 구간 라임·민트·블루 순환 표시
- WinGet 기반 FFmpeg 자동 설치
- FFmpeg 공식 다운로드 및 직접 선택 흐름
