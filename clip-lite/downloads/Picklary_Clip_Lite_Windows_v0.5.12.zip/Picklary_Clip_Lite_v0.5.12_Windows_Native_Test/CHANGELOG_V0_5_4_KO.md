# Picklary Clip Lite Windows v0.5.4

- QVideoWidget 전체화면 I/O 편집 모드 추가
- 전체화면에서 ApplicationShortcut 방식으로 I/O/Space/Esc 작동
- 전체화면 상단 상태와 하단 키 안내 HUD 추가
- 음소거 버튼, 0~100% 볼륨 슬라이더 및 수치 표시 추가
- 영상 변경·재생·장면 미리보기에서도 사용자의 볼륨 유지
