# Picklary Clip Lite Windows v0.5.9

- 상단 히어로 영역 축소
- 볼륨과 전체화면 버튼을 재생 컨트롤 하단 줄로 이동
- IN/OUT 분·초 직접 입력 장면 추가
- 전체화면 좌우 방향키 ±3초 이동
