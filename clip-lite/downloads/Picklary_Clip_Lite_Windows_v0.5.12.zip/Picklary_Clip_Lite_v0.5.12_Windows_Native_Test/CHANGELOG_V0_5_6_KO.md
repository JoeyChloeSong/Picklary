# v0.5.6 Windows launcher repair

- 실행 배치 파일을 BOM 없는 ASCII/CRLF 형식으로 교체했습니다.
- Microsoft Store의 잘못된 Python 별칭을 실행 가능한 Python으로 오인하지 않습니다.
- 손상된 `.venv`를 감지하면 자동 삭제 후 재생성합니다.
- 설치·실행 단계별 오류 메시지와 진단 배치 파일을 보강했습니다.
