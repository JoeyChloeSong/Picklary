# Picklary Clip Lite Windows v0.5.9

Windows 네이티브 저장 폴더 선택 방식은 기존처럼 유지됩니다. 이번 버전은 웹의 폴더 권한 차단을 없애기 위한 동시 배포 버전이며, Windows 실행기 복구 기능과 편집 기능은 v0.5.6과 동일합니다.
