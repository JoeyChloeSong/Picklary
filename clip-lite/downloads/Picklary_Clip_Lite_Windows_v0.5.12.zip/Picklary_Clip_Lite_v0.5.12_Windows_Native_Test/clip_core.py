from __future__ import annotations

import os
import re
import shutil
from pathlib import Path

MIN_SEGMENT_MS = 250


def format_time(milliseconds: int, with_millis: bool = True) -> str:
    value = max(0, int(milliseconds or 0))
    hours, remainder = divmod(value, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    seconds, millis = divmod(remainder, 1_000)
    base = f"{hours:02d}:{minutes:02d}:{seconds:02d}" if hours else f"{minutes:02d}:{seconds:02d}"
    return f"{base}.{millis:03d}" if with_millis else base


def safe_base_name(filename: str) -> str:
    stem = Path(filename or "video").stem
    cleaned = re.sub(r"[^0-9A-Za-z가-힣_-]+", "_", stem).strip("_")
    return (cleaned[:64] or "video")


def bytes_text(size: int) -> str:
    value = float(max(0, int(size or 0)))
    units = ("B", "KB", "MB", "GB", "TB")
    unit = 0
    while value >= 1024 and unit < len(units) - 1:
        value /= 1024
        unit += 1
    digits = 1 if unit > 1 else 0
    return f"{value:.{digits}f} {units[unit]}"


def normalize_segment(start_ms: int, end_ms: int, duration_ms: int) -> tuple[int, int]:
    limit = max(0, int(duration_ms or 0))
    start = max(0, min(limit, int(start_ms or 0)))
    end = max(0, min(limit, int(end_ms or 0)))
    start, end = min(start, end), max(start, end)
    if end - start < MIN_SEGMENT_MS:
        raise ValueError("편집 구간은 최소 0.25초 이상이어야 합니다.")
    return start, end


def find_ffmpeg(configured: str = "") -> str | None:
    candidates = [
        configured,
        os.getenv("PICKLARY_FFMPEG", ""),
        shutil.which("ffmpeg") or "",
    ]
    if os.name == "nt":
        home = Path.home()
        local = Path(os.getenv("LOCALAPPDATA", ""))
        candidates.extend(
            [
                str(Path(__file__).resolve().parent / "ffmpeg" / "bin" / "ffmpeg.exe"),
                str(Path(__file__).resolve().parent / "tools" / "ffmpeg" / "bin" / "ffmpeg.exe"),
                str(home / "scoop/apps/ffmpeg/current/bin/ffmpeg.exe"),
                str(local / "Microsoft/WinGet/Links/ffmpeg.exe"),
                "C:/ffmpeg/bin/ffmpeg.exe",
            ]
        )
        packages = local / "Microsoft/WinGet/Packages"
        if packages.is_dir():
            try:
                candidates.extend(str(path) for path in packages.glob("Gyan.FFmpeg*/**/bin/ffmpeg.exe"))
            except OSError:
                pass
    for raw in candidates:
        if not raw:
            continue
        path = Path(raw).expanduser()
        if path.is_file():
            return str(path.resolve())
        located = shutil.which(raw)
        if located:
            return located
    return None


def concat_escape(path: Path) -> str:
    return str(path.resolve()).replace("\\", "/").replace("'", "'\\''")
