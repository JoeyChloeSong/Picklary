from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from PySide6.QtCore import QSettings, Qt, QThread, QUrl, Signal, QRectF, QTimer
from PySide6.QtGui import (
    QAction,
    QColor,
    QDesktopServices,
    QDragEnterEvent,
    QDropEvent,
    QKeySequence,
    QLinearGradient,
    QPainter,
    QPen,
    QShortcut,
)
from PySide6.QtMultimedia import QAudioOutput, QMediaDevices, QMediaPlayer
from PySide6.QtMultimediaWidgets import QVideoWidget
from PySide6.QtWidgets import (
    QApplication,
    QButtonGroup,
    QDoubleSpinBox,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QSpinBox,
    QPushButton,
    QScrollArea,
    QSlider,
    QSizePolicy,
    QStackedLayout,
    QStatusBar,
    QVBoxLayout,
    QWidget,
)

from clip_core import bytes_text, concat_escape, find_ffmpeg, format_time, normalize_segment, safe_base_name

VIDEO_EXTENSIONS = {".mp4", ".mov", ".mkv", ".webm", ".m4v", ".avi"}
FFMPEG_DOWNLOAD_URL = "https://ffmpeg.org/download.html#build-windows"
FFMPEG_WINGET_ID = "Gyan.FFmpeg.Essentials"


class ExportWorker(QThread):
    progress = Signal(int, str)
    completed = Signal(str)
    failed = Signal(str)

    def __init__(self, ffmpeg: str, source: Path, segments: list[tuple[int, int]], mode: str, output_dir: Path):
        super().__init__()
        self.ffmpeg = ffmpeg
        self.source = source
        self.segments = segments
        self.mode = mode
        self.output_dir = output_dir

    def _run(self, command: list[str]) -> None:
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=flags,
        )
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "FFmpeg 실행 실패")[-2400:]
            raise RuntimeError(detail.strip())

    def run(self) -> None:
        try:
            self.output_dir.mkdir(parents=True, exist_ok=True)
            base = safe_base_name(self.source.name)
            keep_individual = self.mode in {"separate", "both"}
            make_merged = self.mode in {"merged", "both"}
            clips_dir = self.output_dir / f"{base}_clips"
            if keep_individual:
                clips_dir.mkdir(parents=True, exist_ok=True)

            with tempfile.TemporaryDirectory(prefix="picklary_clip_lite_") as temp_raw:
                temp_dir = Path(temp_raw)
                generated: list[Path] = []
                total_steps = len(self.segments) + (1 if make_merged else 0)

                for index, (start_ms, end_ms) in enumerate(self.segments, start=1):
                    destination = (clips_dir if keep_individual else temp_dir) / f"{base}_clip_{index:02d}.mp4"
                    duration = max(0.25, (end_ms - start_ms) / 1000.0)
                    start = start_ms / 1000.0
                    self.progress.emit(
                        int(((index - 1) / max(1, total_steps)) * 100),
                        f"장면 {index}/{len(self.segments)} 추출 중",
                    )
                    command = [
                        self.ffmpeg,
                        "-y",
                        "-hide_banner",
                        "-loglevel",
                        "error",
                        "-ss",
                        f"{start:.3f}",
                        "-i",
                        str(self.source),
                        "-t",
                        f"{duration:.3f}",
                        "-map",
                        "0:v:0?",
                        "-map",
                        "0:a:0?",
                        "-c:v",
                        "libx264",
                        "-preset",
                        "veryfast",
                        "-crf",
                        "20",
                        "-pix_fmt",
                        "yuv420p",
                        "-c:a",
                        "aac",
                        "-b:a",
                        "160k",
                        "-movflags",
                        "+faststart",
                        str(destination),
                    ]
                    self._run(command)
                    generated.append(destination)
                    self.progress.emit(int((index / max(1, total_steps)) * 100), f"장면 {index} 완료")

                merged_path = None
                if make_merged:
                    self.progress.emit(int((len(self.segments) / max(1, total_steps)) * 100), "선택 구간 연결 중")
                    concat_file = temp_dir / "concat.txt"
                    concat_file.write_text(
                        "\n".join(f"file '{concat_escape(path)}'" for path in generated) + "\n",
                        encoding="utf-8",
                    )
                    merged_path = self.output_dir / f"{base}_Picklary_Clips.mp4"
                    self._run(
                        [
                            self.ffmpeg,
                            "-y",
                            "-hide_banner",
                            "-loglevel",
                            "error",
                            "-f",
                            "concat",
                            "-safe",
                            "0",
                            "-i",
                            str(concat_file),
                            "-c",
                            "copy",
                            "-movflags",
                            "+faststart",
                            str(merged_path),
                        ]
                    )

            self.progress.emit(100, "내보내기 완료")
            if self.mode == "merged" and merged_path:
                result_path = merged_path
            elif self.mode == "separate":
                result_path = clips_dir
            else:
                result_path = self.output_dir
            self.completed.emit(str(result_path))
        except Exception as exc:
            self.failed.emit(str(exc))


class SegmentTimeline(QWidget):
    seekRequested = Signal(int)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.duration_ms = 0
        self.position_ms = 0
        self.pending_start_ms: int | None = None
        self.segments: list[tuple[int, int]] = []
        self.setMinimumHeight(54)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMouseTracking(True)

    def set_state(
        self,
        duration_ms: int,
        position_ms: int,
        pending_start_ms: int | None,
        segments: list[tuple[int, int]],
    ) -> None:
        self.duration_ms = max(0, int(duration_ms))
        self.position_ms = max(0, min(self.duration_ms, int(position_ms)))
        self.pending_start_ms = pending_start_ms
        self.segments = list(segments)
        self.update()

    def _x_for_ms(self, value: int, rect: QRectF) -> float:
        if self.duration_ms <= 0:
            return rect.left()
        return rect.left() + rect.width() * (max(0, min(self.duration_ms, value)) / self.duration_ms)

    def _ms_for_x(self, x: float, rect: QRectF) -> int:
        if self.duration_ms <= 0 or rect.width() <= 0:
            return 0
        ratio = max(0.0, min(1.0, (x - rect.left()) / rect.width()))
        return int(round(ratio * self.duration_ms))

    def _emit_seek(self, x: float) -> None:
        rect = QRectF(10, (self.height() - 14) / 2, max(1, self.width() - 20), 14)
        self.seekRequested.emit(self._ms_for_x(x, rect))

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._emit_seek(event.position().x())
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:
        if event.buttons() & Qt.MouseButton.LeftButton:
            self._emit_seek(event.position().x())
            event.accept()
            return
        super().mouseMoveEvent(event)

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        track = QRectF(10, (self.height() - 14) / 2, max(1, self.width() - 20), 14)

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(255, 255, 255, 20))
        painter.drawRoundedRect(track, 7, 7)

        if self.duration_ms <= 0:
            return

        current_x = self._x_for_ms(self.position_ms, track)
        if current_x > track.left():
            progress = QRectF(track.left(), track.top(), current_x - track.left(), track.height())
            painter.setBrush(QColor(255, 255, 255, 31))
            painter.drawRoundedRect(progress, 7, 7)

        if self.pending_start_ms is not None:
            start_x = self._x_for_ms(self.pending_start_ms, track)
            left, right = sorted((start_x, current_x))
            if right - left >= 1:
                glow = QRectF(left - 3, track.top() - 5, right - left + 6, track.height() + 10)
                painter.setBrush(QColor(73, 145, 255, 42))
                painter.drawRoundedRect(glow, 10, 10)
                gradient = QLinearGradient(left, 0, right, 0)
                gradient.setColorAt(0, QColor("#2b79ff"))
                gradient.setColorAt(1, QColor("#64e3bb"))
                painter.setBrush(gradient)
                painter.drawRoundedRect(QRectF(left, track.top(), max(2, right - left), track.height()), 7, 7)

        palette = [
            (QColor("#c7ff73"), QColor(199, 255, 115, 43)),
            (QColor("#64e3bb"), QColor(100, 227, 187, 38)),
            (QColor("#6ea8ff"), QColor(110, 168, 255, 38)),
        ]
        for index, (start_ms, end_ms) in enumerate(self.segments):
            left = self._x_for_ms(start_ms, track)
            right = self._x_for_ms(end_ms, track)
            width = max(4.0, right - left)
            border, fill = palette[index % len(palette)]
            saved = QRectF(left, track.top() - 3, width, track.height() + 6)
            painter.setPen(QPen(border, 2))
            painter.setBrush(fill)
            painter.drawRoundedRect(saved, 9, 9)

        painter.setPen(QPen(QColor("#ffffff"), 2))
        painter.drawLine(int(current_x), int(track.top() - 8), int(current_x), int(track.bottom() + 8))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(255, 255, 255, 45))
        painter.drawEllipse(QRectF(current_x - 4, track.top() - 11, 8, 8))



class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Picklary Clip Lite v0.5.12 Windows")
        self.resize(1320, 820)
        self.setMinimumSize(900, 560)
        self.setAcceptDrops(True)

        self.settings = QSettings("Picklary", "ClipLiteNative")
        self.source_path: Path | None = None
        self.duration_ms = 0
        self.pending_start_ms: int | None = None
        self.segments: list[tuple[int, int]] = []
        self.worker: ExportWorker | None = None
        self.last_audible_volume = max(0.05, min(1.0, self.settings.value("volume", 1.0, float)))
        self._shortcuts: list[QShortcut] = []

        self.player = QMediaPlayer(self)
        self.audio = QAudioOutput(self)
        default_device = QMediaDevices.defaultAudioOutput()
        if not default_device.isNull():
            self.audio.setDevice(default_device)
        self.audio.setMuted(False)
        self.audio.setVolume(self.last_audible_volume)
        self.player.setAudioOutput(self.audio)
        self.video_widget = QVideoWidget()
        self.video_widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.video_widget.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.player.setVideoOutput(self.video_widget)

        self._build_ui()
        self._connect_signals()
        self._apply_style()
        self.refresh_ffmpeg_status()
        self.statusBar().showMessage("영상 파일을 선택하세요.")

    def fit_initial_window_to_screen(self) -> None:
        """Fit the entire native window frame inside the usable desktop.

        Qt's client geometry excludes the Windows title bar and borders. Setting the
        client top to availableGeometry().top() can therefore push the title bar above
        the monitor. The window is shown once to obtain real frame margins, then the
        client rectangle is calculated so the outer frame remains fully visible.
        """
        screen = self.screen() or QApplication.primaryScreen()
        if screen is None:
            self.show()
            return

        self.show()
        QApplication.processEvents()
        area = screen.availableGeometry()
        frame = self.frameGeometry()
        client = self.geometry()

        frame_left = max(0, client.left() - frame.left())
        frame_top = max(0, client.top() - frame.top())
        frame_right = max(0, frame.right() - client.right())
        frame_bottom = max(0, frame.bottom() - client.bottom())
        safety = 10

        max_client_width = max(760, area.width() - frame_left - frame_right - safety * 2)
        max_client_height = max(520, area.height() - frame_top - frame_bottom - safety * 2)
        target_width = min(max_client_width, max(960, min(1440, int(area.width() * 0.90))))
        target_height = max(520, max_client_height)

        frame_width = target_width + frame_left + frame_right
        frame_x = area.x() + max(safety, (area.width() - frame_width) // 2)
        client_x = frame_x + frame_left
        client_y = area.y() + safety + frame_top
        self.setGeometry(client_x, client_y, target_width, target_height)
        QApplication.processEvents()
        self._clamp_window_frame_to_available_area()
        QTimer.singleShot(120, self._clamp_window_frame_to_available_area)

    def _clamp_window_frame_to_available_area(self) -> None:
        """Move/resize once more if DPI or a taskbar changed the real frame bounds."""
        screen = self.screen() or QApplication.primaryScreen()
        if screen is None:
            return
        area = screen.availableGeometry().adjusted(6, 6, -6, -6)
        frame = self.frameGeometry()

        if frame.height() > area.height():
            excess = frame.height() - area.height()
            self.resize(self.width(), max(520, self.height() - excess))
            QApplication.processEvents()
            frame = self.frameGeometry()

        dx = 0
        dy = 0
        if frame.left() < area.left():
            dx = area.left() - frame.left()
        elif frame.right() > area.right():
            dx = area.right() - frame.right()
        if frame.top() < area.top():
            dy = area.top() - frame.top()
        elif frame.bottom() > area.bottom():
            dy = area.bottom() - frame.bottom()
        if dx or dy:
            self.move(self.x() + dx, self.y() + dy)

    def _make_value_card(self, number: str, title: str, body: str) -> QFrame:
        card = QFrame()
        card.setObjectName("ValueCard")
        layout = QHBoxLayout(card)
        layout.setContentsMargins(18, 15, 18, 15)
        number_label = QLabel(number)
        number_label.setObjectName("ValueNumber")
        copy = QVBoxLayout()
        copy.setSpacing(2)
        title_label = QLabel(title)
        title_label.setObjectName("ValueTitle")
        body_label = QLabel(body)
        body_label.setObjectName("MutedSmall")
        copy.addWidget(title_label)
        copy.addWidget(body_label)
        layout.addWidget(number_label)
        layout.addLayout(copy, 1)
        return card

    def _make_side_step(self, number: str, title: str, subtitle: str) -> QWidget:
        widget = QWidget()
        row = QHBoxLayout(widget)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(10)
        badge = QLabel(number)
        badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        badge.setObjectName("StepBadge")
        copy = QVBoxLayout()
        copy.setSpacing(2)
        title_label = QLabel(title)
        title_label.setObjectName("SideStepTitle")
        subtitle_label = QLabel(subtitle)
        subtitle_label.setObjectName("MutedSmall")
        copy.addWidget(title_label)
        copy.addWidget(subtitle_label)
        row.addWidget(badge)
        row.addLayout(copy, 1)
        return widget

    def _build_ui(self) -> None:
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setCentralWidget(self.scroll)

        page = QWidget()
        page.setObjectName("Page")
        self.scroll.setWidget(page)
        outer = QVBoxLayout(page)
        outer.setContentsMargins(24, 16, 24, 24)
        outer.setSpacing(16)

        header = QHBoxLayout()
        header.setSpacing(12)
        mark = QLabel("P")
        mark.setAlignment(Qt.AlignmentFlag.AlignCenter)
        mark.setObjectName("BrandMark")
        brand_copy = QVBoxLayout()
        brand_copy.setSpacing(1)
        brand = QLabel("Picklary")
        brand.setObjectName("BrandTitle")
        brand_sub = QLabel("CLIP LITE · WINDOWS")
        brand_sub.setObjectName("BrandSub")
        brand_copy.addWidget(brand)
        brand_copy.addWidget(brand_sub)
        privacy = QLabel("▣  영상은 내 기기에서만 처리됩니다")
        privacy.setObjectName("PrivacyPill")
        header.addWidget(mark)
        header.addLayout(brand_copy)
        header.addStretch(1)
        header.addWidget(privacy)
        outer.addLayout(header)

        hero = QVBoxLayout()
        hero.setSpacing(4)
        eyebrow = QLabel("NO INSTALL · NO UPLOAD · JUST CUT")
        eyebrow.setAlignment(Qt.AlignmentFlag.AlignCenter)
        eyebrow.setObjectName("Eyebrow")
        headline = QLabel(
            '<div style="text-align:center">영상 자르기,<br>'
            '<span style="color:#83bdff">이보다 쉬울 수 없어요.</span></div>'
        )
        headline.setTextFormat(Qt.TextFormat.RichText)
        headline.setAlignment(Qt.AlignmentFlag.AlignCenter)
        headline.setObjectName("HeroTitle")
        intro = QLabel("재생하면서 랠리 시작과 종료만 누르세요. 종료를 누르는 순간 장면이 목록에 바로 저장됩니다.")
        intro.setAlignment(Qt.AlignmentFlag.AlignCenter)
        intro.setWordWrap(True)
        intro.setObjectName("HeroCopy")
        hero.addWidget(eyebrow)
        hero.addWidget(headline)
        hero.addWidget(intro)
        outer.addLayout(hero)

        shell = QFrame()
        shell.setObjectName("EditorShell")
        shell_layout = QHBoxLayout(shell)
        shell_layout.setContentsMargins(0, 0, 0, 0)
        shell_layout.setSpacing(0)
        outer.addWidget(shell, 1)

        editor_main = QFrame()
        editor_main.setObjectName("EditorMain")
        main_layout = QVBoxLayout(editor_main)
        main_layout.setContentsMargins(22, 22, 22, 22)
        main_layout.setSpacing(14)

        self.stage = QFrame()
        self.stage.setObjectName("VideoStage")
        self.stage.setMinimumHeight(500)
        self.video_stack = QStackedLayout(self.stage)
        self.video_stack.setContentsMargins(0, 0, 0, 0)
        empty = QWidget()
        empty_layout = QVBoxLayout(empty)
        empty_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        empty_icon = QLabel("⇧")
        empty_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        empty_icon.setObjectName("EmptyIcon")
        empty_title = QLabel("영상을 여기에 놓으세요")
        empty_title.setObjectName("EmptyTitle")
        empty_sub = QLabel("MP4 · MOV · MKV · WEBM · AVI")
        empty_sub.setObjectName("EmptySub")
        empty_layout.addWidget(empty_icon, 0, Qt.AlignmentFlag.AlignCenter)
        empty_layout.addWidget(empty_title, 0, Qt.AlignmentFlag.AlignCenter)
        empty_layout.addWidget(empty_sub, 0, Qt.AlignmentFlag.AlignCenter)
        self.video_stack.addWidget(empty)
        self.video_stack.addWidget(self.video_widget)
        self.video_stack.setCurrentIndex(0)
        main_layout.addWidget(self.stage, 1)

        self.trim_workspace = QWidget()
        self.trim_workspace.setObjectName("TrimWorkspace")
        trim_layout = QVBoxLayout(self.trim_workspace)
        trim_layout.setContentsMargins(0, 0, 0, 0)
        trim_layout.setSpacing(14)
        self.trim_workspace.hide()

        transport = QHBoxLayout()
        transport.setSpacing(7)
        self.back_5_button = QPushButton("−5s")
        self.back_3_button = QPushButton("−3s")
        self.back_1_button = QPushButton("−1s")
        self.play_button = QPushButton("▶  재생")
        self.play_button.setObjectName("PlayButton")
        self.forward_1_button = QPushButton("+1s")
        self.forward_3_button = QPushButton("+3s")
        self.forward_5_button = QPushButton("+5s")
        for button in (
            self.back_5_button, self.back_3_button, self.back_1_button,
            self.forward_1_button, self.forward_3_button, self.forward_5_button,
        ):
            button.setObjectName("SeekButton")
            button.setFixedWidth(48)
        self.time_label = QLabel("00:00.000  /  00:00.000")
        self.time_label.setObjectName("TimeReadout")
        transport.addWidget(self.back_5_button)
        transport.addWidget(self.back_3_button)
        transport.addWidget(self.back_1_button)
        transport.addWidget(self.play_button)
        transport.addWidget(self.forward_1_button)
        transport.addWidget(self.forward_3_button)
        transport.addWidget(self.forward_5_button)
        transport.addStretch(1)
        transport.addWidget(self.time_label)
        trim_layout.addLayout(transport)

        transport_tools = QHBoxLayout()
        transport_tools.setSpacing(8)
        self.mute_button = QPushButton("🔊")
        self.mute_button.setObjectName("VolumeButton")
        self.mute_button.setFixedWidth(42)
        self.volume_slider = QSlider(Qt.Orientation.Horizontal)
        self.volume_slider.setObjectName("VolumeSlider")
        self.volume_slider.setRange(0, 100)
        self.volume_slider.setValue(int(round(self.last_audible_volume * 100)))
        self.volume_slider.setFixedWidth(120)
        self.volume_value = QLabel(f"{self.volume_slider.value()}%")
        self.volume_value.setObjectName("VolumeValue")
        self.volume_value.setFixedWidth(38)
        transport_tools.addWidget(self.mute_button)
        transport_tools.addWidget(self.volume_slider)
        transport_tools.addWidget(self.volume_value)
        transport_tools.addStretch(1)
        trim_layout.addLayout(transport_tools)

        timeline_card = QFrame()
        timeline_card.setObjectName("TimelineCard")
        timeline_layout = QVBoxLayout(timeline_card)
        timeline_layout.setContentsMargins(17, 15, 17, 15)
        timeline_layout.setSpacing(9)
        timeline_head = QHBoxLayout()
        timeline_title = QLabel("하나의 편집 타임라인")
        timeline_title.setObjectName("TimelineTitle")
        self.mark_status = QLabel("재생 후 랠리 시작을 누르세요")
        self.mark_status.setObjectName("MutedSmall")
        timeline_head.addWidget(timeline_title)
        timeline_head.addStretch(1)
        timeline_head.addWidget(self.mark_status)
        timeline_layout.addLayout(timeline_head)
        self.timeline = SegmentTimeline()
        timeline_layout.addWidget(self.timeline)

        mark_row = QHBoxLayout()
        mark_row.setSpacing(10)
        self.start_button = QPushButton("I   랠리 시작\n현재 위치를 시작점으로 지정")
        self.start_button.setObjectName("StartButton")
        self.end_button = QPushButton("O   랠리 종료\n종료와 동시에 목록에 추가")
        self.end_button.setObjectName("EndButton")
        mark_row.addWidget(self.start_button)
        mark_row.addWidget(self.end_button)
        timeline_layout.addLayout(mark_row)
        shortcut = QLabel("I 시작  ·  O 종료  ·  Space 재생/일시정지")
        shortcut.setObjectName("ShortcutHint")
        shortcut.setAlignment(Qt.AlignmentFlag.AlignCenter)
        timeline_layout.addWidget(shortcut)
        trim_layout.addWidget(timeline_card)

        manual_card = QFrame()
        manual_card.setObjectName("ManualTimeCard")
        manual_layout = QVBoxLayout(manual_card)
        manual_layout.setContentsMargins(15, 13, 15, 13)
        manual_layout.setSpacing(8)
        manual_title = QLabel("IN / OUT 시간 직접 입력")
        manual_title.setObjectName("ManualTitle")
        manual_copy = QLabel("지점을 알고 있다면 영상을 재생하지 않고 분·초만 입력해 장면 목록에 추가할 수 있습니다.")
        manual_copy.setObjectName("MutedSmall")
        manual_copy.setWordWrap(True)
        manual_row = QHBoxLayout()
        manual_row.setSpacing(7)
        self.manual_start_min = QSpinBox()
        self.manual_start_min.setRange(0, 999)
        self.manual_start_min.setSuffix(" 분")
        self.manual_start_sec = QDoubleSpinBox()
        self.manual_start_sec.setRange(0.0, 59.999)
        self.manual_start_sec.setDecimals(3)
        self.manual_start_sec.setSuffix(" 초")
        self.manual_end_min = QSpinBox()
        self.manual_end_min.setRange(0, 999)
        self.manual_end_min.setSuffix(" 분")
        self.manual_end_sec = QDoubleSpinBox()
        self.manual_end_sec.setRange(0.0, 59.999)
        self.manual_end_sec.setDecimals(3)
        self.manual_end_sec.setSuffix(" 초")
        for widget in (self.manual_start_min, self.manual_start_sec, self.manual_end_min, self.manual_end_sec):
            widget.setObjectName("ManualTimeInput")
            widget.setMinimumWidth(82)
        self.manual_add_button = QPushButton("장면 추가")
        self.manual_add_button.setObjectName("ManualAddButton")
        manual_row.addWidget(QLabel("IN"))
        manual_row.addWidget(self.manual_start_min)
        manual_row.addWidget(self.manual_start_sec)
        manual_row.addWidget(QLabel("→  OUT"))
        manual_row.addWidget(self.manual_end_min)
        manual_row.addWidget(self.manual_end_sec)
        manual_row.addWidget(self.manual_add_button)
        manual_layout.addWidget(manual_title)
        manual_layout.addWidget(manual_copy)
        manual_layout.addLayout(manual_row)
        trim_layout.addWidget(manual_card)

        clips_head = QHBoxLayout()
        clips_label = QLabel("CUTS   내가 고른 장면")
        clips_label.setObjectName("SectionTitle")
        self.clear_button = QPushButton("전체 삭제")
        self.clear_button.setObjectName("TextDanger")
        clips_head.addWidget(clips_label)
        clips_head.addStretch(1)
        clips_head.addWidget(self.clear_button)
        trim_layout.addLayout(clips_head)
        self.clip_list = QListWidget()
        self.clip_list.setMinimumHeight(120)
        self.clip_list.setMaximumHeight(180)
        trim_layout.addWidget(self.clip_list)

        clip_actions = QHBoxLayout()
        self.preview_clip_button = QPushButton("선택 장면 재생")
        self.delete_clip_button = QPushButton("선택 삭제")
        clip_actions.addWidget(self.preview_clip_button)
        clip_actions.addWidget(self.delete_clip_button)
        clip_actions.addStretch(1)
        trim_layout.addLayout(clip_actions)
        main_layout.addWidget(self.trim_workspace)
        shell_layout.addWidget(editor_main, 1)

        self.side = QFrame()
        self.side.setObjectName("EditorSide")
        self.side.setFixedWidth(310)
        side_layout = QVBoxLayout(self.side)
        side_layout.setContentsMargins(20, 22, 20, 22)
        side_layout.setSpacing(14)

        load_card = QFrame()
        load_card.setObjectName("SideCard")
        load_layout = QVBoxLayout(load_card)
        load_layout.setContentsMargins(16, 16, 16, 16)
        step1 = self._make_side_step("1", "영상 불러오기", "드래그하거나 파일을 선택하세요")
        self.open_button = QPushButton("⇧  영상 선택")
        self.open_button.setObjectName("UploadButton")
        self.file_label = QLabel("MP4 · MOV · MKV · WEBM · AVI")
        codec_notice = QLabel("Windows 네이티브 재생\nHEVC/H.265 · 10-bit · HDR · 대용량 영상에 적합")
        codec_notice.setWordWrap(True)
        codec_notice.setObjectName("CodecNotice")
        self.file_label.setWordWrap(True)
        self.file_label.setObjectName("FileSummary")
        load_layout.addWidget(step1)
        load_layout.addSpacing(5)
        load_layout.addWidget(self.open_button)
        load_layout.addWidget(self.file_label)
        load_layout.addWidget(codec_notice)
        side_layout.addWidget(load_card)

        export_card = QFrame()
        export_card.setObjectName("SideCard")
        self.export_side_card = export_card
        self.export_side_card.setEnabled(False)
        export_layout = QVBoxLayout(export_card)
        export_layout.setContentsMargins(16, 16, 16, 16)
        export_layout.setSpacing(9)
        step2 = self._make_side_step("2", "추출하기", "원하는 저장 방식을 고르세요")
        export_layout.addWidget(step2)
        self.output_group = QButtonGroup(self)
        self.output_group.setExclusive(True)
        self.output_buttons: dict[str, QPushButton] = {}
        for label, description, mode in (
            ("하나의 영상", "고른 구간을 순서대로 연결", "merged"),
            ("개별 영상", "구간별 MP4를 따로 저장", "separate"),
            ("둘 다", "통합본과 개별 영상을 함께 저장", "both"),
        ):
            button = QPushButton(f"{label}\n{description}")
            button.setObjectName("ModeOption")
            button.setCheckable(True)
            button.setProperty("mode", mode)
            if mode == "merged":
                button.setChecked(True)
            self.output_group.addButton(button)
            self.output_buttons[mode] = button
            export_layout.addWidget(button)
        self.export_button = QPushButton("✦  영상 추출 시작")
        self.export_button.setObjectName("ExportButton")
        self.export_button.setEnabled(False)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress_label = QLabel("구간을 먼저 추가하세요.")
        self.progress_label.setWordWrap(True)
        self.progress_label.setObjectName("MutedSmall")
        export_layout.addWidget(self.export_button)
        export_layout.addWidget(self.progress)
        export_layout.addWidget(self.progress_label)
        side_layout.addWidget(export_card)

        ffmpeg_card = QFrame()
        ffmpeg_card.setObjectName("FfmpegCard")
        self.ffmpeg_card = ffmpeg_card
        self.ffmpeg_card.hide()
        ff_layout = QVBoxLayout(ffmpeg_card)
        ff_layout.setContentsMargins(16, 16, 16, 16)
        ff_layout.setSpacing(8)
        ff_title = QLabel("FFmpeg 내보내기 도우미")
        ff_title.setObjectName("SideTitle")
        ff_copy = QLabel("재생에는 필요하지 않습니다. 영상 추출을 시작할 때만 사용합니다.")
        ff_copy.setWordWrap(True)
        ff_copy.setObjectName("MutedSmall")
        self.ffmpeg_status = QLabel("FFmpeg 확인 중")
        self.ffmpeg_status.setObjectName("FfmpegStatus")
        ff_actions = QHBoxLayout()
        self.ffmpeg_install_button = QPushButton("자동 설치")
        self.ffmpeg_download_button = QPushButton("다운로드 안내")
        self.ffmpeg_check_button = QPushButton("설치 확인")
        ff_actions.addWidget(self.ffmpeg_install_button)
        ff_actions.addWidget(self.ffmpeg_download_button)
        ff_layout.addWidget(ff_title)
        ff_layout.addWidget(ff_copy)
        ff_layout.addWidget(self.ffmpeg_status)
        ff_layout.addLayout(ff_actions)
        ff_layout.addWidget(self.ffmpeg_check_button)
        side_layout.addWidget(ffmpeg_card)

        note = QLabel("▣  파일은 서버로 전송되지 않습니다.\n브라우저 없이 Windows에서 직접 재생합니다.")
        note.setWordWrap(True)
        note.setObjectName("SideNote")
        side_layout.addWidget(note)
        side_layout.addStretch(1)
        shell_layout.addWidget(self.side)

        value_row = QHBoxLayout()
        value_row.setSpacing(0)
        value_row.addWidget(self._make_value_card("01", "원본 직접", "Windows 미디어 엔진으로 바로 재생"))
        value_row.addWidget(self._make_value_card("02", "업로드 없이", "내 영상은 내 기기에만"))
        value_row.addWidget(self._make_value_card("03", "I와 O만", "종료를 누르면 즉시 목록 저장"))
        outer.addLayout(value_row)

        guide_panel = QFrame()
        guide_panel.setObjectName("FormatGuide")
        guide_layout = QVBoxLayout(guide_panel)
        guide_layout.setContentsMargins(24, 22, 24, 22)
        guide_layout.setSpacing(10)
        guide_eyebrow = QLabel("WINDOWS NATIVE")
        guide_eyebrow.setAlignment(Qt.AlignmentFlag.AlignCenter)
        guide_eyebrow.setObjectName("Eyebrow")
        guide_title = QLabel("내 영상에 맞는 실행 방법")
        guide_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        guide_title.setObjectName("GuideTitle")
        guide_copy = QLabel("HEVC/H.265, 10-bit, HDR, 4K/60fps 또는 1GB 이상의 영상은 Windows 네이티브 버전이 더 안정적입니다.")
        guide_copy.setAlignment(Qt.AlignmentFlag.AlignCenter)
        guide_copy.setWordWrap(True)
        guide_copy.setObjectName("HeroCopy")
        guide_layout.addWidget(guide_eyebrow)
        guide_layout.addWidget(guide_title)
        guide_layout.addWidget(guide_copy)
        outer.addWidget(guide_panel)

        footer = QHBoxLayout()
        footer_left = QLabel("© 2026 Picklary · Windows v0.5.10")
        footer_right = QLabel("Simple tools for better play.")
        footer_left.setObjectName("MutedSmall")
        footer_right.setObjectName("MutedSmall")
        footer.addWidget(footer_left)
        footer.addStretch(1)
        footer.addWidget(footer_right)
        outer.addLayout(footer)

        self.setStatusBar(QStatusBar())
        file_menu = self.menuBar().addMenu("파일")
        open_action = QAction("영상 열기", self)
        open_action.setShortcut(QKeySequence.StandardKey.Open)
        open_action.triggered.connect(self.choose_file)
        file_menu.addAction(open_action)
        self.menuBar().hide()

    def _connect_signals(self) -> None:
        self.open_button.clicked.connect(self.choose_file)
        self.play_button.clicked.connect(self.toggle_playback)
        self.back_5_button.clicked.connect(lambda: self.seek_relative(-5000))
        self.back_3_button.clicked.connect(lambda: self.seek_relative(-3000))
        self.back_1_button.clicked.connect(lambda: self.seek_relative(-1000))
        self.forward_1_button.clicked.connect(lambda: self.seek_relative(1000))
        self.forward_3_button.clicked.connect(lambda: self.seek_relative(3000))
        self.forward_5_button.clicked.connect(lambda: self.seek_relative(5000))
        self.mute_button.clicked.connect(self.toggle_mute)
        self.volume_slider.valueChanged.connect(self.set_volume)
        self.start_button.clicked.connect(self.mark_start)
        self.end_button.clicked.connect(self.mark_end)
        self.manual_add_button.clicked.connect(self.add_manual_segment)
        self.delete_clip_button.clicked.connect(self.delete_selected)
        self.clear_button.clicked.connect(self.clear_segments)
        self.preview_clip_button.clicked.connect(self.preview_selected)
        self.export_button.clicked.connect(self.export_video)
        self.timeline.seekRequested.connect(self.player.setPosition)
        self.ffmpeg_install_button.clicked.connect(self.install_ffmpeg_with_winget)
        self.ffmpeg_download_button.clicked.connect(self.open_ffmpeg_download)
        self.ffmpeg_check_button.clicked.connect(self.refresh_ffmpeg_status)

        self.player.positionChanged.connect(self.on_position_changed)
        self.player.durationChanged.connect(self.on_duration_changed)
        self.player.playbackStateChanged.connect(self.on_playback_state_changed)
        self.player.errorOccurred.connect(self.on_media_error)

        for sequence, callback in (
            ("Space", self.toggle_playback),
            ("I", self.mark_start),
            ("O", self.mark_end),
            ("Delete", self.delete_selected),
        ):
            shortcut = QShortcut(QKeySequence(sequence), self)
            shortcut.setContext(Qt.ShortcutContext.ApplicationShortcut)
            shortcut.activated.connect(callback)
            self._shortcuts.append(shortcut)

    def _apply_style(self) -> None:
        self.setStyleSheet(
            """
            QMainWindow, QWidget#Page, QScrollArea { background:#07101f; color:#f7fbff; font-family:'Segoe UI','Malgun Gothic'; font-size:13px; }
            QScrollArea > QWidget > QWidget { background:#07101f; }
            QMenuBar, QMenu { background:#0b1930; color:#eef5ff; }
            QMenuBar::item:selected, QMenu::item:selected { background:#152743; }
            QLabel#BrandMark { min-width:44px; min-height:44px; max-width:44px; max-height:44px; border-radius:13px; background:#78ebc9; color:#06121e; font-size:25px; font-weight:950; }
            QLabel#BrandTitle { font-size:19px; font-weight:950; color:#f7fbff; }
            QLabel#BrandSub { color:#9fb0c8; font-size:10px; letter-spacing:2px; }
            QLabel#PrivacyPill { padding:10px 14px; border:1px solid rgba(255,255,255,.12); border-radius:18px; background:rgba(255,255,255,.04); color:#dce8f7; }
            QLabel#Eyebrow { color:#64e3bb; font-size:11px; font-weight:900; letter-spacing:3px; }
            QLabel#HeroTitle { font-size:38px; font-weight:950; color:#f7fbff; margin-top:2px; }
            QLabel#HeroCopy { color:#9fb0c8; font-size:12px; margin-bottom:2px; }
            QFrame#EditorShell { min-height:650px; background:#0c172b; border:1px solid rgba(255,255,255,.12); border-radius:25px; }
            QFrame#EditorMain { background:#101d34; border-right:1px solid rgba(255,255,255,.10); border-top-left-radius:25px; border-bottom-left-radius:25px; }
            QFrame#EditorSide { background:#081120; border-top-right-radius:25px; border-bottom-right-radius:25px; }
            QFrame#VideoStage { background:#02050a; border:1px solid rgba(255,255,255,.08); border-radius:18px; }
            QVideoWidget { background:#010308; }
            QLabel#EmptyIcon { min-width:76px; min-height:76px; max-width:76px; max-height:76px; border:1px solid rgba(100,227,187,.30); border-radius:24px; background:rgba(100,227,187,.10); color:#64e3bb; font-size:34px; }
            QLabel#EmptyTitle { color:#f7fbff; font-size:23px; font-weight:900; margin-top:8px; }
            QLabel#EmptySub { color:#9fb0c8; font-size:11px; letter-spacing:2px; }
            QPushButton { min-height:36px; border:1px solid #2a4264; border-radius:10px; background:#10213b; color:#eaf2ff; padding:0 12px; font-weight:800; }
            QPushButton:hover { background:#172d4d; border-color:#3d5c85; }
            QPushButton:disabled { color:#5d6c82; background:#0b1729; border-color:#182942; }
            QPushButton#SeekButton { min-width:48px; max-width:48px; padding:0; }
            QPushButton#PlayButton { min-width:105px; background:#2f83f7; color:white; border:0; }
            QPushButton#VolumeButton { min-width:42px; max-width:42px; padding:0; color:#64e3bb; }
            QSlider#VolumeSlider::groove:horizontal { height:4px; border-radius:2px; background:#2a3d59; }
            QSlider#VolumeSlider::sub-page:horizontal { background:#64e3bb; border-radius:2px; }
            QSlider#VolumeSlider::handle:horizontal { width:14px; margin:-5px 0; border-radius:7px; background:#64e3bb; }
            QLabel#VolumeValue { color:#9fb0c8; font-size:10px; }
            QLabel#TimeReadout { color:#f7fbff; font-weight:800; }
            QFrame#TimelineCard { background:rgba(255,255,255,.025); border:1px solid rgba(255,255,255,.10); border-radius:17px; }
            QLabel#TimelineTitle, QLabel#SectionTitle { color:#f7fbff; font-size:15px; font-weight:900; }
            QLabel#MutedSmall { color:#9fb0c8; font-size:11px; }
            QLabel#ShortcutHint { color:#9fb0c8; font-size:10px; }
            QPushButton#StartButton { text-align:left; min-height:62px; background:rgba(43,121,255,.10); border-color:rgba(110,168,255,.36); color:#dceaff; }
            QPushButton#StartButton[armed="true"] { background:rgba(43,121,255,.20); border-color:#6ea8ff; }
            QPushButton#EndButton { text-align:left; min-height:62px; background:rgba(100,227,187,.08); border-color:rgba(100,227,187,.26); color:#dffff4; }
            QFrame#ManualTimeCard { background:rgba(43,121,255,.08); border:1px solid rgba(110,168,255,.25); border-radius:14px; }
            QLabel#ManualTitle { color:#eaf2ff; font-size:12px; font-weight:950; }
            QSpinBox#ManualTimeInput, QDoubleSpinBox#ManualTimeInput { min-height:34px; background:#071326; color:#f7fbff; border:1px solid #2a4264; border-radius:8px; padding:0 7px; }
            QPushButton#ManualAddButton { min-height:36px; background:#64e3bb; color:#06131b; border:0; font-weight:950; }
            QPushButton#TextDanger { background:transparent; border:0; color:#ff9ab1; }
            QListWidget { background:#08162a; color:#eaf2ff; border:1px solid #263d5d; border-radius:12px; padding:7px; }
            QListWidget::item { padding:10px 8px; border-bottom:1px solid #172a45; }
            QListWidget::item:selected { background:#173b63; color:#fff; }
            QFrame#SideCard, QFrame#FfmpegCard { background:rgba(255,255,255,.035); border:1px solid rgba(255,255,255,.11); border-radius:17px; }
            QFrame#FfmpegCard { border-color:rgba(100,227,187,.25); background:rgba(100,227,187,.045); }
            QLabel#SideTitle { font-size:15px; font-weight:950; color:#f7fbff; }
            QLabel#StepBadge { min-width:30px; min-height:30px; max-width:30px; max-height:30px; border-radius:10px; background:#2f83f7; color:#ffffff; font-size:12px; font-weight:950; }
            QLabel#SideStepTitle { font-size:15px; font-weight:950; color:#f7fbff; }
            QPushButton#UploadButton { min-height:48px; background:#dceaff; color:#081323; border:0; }
            QLabel#FileSummary { padding:10px; border:1px solid rgba(255,255,255,.10); border-radius:11px; background:rgba(0,0,0,.14); color:#9fb0c8; }
            QLabel#CodecNotice { padding:11px; border:1px solid rgba(100,227,187,.24); border-radius:11px; background:rgba(100,227,187,.055); color:#a8ead8; font-size:10px; }
            QPushButton#ModeOption { min-height:52px; text-align:left; padding:7px 12px; background:#0c192c; color:#94a6be; border:1px solid #1d304a; border-radius:11px; }
            QPushButton#ModeOption:checked { color:#eafff7; border-color:#64e3bb; background:rgba(100,227,187,.09); }
            QPushButton#ModeOption:disabled { color:#53657c; border-color:#16263c; background:#0a1424; }
            QPushButton#ExportButton { min-height:54px; background:#64e3bb; color:#06131b; border:0; font-weight:950; }
            QPushButton#ExportButton:disabled { background:#152238; color:#58677c; }
            QProgressBar { border:1px solid #263d5d; border-radius:7px; height:14px; text-align:center; background:#071326; color:#eaf2ff; }
            QProgressBar::chunk { background:#64e3bb; border-radius:6px; }
            QLabel#FfmpegStatus { padding:9px; border-radius:9px; background:rgba(0,0,0,.17); color:#64e3bb; font-weight:900; }
            QLabel#SideNote { color:#9fb0c8; font-size:11px; padding:8px; }
            QFrame#ValueCard { min-height:62px; background:rgba(255,255,255,.025); border:1px solid rgba(255,255,255,.09); }
            QFrame#FormatGuide { background:#0d1b32; border:1px solid rgba(255,255,255,.10); border-radius:22px; }
            QLabel#GuideTitle { color:#f7fbff; font-size:28px; font-weight:950; }
            QLabel#ValueNumber { color:#64e3bb; font-size:12px; font-weight:950; min-width:28px; }
            QLabel#ValueTitle { color:#f7fbff; font-size:13px; font-weight:900; }
            QStatusBar { background:#09182b; color:#91a5bf; }
            """
        )

    def _update_timeline(self, position: int | None = None) -> None:
        value = self.player.position() if position is None else position
        self.timeline.set_state(self.duration_ms, value, self.pending_start_ms, self.segments)

    def choose_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "영상 선택",
            str(Path.home()),
            "Video Files (*.mp4 *.mov *.mkv *.webm *.m4v *.avi);;All Files (*)",
        )
        if path:
            self.load_video(Path(path))

    def load_video(self, path: Path) -> None:
        if not path.is_file() or path.suffix.lower() not in VIDEO_EXTENSIONS:
            QMessageBox.warning(self, "영상 파일", "지원되는 영상 파일을 선택해 주세요.")
            return
        self.player.stop()
        self.source_path = path.resolve()
        self.duration_ms = 0
        self.pending_start_ms = None
        self.segments.clear()
        self.refresh_segments()
        self._update_timeline(0)
        self.apply_volume_setting()
        default_device = QMediaDevices.defaultAudioOutput()
        if not default_device.isNull():
            self.audio.setDevice(default_device)
        self.player.setSource(QUrl.fromLocalFile(str(self.source_path)))
        self.video_stack.setCurrentIndex(1)
        self.trim_workspace.show()
        self.export_side_card.setEnabled(True)
        self.ffmpeg_card.show()
        self.file_label.setText(f"{self.source_path.name}\n{bytes_text(self.source_path.stat().st_size)} · 원본 파일 직접 연결")
        self.statusBar().showMessage("원본 경로를 Windows 네이티브 플레이어에 연결했습니다.")

    def toggle_playback(self) -> None:
        if not self.source_path:
            return
        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
        else:
            self.apply_volume_setting()
            self.player.play()

    def seek_relative(self, delta_ms: int) -> None:
        self.player.setPosition(max(0, min(self.duration_ms, self.player.position() + delta_ms)))

    def apply_volume_setting(self) -> None:
        value = max(0.0, min(1.0, self.volume_slider.value() / 100.0 if hasattr(self, "volume_slider") else self.last_audible_volume))
        self.audio.setVolume(value)
        self.audio.setMuted(value <= 0 or self.audio.isMuted())
        self._update_volume_ui()

    def set_volume(self, percent: int) -> None:
        value = max(0.0, min(1.0, int(percent) / 100.0))
        if value > 0:
            self.last_audible_volume = value
            self.audio.setMuted(False)
            self.settings.setValue("volume", value)
        else:
            self.audio.setMuted(True)
        self.audio.setVolume(value)
        self._update_volume_ui()

    def toggle_mute(self) -> None:
        if self.audio.isMuted() or self.volume_slider.value() == 0:
            restored = max(5, int(round(self.last_audible_volume * 100)))
            self.volume_slider.blockSignals(True)
            self.volume_slider.setValue(restored)
            self.volume_slider.blockSignals(False)
            self.audio.setVolume(restored / 100.0)
            self.audio.setMuted(False)
        else:
            self.last_audible_volume = max(0.05, self.volume_slider.value() / 100.0)
            self.audio.setMuted(True)
        self._update_volume_ui()

    def _update_volume_ui(self) -> None:
        if not hasattr(self, "volume_slider"):
            return
        value = self.volume_slider.value()
        muted = self.audio.isMuted() or value == 0
        self.mute_button.setText("🔇" if muted else "🔊")
        self.mute_button.setToolTip("음소거 해제" if muted else "음소거")
        self.volume_value.setText(f"{value}%")


    def on_position_changed(self, position: int) -> None:
        self.time_label.setText(f"{format_time(position)}  /  {format_time(self.duration_ms)}")
        if self.pending_start_ms is not None:
            elapsed = max(0, position - self.pending_start_ms)
            self.mark_status.setText(f"시작 {format_time(self.pending_start_ms)} · 현재까지 {format_time(elapsed)}")
        elif self.segments:
            self.mark_status.setText(f"{len(self.segments)}개 장면 저장됨 · 랠리 시작을 누르세요")
        self._update_timeline(position)

    def on_duration_changed(self, duration: int) -> None:
        self.duration_ms = max(0, int(duration))
        self.time_label.setText(f"00:00.000  /  {format_time(self.duration_ms)}")
        if self.source_path:
            self.file_label.setText(
                f"{self.source_path.name}\n{bytes_text(self.source_path.stat().st_size)} · {format_time(self.duration_ms, False)} · Native"
            )
        self._update_timeline(0)
        self.statusBar().showMessage("영상 준비 완료. 재생하면서 I와 O로 구간을 지정하세요.")

    def on_playback_state_changed(self, state: QMediaPlayer.PlaybackState) -> None:
        self.play_button.setText("Ⅱ  일시정지" if state == QMediaPlayer.PlaybackState.PlayingState else "▶  재생")

    def on_media_error(self, _error, message: str) -> None:
        if not self.source_path:
            return
        QMessageBox.warning(
            self,
            "영상 재생 오류",
            (message or "Windows에서 이 영상 코덱을 재생하지 못했습니다.")
            + "\n\nHEVC 영상이라면 Microsoft Store의 HEVC Video Extensions 설치 여부를 확인하세요. 원본은 변환되지 않았습니다.",
        )

    def add_manual_segment(self) -> None:
        if not self.source_path or not self.duration_ms:
            QMessageBox.information(self, "시간 직접 입력", "영상을 먼저 불러와 주세요.")
            return
        start_ms = int(round((self.manual_start_min.value() * 60 + self.manual_start_sec.value()) * 1000))
        end_ms = int(round((self.manual_end_min.value() * 60 + self.manual_end_sec.value()) * 1000))
        if start_ms >= self.duration_ms or end_ms > self.duration_ms:
            QMessageBox.warning(self, "시간 확인", f"입력 시간은 영상 길이 {format_time(self.duration_ms)} 안에 있어야 합니다.")
            return
        try:
            segment = normalize_segment(start_ms, end_ms, self.duration_ms)
        except ValueError as exc:
            QMessageBox.warning(self, "시간 확인", str(exc))
            return
        self.segments.append(segment)
        self.segments.sort(key=lambda item: (item[0], item[1]))
        self.refresh_segments()
        self.mark_status.setText(f"직접 입력한 {format_time(segment[0])} → {format_time(segment[1])} 장면을 추가했습니다.")
        self.statusBar().showMessage("In/Out 직접 입력 장면이 색상 타임라인과 목록에 추가되었습니다.")

    def mark_start(self) -> None:
        if not self.source_path or not self.duration_ms:
            return
        self.pending_start_ms = self.player.position()
        self.mark_status.setText(f"랠리 시작 {format_time(self.pending_start_ms)} 지정됨")
        self.start_button.setProperty("armed", True)
        self.start_button.style().unpolish(self.start_button)
        self.start_button.style().polish(self.start_button)
        self._update_timeline()
        self.statusBar().showMessage("종료 지점에서 O 또는 랠리 종료 버튼을 누르세요.")

    def mark_end(self) -> None:
        if self.pending_start_ms is None:
            QMessageBox.information(self, "랠리 시작", "먼저 랠리 시작(I)을 지정해 주세요.")
            return
        try:
            segment = normalize_segment(self.pending_start_ms, self.player.position(), self.duration_ms)
        except ValueError as exc:
            QMessageBox.warning(self, "구간 확인", str(exc))
            return
        self.segments.append(segment)
        self.segments.sort(key=lambda item: (item[0], item[1]))
        self.pending_start_ms = None
        self.start_button.setProperty("armed", False)
        self.start_button.style().unpolish(self.start_button)
        self.start_button.style().polish(self.start_button)
        self.refresh_segments()
        self._update_timeline()
        self.mark_status.setText(f"장면 {self.segments.index(segment) + 1}이 색상 구간으로 저장되었습니다.")

    def refresh_segments(self) -> None:
        self.clip_list.clear()
        for index, (start, end) in enumerate(self.segments, start=1):
            self.clip_list.addItem(
                f"{index:02d}   {format_time(start)}  →  {format_time(end)}   ({format_time(end - start)})"
            )
        enabled = bool(self.source_path and self.segments and not self.worker)
        self.export_button.setEnabled(enabled)
        self.progress_label.setText("영상 추출 준비 완료." if enabled else "구간을 먼저 추가하세요.")
        if self.segments and self.clip_list.currentRow() < 0:
            self.clip_list.setCurrentRow(0)
        self._update_timeline()

    def delete_selected(self) -> None:
        row = self.clip_list.currentRow()
        if 0 <= row < len(self.segments):
            del self.segments[row]
            self.refresh_segments()

    def clear_segments(self) -> None:
        self.segments.clear()
        self.pending_start_ms = None
        self.refresh_segments()
        self.mark_status.setText("모든 장면을 삭제했습니다.")

    def preview_selected(self) -> None:
        row = self.clip_list.currentRow()
        if 0 <= row < len(self.segments):
            start, _ = self.segments[row]
            self.player.setPosition(start)
            self.apply_volume_setting()
            self.player.play()

    def refresh_ffmpeg_status(self) -> str | None:
        configured = self.settings.value("ffmpeg_path", "", str)
        ffmpeg = find_ffmpeg(configured)
        if ffmpeg:
            self.ffmpeg_status.setText(f"✓ 준비됨\n{ffmpeg}")
            self.ffmpeg_status.setStyleSheet("color:#64e3bb;")
            return ffmpeg
        self.ffmpeg_status.setText("! 설치 필요 · 재생은 가능하며 추출 전에만 설치하면 됩니다.")
        self.ffmpeg_status.setStyleSheet("color:#ffcc80;")
        return None

    def install_ffmpeg_with_winget(self) -> None:
        if os.name != "nt":
            self.open_ffmpeg_download()
            return
        if shutil.which("winget") is None:
            QMessageBox.information(
                self,
                "WinGet를 찾을 수 없습니다",
                "Windows 패키지 관리자(WinGet)가 없어 자동 설치를 시작할 수 없습니다.\n공식 다운로드 안내 페이지를 열겠습니다.",
            )
            self.open_ffmpeg_download()
            return
        answer = QMessageBox.question(
            self,
            "FFmpeg 자동 설치",
            "Microsoft WinGet을 사용해 FFmpeg Essentials를 설치합니다.\n\n"
            "별도 명령창이 열리며 설치가 완료된 뒤 이 프로그램에서 '설치 확인'을 눌러 주세요.",
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        command = (
            f'winget install --id {FFMPEG_WINGET_ID} -e --source winget '
            '--accept-source-agreements --accept-package-agreements'
        )
        subprocess.Popen(
            ["cmd.exe", "/k", command],
            creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0),
        )
        self.statusBar().showMessage("FFmpeg 설치 창을 열었습니다. 완료 후 '설치 확인'을 누르세요.")

    def open_ffmpeg_download(self) -> None:
        QDesktopServices.openUrl(QUrl(FFMPEG_DOWNLOAD_URL))

    def choose_ffmpeg_file(self) -> str | None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "ffmpeg 실행 파일 선택",
            "",
            "FFmpeg (ffmpeg.exe ffmpeg);;All Files (*)",
        )
        if path and Path(path).is_file():
            self.settings.setValue("ffmpeg_path", path)
            self.refresh_ffmpeg_status()
            return path
        return None

    def resolve_ffmpeg(self) -> str | None:
        ffmpeg = self.refresh_ffmpeg_status()
        if ffmpeg:
            return ffmpeg
        box = QMessageBox(self)
        box.setWindowTitle("FFmpeg가 필요합니다")
        box.setIcon(QMessageBox.Icon.Information)
        box.setText("영상 재생은 정상입니다. 선택 구간을 파일로 추출하려면 FFmpeg가 필요합니다.")
        box.setInformativeText(
            "가장 쉬운 방법은 '자동 설치'입니다. 설치가 제한된 PC라면 공식 다운로드 안내를 열거나 ffmpeg.exe를 직접 선택하세요."
        )
        auto_button = box.addButton("자동 설치", QMessageBox.ButtonRole.ActionRole)
        page_button = box.addButton("공식 다운로드", QMessageBox.ButtonRole.ActionRole)
        select_button = box.addButton("직접 선택", QMessageBox.ButtonRole.ActionRole)
        box.addButton(QMessageBox.StandardButton.Cancel)
        box.exec()
        clicked = box.clickedButton()
        if clicked == auto_button:
            self.install_ffmpeg_with_winget()
            return None
        if clicked == page_button:
            self.open_ffmpeg_download()
            return None
        if clicked == select_button:
            return self.choose_ffmpeg_file()
        return None

    def selected_output_mode(self) -> str:
        button = self.output_group.checkedButton() if hasattr(self, "output_group") else None
        return str(button.property("mode")) if button is not None else "merged"

    def export_video(self) -> None:
        if not self.source_path or not self.segments:
            return
        ffmpeg = self.resolve_ffmpeg()
        if not ffmpeg:
            self.progress_label.setText("FFmpeg 설치 또는 선택 후 다시 추출을 눌러 주세요.")
            return
        output = QFileDialog.getExistingDirectory(self, "저장 폴더 선택", str(self.source_path.parent))
        if not output:
            return
        self.worker = ExportWorker(
            ffmpeg=ffmpeg,
            source=self.source_path,
            segments=list(self.segments),
            mode=self.selected_output_mode(),
            output_dir=Path(output),
        )
        self.worker.progress.connect(self.on_export_progress)
        self.worker.completed.connect(self.on_export_completed)
        self.worker.failed.connect(self.on_export_failed)
        self.worker.finished.connect(self.on_export_finished)
        self.export_button.setEnabled(False)
        self.open_button.setEnabled(False)
        self.progress.setValue(0)
        self.progress_label.setText("네이티브 FFmpeg 내보내기를 시작합니다.")
        self.worker.start()

    def on_export_progress(self, percent: int, message: str) -> None:
        self.progress.setValue(percent)
        self.progress_label.setText(message)

    def on_export_completed(self, path: str) -> None:
        self.progress.setValue(100)
        self.progress_label.setText(f"완료: {path}")
        QMessageBox.information(self, "내보내기 완료", f"영상 추출을 완료했습니다.\n\n{path}")

    def on_export_failed(self, message: str) -> None:
        self.progress.setValue(0)
        self.progress_label.setText("내보내기 실패")
        QMessageBox.critical(self, "내보내기 실패", message)

    def on_export_finished(self) -> None:
        self.worker = None
        self.open_button.setEnabled(True)
        self.refresh_segments()

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:
        urls = event.mimeData().urls()
        if urls and Path(urls[0].toLocalFile()).suffix.lower() in VIDEO_EXTENSIONS:
            event.acceptProposedAction()

    def dropEvent(self, event: QDropEvent) -> None:
        urls = event.mimeData().urls()
        if urls:
            self.load_video(Path(urls[0].toLocalFile()))
            event.acceptProposedAction()

    def closeEvent(self, event) -> None:
        if self.worker and self.worker.isRunning():
            QMessageBox.information(self, "내보내기 진행 중", "영상 내보내기가 끝난 뒤 프로그램을 종료해 주세요.")
            event.ignore()
            return
        self.player.stop()
        event.accept()


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("Picklary Clip Lite")
    app.setOrganizationName("Picklary")
    window = MainWindow()
    window.fit_initial_window_to_screen()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
