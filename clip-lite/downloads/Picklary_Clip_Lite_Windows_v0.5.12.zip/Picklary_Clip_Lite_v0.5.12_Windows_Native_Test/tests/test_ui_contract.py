import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "clip_lite_native.py").read_text(encoding="utf-8")

class UiContractTests(unittest.TestCase):
    def test_web_master_visual_tokens(self):
        for token in ["SegmentTimeline", "#c7ff73", "#64e3bb", "#6ea8ff", "#2b79ff"]:
            self.assertIn(token, SOURCE)

    def test_seek_controls(self):
        for token in ["back_5_button", "back_3_button", "back_1_button",
                      "forward_1_button", "forward_3_button", "forward_5_button"]:
            self.assertIn(token, SOURCE)

    def test_seek_labels_include_seconds(self):
        for token in ['QPushButton("−5s")', 'QPushButton("−3s")', 'QPushButton("−1s")',
                      'QPushButton("+1s")', 'QPushButton("+3s")', 'QPushButton("+5s")']:
            self.assertIn(token, SOURCE)

    def test_export_asks_for_folder(self):
        self.assertIn('QFileDialog.getExistingDirectory', SOURCE)
        self.assertIn('저장 폴더 선택', SOURCE)
        self.assertIn('if not output:', SOURCE)

    def test_ffmpeg_assistant(self):
        self.assertIn("Gyan.FFmpeg.Essentials", SOURCE)
        self.assertIn("FFMPEG_DOWNLOAD_URL", SOURCE)
        self.assertIn("install_ffmpeg_with_winget", SOURCE)

    def test_fullscreen_editor_removed(self):
        for token in ["fullscreen_button", "toggle_fullscreen_edit", "enter_fullscreen_edit",
                      "exit_fullscreen_edit", "showFullScreen()", "FullscreenStatus", "FullscreenHint"]:
            self.assertNotIn(token, SOURCE)

    def test_default_window_frame_stays_inside_available_screen(self):
        for token in [
            "fit_initial_window_to_screen", "availableGeometry()", "frameGeometry()",
            "QApplication.processEvents()", "_clamp_window_frame_to_available_area",
            "frame_top", "frame_bottom", "safety = 10", "self.move(self.x() + dx, self.y() + dy)"
        ]:
            self.assertIn(token, SOURCE)
        self.assertNotIn("window.showMaximized()", SOURCE)

    def test_volume_controls(self):
        for token in ["VolumeButton", "VolumeSlider", "toggle_mute", "set_volume",
                      "audio.setVolume", "audio.setMuted"]:
            self.assertIn(token, SOURCE)

    def test_manual_time_entry(self):
        for token in ["manual_start_min", "manual_start_sec", "manual_end_min", "manual_end_sec",
                      "manual_add_button", "add_manual_segment", "QDoubleSpinBox", "QSpinBox"]:
            self.assertIn(token, SOURCE)

    def test_mode_cards_match_web_export_choices(self):
        for token in ['("하나의 영상", "고른 구간을 순서대로 연결", "merged")',
                      '("개별 영상", "구간별 MP4를 따로 저장", "separate")',
                      '("둘 다", "통합본과 개별 영상을 함께 저장", "both")',
                      "selected_output_mode"]:
            self.assertIn(token, SOURCE)

    def test_compact_hero_and_secondary_controls(self):
        self.assertIn("font-size:38px", SOURCE)
        self.assertIn("transport_tools = QHBoxLayout()", SOURCE)
        self.assertIn("self.trim_workspace.hide()", SOURCE)

if __name__ == "__main__":
    unittest.main()
