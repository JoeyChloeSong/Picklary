@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Picklary Lite v0.7.5 EN GPU Diagnosis

if not exist ".venv\Scripts\python.exe" (
  echo Run 00_RUN_PICKLARY_LITE_WINDOWS.bat once first.
  pause
  exit /b 1
)

".venv\Scripts\python.exe" "picklary_internal\gpu_diagnose.py"
echo.
pause
