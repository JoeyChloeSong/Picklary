# Picklary Lite v0.7.4 EN Release Notes

## English Edition
- Translated the complete user interface for Clip Editor, DualCam Composer, audio auto-sync, export, FFmpeg setup, GPU diagnostics, warnings, and progress messages.
- Preserved all v0.7.4 Korean-edition features and processing behavior.

## DualCam Audio Auto-Sync
- Compares audio waveforms from both videos to detect a shared section and recording offset.
- Trims only the video that started recording earlier.
- Shows recommended start points, confidence, correlation, agreement, and candidate separation.
- Applies the detected start points only after user confirmation.
- Keeps the existing manual start-point workflow as a fallback.
- Search ranges: first 2, 5, 10 (default), or 20 minutes.

## Existing Features Retained
- Single-window Clip Editor and DualCam Composer
- Drag-and-drop replacement in both modes
- Horizontal layout and 4K output defaults
- NVIDIA NVENC first with CPU fallback
- Vertical / Horizontal output filenames
- Send a DualCam result directly to Clip Editor
