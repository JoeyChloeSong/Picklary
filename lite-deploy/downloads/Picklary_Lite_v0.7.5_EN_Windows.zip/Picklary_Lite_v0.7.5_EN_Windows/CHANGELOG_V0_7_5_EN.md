# Picklary Lite v0.7.5 EN Release Notes

## DualCam control-overlay fix

- Removed the Windows-native `QVideoWidget` from DualCam previews.
- Video frames are now received through `QVideoSink` and painted on regular Qt canvases.
- Loading both videos no longer allows a native video surface to cover play controls or timelines.
- Source resolution no longer expands the preview's layout size unexpectedly.
- The complete DualCam page is vertically scrollable for smaller and high-DPI displays.

## Video labels

- `A · Video 1 (Left/Top in Output)`
- `B · Video 2 (Right/Bottom in Output)`

Audio auto-sync, manual alignment, Horizontal/4K defaults, GPU-first composition, and Clip Editor handoff remain available.
