@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Picklary FFmpeg Setup Helper

echo ======================================================
echo Picklary Lite - FFmpeg Setup Helper
echo ======================================================
echo.
echo FFmpeg is not required for video playback.
echo It is required only for exporting clips, DualCam composition,
echo and audio auto-sync.
echo.

where ffmpeg >nul 2>nul
if %errorlevel%==0 (
  echo [READY] FFmpeg is already installed.
  ffmpeg -version | findstr /b "ffmpeg version"
  pause
  exit /b 0
)

where winget >nul 2>nul
if errorlevel 1 goto :manual

echo Installing FFmpeg Essentials with Microsoft WinGet...
echo Consent prompts or an installation progress window may appear.
echo.
winget install --id Gyan.FFmpeg.Essentials -e --source winget --accept-source-agreements --accept-package-agreements
if errorlevel 1 goto :manual

echo.
echo [COMPLETE] Restart Picklary or click "Check Installation" in the app.
pause
exit /b 0

:manual
echo.
echo Automatic installation is unavailable. Opening the official FFmpeg download page.
start "" "https://ffmpeg.org/download.html#build-windows"
echo.
echo See FFMPEG_SETUP_GUIDE_EN.html for detailed instructions.
pause
exit /b 1
