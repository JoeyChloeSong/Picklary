# Picklary Lite v0.7.5 EN — Test Result

- Windows version:
- GPU:
- A/B video formats:
- Controls remain visible:
- Other results:
