from __future__ import annotations

from .ui import run


def main() -> int:
    return int(run())
