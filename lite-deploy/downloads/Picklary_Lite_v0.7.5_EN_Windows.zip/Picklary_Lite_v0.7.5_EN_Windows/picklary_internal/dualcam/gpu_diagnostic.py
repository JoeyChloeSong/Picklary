from __future__ import annotations

from pathlib import Path

from .ffmpeg import acceleration_diagnostic_report, find_tool


def main() -> int:
    ffmpeg = find_tool("ffmpeg")
    if not ffmpeg:
        print("FFmpeg was not found. Run INSTALL_FFMPEG_WINDOWS.bat first.")
        return 1
    report = acceleration_diagnostic_report(ffmpeg)
    print(report)
    target = Path.cwd() / "Picklary_GPU_Diagnostic.txt"
    target.write_text(report, encoding="utf-8")
    print(f"\nDiagnostic file saved: {target}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
