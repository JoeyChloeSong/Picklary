from __future__ import annotations

import os
import sys
from pathlib import Path


def _candidate_plugin_dirs() -> list[Path]:
    candidates: list[Path] = []
    try:
        import PySide6
        root = Path(PySide6.__file__).resolve().parent
        candidates.extend([
            root / "plugins",
            root / "Qt" / "plugins",
        ])
    except Exception:
        pass
    for item in sys.path:
        root = Path(item)
        candidates.extend([
            root / "PySide6" / "plugins",
            root / "PySide6" / "Qt" / "plugins",
        ])
    return list(dict.fromkeys(candidates))


def configure_qt_runtime() -> Path:
    if os.name != "nt":
        return Path()
    os.environ.pop("QT_PLUGIN_PATH", None)
    os.environ.pop("QT_QPA_PLATFORM_PLUGIN_PATH", None)
    os.environ["QT_QPA_PLATFORM"] = "windows"
    for plugins in _candidate_plugin_dirs():
        platform = plugins / "platforms" / "qwindows.dll"
        if platform.is_file():
            os.environ["QT_PLUGIN_PATH"] = str(plugins)
            os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = str(plugins / "platforms")
            try:
                os.add_dll_directory(str(plugins.parent))
                os.add_dll_directory(str(plugins))
            except (AttributeError, OSError):
                pass
            return plugins
    raise RuntimeError("PySide6 Windows platform plugin qwindows.dll was not found.")


def main() -> int:
    try:
        plugins = configure_qt_runtime()
        if os.name == "nt":
            print(f"Qt plugins: {plugins}")
        return 0
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
