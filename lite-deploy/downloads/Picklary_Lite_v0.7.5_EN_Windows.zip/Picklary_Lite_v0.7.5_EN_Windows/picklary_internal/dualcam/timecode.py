from __future__ import annotations


def format_time(seconds: float) -> str:
    seconds = max(0.0, float(seconds))
    hours = int(seconds // 3600)
    minutes = int(seconds % 3600 // 60)
    secs = seconds % 60
    if hours:
        return f"{hours:02d}:{minutes:02d}:{secs:06.3f}"
    return f"{minutes:02d}:{secs:06.3f}"


def parse_time_text(text: str) -> float:
    value = text.strip().replace(",", ".")
    if not value:
        raise ValueError("Enter a start point.")
    parts = value.split(":")
    try:
        if len(parts) == 1:
            seconds = float(parts[0])
        elif len(parts) == 2:
            minutes, seconds_part = parts
            seconds = int(minutes) * 60 + float(seconds_part)
        elif len(parts) == 3:
            hours, minutes, seconds_part = parts
            seconds = int(hours) * 3600 + int(minutes) * 60 + float(seconds_part)
        else:
            raise ValueError
    except (TypeError, ValueError) as exc:
        raise ValueError("Enter time as 90.5, 01:30.500, or 00:01:30.500.") from exc
    if seconds < 0:
        raise ValueError("Start points must be 0 seconds or later.")
    return seconds
