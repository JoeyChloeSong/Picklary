from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence


@dataclass(frozen=True)
class GpuInfo:
    names: tuple[str, ...]
    driver: str
    nvidia_detected: bool


@dataclass(frozen=True)
class EncoderDecision:
    ffmpeg_path: str
    encoder: str
    mode: str
    gpu: GpuInfo
    supported_encoders: tuple[str, ...]
    nvenc_test_ok: bool
    reason: str


@dataclass(frozen=True)
class ExportAttempt:
    name: str
    hardware_label: str
    command: tuple[str, ...]


def run_text(command: Sequence[str], timeout: float = 12.0) -> subprocess.CompletedProcess[str]:
    startupinfo = None
    creationflags = 0
    if os.name == "nt":
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return subprocess.run(
        list(command),
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
        check=False,
        startupinfo=startupinfo,
        creationflags=creationflags,
    )


def supported_video_encoders(ffmpeg_path: str | Path) -> tuple[str, ...]:
    result = run_text([str(ffmpeg_path), "-hide_banner", "-encoders"], timeout=15)
    text = f"{result.stdout}\n{result.stderr}"
    known = ("h264_nvenc", "h264_qsv", "h264_amf", "libx264")
    return tuple(name for name in known if re.search(rf"\b{re.escape(name)}\b", text))


def _powershell_gpu_info() -> tuple[list[str], str]:
    if os.name != "nt":
        return [], ""
    command = [
        "powershell.exe",
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-Command",
        "$g=Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion; $g | ConvertTo-Json -Compress",
    ]
    try:
        result = run_text(command, timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        return [], ""
    if result.returncode != 0 or not result.stdout.strip():
        return [], ""
    try:
        payload = json.loads(result.stdout.strip())
    except json.JSONDecodeError:
        return [], ""
    rows = payload if isinstance(payload, list) else [payload]
    names = [str(row.get("Name", "")).strip() for row in rows if row.get("Name")]
    drivers = [str(row.get("DriverVersion", "")).strip() for row in rows if row.get("DriverVersion")]
    return names, ", ".join(dict.fromkeys(drivers))


def _nvidia_smi_info() -> tuple[list[str], str]:
    executable = shutil.which("nvidia-smi")
    if not executable and os.name == "nt":
        common = Path(r"C:\Program Files\NVIDIA Corporation\NVSMI\nvidia-smi.exe")
        if common.is_file():
            executable = str(common)
    if not executable:
        return [], ""
    try:
        result = run_text(
            [executable, "--query-gpu=name,driver_version", "--format=csv,noheader,nounits"],
            timeout=8,
        )
    except (OSError, subprocess.TimeoutExpired):
        return [], ""
    names: list[str] = []
    drivers: list[str] = []
    for line in result.stdout.splitlines():
        if "," in line:
            name, driver = line.split(",", 1)
            names.append(name.strip())
            drivers.append(driver.strip())
    return names, ", ".join(dict.fromkeys(drivers))


def detect_gpu_info() -> GpuInfo:
    names, driver = _powershell_gpu_info()
    smi_names, smi_driver = _nvidia_smi_info()
    merged_names = list(dict.fromkeys([*names, *smi_names]))
    if smi_driver:
        driver = smi_driver
    nvidia = any(
        token in name.lower()
        for name in merged_names
        for token in ("nvidia", "geforce", "quadro", "rtx")
    )
    return GpuInfo(tuple(merged_names), driver or "Check failed", nvidia)


def test_nvenc(ffmpeg_path: str | Path) -> tuple[bool, str]:
    command = [
        str(ffmpeg_path),
        "-hide_banner",
        "-loglevel",
        "error",
        "-f",
        "lavfi",
        "-i",
        "color=c=black:s=256x144:r=6",
        "-frames:v",
        "6",
        "-an",
        "-c:v",
        "h264_nvenc",
        "-preset",
        "p1",
        "-f",
        "null",
        "-",
    ]
    try:
        result = run_text(command, timeout=15)
    except subprocess.TimeoutExpired:
        return False, "NVENC test encode timed out"
    except OSError as exc:
        return False, f"NVENC test failed to run: {exc}"
    detail = (result.stderr or result.stdout).strip()
    return result.returncode == 0, detail[-1600:]


def choose_encoder(ffmpeg_path: str | Path) -> EncoderDecision:
    path = str(Path(ffmpeg_path).resolve())
    gpu = detect_gpu_info()
    try:
        encoders = supported_video_encoders(path)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return EncoderDecision(path, "libx264", "CPU", gpu, (), False, f"Unable to inspect FFmpeg encoders: {exc}")

    if "h264_nvenc" in encoders:
        ok, detail = test_nvenc(path)
        if ok:
            gpu_name = next((name for name in gpu.names if "nvidia" in name.lower() or "geforce" in name.lower() or "rtx" in name.lower()), "NVIDIA GPU")
            return EncoderDecision(
                path,
                "h264_nvenc",
                "NVIDIA GPU",
                gpu,
                encoders,
                True,
                f"{gpu_name} · NVENC live test passed",
            )
        reason = "h264_nvenc is present, but the live test failed"
        if detail:
            reason += f": {detail.splitlines()[-1]}"
        return EncoderDecision(path, "libx264", "CPU", gpu, encoders, False, reason)

    return EncoderDecision(
        path,
        "libx264",
        "CPU",
        gpu,
        encoders,
        False,
        "This FFmpeg build does not include the h264_nvenc encoder.",
    )


def _base_command(
    ffmpeg: str,
    source: str | Path,
    start_seconds: float,
    duration_seconds: float,
    destination: str | Path,
) -> list[str]:
    return [
        ffmpeg,
        "-y",
        "-hide_banner",
        "-loglevel",
        "error",
        "-ss",
        f"{start_seconds:.3f}",
        "-i",
        str(source),
        "-t",
        f"{duration_seconds:.3f}",
        "-map",
        "0:v:0?",
        "-map",
        "0:a:0?",
        "-sn",
        "-dn",
        "-c:a",
        "aac",
        "-b:a",
        "160k",
        "-ar",
        "48000",
        "-movflags",
        "+faststart",
        "-avoid_negative_ts",
        "make_zero",
        str(destination),
    ]


def build_export_attempts(
    decision: EncoderDecision,
    source: str | Path,
    start_seconds: float,
    duration_seconds: float,
    destination: str | Path,
) -> tuple[ExportAttempt, ...]:
    attempts: list[ExportAttempt] = []

    if decision.nvenc_test_ok:
        cuda = _base_command(decision.ffmpeg_path, source, start_seconds, duration_seconds, destination)
        cuda[5:5] = ["-hwaccel", "cuda"]
        output_index = len(cuda) - 1
        cuda[output_index:output_index] = [
            "-c:v",
            "h264_nvenc",
            "-preset",
            "p2",
            "-rc:v",
            "vbr",
            "-cq:v",
            "20",
            "-b:v",
            "0",
            "-pix_fmt",
            "yuv420p",
        ]
        attempts.append(
            ExportAttempt(
                "CUDA decoding + NVENC encoding",
                "GPU · NVIDIA NVENC",
                tuple(cuda),
            )
        )

        nvenc = _base_command(decision.ffmpeg_path, source, start_seconds, duration_seconds, destination)
        output_index = len(nvenc) - 1
        nvenc[output_index:output_index] = [
            "-c:v",
            "h264_nvenc",
            "-preset",
            "p2",
            "-rc:v",
            "vbr",
            "-cq:v",
            "20",
            "-b:v",
            "0",
            "-pix_fmt",
            "yuv420p",
        ]
        attempts.append(
            ExportAttempt(
                "Standard decoding + NVENC encoding",
                "GPU · NVIDIA NVENC",
                tuple(nvenc),
            )
        )

    cpu = _base_command(decision.ffmpeg_path, source, start_seconds, duration_seconds, destination)
    output_index = len(cpu) - 1
    cpu[output_index:output_index] = [
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-crf",
        "20",
        "-pix_fmt",
        "yuv420p",
        "-threads",
        "0",
    ]
    attempts.append(ExportAttempt("CPU Safe Mode", "CPU · libx264", tuple(cpu)))
    return tuple(attempts)


def decision_label(decision: EncoderDecision) -> str:
    if decision.nvenc_test_ok:
        gpu_name = next(
            (name for name in decision.gpu.names if "nvidia" in name.lower() or "geforce" in name.lower() or "rtx" in name.lower()),
            "NVIDIA GPU",
        )
        return f"GPU Ready · {gpu_name}\nNVENC"
    return "CPU Ready · libx264\nNVENC unavailable"
