from __future__ import annotations

from clip_core import find_ffmpeg
from gpu_core import choose_encoder


def main() -> int:
    ffmpeg = find_ffmpeg("")
    print("Picklary Lite GPU Diagnostics")
    print("=" * 48)
    if not ffmpeg:
        print("FFmpeg: not found")
        print("Place ffmpeg.exe in the app folder or your Downloads folder.")
        return 1
    decision = choose_encoder(ffmpeg)
    print(f"FFmpeg: {decision.ffmpeg_path}")
    print(f"Detected GPU: {', '.join(decision.gpu.names) if decision.gpu.names else 'Check failed'}")
    print(f"NVIDIA driver: {decision.gpu.driver}")
    print(f"Available encoders: {', '.join(decision.supported_encoders) if decision.supported_encoders else 'Check failed'}")
    print(f"NVENC live test: {'Success' if decision.nvenc_test_ok else 'Failed'}")
    print(f"Selected processing: {decision.mode} · {decision.encoder}")
    print(f"Decision reason: {decision.reason}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
