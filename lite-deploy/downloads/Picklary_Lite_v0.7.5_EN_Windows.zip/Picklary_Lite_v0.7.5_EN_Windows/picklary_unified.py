from __future__ import annotations

import os
import sys
from pathlib import Path

from PySide6.QtCore import QTimer, Qt
from PySide6.QtGui import QCloseEvent, QDragEnterEvent, QDropEvent, QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

ROOT = Path(__file__).resolve().parent
INTERNAL = ROOT / "picklary_internal"
if str(INTERNAL) not in sys.path:
    sys.path.insert(0, str(INTERNAL))

from clip_mode import MainWindow as ClipModeController  # noqa: E402
from dualcam.ui import MainWindow as DualCamModeController, dropped_video_paths  # noqa: E402

APP_VERSION = "0.7.5 EN"


class UnifiedMainWindow(QMainWindow):
    """One-window shell for Clip editing and DualCam composition.

    The legacy mode controllers remain internal implementation objects only. Their
    central widgets are hosted in this window's stacked page, so the user sees one
    application, one title bar, and one launcher.
    """

    MODE_CLIP = 0
    MODE_DUALCAM = 1

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"Picklary Lite v{APP_VERSION} · Clip + DualCam")
        self.resize(1400, 900)
        self.setMinimumSize(1020, 650)
        self.setAcceptDrops(True)

        self.clip = ClipModeController()
        self.dualcam = DualCamModeController()
        self.clip.setParent(self)
        self.dualcam.setParent(self)

        self.clip_page = self.clip.takeCentralWidget()
        self.dualcam_page = self.dualcam.takeCentralWidget()
        if self.clip_page is None or self.dualcam_page is None:
            raise RuntimeError("Unable to build the integrated interface.")

        # Keep each mode's visual design after reparenting its central widget.
        self.clip_page.setStyleSheet(self.clip.styleSheet())
        self.dualcam_page.setStyleSheet(self.dualcam.styleSheet())

        self._build_ui()
        self._disable_internal_window_shortcuts()
        self._rewire_mode_actions()
        self._install_shortcuts()
        self.show_clip_mode(initial=True)

    def _build_ui(self) -> None:
        root = QWidget(self)
        root.setObjectName("UnifiedRoot")
        layout = QVBoxLayout(root)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        nav = QFrame(root)
        nav.setObjectName("UnifiedNav")
        nav_layout = QHBoxLayout(nav)
        nav_layout.setContentsMargins(16, 10, 16, 10)
        nav_layout.setSpacing(10)

        brand = QLabel("P  Picklary Lite")
        brand.setObjectName("UnifiedBrand")
        self.clip_button = QPushButton("✂  Clip Editor")
        self.dualcam_button = QPushButton("▣  DualCam Composer")
        self.clip_button.setCheckable(True)
        self.dualcam_button.setCheckable(True)
        self.clip_button.setObjectName("ModeButton")
        self.dualcam_button.setObjectName("ModeButton")
        self.mode_label = QLabel("CLIP MODE")
        self.mode_label.setObjectName("ModeLabel")

        nav_layout.addWidget(brand)
        nav_layout.addSpacing(14)
        nav_layout.addWidget(self.clip_button)
        nav_layout.addWidget(self.dualcam_button)
        nav_layout.addStretch(1)
        nav_layout.addWidget(self.mode_label)

        self.pages = QStackedWidget(root)
        self.pages.setObjectName("UnifiedPages")
        self.pages.addWidget(self.clip_page)
        self.pages.addWidget(self.dualcam_page)

        layout.addWidget(nav)
        layout.addWidget(self.pages, 1)
        self.setCentralWidget(root)

        self.clip_button.clicked.connect(self.show_clip_mode)
        self.dualcam_button.clicked.connect(self.show_dualcam_mode)

        self.setStyleSheet(
            """
            QWidget#UnifiedRoot { background:#06111f; }
            QFrame#UnifiedNav { background:#08172a; border-bottom:1px solid #203b5e; }
            QLabel#UnifiedBrand { color:#f7fbff; font:900 18px 'Segoe UI'; padding:7px 12px; }
            QPushButton#ModeButton { min-height:38px; padding:7px 18px; border-radius:10px;
                background:#10243e; color:#aebed1; border:1px solid #29466b; font-weight:800; }
            QPushButton#ModeButton:hover { color:#ffffff; border-color:#64e3bb; }
            QPushButton#ModeButton:checked { background:#64e3bb; color:#071521; border-color:#8bf3d3; }
            QLabel#ModeLabel { color:#64e3bb; border:1px solid rgba(100,227,187,.38);
                border-radius:12px; padding:7px 12px; font-weight:900; }
            """
        )


    def _disable_internal_window_shortcuts(self) -> None:
        # The unified shell owns all keyboard commands. Disable shortcuts that
        # belonged to the formerly separate windows to prevent double actions.
        for shortcut in getattr(self.clip, "_shortcuts", []):
            shortcut.setEnabled(False)
        for name in ("space_shortcut", "left_shortcut", "right_shortcut"):
            shortcut = getattr(self.dualcam, name, None)
            if shortcut is not None:
                shortcut.setEnabled(False)

    def _rewire_mode_actions(self) -> None:
        # The Clip page's original DualCam button now changes the page in this
        # same window instead of opening a second QMainWindow.
        try:
            self.clip.dualcam_button.clicked.disconnect()
        except (RuntimeError, TypeError):
            pass
        self.clip.dualcam_button.clicked.connect(self.show_dualcam_mode)
        self.clip.dualcam_button.setText("▣  Combine Videos · Open DualCam")
        self.clip.dualcam_button.setToolTip("Switch to DualCam composition in the same Picklary window.")
        self.dualcam.clip_edit_requested.connect(self._load_dualcam_output_in_clip)

        # Add an explicit return button inside the DualCam page header so users
        # do not need to use the top navigation bar.
        return_button = QPushButton("← Back to Clip Editor", self.dualcam_page)
        return_button.setObjectName("secondaryButton")
        return_button.clicked.connect(self.show_clip_mode)
        dual_root_layout = self.dualcam_page.layout()
        if isinstance(dual_root_layout, QVBoxLayout):
            dual_root_layout.insertWidget(0, return_button, 0, Qt.AlignmentFlag.AlignLeft)
        self.return_to_clip_button = return_button

    def _install_shortcuts(self) -> None:
        self._shortcuts: list[QShortcut] = []
        mapping = {
            "Space": self._space_action,
            "Left": self._left_action,
            "Right": self._right_action,
            "I": self._clip_mark_start,
            "O": self._clip_mark_end,
            "Escape": self._clip_cancel_marker,
            "Delete": self._clip_delete,
            "Ctrl+1": self.show_clip_mode,
            "Ctrl+2": self.show_dualcam_mode,
            "Ctrl+O": self._open_video,
        }
        for sequence, callback in mapping.items():
            shortcut = QShortcut(QKeySequence(sequence), self)
            shortcut.setContext(Qt.ShortcutContext.WindowShortcut)
            shortcut.activated.connect(callback)
            self._shortcuts.append(shortcut)

    def current_mode(self) -> int:
        return self.pages.currentIndex()

    def show_clip_mode(self, checked: bool = False, *, initial: bool = False) -> None:
        del checked
        if not initial:
            self.dualcam.card_a.player.pause()
            self.dualcam.card_b.player.pause()
        self.pages.setCurrentIndex(self.MODE_CLIP)
        self.clip_button.setChecked(True)
        self.dualcam_button.setChecked(False)
        self.mode_label.setText("CLIP MODE")
        self.setWindowTitle(f"Picklary Lite v{APP_VERSION} · Clip Editor")
        QTimer.singleShot(0, self.clip._update_responsive_layout)

    def show_dualcam_mode(self, checked: bool = False) -> None:
        del checked
        self.clip.player.pause()
        try:
            shared_ffmpeg = self.clip.refresh_ffmpeg_status(start_probe=False)
            if shared_ffmpeg:
                os.environ["PICKLARY_FFMPEG"] = shared_ffmpeg
                ffmpeg_changed = self.dualcam.ffmpeg != shared_ffmpeg
                self.dualcam.ffmpeg = shared_ffmpeg
                if ffmpeg_changed or self.dualcam.acceleration is None:
                    self.dualcam.refresh_acceleration()
        except Exception:
            # The DualCam page can still ask the user to select FFmpeg itself.
            pass

        if self.clip.source_path and not self.dualcam.card_a.path:
            self.dualcam.card_a.load_file(self.clip.source_path)

        self.pages.setCurrentIndex(self.MODE_DUALCAM)
        self.clip_button.setChecked(False)
        self.dualcam_button.setChecked(True)
        self.mode_label.setText("DUALCAM MODE")
        self.setWindowTitle(f"Picklary Lite v{APP_VERSION} · DualCam Composer")
        self.dualcam.refresh_summary()

    def _load_dualcam_output_in_clip(self, output_path) -> None:
        path = Path(output_path).expanduser().resolve()
        if not path.is_file():
            QMessageBox.warning(self, "Check Composition Output", "The composed file could not be found for Clip Editor.")
            return
        self.clip.load_video(path)
        self.show_clip_mode()
        self.clip.player.setPosition(0)
        self.clip.statusBar().showMessage(
            "The DualCam output is now loaded in Clip Editor. Edit your cuts, then choose a save location when exporting."
        )

    def _space_action(self) -> None:
        if self.current_mode() == self.MODE_CLIP:
            self.clip.toggle_playback()
        else:
            self.dualcam.toggle_active_playback()

    def _left_action(self) -> None:
        if self.current_mode() == self.MODE_CLIP:
            self.clip.seek_relative(-3000)
        else:
            self.dualcam.step_active(-3.0)

    def _right_action(self) -> None:
        if self.current_mode() == self.MODE_CLIP:
            self.clip.seek_relative(3000)
        else:
            self.dualcam.step_active(3.0)

    def _clip_mark_start(self) -> None:
        if self.current_mode() == self.MODE_CLIP:
            self.clip.mark_start()

    def _clip_mark_end(self) -> None:
        if self.current_mode() == self.MODE_CLIP:
            self.clip.mark_end()

    def _clip_cancel_marker(self) -> None:
        if self.current_mode() == self.MODE_CLIP:
            self.clip.cancel_pending_start()

    def _clip_delete(self) -> None:
        if self.current_mode() == self.MODE_CLIP:
            self.clip.delete_selected()

    def _open_video(self) -> None:
        if self.current_mode() == self.MODE_CLIP:
            self.clip.choose_file()
        else:
            self.dualcam.card_a.choose_file()

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:
        if self.current_mode() == self.MODE_CLIP:
            latest = self.clip._latest_video_from_urls(event.mimeData().urls())
            if latest is not None:
                event.acceptProposedAction()
                return
        elif dropped_video_paths(event):
            event.acceptProposedAction()
            return
        event.ignore()

    def dropEvent(self, event: QDropEvent) -> None:
        if self.current_mode() == self.MODE_CLIP:
            latest = self.clip._latest_video_from_urls(event.mimeData().urls())
            if latest is None:
                event.ignore()
                return
            self.clip.load_video(latest)
            event.acceptProposedAction()
            return

        paths = dropped_video_paths(event)
        if not paths:
            event.ignore()
            return
        target = self.dualcam._card_under_cursor()
        if target is not None:
            target.load_dropped_files(paths)
            self.dualcam.set_active_card(target)
        else:
            self.dualcam._load_window_drop(paths)
        event.acceptProposedAction()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        if self.current_mode() == self.MODE_CLIP:
            QTimer.singleShot(0, self.clip._update_responsive_layout)

    def closeEvent(self, event: QCloseEvent) -> None:
        if self.clip.worker and self.clip.worker.isRunning():
            QMessageBox.information(self, "Export in Progress", "Please wait until the Clip export is complete before closing the application.")
            event.ignore()
            return
        if self.dualcam.sync_thread and self.dualcam.sync_thread.isRunning():
            answer = QMessageBox.question(self, "Audio Analysis in Progress", "Stop DualCam auto-sync analysis and exit?")
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            if self.dualcam.sync_worker:
                self.dualcam.sync_worker.cancelled = True
            self.dualcam.sync_thread.quit()
            self.dualcam.sync_thread.wait(4000)

        if self.dualcam.thread and self.dualcam.thread.isRunning():
            answer = QMessageBox.question(self, "Composition in Progress", "Stop DualCam composition and exit?")
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            if self.dualcam.worker:
                self.dualcam.worker.cancelled = True
            self.dualcam.thread.quit()
            self.dualcam.thread.wait(4000)

        if self.clip.hardware_probe and self.clip.hardware_probe.isRunning():
            self.clip.hardware_probe.wait(17000)
        self.clip.player.stop()
        self.dualcam.card_a.player.stop()
        self.dualcam.card_b.player.stop()
        event.accept()

    def fit_initial_window_to_screen(self) -> None:
        screen = self.screen() or QApplication.primaryScreen()
        if screen is None:
            self.show()
            return
        area = screen.availableGeometry().adjusted(8, 8, -8, -8)
        target_width = min(1500, max(1020, int(area.width() * 0.92)))
        target_height = min(area.height(), max(650, int(area.height() * 0.96)))
        x = area.x() + max(0, (area.width() - target_width) // 2)
        y = area.y() + max(0, (area.height() - target_height) // 2)
        self.setGeometry(x, y, target_width, target_height)
        self.show()
        QTimer.singleShot(0, self.clip._update_responsive_layout)


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("Picklary Lite")
    app.setOrganizationName("Picklary")
    window = UnifiedMainWindow()
    window.fit_initial_window_to_screen()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
