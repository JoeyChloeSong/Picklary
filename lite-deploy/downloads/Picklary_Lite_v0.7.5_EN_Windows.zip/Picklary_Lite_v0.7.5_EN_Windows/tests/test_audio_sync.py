import math
import random
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INTERNAL = ROOT / "picklary_internal"
if str(INTERNAL) not in sys.path:
    sys.path.insert(0, str(INTERNAL))

from dualcam.audio_sync import AudioSyncError, estimate_sync_from_features


def common_signal(seconds: float = 120.0, rate: int = 100) -> list[float]:
    random.seed(20260719)
    values: list[float] = []
    events = [
        (7.0, 2.5, 0.08), (12.5, 1.8, 0.18), (23.0, 3.0, 0.07),
        (41.0, 3.6, 0.08), (42.1, 2.1, 0.09), (65.0, 2.7, 0.13),
        (84.0, 2.2, 0.20), (102.0, 3.2, 0.08),
    ]
    for index in range(int(seconds * rate)):
        t = index / rate
        value = 0.04 * random.uniform(-1.0, 1.0)
        value += 0.25 * math.sin(2 * math.pi * 0.67 * t) if int(t) % 9 < 4 else 0.0
        for center, amplitude, width in events:
            value += amplitude * math.exp(-((t - center) / width) ** 2)
        values.append(value)
    return values


class AudioSyncTests(unittest.TestCase):
    def test_detects_when_a_started_earlier(self):
        rate = 100
        common = common_signal(rate=rate)
        random.seed(1)
        delay = 7.35
        a = [0.08 * random.uniform(-1, 1) for _ in range(round(delay * rate))] + common
        b = [value * 0.72 + 0.03 * random.uniform(-1, 1) for value in common]
        result = estimate_sync_from_features(a, b, rate=rate)
        self.assertAlmostEqual(result.start_a, delay, delta=0.04)
        self.assertAlmostEqual(result.start_b, 0.0, delta=0.02)
        self.assertEqual(result.confidence, "high")

    def test_detects_when_b_started_earlier(self):
        rate = 100
        common = common_signal(rate=rate)
        random.seed(2)
        delay = 4.20
        a = [value + 0.02 * random.uniform(-1, 1) for value in common]
        b = [0.07 * random.uniform(-1, 1) for _ in range(round(delay * rate))] + [
            value * 1.15 + 0.02 * random.uniform(-1, 1) for value in common
        ]
        result = estimate_sync_from_features(a, b, rate=rate)
        self.assertAlmostEqual(result.start_a, 0.0, delta=0.02)
        self.assertAlmostEqual(result.start_b, delay, delta=0.04)

    def test_rejects_silent_or_featureless_audio(self):
        with self.assertRaises(AudioSyncError):
            estimate_sync_from_features([0.0] * 5000, [0.0] * 5000, rate=100)


if __name__ == "__main__":
    unittest.main()
