import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INTERNAL = ROOT / "picklary_internal"
if str(INTERNAL) not in sys.path:
    sys.path.insert(0, str(INTERNAL))

import unittest

from clip_core import bytes_text, concat_escape, format_time, normalize_segment, safe_base_name


class ClipCoreTests(unittest.TestCase):
    def test_format_time(self):
        self.assertEqual(format_time(65_123), "01:05.123")
        self.assertEqual(format_time(3_665_123), "01:01:05.123")

    def test_segment(self):
        self.assertEqual(normalize_segment(2000, 1000, 5000), (1000, 2000))
        with self.assertRaises(ValueError):
            normalize_segment(1000, 1100, 5000)

    def test_names_and_sizes(self):
        self.assertEqual(safe_base_name("My Rally (1).mp4"), "My_Rally_1")
        self.assertEqual(bytes_text(1024 * 1024), "1.0 MB")

    def test_concat_path(self):
        value = concat_escape(Path("sample clip.mp4"))
        self.assertIn("sample clip.mp4", value)


if __name__ == "__main__":
    unittest.main()
