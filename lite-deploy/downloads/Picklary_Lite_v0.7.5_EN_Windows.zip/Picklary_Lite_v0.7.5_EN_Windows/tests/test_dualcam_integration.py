import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parents[1]
INTERNAL = ROOT / "picklary_internal"
if str(INTERNAL) not in sys.path:
    sys.path.insert(0, str(INTERNAL))

from dualcam.exporter import ExportRequest, build_command, create_output_path, layout_filename_label
from dualcam.ffmpeg import MediaInfo, _encoder_args
from dualcam.timecode import format_time, parse_time_text

SOURCE = (ROOT / "picklary_unified.py").read_text(encoding="utf-8")
DUAL_UI = (INTERNAL / "dualcam" / "ui.py").read_text(encoding="utf-8")


class DualCamIntegrationTests(unittest.TestCase):
    def test_dualcam_shortcuts_and_modes_remain(self):
        for token in [
            'QKeySequence("Space")', 'QKeySequence("Left")', 'QKeySequence("Right")',
            "toggle_active_playback", "step_active(-3.0)", "step_active(3.0)",
            'QRadioButton("Vertical")', 'QRadioButton("Horizontal · Default")',
            'QRadioButton("Create Both Vertical and Horizontal")',
            'QRadioButton("FHD · Quick Preview")', 'QRadioButton("4K · Default / Final")',
        ]:
            self.assertIn(token, DUAL_UI)

    def test_dualcam_defaults_to_horizontal_4k(self):
        for token in [
            'self.side_by_side.setChecked(True)',
            'self.uhd.setChecked(True)',
            'quality = "4k" if self.uhd.isChecked() else "fhd"',
            'return "side_by_side"',
        ]:
            self.assertIn(token, DUAL_UI)
        self.assertNotIn('self.top_bottom.setChecked(True)', DUAL_UI)
        self.assertNotIn('self.fhd.setChecked(True)', DUAL_UI)

    def test_shortcuts_are_limited_to_active_mode_window(self):
        self.assertIn("Qt.ShortcutContext.WindowShortcut", SOURCE)
        self.assertIn("if self.current_mode() == self.MODE_CLIP", SOURCE)
        self.assertIn("self._disable_internal_window_shortcuts()", SOURCE)
        self.assertNotIn("Qt.ShortcutContext.ApplicationShortcut", SOURCE)

    def test_dualcam_drag_drop_replaces_loaded_videos(self):
        for token in [
            "class DropVideoWidget(QWidget):",
            "self.setAcceptDrops(True)",
            "self.video_sink = QVideoSink(self)",
            "self.video_sink.videoFrameChanged.connect(self.video.set_video_frame)",
            "self.player.setVideoOutput(self.video_sink)",
            "self.video.clear_frame()",
            "self.scroll_area = QScrollArea(root)",
            "app.installEventFilter(self)",
            "QEvent.Type.DragEnter",
            "QEvent.Type.DragMove",
            "QEvent.Type.Drop",
            "self._card_for_object(watched) or self._card_under_cursor()",
            "card.load_dropped_files(paths)",
            "self.load_file(valid[-1])",
            "target.load_file(paths[-1])",
        ]:
            self.assertIn(token, DUAL_UI)

    def test_dualcam_active_card_and_seek_controls(self):
        for token in [
            'self.active_badge = QLabel("Active Video")',
            'self.setProperty("activeCard", active)',
            'self.minus_three = QPushButton("-3 sec")',
            'self.minus_one = QPushButton("-1 sec")',
            'self.plus_one = QPushButton("+1 sec")',
            'self.plus_three = QPushButton("+3 sec")',
            'self.space_shortcut.activated.connect(self.toggle_active_playback)',
            'self.left_shortcut.activated.connect(lambda: self.step_active(-3.0))',
            'self.right_shortcut.activated.connect(lambda: self.step_active(3.0))',
        ]:
            self.assertIn(token, DUAL_UI)

    def test_dualcam_result_can_move_to_clip_editor(self):
        for token in [
            'clip_edit_requested = Signal(object)',
            'self.open_result_folder_button = QPushButton("Open Output Folder")',
            'self.edit_result_in_clip_button = QPushButton("Open in Clip Editor")',
            'self.clip_edit_requested.emit(output)',
            'clip_button = box.addButton("Open in Clip Editor"',
        ]:
            self.assertIn(token, DUAL_UI)


    def test_sound_auto_alignment_and_manual_fallback(self):
        for token in [
            'from .audio_sync import AudioSyncResult, analyze_audio_sync',
            'self.auto_sync_button = QPushButton("Find Start Points from Audio")',
            'self.apply_sync_button = QPushButton("Apply Auto-Sync Result")',
            'self.manual_sync_button = QPushButton("Use Manual Start Points")',
            'self.card_a.apply_start_seconds(result.start_a)',
            'self.card_b.apply_start_seconds(result.start_b)',
            "Find the same moment in each video and click 'Use Current Position'",
        ]:
            self.assertIn(token, DUAL_UI)
        self.assertTrue((INTERNAL / "dualcam" / "audio_sync.py").is_file())

    def test_dualcam_labels_use_output_positions(self):
        self.assertIn('VideoCard("A · Video 1 (Left/Top in Output)"', DUAL_UI)
        self.assertIn('VideoCard("B · Video 2 (Right/Bottom in Output)"', DUAL_UI)
        self.assertNotIn("Rear Fixed Camera", DUAL_UI)
        self.assertNotIn("POV / Glasses Camera", DUAL_UI)

    def test_dualcam_preview_avoids_native_overlay(self):
        self.assertNotIn("from PySide6.QtMultimediaWidgets import QVideoWidget", DUAL_UI)
        self.assertIn("QSizePolicy.Policy.Ignored", DUAL_UI)
        self.assertIn("QScrollArea", DUAL_UI)

    def test_dualcam_command_builds_both_layouts(self):
        with TemporaryDirectory() as folder:
            root = Path(folder)
            a = root / "a.mp4"; a.write_bytes(b"a")
            b = root / "b.mp4"; b.write_bytes(b"b")
            info = MediaInfo(30.0, 1920, 1080, 30.0, True)
            top = ExportRequest(a, b, 1.0, 2.0, "top_bottom", "fhd", root / "top.mp4")
            command, duration = build_command(
                "ffmpeg", top, info, info,
                encoder="libx264", encoder_args=["-c:v", "libx264"], hardware_decode=False,
            )
            graph = command[command.index("-filter_complex") + 1]
            self.assertIn("vstack=inputs=2", graph)
            self.assertIn("scale=1920:540", graph)
            self.assertEqual(duration, 28.0)
            side = ExportRequest(a, b, 0.0, 0.0, "side_by_side", "4k", root / "side.mp4")
            command, _ = build_command(
                "ffmpeg", side, info, info,
                encoder="libx264", encoder_args=["-c:v", "libx264"], hardware_decode=False,
            )
            graph = command[command.index("-filter_complex") + 1]
            self.assertIn("hstack=inputs=2", graph)
            self.assertIn("scale=1920:2160", graph)

    def test_dualcam_timecode_output_and_nvenc_options(self):
        self.assertEqual(parse_time_text("01:30.500"), 90.5)
        self.assertEqual(format_time(90.5), "01:30.500")
        args = _encoder_args("h264_nvenc")
        self.assertEqual(args[:2], ["-c:v", "h264_nvenc"])
        self.assertIn("p1", args)

    def test_output_names_preserve_existing_results(self):
        with TemporaryDirectory() as folder:
            root = Path(folder)
            first, _ = create_output_path(root, "top_bottom", "fhd")
            first.write_bytes(b"keep")
            self.assertEqual(first.read_bytes(), b"keep")

    def test_output_names_use_vertical_and_horizontal(self):
        self.assertEqual(layout_filename_label("top_bottom"), "Vertical")
        self.assertEqual(layout_filename_label("side_by_side"), "Horizontal")
        with TemporaryDirectory() as folder:
            root = Path(folder)
            vertical, _ = create_output_path(root, "top_bottom", "fhd")
            horizontal, _ = create_output_path(root, "side_by_side", "4k")
            both, _ = create_output_path(root, "both", "fhd")
            self.assertIn("Vertical", vertical.name)
            self.assertIn("Horizontal", horizontal.name)
            self.assertIn("Both", both.name)


if __name__ == "__main__":
    unittest.main()
