import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INTERNAL = ROOT / "picklary_internal"
if str(INTERNAL) not in sys.path:
    sys.path.insert(0, str(INTERNAL))

import unittest

from gpu_core import EncoderDecision, GpuInfo, build_export_attempts, decision_label


class GpuCoreTests(unittest.TestCase):
    def setUp(self):
        self.gpu = GpuInfo(("NVIDIA GeForce RTX 4070 Ti SUPER",), "999.1", True)

    def test_nvenc_attempt_order_and_cpu_fallback(self):
        decision = EncoderDecision(
            ffmpeg_path="ffmpeg",
            encoder="h264_nvenc",
            mode="NVIDIA GPU",
            gpu=self.gpu,
            supported_encoders=("h264_nvenc", "libx264"),
            nvenc_test_ok=True,
            reason="ok",
        )
        attempts = build_export_attempts(decision, "input.mp4", 3.0, 5.0, "output.mp4")
        self.assertEqual([a.name for a in attempts], [
            "CUDA decoding + NVENC encoding",
            "Standard decoding + NVENC encoding",
            "CPU Safe Mode",
        ])
        self.assertIn("-hwaccel", attempts[0].command)
        self.assertIn("h264_nvenc", attempts[0].command)
        self.assertNotIn("-hwaccel", attempts[1].command)
        self.assertIn("h264_nvenc", attempts[1].command)
        self.assertIn("libx264", attempts[2].command)

    def test_cpu_only_decision(self):
        decision = EncoderDecision(
            ffmpeg_path="ffmpeg",
            encoder="libx264",
            mode="CPU",
            gpu=GpuInfo((), "Check failed", False),
            supported_encoders=("libx264",),
            nvenc_test_ok=False,
            reason="no nvenc",
        )
        attempts = build_export_attempts(decision, "input.mp4", 0.0, 1.0, "output.mp4")
        self.assertEqual(len(attempts), 1)
        self.assertEqual(attempts[0].hardware_label, "CPU · libx264")
        self.assertIn("libx264", attempts[0].command)

    def test_decision_label_names_gpu(self):
        decision = EncoderDecision(
            ffmpeg_path="ffmpeg",
            encoder="h264_nvenc",
            mode="NVIDIA GPU",
            gpu=self.gpu,
            supported_encoders=("h264_nvenc",),
            nvenc_test_ok=True,
            reason="ok",
        )
        label = decision_label(decision)
        self.assertIn("RTX 4070 Ti SUPER", label)
        self.assertIn("NVENC", label)


if __name__ == "__main__":
    unittest.main()
