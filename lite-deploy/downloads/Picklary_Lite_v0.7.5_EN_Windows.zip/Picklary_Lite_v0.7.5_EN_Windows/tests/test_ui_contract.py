import ast
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "picklary_internal" / "clip_mode.py").read_text(encoding="utf-8")
GPU_SOURCE = (ROOT / "picklary_internal" / "gpu_core.py").read_text(encoding="utf-8")


class UiContractTests(unittest.TestCase):
    def test_visual_tokens(self):
        for token in ["SegmentTimeline", "#64e3bb", "#6ea8ff", "#2b79ff"]:
            self.assertIn(token, SOURCE)

    def test_seek_controls_and_arrow_shortcuts(self):
        for token in [
            "back_5_button", "back_3_button", "back_1_button",
            "forward_1_button", "forward_3_button", "forward_5_button",
            '("Left", lambda: self.seek_relative(-3000))',
            '("Right", lambda: self.seek_relative(3000))',
        ]:
            self.assertIn(token, SOURCE)

    def test_escape_cancels_temporary_rally_marker(self):
        for token in [
            '("Escape", self.cancel_pending_start)',
            'def cancel_pending_start(self) -> None:',
            'self.pending_start_ms = None',
            'self.pending_end_ms = None',
            'The temporary I/O marker was canceled',
            'Playback position and saved cuts are preserved',
            'QApplication.activeModalWidget()',
        ]:
            self.assertIn(token, SOURCE)

        tree = ast.parse(SOURCE)
        method = next(
            node
            for class_node in tree.body
            if isinstance(class_node, ast.ClassDef) and class_node.name == 'MainWindow'
            for node in class_node.body
            if isinstance(node, ast.FunctionDef) and node.name == 'cancel_pending_start'
        )
        method_source = ast.get_source_segment(SOURCE, method) or ''
        for forbidden in [
            'self.player.setPosition',
            'self.segments.clear',
            'self.refresh_segments',
            'self.clip_list',
        ]:
            self.assertNotIn(forbidden, method_source)

    def test_seek_labels_include_seconds(self):
        for token in [
            'QPushButton("−5s")', 'QPushButton("−3s")', 'QPushButton("−1s")',
            'QPushButton("+1s")', 'QPushButton("+3s")', 'QPushButton("+5s")',
        ]:
            self.assertIn(token, SOURCE)

    def test_hero_copy_removed_and_video_is_65_percent_responsive(self):
        self.assertNotIn("Trim Video,", SOURCE)
        self.assertNotIn("It could not be easier", SOURCE)
        self.assertNotIn("Play and press only Rally In and Rally Out", SOURCE)
        self.assertIn("viewport_height * 0.65", SOURCE)
        self.assertIn("self.stage.setFixedHeight(video_height)", SOURCE)
        self.assertIn("def resizeEvent", SOURCE)
        self.assertIn("def showEvent", SOURCE)

    def test_timeline_and_mark_buttons_share_horizontal_row(self):
        self.assertIn("timeline_layout = QHBoxLayout(timeline_card)", SOURCE)
        self.assertIn("timeline_layout.addLayout(timeline_main, 1)", SOURCE)
        self.assertIn("timeline_layout.addLayout(mark_column)", SOURCE)
        self.assertIn("self.start_button.setFixedWidth(172)", SOURCE)
        self.assertIn("self.end_button.setFixedWidth(172)", SOURCE)

    def test_manual_time_entry_is_one_line(self):
        self.assertIn("manual_layout = QHBoxLayout(manual_card)", SOURCE)
        for token in [
            "manual_start_min", "manual_start_sec", "manual_end_min", "manual_end_sec",
            "manual_add_button", "add_manual_segment", "QDoubleSpinBox", "QSpinBox",
        ]:
            self.assertIn(token, SOURCE)
        self.assertNotIn("If you know the points, without playing the video", SOURCE)

    def test_clip_list_shows_five_rows_with_scroll(self):
        self.assertIn("self.clip_list.setFixedHeight(174)", SOURCE)
        self.assertIn("Up to five cuts", SOURCE)
        self.assertIn("ScrollBarAsNeeded", SOURCE)
        self.assertIn("ScrollBarAlwaysOff", SOURCE)

    def test_delete_removes_only_selected_row_and_keeps_position(self):
        for token in [
            "self.clip_list.takeItem(row)",
            "old_scroll = scroll_bar.value()",
            "self.clip_list.setCurrentRow(min(row, len(self.segments) - 1))",
            "scroll_bar.setValue(min(value, scroll_bar.maximum()))",
        ]:
            self.assertIn(token, SOURCE)

    def test_value_cards_start_below_first_viewport(self):
        for token in [
            "self.below_fold_anchor",
            "shell_floor = max(560, viewport_height - 62)",
            "self.editor_shell.setMinimumHeight(shell_floor)",
        ]:
            self.assertIn(token, SOURCE)

    def test_hardware_badge_and_nvenc_fallback(self):
        for token in [
            "HardwareBadge", "HardwareProbeWorker", "hardware_changed",
            "choose_encoder", "build_export_attempts", "GPU · NVIDIA NVENC", "CPU · libx264",
        ]:
            self.assertIn(token, SOURCE + GPU_SOURCE)

    def test_export_asks_for_folder(self):
        self.assertIn("QFileDialog.getExistingDirectory", SOURCE)
        self.assertIn("Select Save Folder", SOURCE)
        self.assertIn("if not output:", SOURCE)

    def test_mode_cards_match_export_choices(self):
        for token in [
            '("Single Video", "Join selected cuts in order", "merged")',
            '("Separate Videos", "Save each cut as a separate MP4", "separate")',
            '("Both", "Save both the joined video and separate clips", "both")',
            "selected_output_mode",
        ]:
            self.assertIn(token, SOURCE)

    def test_window_fit_and_volume_controls_remain(self):
        for token in [
            "fit_initial_window_to_screen", "availableGeometry()", "frameGeometry()",
            "VolumeButton", "VolumeSlider", "toggle_mute", "set_volume", "audio.setVolume",
        ]:
            self.assertIn(token, SOURCE)

    def test_out_can_be_marked_before_in(self):
        main_window_class = next(
            node for node in ast.parse(SOURCE).body
            if isinstance(node, ast.ClassDef) and node.name == "MainWindow"
        )
        init_method = next(
            node for node in main_window_class.body
            if isinstance(node, ast.FunctionDef) and node.name == "__init__"
        )
        init_source = ast.get_source_segment(SOURCE, init_method) or ""
        self.assertIn("self.pending_end_ms: int | None = None", init_source)
        for token in [
            'self.pending_end_ms: int | None = None',
            'self.pending_end_ms = current_ms',
            'move to the start position and press I',
            'if self.pending_end_ms is not None:',
            'segment = self._append_segment(current_ms, self.pending_end_ms)',
            'Saved one cut from I to the preset O point',
        ]:
            self.assertIn(token, SOURCE)

    def test_new_dragged_video_replaces_current_source(self):
        for token in [
            'def _configure_clip_drop_targets(self) -> None:',
            'def _latest_video_from_urls(urls) -> Path | None:',
            'for url in reversed(urls):',
            'self.load_video(latest)',
            'The source was replaced with the most recently dropped video',
        ]:
            self.assertIn(token, SOURCE)


if __name__ == "__main__":
    unittest.main()
