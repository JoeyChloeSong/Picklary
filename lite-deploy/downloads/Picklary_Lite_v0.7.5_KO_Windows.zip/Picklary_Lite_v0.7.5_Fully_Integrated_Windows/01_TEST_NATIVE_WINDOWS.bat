@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Picklary Lite v0.7.5 Diagnostics

echo === Picklary Lite v0.7.5 Fully Integrated Diagnostics ===
echo Folder: %CD%
echo.
where py
where python
echo.
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" --version
  ".venv\Scripts\python.exe" -c "import PySide6; print('PySide6', PySide6.__version__)"
  ".venv\Scripts\python.exe" -m compileall -q "picklary_unified.py" "picklary_internal"
  ".venv\Scripts\python.exe" -m unittest discover -s tests -v
) else (
  echo Private environment not found. Run 00_RUN_PICKLARY_LITE_WINDOWS.bat first.
)
echo.
pause
