@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run 00_RUN_PICKLARY_LITE_WINDOWS.bat once first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pip install pyinstaller
".venv\Scripts\pyinstaller.exe" --noconfirm --clean --windowed ^
  --paths "picklary_internal" ^
  --collect-submodules dualcam ^
  --name PicklaryLite_v0_7_2 picklary_unified.py
pause
