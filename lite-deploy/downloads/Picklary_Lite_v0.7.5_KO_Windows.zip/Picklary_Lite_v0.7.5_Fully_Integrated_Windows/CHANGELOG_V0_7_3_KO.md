# Picklary Lite v0.7.3 변경 사항

- Clip 편집 영상이 하단 한 줄로만 표시되는 Windows 렌더링 문제 수정
- 네이티브 QVideoWidget 대신 QVideoSink 기반 호환 영상 캔버스 적용
- 통합 창·스크롤·고해상도 DPI 환경에서 영상 영역 전체 렌더링
- 영상 회전/반전 메타데이터 처리
- 새 영상 불러오기 시 이전 화면 프레임 즉시 초기화
- 기존 DualCam, CUTS, 드래그앤드롭, NVENC 추출 기능 유지
