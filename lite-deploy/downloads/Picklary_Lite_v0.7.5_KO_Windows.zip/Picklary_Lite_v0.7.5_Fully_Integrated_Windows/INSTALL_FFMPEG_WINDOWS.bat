﻿@echo off
setlocal
chcp 65001 >nul
title Picklary FFmpeg 설치 도우미
echo ======================================================
echo Picklary Lite - FFmpeg 설치 도우미
echo ======================================================
echo.
echo FFmpeg는 영상 재생에는 필요하지 않습니다.
echo 선택한 구간을 MP4 파일로 추출할 때만 필요합니다.
echo.

where ffmpeg >nul 2>nul
if %errorlevel%==0 (
  echo [완료] FFmpeg가 이미 설치되어 있습니다.
  ffmpeg -version | findstr /b "ffmpeg version"
  pause
  exit /b 0
)

where winget >nul 2>nul
if errorlevel 1 goto :manual

echo Microsoft WinGet으로 FFmpeg Essentials를 설치합니다.
echo 설치 중 동의 문구 또는 진행 화면이 나타날 수 있습니다.
echo.
winget install --id Gyan.FFmpeg.Essentials -e --source winget --accept-source-agreements --accept-package-agreements
if errorlevel 1 goto :manual

echo.
echo [설치 완료] 프로그램을 다시 실행하거나 "설치 확인" 버튼을 누르세요.
pause
exit /b 0

:manual
echo.
echo 자동 설치를 진행할 수 없어 FFmpeg 공식 다운로드 페이지를 엽니다.
start "" "https://ffmpeg.org/download.html#build-windows"
echo.
echo 자세한 방법은 FFMPEG_SETUP_GUIDE_KO.html을 확인해 주세요.
pause
exit /b 1
