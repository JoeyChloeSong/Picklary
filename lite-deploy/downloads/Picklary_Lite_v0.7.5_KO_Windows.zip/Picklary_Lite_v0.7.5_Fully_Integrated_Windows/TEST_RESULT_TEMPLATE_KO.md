# Picklary Lite v0.7.5 테스트 결과

- Windows 버전:
- GPU:
- A/B 영상 형식:
- 조작부 가림 여부:
- 기타 결과:
