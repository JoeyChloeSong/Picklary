# Picklary Clip Lite v0.6.0 + DualCam Integrated

- Clip Lite v0.5.15를 기본 프로그램으로 유지했습니다.
- DualCam Lite 1.0.3 RC의 소스 모듈을 동일 패키지에 통합했습니다.
- 영상 선택 버튼 아래에 `영상 합치기 · DualCam 모드` 버튼을 추가했습니다.
- 별도 배치 파일이나 별도 가상환경 없이 DualCam 모드를 실행합니다.
- 현재 Clip Lite 원본 영상이 있으면 DualCam A 영상으로 자동 전달합니다.
- DualCam 창을 닫아도 Clip Lite 편집 상태와 CUTS 목록은 유지됩니다.
- 두 모드의 NVIDIA GPU 우선 처리 및 CPU fallback을 모두 유지했습니다.
