from __future__ import annotations

import math
import os
import subprocess
import sys
import tempfile
from array import array
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable

Progress = Callable[[int, str], None]
Cancelled = Callable[[], bool]


@dataclass(frozen=True, slots=True)
class AudioSyncResult:
    start_a: float
    start_b: float
    offset_seconds: float
    correlation: float
    confidence: str
    support: int
    agreement_seconds: float
    analyzed_seconds: float
    detail: str

    @property
    def confidence_ko(self) -> str:
        return {"high": "높음", "medium": "보통", "low": "낮음"}.get(self.confidence, self.confidence)


@dataclass(frozen=True, slots=True)
class _Candidate:
    delta: float  # t_B - t_A for the same physical sound event.
    correlation: float
    ref_side: str
    ref_start: float
    target_start: float


class AudioSyncError(RuntimeError):
    pass


def _creationflags() -> int:
    return subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def _extract_pcm(
    ffmpeg: str,
    source: Path,
    max_seconds: float,
    *,
    sample_rate: int = 8000,
    cancelled: Cancelled | None = None,
) -> bytes:
    if cancelled and cancelled():
        raise AudioSyncError("사용자가 사운드 분석을 취소했습니다.")
    with tempfile.TemporaryDirectory(prefix="picklary_audio_sync_") as folder:
        raw_path = Path(folder) / "audio.raw"
        command = [
            ffmpeg,
            "-hide_banner",
            "-loglevel",
            "error",
            "-nostdin",
            "-y",
            "-t",
            f"{max_seconds:.3f}",
            "-i",
            str(source.resolve()),
            "-vn",
            "-sn",
            "-dn",
            "-ac",
            "1",
            "-ar",
            str(sample_rate),
            "-c:a",
            "pcm_s16le",
            "-f",
            "s16le",
            str(raw_path),
        ]
        process = subprocess.Popen(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=_creationflags(),
        )
        while process.poll() is None:
            if cancelled and cancelled():
                process.terminate()
                try:
                    process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    process.kill()
                raise AudioSyncError("사용자가 사운드 분석을 취소했습니다.")
            try:
                process.wait(timeout=0.15)
            except subprocess.TimeoutExpired:
                pass
        stderr = process.stderr.read() if process.stderr else ""
        if process.returncode != 0:
            raise AudioSyncError(stderr.strip() or f"{source.name}의 오디오를 읽지 못했습니다.")
        if not raw_path.is_file() or raw_path.stat().st_size < sample_rate:
            raise AudioSyncError(f"{source.name}에서 분석 가능한 오디오를 찾지 못했습니다.")
        return raw_path.read_bytes()


def _robust_normalize(values: list[float]) -> list[float]:
    if not values:
        return []
    ordered = sorted(values)
    mid = len(ordered) // 2
    median = ordered[mid] if len(ordered) % 2 else (ordered[mid - 1] + ordered[mid]) / 2
    deviations = sorted(abs(value - median) for value in values)
    mad = deviations[mid] if len(deviations) % 2 else (deviations[mid - 1] + deviations[mid]) / 2
    scale = max(mad * 1.4826, 1e-4)
    return [max(-6.0, min(6.0, (value - median) / scale)) for value in values]


def pcm_to_feature(pcm: bytes, *, sample_rate: int = 8000, frame_hz: int = 100) -> list[float]:
    samples = array("h")
    samples.frombytes(pcm[: len(pcm) - (len(pcm) % 2)])
    if sys.byteorder != "little":
        samples.byteswap()
    frame_size = max(1, sample_rate // frame_hz)
    energies: list[float] = []
    for start in range(0, len(samples) - frame_size + 1, frame_size):
        total = 0.0
        for value in samples[start : start + frame_size]:
            total += abs(value)
        energies.append(math.log1p(total / frame_size))
    if len(energies) < frame_hz * 8:
        raise AudioSyncError("공통 소리를 찾기에는 오디오 구간이 너무 짧습니다.")

    # Remove slow microphone gain changes, then emphasize attacks and impacts.
    baseline = energies[0]
    previous = energies[0]
    shaped: list[float] = []
    alpha = 1.0 / max(10.0, frame_hz * 0.8)
    for energy in energies:
        baseline += alpha * (energy - baseline)
        high_pass = energy - baseline
        onset = max(0.0, energy - previous)
        shaped.append(high_pass + 1.8 * onset)
        previous = energy
    return _robust_normalize(shaped)


def _downsample(values: list[float], factor: int) -> list[float]:
    if factor <= 1:
        return list(values)
    result: list[float] = []
    for start in range(0, len(values) - factor + 1, factor):
        block = values[start : start + factor]
        result.append(sum(block) / len(block))
    return result


def _prefix(values: list[float]) -> tuple[list[float], list[float]]:
    sums = [0.0]
    squares = [0.0]
    for value in values:
        sums.append(sums[-1] + value)
        squares.append(squares[-1] + value * value)
    return sums, squares


def _window_variance(sums: list[float], squares: list[float], start: int, length: int) -> float:
    total = sums[start + length] - sums[start]
    total_sq = squares[start + length] - squares[start]
    return max(0.0, total_sq - total * total / max(length, 1))


def _reference_starts(values: list[float], rate: int, window_seconds: float, count: int = 4) -> list[int]:
    length = int(window_seconds * rate)
    if len(values) < length + rate:
        return []
    sums, squares = _prefix(values)
    last = min(len(values) - length, int(150 * rate))
    first = min(int(2 * rate), max(0, last))
    stride = max(1, int(4 * rate))
    ranked = [
        (_window_variance(sums, squares, start, length), start)
        for start in range(first, last + 1, stride)
    ]
    ranked.sort(reverse=True)
    selected: list[int] = []
    min_gap = int(window_seconds * rate * 0.55)
    for variance, start in ranked:
        if variance < length * 0.025:
            continue
        if all(abs(start - previous) >= min_gap for previous in selected):
            selected.append(start)
            if len(selected) >= count:
                break
    return selected


def _normalized_reference(values: list[float]) -> tuple[list[float], float]:
    mean = sum(values) / len(values)
    centered = [value - mean for value in values]
    norm = math.sqrt(sum(value * value for value in centered))
    if norm < 1e-8:
        return [], 0.0
    return [value / norm for value in centered], norm


def _best_positions(
    reference: list[float],
    target: list[float],
    *,
    step: int,
    top_n: int = 2,
    search_start: int = 0,
    search_end: int | None = None,
    exclusion: int = 0,
) -> list[tuple[float, int]]:
    length = len(reference)
    if length == 0 or len(target) < length:
        return []
    ref_norm, _ = _normalized_reference(reference)
    if not ref_norm:
        return []
    sums, squares = _prefix(target)
    maximum = len(target) - length
    begin = max(0, search_start)
    end = min(maximum, maximum if search_end is None else search_end)
    if end < begin:
        return []
    scored: list[tuple[float, int]] = []
    for position in range(begin, end + 1, max(1, step)):
        variance = _window_variance(sums, squares, position, length)
        if variance < length * 0.01:
            continue
        dot = 0.0
        segment = target[position : position + length]
        for ref_value, target_value in zip(ref_norm, segment):
            dot += ref_value * target_value
        correlation = dot / math.sqrt(variance)
        scored.append((correlation, position))
    scored.sort(reverse=True)
    selected: list[tuple[float, int]] = []
    for correlation, position in scored:
        if all(abs(position - prior) > exclusion for _score, prior in selected):
            selected.append((correlation, position))
            if len(selected) >= top_n:
                break
    return selected


def _cluster_candidates(candidates: list[_Candidate], tolerance: float = 0.45) -> list[dict]:
    clusters: list[dict] = []
    for candidate in sorted(candidates, key=lambda item: item.correlation, reverse=True):
        weight = max(0.01, candidate.correlation) ** 2
        chosen = None
        for cluster in clusters:
            if abs(candidate.delta - cluster["center"]) <= tolerance:
                chosen = cluster
                break
        if chosen is None:
            chosen = {"center": candidate.delta, "weight": 0.0, "items": []}
            clusters.append(chosen)
        chosen["items"].append(candidate)
        chosen["weight"] += weight
        chosen["center"] = sum(
            item.delta * max(0.01, item.correlation) ** 2 for item in chosen["items"]
        ) / chosen["weight"]
    clusters.sort(key=lambda item: item["weight"], reverse=True)
    return clusters


def _weighted_mean(values: Iterable[tuple[float, float]]) -> float:
    pairs = list(values)
    total = sum(weight for _value, weight in pairs)
    if total <= 0:
        return 0.0
    return sum(value * weight for value, weight in pairs) / total


def estimate_sync_from_features(
    feature_a: list[float],
    feature_b: list[float],
    *,
    rate: int = 100,
    window_seconds: float = 18.0,
) -> AudioSyncResult:
    if len(feature_a) < rate * 10 or len(feature_b) < rate * 10:
        raise AudioSyncError("공통 소리를 찾기에는 영상의 오디오가 너무 짧습니다.")
    coarse_factor = max(1, rate // 20)
    coarse_rate = rate // coarse_factor
    coarse_a = _downsample(feature_a, coarse_factor)
    coarse_b = _downsample(feature_b, coarse_factor)
    coarse_window = int(window_seconds * coarse_rate)
    starts_a = _reference_starts(coarse_a, coarse_rate, window_seconds)
    starts_b = _reference_starts(coarse_b, coarse_rate, window_seconds)
    if not starts_a and not starts_b:
        raise AudioSyncError("박수·타격음·말소리처럼 구분 가능한 소리 패턴을 찾지 못했습니다.")

    candidates: list[_Candidate] = []
    exclusion = int(1.5 * coarse_rate)
    for ref_side, reference_values, target_values, starts in (
        ("A", coarse_a, coarse_b, starts_a),
        ("B", coarse_b, coarse_a, starts_b),
    ):
        for start in starts:
            reference = reference_values[start : start + coarse_window]
            matches = _best_positions(
                reference,
                target_values,
                step=max(1, coarse_rate // 10),
                top_n=2,
                exclusion=exclusion,
            )
            for correlation, position in matches:
                if correlation < 0.08:
                    continue
                ref_time = start / coarse_rate
                target_time = position / coarse_rate
                delta = target_time - ref_time if ref_side == "A" else ref_time - target_time
                candidates.append(_Candidate(delta, correlation, ref_side, ref_time, target_time))
    if not candidates:
        raise AudioSyncError("두 영상에서 일치하는 사운드 구간을 찾지 못했습니다. 수동 시작점을 사용해 주세요.")

    clusters = _cluster_candidates(candidates)
    best_cluster = clusters[0]
    runner_weight = clusters[1]["weight"] if len(clusters) > 1 else 0.0
    coarse_items = best_cluster["items"][:4]

    fine_candidates: list[_Candidate] = []
    fine_window = int(window_seconds * rate)
    radius = int(0.8 * rate)
    for item in coarse_items:
        if item.ref_side == "A":
            ref_start = int(round(item.ref_start * rate))
            predicted = int(round(item.target_start * rate))
            reference_values, target_values = feature_a, feature_b
        else:
            ref_start = int(round(item.ref_start * rate))
            predicted = int(round(item.target_start * rate))
            reference_values, target_values = feature_b, feature_a
        reference = reference_values[ref_start : ref_start + fine_window]
        matches = _best_positions(
            reference,
            target_values,
            step=1,
            top_n=1,
            search_start=predicted - radius,
            search_end=predicted + radius,
        )
        if not matches:
            continue
        correlation, position = matches[0]
        ref_time = ref_start / rate
        target_time = position / rate
        delta = target_time - ref_time if item.ref_side == "A" else ref_time - target_time
        fine_candidates.append(_Candidate(delta, correlation, item.ref_side, ref_time, target_time))
    final_items = fine_candidates or coarse_items
    weights = [max(0.01, item.correlation) ** 2 for item in final_items]
    delta = _weighted_mean((item.delta, weight) for item, weight in zip(final_items, weights))
    correlation = _weighted_mean((item.correlation, weight) for item, weight in zip(final_items, weights))
    agreement = math.sqrt(
        _weighted_mean(((item.delta - delta) ** 2, weight) for item, weight in zip(final_items, weights))
    )
    support = len(final_items)
    margin = best_cluster["weight"] / max(runner_weight, 1e-6) if runner_weight else 99.0

    if correlation >= 0.62 and support >= 2 and agreement <= 0.18 and margin >= 1.15:
        confidence = "high"
    elif correlation >= 0.40 and support >= 2 and agreement <= 0.45:
        confidence = "medium"
    else:
        confidence = "low"

    # Avoid tiny offsets caused by decoder frame rounding.
    if abs(delta) < 0.025:
        delta = 0.0
    start_a = max(0.0, -delta)
    start_b = max(0.0, delta)
    analyzed_seconds = min(len(feature_a), len(feature_b)) / rate
    detail = (
        f"상관도 {correlation:.3f} · 기준 구간 {support}개 · "
        f"결과 편차 {agreement:.3f}초 · 후보 분리도 {margin:.2f}"
    )
    return AudioSyncResult(
        start_a=start_a,
        start_b=start_b,
        offset_seconds=delta,
        correlation=correlation,
        confidence=confidence,
        support=support,
        agreement_seconds=agreement,
        analyzed_seconds=analyzed_seconds,
        detail=detail,
    )


def analyze_audio_sync(
    ffmpeg: str,
    video_a: str | Path,
    video_b: str | Path,
    *,
    max_seconds: float = 600.0,
    progress: Progress | None = None,
    cancelled: Cancelled | None = None,
) -> AudioSyncResult:
    source_a = Path(video_a).expanduser().resolve()
    source_b = Path(video_b).expanduser().resolve()
    if not source_a.is_file() or not source_b.is_file():
        raise AudioSyncError("A와 B 영상 파일을 모두 불러와 주세요.")
    if source_a == source_b:
        raise AudioSyncError("서로 다른 두 영상이 필요합니다.")
    max_seconds = max(30.0, min(float(max_seconds), 1800.0))
    if progress:
        progress(5, "A 영상의 사운드를 읽는 중")
    pcm_a = _extract_pcm(ffmpeg, source_a, max_seconds + 25.0, cancelled=cancelled)
    if progress:
        progress(35, "B 영상의 사운드를 읽는 중")
    pcm_b = _extract_pcm(ffmpeg, source_b, max_seconds + 25.0, cancelled=cancelled)
    if cancelled and cancelled():
        raise AudioSyncError("사용자가 사운드 분석을 취소했습니다.")
    if progress:
        progress(65, "오디오 파형의 공통 구간을 비교하는 중")
    feature_a = pcm_to_feature(pcm_a)
    feature_b = pcm_to_feature(pcm_b)
    # Limit the actual matching arrays to the selected search range plus one reference window.
    limit = int((max_seconds + 20.0) * 100)
    result = estimate_sync_from_features(feature_a[:limit], feature_b[:limit])
    if progress:
        progress(100, "사운드 자동 정렬 분석 완료")
    return result
