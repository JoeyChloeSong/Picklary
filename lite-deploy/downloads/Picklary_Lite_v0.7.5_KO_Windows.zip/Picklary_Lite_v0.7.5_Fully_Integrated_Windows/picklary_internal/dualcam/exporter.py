from __future__ import annotations

import json
import os
import subprocess
from datetime import datetime
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Callable

from .ffmpeg import MediaInfo, acceleration_info, cpu_name, probe_media

Progress = Callable[[int, str], None]
Cancelled = Callable[[], bool]


@dataclass(frozen=True, slots=True)
class ExportRequest:
    video_a: Path
    video_b: Path
    start_a: float
    start_b: float
    layout: str
    quality: str
    output: Path

    def validate(self) -> None:
        if not self.video_a.is_file() or not self.video_b.is_file():
            raise ValueError("두 영상 파일을 모두 불러와 주세요.")
        if self.video_a.resolve() == self.video_b.resolve():
            raise ValueError("서로 다른 두 영상 파일을 선택해 주세요.")
        if self.start_a < 0 or self.start_b < 0:
            raise ValueError("시작 지점은 0초 이상이어야 합니다.")
        if self.layout not in {"top_bottom", "side_by_side", "both"}:
            raise ValueError("지원하지 않는 화면 배치입니다.")
        if self.quality not in {"fhd", "4k"}:
            raise ValueError("지원하지 않는 화질입니다.")


def layout_filename_label(layout: str) -> str:
    if layout == "top_bottom":
        return "Vertical"
    if layout == "side_by_side":
        return "Horizontal"
    if layout == "both":
        return "Both"
    raise ValueError("지원하지 않는 화면 배치입니다.")


def create_output_path(
    output_dir: Path,
    layout: str,
    quality: str,
    *,
    now: datetime | None = None,
) -> tuple[Path, str]:
    """Create a collision-free output path without deleting older exports.

    All files produced by one export share the same run id. When two exports
    begin in the same second, a numeric suffix is appended.
    """
    if layout not in {"top_bottom", "side_by_side", "both"}:
        raise ValueError("지원하지 않는 화면 배치입니다.")
    if quality not in {"fhd", "4k"}:
        raise ValueError("지원하지 않는 화질입니다.")
    output_dir = Path(output_dir).expanduser().resolve()
    stamp = (now or datetime.now()).strftime("%Y%m%d_%H%M%S")
    for index in range(1, 1000):
        run_id = stamp if index == 1 else f"{stamp}_{index:02d}"
        label = layout_filename_label(layout)
        placeholder = output_dir / f"dualcam_{label}_{quality}_{run_id}.mp4"
        if layout == "both":
            candidates = [
                output_dir / f"dualcam_Vertical_{quality}_{run_id}.mp4",
                output_dir / f"dualcam_Horizontal_{quality}_{run_id}.mp4",
                output_dir / f"dualcam_Both_{quality}_{run_id}_manifest.json",
            ]
        else:
            candidates = [
                placeholder,
                placeholder.with_suffix(".json"),
                placeholder.with_name(f"{placeholder.stem}_manifest.json"),
            ]
        if not any(path.exists() for path in candidates):
            return placeholder, run_id
    raise RuntimeError("같은 시각의 출력 파일이 너무 많아 새 파일명을 만들지 못했습니다.")


def _dimensions(quality: str) -> tuple[int, int]:
    return (3840, 2160) if quality == "4k" else (1920, 1080)


def _video_filter(input_index: int, label: str, panel_w: int, panel_h: int, trim_offset: float, duration: float) -> str:
    return (
        f"[{input_index}:v:0]trim=start={trim_offset:.6f}:duration={duration:.6f},"
        f"setpts=PTS-STARTPTS,scale={panel_w}:{panel_h}:force_original_aspect_ratio=decrease:flags=fast_bilinear,"
        f"pad={panel_w}:{panel_h}:(ow-iw)/2:(oh-ih)/2:color=0x06121e,fps=30,setsar=1[{label}]"
    )


def build_command(
    ffmpeg: str,
    request: ExportRequest,
    info_a: MediaInfo,
    info_b: MediaInfo,
    *,
    encoder: str,
    encoder_args: list[str],
    hardware_decode: bool,
) -> tuple[list[str], float]:
    request.validate()
    if request.layout == "both":
        raise ValueError("'both'는 개별 상하/좌우 렌더 요청으로 분리해야 합니다.")
    remaining_a = info_a.duration - request.start_a
    remaining_b = info_b.duration - request.start_b
    duration = min(remaining_a, remaining_b)
    if duration <= 0.1:
        raise ValueError("선택한 시작 지점 뒤에 합성할 영상이 없습니다.")

    width, height = _dimensions(request.quality)
    if request.layout == "top_bottom":
        panel_w, panel_h = width, height // 2
        stack = "vstack"
    else:
        panel_w, panel_h = width // 2, height
        stack = "hstack"

    seek_margin = 3.0
    input_start_a = max(0.0, request.start_a - seek_margin)
    input_start_b = max(0.0, request.start_b - seek_margin)
    trim_a = request.start_a - input_start_a
    trim_b = request.start_b - input_start_b
    read_a = duration + trim_a + 0.25
    read_b = duration + trim_b + 0.25

    command = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y"]
    if hardware_decode:
        command.extend(["-hwaccel", "auto"])
    command.extend(["-ss", f"{input_start_a:.6f}", "-t", f"{read_a:.6f}", "-i", str(request.video_a.resolve())])
    if hardware_decode:
        command.extend(["-hwaccel", "auto"])
    command.extend(["-ss", f"{input_start_b:.6f}", "-t", f"{read_b:.6f}", "-i", str(request.video_b.resolve())])

    filters = [
        _video_filter(0, "va", panel_w, panel_h, trim_a, duration),
        _video_filter(1, "vb", panel_w, panel_h, trim_b, duration),
        f"[va][vb]{stack}=inputs=2:shortest=1[vout]",
    ]
    audio_map: list[str] = []
    if info_a.has_audio:
        filters.append(
            f"[0:a:0]atrim=start={trim_a:.6f}:duration={duration:.6f},asetpts=PTS-STARTPTS,"
            "aresample=48000:async=1:first_pts=0,aformat=channel_layouts=stereo[aout]"
        )
        audio_map = ["-map", "[aout]"]
    elif info_b.has_audio:
        filters.append(
            f"[1:a:0]atrim=start={trim_b:.6f}:duration={duration:.6f},asetpts=PTS-STARTPTS,"
            "aresample=48000:async=1:first_pts=0,aformat=channel_layouts=stereo[aout]"
        )
        audio_map = ["-map", "[aout]"]

    command.extend([
        "-filter_complex", ";".join(filters),
        "-map", "[vout]", *audio_map,
        *encoder_args,
        "-pix_fmt", "yuv420p",
        "-max_muxing_queue_size", "4096",
    ])
    if audio_map:
        command.extend(["-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-ac", "2"])
    command.extend([
        "-t", f"{duration:.6f}", "-shortest", "-avoid_negative_ts", "make_zero",
        "-movflags", "+faststart", "-progress", "pipe:1", "-nostats", str(request.output.resolve()),
    ])
    return command, duration


def _run_progress(
    command: list[str],
    duration: float,
    progress: Progress | None,
    cancelled: Cancelled | None,
    *,
    progress_start: int = 0,
    progress_span: int = 100,
    stage_name: str = "",
) -> tuple[int, str]:
    creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        bufsize=1,
        creationflags=creationflags,
    )
    lines: list[str] = []
    assert process.stdout is not None
    for raw in process.stdout:
        line = raw.strip()
        if line:
            lines.append(line)
            if len(lines) > 300:
                lines.pop(0)
        if cancelled and cancelled():
            process.terminate()
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill()
            return 130, "사용자가 작업을 취소했습니다."
        if line.startswith("out_time_ms="):
            try:
                microseconds = int(line.split("=", 1)[1])
                local_pct = min(0.99, max(0.0, microseconds / 1_000_000 / max(duration, 0.1)))
                pct = int(progress_start + local_pct * progress_span)
                if progress:
                    prefix = f"{stage_name} · " if stage_name else ""
                    progress(pct, f"{prefix}빠른 합성 중 · {pct}%")
            except ValueError:
                pass
    return process.wait(), "\n".join(lines[-80:])


def _output_for_layout(request: ExportRequest, layout: str) -> Path:
    if request.layout != "both":
        return request.output
    label = layout_filename_label(layout)
    marker = f"dualcam_Both_{request.quality}_"
    stem = request.output.stem
    run_id = stem[len(marker):] if stem.startswith(marker) else stem
    return request.output.parent / f"dualcam_{label}_{request.quality}_{run_id}.mp4"


def _export_one(
    ffmpeg: str,
    request: ExportRequest,
    info_a: MediaInfo,
    info_b: MediaInfo,
    *,
    progress: Progress | None,
    cancelled: Cancelled | None,
    progress_start: int,
    progress_span: int,
    stage_name: str,
) -> dict:
    request.output.parent.mkdir(parents=True, exist_ok=True)
    if request.output.exists():
        raise FileExistsError(
            f"기존 출력 파일을 보호하기 위해 덮어쓰지 않았습니다: {request.output}"
        )

    acceleration = acceleration_info(ffmpeg)
    if acceleration.gpu:
        attempts = [
            (
                acceleration.encoder,
                list(acceleration.encoder_args),
                True,
                True,
                f"GPU · {acceleration.device_name} · 하드웨어 디코딩",
            ),
            (
                acceleration.encoder,
                list(acceleration.encoder_args),
                True,
                False,
                f"GPU · {acceleration.device_name} · 호환 디코딩",
            ),
            (
                "libx264",
                ["-c:v", "libx264", "-preset", "ultrafast", "-crf", "23", "-threads", "0"],
                False,
                False,
                f"CPU · {cpu_name()} · 안전 모드",
            ),
        ]
    else:
        attempts = [
            (
                "libx264",
                list(acceleration.encoder_args),
                False,
                True,
                f"CPU · {acceleration.device_name} · 자동 디코딩",
            ),
            (
                "libx264",
                list(acceleration.encoder_args),
                False,
                False,
                f"CPU · {acceleration.device_name} · 안전 모드",
            ),
        ]

    failures: list[str] = []
    for current_encoder, current_args, current_gpu, hw_decode, label in attempts:
        if cancelled and cancelled():
            raise RuntimeError("사용자가 작업을 취소했습니다.")
        request.output.unlink(missing_ok=True)
        command, duration = build_command(
            ffmpeg,
            request,
            info_a,
            info_b,
            encoder=current_encoder,
            encoder_args=current_args,
            hardware_decode=hw_decode,
        )
        if progress:
            progress(progress_start, f"{stage_name} · {label} 준비 중")
        code, detail = _run_progress(
            command,
            duration,
            progress,
            cancelled,
            progress_start=progress_start,
            progress_span=progress_span,
            stage_name=stage_name,
        )
        if code == 0 and request.output.is_file() and request.output.stat().st_size > 0:
            result = {
                "output": str(request.output),
                "duration": round(duration, 3),
                "layout": request.layout,
                "quality": request.quality,
                "encoder": current_encoder,
                "gpu_used": current_gpu,
                "device_name": acceleration.device_name if current_gpu else cpu_name(),
                "hardware_decode": hw_decode,
                "mode": label,
                "start_a": round(request.start_a, 3),
                "start_b": round(request.start_b, 3),
                "failures_before_success": failures,
            }
            request.output.with_suffix(".json").write_text(
                json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            return result
        request.output.unlink(missing_ok=True)
        failures.append(f"{label}: {detail[-1500:]}")

    raise RuntimeError("모든 빠른 렌더 경로가 실패했습니다.\n\n" + "\n\n".join(failures))


def export_dualcam(
    ffmpeg: str,
    request: ExportRequest,
    *,
    progress: Progress | None = None,
    cancelled: Cancelled | None = None,
) -> dict:
    request.validate()
    info_a = probe_media(request.video_a, ffmpeg)
    info_b = probe_media(request.video_b, ffmpeg)
    layouts = [request.layout] if request.layout != "both" else ["top_bottom", "side_by_side"]
    results: list[dict] = []
    span = 100 // len(layouts)

    for index, layout in enumerate(layouts):
        output = _output_for_layout(request, layout)
        single = replace(request, layout=layout, output=output)
        stage = "상하" if layout == "top_bottom" else "좌우"
        result = _export_one(
            ffmpeg,
            single,
            info_a,
            info_b,
            progress=progress,
            cancelled=cancelled,
            progress_start=index * span,
            progress_span=span,
            stage_name=f"{index + 1}/{len(layouts)} {stage}",
        )
        results.append(result)

    outputs = [item["output"] for item in results]
    summary = {
        "output": outputs[0],
        "outputs": outputs,
        "results": results,
        "duration": results[0]["duration"],
        "layout": request.layout,
        "quality": request.quality,
        "gpu_used": all(item["gpu_used"] for item in results),
        "encoder": results[0]["encoder"] if len({item["encoder"] for item in results}) == 1 else "mixed",
        "device_name": results[0]["device_name"] if len({item["device_name"] for item in results}) == 1 else "혼합 처리",
        "mode": results[0]["mode"] if len(results) == 1 else "상하·좌우 2개 생성",
        "start_a": round(request.start_a, 3),
        "start_b": round(request.start_b, 3),
    }
    manifest = request.output.with_name(f"{request.output.stem}_manifest.json")
    summary["manifest"] = str(manifest)
    manifest.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    if progress:
        progress(100, f"완료 · {summary['mode']}")
    return summary
