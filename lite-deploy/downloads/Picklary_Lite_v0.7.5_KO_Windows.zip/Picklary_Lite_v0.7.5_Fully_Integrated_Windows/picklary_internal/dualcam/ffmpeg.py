from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


@dataclass(frozen=True, slots=True)
class MediaInfo:
    duration: float
    width: int
    height: int
    fps: float
    has_audio: bool


@dataclass(frozen=True, slots=True)
class EncoderProbe:
    success: bool
    detail: str


@dataclass(frozen=True, slots=True)
class AccelerationInfo:
    encoder: str
    encoder_args: tuple[str, ...]
    gpu: bool
    device_name: str
    diagnostic: str = ""
    ffmpeg_path: str = ""
    driver_version: str = ""

    @property
    def short_label(self) -> str:
        kind = "GPU" if self.gpu else "CPU"
        return f"{kind} · {self.device_name} · {self.encoder}"


_ENCODER_ORDER = ("h264_nvenc", "h264_qsv", "h264_amf")


def _settings_path() -> Path:
    if os.name == "nt":
        root = Path(os.getenv("LOCALAPPDATA", str(Path.home()))) / "PicklaryDualCamLite"
    else:
        root = Path.home() / ".picklary_dualcam_lite"
    root.mkdir(parents=True, exist_ok=True)
    return root / "settings.json"


def _saved_tool(name: str) -> str:
    try:
        payload = json.loads(_settings_path().read_text(encoding="utf-8"))
        return str(payload.get(f"{name}_path") or "")
    except Exception:
        return ""


def save_tool(name: str, path: str | Path) -> str:
    resolved = Path(path).expanduser().resolve()
    if not resolved.is_file():
        raise FileNotFoundError(str(resolved))
    settings = _settings_path()
    try:
        payload = json.loads(settings.read_text(encoding="utf-8"))
    except Exception:
        payload = {}
    payload[f"{name}_path"] = str(resolved)
    settings.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    clear_acceleration_cache()
    return str(resolved)


def _common_windows_candidates(name: str) -> list[Path]:
    if os.name != "nt":
        return []
    exe = f"{name}.exe"
    home = Path.home()
    local = Path(os.getenv("LOCALAPPDATA", ""))
    program_files = Path(os.getenv("PROGRAMFILES", ""))
    program_files_x86 = Path(os.getenv("PROGRAMFILES(X86)", ""))
    candidates = [
        home / "scoop" / "apps" / "ffmpeg" / "current" / "bin" / exe,
        local / "Microsoft" / "WinGet" / "Links" / exe,
        Path("C:/ffmpeg/bin") / exe,
        program_files / "ffmpeg" / "bin" / exe,
        program_files / "FFmpeg" / "bin" / exe,
        program_files_x86 / "ffmpeg" / "bin" / exe,
    ]
    winget_packages = local / "Microsoft" / "WinGet" / "Packages"
    if winget_packages.is_dir():
        try:
            candidates.extend(winget_packages.glob(f"Gyan.FFmpeg*/*/bin/{exe}"))
            candidates.extend(winget_packages.glob(f"Gyan.FFmpeg*/**/bin/{exe}"))
        except OSError:
            pass
    return candidates


def _tool_candidates(name: str) -> list[str]:
    env_name = f"PICKLARY_{name.upper()}"
    raw = [os.getenv(env_name, ""), _saved_tool(name), shutil.which(name)]
    raw.extend(str(p) for p in _common_windows_candidates(name))
    found: list[str] = []
    seen: set[str] = set()
    for value in raw:
        if not value:
            continue
        path = Path(value).expanduser()
        try:
            if not path.is_file():
                continue
            resolved = str(path.resolve())
        except OSError:
            continue
        key = resolved.lower() if os.name == "nt" else resolved
        if key not in seen:
            seen.add(key)
            found.append(resolved)
    return found


def find_tool(name: str) -> str | None:
    candidates = _tool_candidates(name)
    if not candidates:
        return None
    if name.lower() != "ffmpeg" or os.getenv("PICKLARY_FFMPEG"):
        return candidates[0]

    # A previously saved CPU-only FFmpeg must not hide a newer NVENC-capable build.
    gpu_names = _windows_gpu_names()
    if any("nvidia" in item.lower() or "geforce" in item.lower() or "rtx" in item.lower() for item in gpu_names):
        for candidate in candidates:
            try:
                if "h264_nvenc" in available_encoders(candidate) and encoder_probe(candidate, "h264_nvenc").success:
                    return candidate
            except Exception:
                continue
    return candidates[0]


def ffprobe_for(ffmpeg: str) -> str | None:
    source = Path(ffmpeg)
    sibling = source.with_name("ffprobe.exe" if source.suffix.lower() == ".exe" else "ffprobe")
    if sibling.is_file():
        return str(sibling)
    return find_tool("ffprobe")


def probe_media(path: str | Path, ffmpeg: str) -> MediaInfo:
    source = Path(path).resolve()
    ffprobe = ffprobe_for(ffmpeg)
    if not ffprobe:
        raise RuntimeError("ffprobe를 찾을 수 없습니다. ffmpeg.exe와 같은 폴더에 ffprobe.exe가 필요합니다.")
    completed = subprocess.run(
        [ffprobe, "-v", "error", "-show_streams", "-show_format", "-of", "json", str(source)],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=30,
        check=False,
        creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
    )
    if completed.returncode != 0:
        raise RuntimeError(completed.stderr.strip() or "영상 정보를 읽지 못했습니다.")
    payload = json.loads(completed.stdout)
    streams = payload.get("streams", [])
    video = next((s for s in streams if s.get("codec_type") == "video"), None)
    if not video:
        raise RuntimeError("비디오 스트림이 없습니다.")
    duration = float(video.get("duration") or payload.get("format", {}).get("duration") or 0.0)
    rate = str(video.get("avg_frame_rate") or video.get("r_frame_rate") or "30/1")
    try:
        num, den = rate.split("/", 1)
        fps = float(num) / max(float(den), 1.0)
    except Exception:
        fps = 30.0
    return MediaInfo(
        duration=max(0.0, duration),
        width=int(video.get("width") or 0),
        height=int(video.get("height") or 0),
        fps=max(1.0, min(120.0, fps)),
        has_audio=any(s.get("codec_type") == "audio" for s in streams),
    )


@lru_cache(maxsize=16)
def available_encoders(ffmpeg: str) -> frozenset[str]:
    completed = subprocess.run(
        [ffmpeg, "-hide_banner", "-encoders"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=20,
        check=False,
        creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
    )
    text = f"{completed.stdout}\n{completed.stderr}"
    return frozenset(name for name in (*_ENCODER_ORDER, "libx264") if name in text)


def _encoder_args(name: str) -> list[str]:
    if name == "h264_nvenc":
        # Conservative options work across more FFmpeg/NVIDIA driver combinations.
        return ["-c:v", name, "-preset", "p1", "-rc", "constqp", "-qp", "24", "-bf", "0"]
    if name == "h264_qsv":
        return ["-c:v", name, "-preset", "veryfast", "-global_quality", "25", "-look_ahead", "0"]
    if name == "h264_amf":
        return ["-c:v", name, "-quality", "speed", "-rc", "cqp", "-qp_i", "24", "-qp_p", "24"]
    return ["-c:v", "libx264", "-preset", "ultrafast", "-crf", "23", "-threads", "0"]


def _compact_error(text: str, limit: int = 500) -> str:
    lines = [line.strip() for line in text.replace("\r", "\n").splitlines() if line.strip()]
    if not lines:
        return "알 수 없는 오류"
    useful = [line for line in lines if not line.lower().startswith("ffmpeg version")]
    joined = " | ".join(useful[-4:] or lines[-4:])
    return joined[-limit:]


@lru_cache(maxsize=32)
def encoder_probe(ffmpeg: str, encoder: str) -> EncoderProbe:
    if encoder == "libx264":
        return EncoderProbe(True, "CPU 인코더 사용 가능")
    try:
        with tempfile.TemporaryDirectory(prefix="picklary_gpu_test_") as folder:
            target = Path(folder) / "test.mp4"
            command = [
                ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
                "-f", "lavfi", "-i", "color=size=256x144:rate=30:color=black",
                "-frames:v", "6", "-an", "-c:v", encoder, "-pix_fmt", "yuv420p",
                str(target),
            ]
            completed = subprocess.run(
                command,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=30,
                check=False,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            if completed.returncode == 0 and target.is_file() and target.stat().st_size > 0:
                return EncoderProbe(True, "시험 인코딩 성공")
            return EncoderProbe(False, _compact_error(f"{completed.stdout}\n{completed.stderr}"))
    except Exception as exc:
        return EncoderProbe(False, str(exc))


def encoder_smoke_test(ffmpeg: str, encoder: str) -> bool:
    return encoder_probe(ffmpeg, encoder).success


@lru_cache(maxsize=16)
def select_encoder(ffmpeg: str) -> tuple[str, list[str], bool]:
    encoders = available_encoders(ffmpeg)
    for name in _ENCODER_ORDER:
        if name in encoders and encoder_probe(ffmpeg, name).success:
            return name, _encoder_args(name), True
    return "libx264", _encoder_args("libx264"), False


def _run_text(command: list[str], timeout: int = 10) -> str:
    creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            check=False,
            creationflags=creationflags,
        )
        return (completed.stdout or completed.stderr or "").strip()
    except Exception:
        return ""


@lru_cache(maxsize=4)
def _nvidia_smi_info() -> tuple[str, str]:
    if os.name != "nt":
        return "", ""
    nvidia_smi = shutil.which("nvidia-smi") or shutil.which("nvidia-smi.exe")
    if not nvidia_smi:
        system_path = Path(os.getenv("WINDIR", "C:/Windows")) / "System32" / "nvidia-smi.exe"
        if system_path.is_file():
            nvidia_smi = str(system_path)
    if not nvidia_smi:
        return "", ""
    text = _run_text([
        nvidia_smi,
        "--query-gpu=name,driver_version",
        "--format=csv,noheader",
    ])
    first = next((line.strip() for line in text.splitlines() if line.strip()), "")
    if not first:
        return "", ""
    parts = [part.strip() for part in first.split(",", 1)]
    return parts[0], parts[1] if len(parts) > 1 else ""


@lru_cache(maxsize=4)
def _windows_gpu_names() -> tuple[str, ...]:
    if os.name != "nt":
        return ()
    nvidia_name, _driver = _nvidia_smi_info()
    names: list[str] = [nvidia_name] if nvidia_name else []
    powershell = shutil.which("powershell") or shutil.which("powershell.exe")
    if powershell:
        text = _run_text([
            powershell, "-NoProfile", "-Command",
            "Get-CimInstance Win32_VideoController | ForEach-Object { $_.Name }",
        ])
        names.extend(line.strip() for line in text.splitlines() if line.strip())
    if not names:
        wmic = shutil.which("wmic") or shutil.which("wmic.exe")
        if wmic:
            text = _run_text([wmic, "path", "win32_VideoController", "get", "name"])
            names.extend(
                line.strip() for line in text.splitlines()
                if line.strip() and line.strip().lower() != "name"
            )
    unique: list[str] = []
    seen: set[str] = set()
    for name in names:
        key = name.lower()
        if key not in seen:
            seen.add(key)
            unique.append(name)
    return tuple(unique)


def _gpu_name_for_encoder(encoder: str) -> str:
    names = list(_windows_gpu_names())
    vendor_tokens = {
        "h264_nvenc": ("nvidia", "geforce", "quadro", "rtx", "gtx"),
        "h264_qsv": ("intel", "arc", "iris", "uhd"),
        "h264_amf": ("amd", "radeon"),
    }.get(encoder, ())
    for name in names:
        lowered = name.lower()
        if any(token in lowered for token in vendor_tokens):
            return name
    if names:
        non_basic = [name for name in names if "microsoft basic" not in name.lower()]
        if non_basic:
            return non_basic[0]
    fallback = {
        "h264_nvenc": "NVIDIA GPU",
        "h264_qsv": "Intel GPU",
        "h264_amf": "AMD GPU",
    }
    return fallback.get(encoder, "GPU")


def cpu_name() -> str:
    name = os.getenv("PROCESSOR_IDENTIFIER", "").strip() or platform.processor().strip()
    return name or "시스템 CPU"


def _ffmpeg_version(ffmpeg: str) -> str:
    text = _run_text([ffmpeg, "-hide_banner", "-version"], timeout=10)
    return next((line.strip() for line in text.splitlines() if line.strip()), "버전 확인 실패")


@lru_cache(maxsize=16)
def acceleration_info(ffmpeg: str) -> AccelerationInfo:
    encoders = available_encoders(ffmpeg)
    failures: list[str] = []
    for name in _ENCODER_ORDER:
        if name not in encoders:
            failures.append(f"{name}: 현재 FFmpeg 빌드에 없음")
            continue
        probe = encoder_probe(ffmpeg, name)
        if probe.success:
            device = _gpu_name_for_encoder(name)
            driver = _nvidia_smi_info()[1] if name == "h264_nvenc" else ""
            return AccelerationInfo(
                encoder=name,
                encoder_args=tuple(_encoder_args(name)),
                gpu=True,
                device_name=device,
                diagnostic=f"{name} 시험 인코딩 성공",
                ffmpeg_path=str(Path(ffmpeg).resolve()),
                driver_version=driver,
            )
        failures.append(f"{name}: 시험 인코딩 실패 - {probe.detail}")

    gpu_names = _windows_gpu_names()
    nvidia_present = any(
        token in name.lower()
        for name in gpu_names
        for token in ("nvidia", "geforce", "rtx", "gtx", "quadro")
    )
    if nvidia_present and "h264_nvenc" not in encoders:
        reason = "RTX/NVIDIA GPU는 감지됐지만 선택된 FFmpeg에 h264_nvenc가 포함되지 않았습니다."
    elif nvidia_present:
        nvenc_failure = next((item for item in failures if item.startswith("h264_nvenc:")), "")
        reason = nvenc_failure or "NVENC 시험 인코딩에 실패했습니다. NVIDIA 드라이버와 FFmpeg를 확인하세요."
    elif gpu_names:
        reason = "감지된 GPU에서 사용 가능한 H.264 하드웨어 인코더 시험이 모두 실패했습니다."
    else:
        reason = "Windows에서 GPU 이름 또는 사용 가능한 하드웨어 인코더를 확인하지 못했습니다."
    if failures:
        reason = f"{reason} ({' / '.join(failures)})"
    return AccelerationInfo(
        encoder="libx264",
        encoder_args=tuple(_encoder_args("libx264")),
        gpu=False,
        device_name=cpu_name(),
        diagnostic=reason,
        ffmpeg_path=str(Path(ffmpeg).resolve()),
        driver_version=_nvidia_smi_info()[1],
    )


def acceleration_diagnostic_report(ffmpeg: str) -> str:
    clear_acceleration_cache()
    info = acceleration_info(ffmpeg)
    encoders = sorted(available_encoders(ffmpeg))
    gpu_names = _windows_gpu_names()
    lines = [
        "Picklary DualCam Lite GPU 진단",
        f"FFmpeg: {Path(ffmpeg).resolve()}",
        f"FFmpeg 버전: {_ffmpeg_version(ffmpeg)}",
        f"감지 GPU: {', '.join(gpu_names) if gpu_names else '없음/확인 실패'}",
        f"NVIDIA 드라이버: {info.driver_version or '확인 실패'}",
        f"지원 인코더: {', '.join(encoders) if encoders else '확인 실패'}",
        f"선택 처리: {info.short_label}",
        f"판정: {info.diagnostic}",
    ]
    for encoder in _ENCODER_ORDER:
        if encoder in encoders:
            probe = encoder_probe(ffmpeg, encoder)
            lines.append(f"{encoder} 시험: {'성공' if probe.success else '실패'} · {probe.detail}")
    return "\n".join(lines)


def clear_acceleration_cache() -> None:
    available_encoders.cache_clear()
    encoder_probe.cache_clear()
    select_encoder.cache_clear()
    acceleration_info.cache_clear()
    _windows_gpu_names.cache_clear()
    _nvidia_smi_info.cache_clear()
