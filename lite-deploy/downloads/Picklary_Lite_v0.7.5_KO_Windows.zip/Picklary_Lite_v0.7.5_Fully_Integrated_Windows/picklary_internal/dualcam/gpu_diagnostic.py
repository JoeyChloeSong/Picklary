from __future__ import annotations

from pathlib import Path

from .ffmpeg import acceleration_diagnostic_report, find_tool


def main() -> int:
    ffmpeg = find_tool("ffmpeg")
    if not ffmpeg:
        print("FFmpeg를 찾지 못했습니다. install_ffmpeg_windows.bat을 먼저 실행하세요.")
        return 1
    report = acceleration_diagnostic_report(ffmpeg)
    print(report)
    target = Path.cwd() / "Picklary_GPU_Diagnostic.txt"
    target.write_text(report, encoding="utf-8")
    print(f"\n진단 파일 저장: {target}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
