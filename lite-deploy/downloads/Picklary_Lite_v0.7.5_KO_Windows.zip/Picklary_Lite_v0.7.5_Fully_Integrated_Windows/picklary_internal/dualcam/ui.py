from __future__ import annotations

import os
from pathlib import Path

from PySide6.QtCore import QEvent, QObject, QSettings, Qt, QThread, QUrl, Signal, Slot, QRectF
from PySide6.QtGui import QColor, QCursor, QDesktopServices, QKeySequence, QPainter, QShortcut, QTransform
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer, QVideoFrame, QVideoSink
from PySide6.QtWidgets import (
    QApplication,
    QButtonGroup,
    QComboBox,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QRadioButton,
    QScrollArea,
    QSizePolicy,
    QSlider,
    QVBoxLayout,
    QWidget,
)

from .audio_sync import AudioSyncResult, analyze_audio_sync
from .exporter import ExportRequest, create_output_path, export_dualcam
from .ffmpeg import (
    AccelerationInfo,
    acceleration_diagnostic_report,
    acceleration_info,
    clear_acceleration_cache,
    find_tool,
    save_tool,
)
from .timecode import format_time, parse_time_text


VIDEO_EXTENSIONS = {".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v"}


def dropped_video_paths(event) -> list[Path]:
    mime = event.mimeData()
    if not mime or not mime.hasUrls():
        return []
    paths: list[Path] = []
    for url in mime.urls():
        if not url.isLocalFile():
            continue
        path = Path(url.toLocalFile()).expanduser()
        if path.is_file() and path.suffix.lower() in VIDEO_EXTENSIONS:
            paths.append(path.resolve())
    return paths


class DropVideoWidget(QWidget):
    """Non-native video canvas that also accepts file drops.

    QVideoWidget may create a native Windows child surface. After both players
    load media, that surface can overlap the playback controls and timeline in
    the unified/scrollable DualCam page. QVideoSink plus a regular QWidget keeps
    all controls in the same Qt layout and prevents the video surface from
    covering sibling widgets.
    """

    files_dropped = Signal(object)
    activated = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._frame = None
        self._image = None
        self.setAcceptDrops(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Ignored)
        self.setMinimumSize(280, 180)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)

    def clear_frame(self) -> None:
        self._frame = None
        self._image = None
        self.update()

    @Slot(QVideoFrame)
    def set_video_frame(self, frame: QVideoFrame) -> None:
        if not frame.isValid():
            return
        self._frame = QVideoFrame(frame)
        image = self._frame.toImage()
        if image.isNull():
            self._frame = None
            return

        rotation_getter = getattr(self._frame, "rotationAngle", None) or getattr(self._frame, "rotation", None)
        rotation_value = rotation_getter() if rotation_getter else 0
        angle = int(getattr(rotation_value, "value", rotation_value or 0))
        mirrored_getter = getattr(self._frame, "mirrored", None)
        mirrored = bool(mirrored_getter()) if mirrored_getter else False
        if angle or mirrored:
            transform = QTransform()
            if mirrored:
                transform.scale(-1.0, 1.0)
            if angle:
                transform.rotate(angle)
            image = image.transformed(transform, Qt.TransformationMode.SmoothTransformation)

        self._image = image
        self.update()

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor("#010308"))
        image = self._image
        if image is None or image.isNull() or self.width() <= 1 or self.height() <= 1:
            return
        target_size = image.size()
        target_size.scale(self.size(), Qt.AspectRatioMode.KeepAspectRatio)
        target = QRectF(
            (self.width() - target_size.width()) / 2.0,
            (self.height() - target_size.height()) / 2.0,
            target_size.width(),
            target_size.height(),
        )
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        painter.drawImage(target, image)

    def mousePressEvent(self, event) -> None:
        self.activated.emit()
        super().mousePressEvent(event)

    def dragEnterEvent(self, event) -> None:
        if dropped_video_paths(event):
            self.activated.emit()
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event) -> None:
        if dropped_video_paths(event):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event) -> None:
        paths = dropped_video_paths(event)
        if not paths:
            event.ignore()
            return
        self.files_dropped.emit(paths)
        event.acceptProposedAction()


class VideoCard(QFrame):
    changed = Signal()
    file_changed = Signal()
    activated = Signal()

    def __init__(self, title: str, subtitle: str) -> None:
        super().__init__()
        self.setObjectName("videoCard")
        self.setAcceptDrops(True)
        self.path: Path | None = None
        self.duration = 0.0
        self.start_seconds = 0.0
        self.player = QMediaPlayer(self)
        self.audio = QAudioOutput(self)
        self.audio.setVolume(0.35)
        self.player.setAudioOutput(self.audio)
        self.video = DropVideoWidget(self)
        self.video_sink = QVideoSink(self)
        self.video_sink.videoFrameChanged.connect(self.video.set_video_frame)
        self.video.files_dropped.connect(self.load_dropped_files)
        self.video.activated.connect(self.activated.emit)
        self.player.setVideoOutput(self.video_sink)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)
        heading_row = QHBoxLayout()
        heading = QLabel(title)
        heading.setObjectName("cardTitle")
        self.active_badge = QLabel("활성 영상")
        self.active_badge.setObjectName("activeBadge")
        self.active_badge.hide()
        heading_row.addWidget(heading)
        heading_row.addStretch(1)
        heading_row.addWidget(self.active_badge)
        hint = QLabel(subtitle)
        hint.setObjectName("muted")
        layout.addLayout(heading_row)
        layout.addWidget(hint)

        file_row = QHBoxLayout()
        self.file_label = QLineEdit()
        self.file_label.setReadOnly(True)
        self.file_label.setAcceptDrops(False)
        self.file_label.setPlaceholderText("MP4, MOV, MKV 영상을 선택하거나 드래그하세요")
        self.load_button = QPushButton("영상 불러오기")
        self.load_button.pressed.connect(self.activated.emit)
        self.load_button.clicked.connect(self.choose_file)
        file_row.addWidget(self.file_label, 1)
        file_row.addWidget(self.load_button)
        layout.addLayout(file_row)
        drop_hint = QLabel("이 카드나 영상 화면에 파일을 드래그하면 해당 영상이 즉시 교체됩니다.")
        drop_hint.setObjectName("dropHint")
        layout.addWidget(drop_hint)

        self.video.setMinimumHeight(180)
        layout.addWidget(self.video, 1)

        controls = QHBoxLayout()
        self.play_button = QPushButton("▶")
        self.play_button.setFixedWidth(54)
        self.play_button.pressed.connect(self.activated.emit)
        self.play_button.clicked.connect(self.toggle_play)
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setRange(0, 0)
        self.slider.sliderPressed.connect(self.activated.emit)
        self.slider.sliderMoved.connect(self.seek)
        self.time_label = QLabel("00:00.000 / 00:00.000")
        self.time_label.setObjectName("timeLabel")
        controls.addWidget(self.play_button)
        controls.addWidget(self.slider, 1)
        controls.addWidget(self.time_label)
        layout.addLayout(controls)

        seek_row = QHBoxLayout()
        seek_hint = QLabel("빠른 이동")
        seek_hint.setObjectName("rowLabel")
        self.minus_three = QPushButton("-3초")
        self.minus_one = QPushButton("-1초")
        self.plus_one = QPushButton("+1초")
        self.plus_three = QPushButton("+3초")
        for button in (self.minus_three, self.minus_one, self.plus_one, self.plus_three):
            button.setObjectName("compactButton")
            button.pressed.connect(self.activated.emit)
        self.minus_three.setToolTip("현재 재생 위치를 3초 뒤로 이동합니다.")
        self.minus_one.setToolTip("현재 재생 위치를 1초 뒤로 이동합니다.")
        self.plus_one.setToolTip("현재 재생 위치를 1초 앞으로 이동합니다.")
        self.plus_three.setToolTip("현재 재생 위치를 3초 앞으로 이동합니다.")
        self.minus_three.clicked.connect(lambda: self.step_by(-3.0))
        self.minus_one.clicked.connect(lambda: self.step_by(-1.0))
        self.plus_one.clicked.connect(lambda: self.step_by(1.0))
        self.plus_three.clicked.connect(lambda: self.step_by(3.0))
        seek_row.addWidget(seek_hint)
        seek_row.addWidget(self.minus_three)
        seek_row.addWidget(self.minus_one)
        seek_row.addWidget(self.plus_one)
        seek_row.addWidget(self.plus_three)
        seek_row.addStretch(1)
        layout.addLayout(seek_row)

        start_row = QHBoxLayout()
        start_title = QLabel("시작 지점")
        start_title.setObjectName("rowLabel")
        self.start_edit = QLineEdit("00:00.000")
        self.start_edit.setAcceptDrops(False)
        self.start_edit.setPlaceholderText("예: 01:23.500")
        self.start_edit.setToolTip("초, MM:SS.mmm 또는 HH:MM:SS.mmm 형식으로 직접 입력할 수 있습니다.")
        self.start_edit.returnPressed.connect(self.apply_manual_start)
        self.apply_start_button = QPushButton("입력 적용")
        self.apply_start_button.setObjectName("secondaryButton")
        self.apply_start_button.pressed.connect(self.activated.emit)
        self.apply_start_button.clicked.connect(self.apply_manual_start)
        self.set_start_button = QPushButton("현재 위치 사용")
        self.set_start_button.setObjectName("secondaryButton")
        self.set_start_button.pressed.connect(self.activated.emit)
        self.set_start_button.clicked.connect(self.set_start)
        start_row.addWidget(start_title)
        start_row.addWidget(self.start_edit, 1)
        start_row.addWidget(self.apply_start_button)
        start_row.addWidget(self.set_start_button)
        layout.addLayout(start_row)

        self.start_summary = QLabel("적용된 시작 지점 · 00:00.000")
        self.start_summary.setObjectName("syncValue")
        layout.addWidget(self.start_summary)

        self.player.positionChanged.connect(self.on_position)
        self.player.durationChanged.connect(self.on_duration)
        self.player.playbackStateChanged.connect(self.on_state)

    def mousePressEvent(self, event) -> None:
        self.activated.emit()
        super().mousePressEvent(event)

    def set_active(self, active: bool) -> None:
        self.setProperty("activeCard", active)
        self.active_badge.setVisible(active)
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()

    def dragEnterEvent(self, event) -> None:
        if dropped_video_paths(event):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event) -> None:
        if dropped_video_paths(event):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event) -> None:
        paths = dropped_video_paths(event)
        if not paths:
            event.ignore()
            return
        self.load_dropped_files(paths)
        event.acceptProposedAction()

    @Slot(object)
    def load_dropped_files(self, paths) -> None:
        valid = [Path(path).resolve() for path in paths if Path(path).is_file()]
        if valid:
            self.activated.emit()
            self.load_file(valid[-1])

    @Slot()
    def choose_file(self) -> None:
        filename, _ = QFileDialog.getOpenFileName(
            self,
            "영상 선택",
            "",
            "Video Files (*.mp4 *.mov *.mkv *.avi *.webm *.m4v);;All Files (*)",
        )
        if filename:
            self.load_file(Path(filename))

    def load_file(self, path: Path) -> None:
        self.activated.emit()
        self.player.stop()
        self.video.clear_frame()
        self.slider.setRange(0, 0)
        self.slider.setValue(0)
        self.time_label.setText("00:00.000 / 00:00.000")
        self.path = path.resolve()
        self.start_seconds = 0.0
        self.duration = 0.0
        self.file_label.setText(self.path.name)
        self.file_label.setToolTip(str(self.path))
        self.start_edit.setText("00:00.000")
        self.start_summary.setText("적용된 시작 지점 · 00:00.000")
        self.player.setSource(QUrl.fromLocalFile(str(self.path)))
        self.file_changed.emit()
        self.changed.emit()

    @Slot()
    def toggle_play(self) -> None:
        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
        else:
            self.player.play()

    @Slot(int)
    def seek(self, position: int) -> None:
        self.player.setPosition(position)

    def step_forward(self, seconds: float) -> None:
        self.step_by(seconds)

    def step_by(self, seconds: float, *, notify: bool = True) -> bool:
        if not self.path:
            if notify:
                QMessageBox.information(self, "영상 필요", "먼저 영상을 불러와 주세요.")
            return False
        maximum = int(self.duration * 1000) if self.duration > 0 else self.slider.maximum()
        target = min(maximum, self.player.position() + int(seconds * 1000))
        self.player.setPosition(max(0, target))
        return True

    @Slot(int)
    def on_position(self, position: int) -> None:
        if not self.slider.isSliderDown():
            self.slider.setValue(position)
        self.time_label.setText(f"{format_time(position / 1000)} / {format_time(self.duration)}")

    @Slot(int)
    def on_duration(self, duration_ms: int) -> None:
        self.duration = max(0.0, duration_ms / 1000)
        self.slider.setRange(0, max(0, duration_ms))
        if self.duration and self.start_seconds > self.duration:
            self.start_seconds = self.duration
            self._update_start_display()
        self.on_position(self.player.position())
        self.changed.emit()

    @Slot(object)
    def on_state(self, state) -> None:
        self.play_button.setText("❚❚" if state == QMediaPlayer.PlaybackState.PlayingState else "▶")

    def _update_start_display(self) -> None:
        text = format_time(self.start_seconds)
        self.start_edit.setText(text)
        self.start_summary.setText(f"적용된 시작 지점 · {text}")

    def apply_start_seconds(self, value: float) -> None:
        maximum = self.duration if self.duration > 0 else max(0.0, value)
        self.start_seconds = max(0.0, min(float(value), maximum))
        self.player.pause()
        self.player.setPosition(int(self.start_seconds * 1000))
        self._update_start_display()
        self.changed.emit()

    @Slot()
    def set_start(self) -> None:
        if not self.path:
            QMessageBox.information(self, "영상 필요", "먼저 영상을 불러와 주세요.")
            return
        self.start_seconds = self.player.position() / 1000
        self._update_start_display()
        self.changed.emit()

    @Slot()
    def apply_manual_start(self) -> bool:
        if not self.path:
            QMessageBox.information(self, "영상 필요", "먼저 영상을 불러와 주세요.")
            return False
        try:
            value = parse_time_text(self.start_edit.text())
        except ValueError as exc:
            QMessageBox.warning(self, "시작 지점 확인", str(exc))
            self._update_start_display()
            return False
        if self.duration > 0 and value >= self.duration:
            QMessageBox.warning(
                self,
                "시작 지점 확인",
                f"시작 지점은 영상 길이 {format_time(self.duration)}보다 앞이어야 합니다.",
            )
            self._update_start_display()
            return False
        self.start_seconds = value
        self.player.setPosition(int(value * 1000))
        self._update_start_display()
        self.changed.emit()
        return True


class ExportWorker(QObject):
    progress = Signal(int, str)
    finished = Signal(dict)
    failed = Signal(str)

    def __init__(self, ffmpeg: str, request: ExportRequest) -> None:
        super().__init__()
        self.ffmpeg = ffmpeg
        self.request = request
        self.cancelled = False

    @Slot()
    def run(self) -> None:
        try:
            result = export_dualcam(
                self.ffmpeg,
                self.request,
                progress=lambda p, m: self.progress.emit(p, m),
                cancelled=lambda: self.cancelled,
            )
            self.finished.emit(result)
        except Exception as exc:
            self.failed.emit(str(exc))


class AudioSyncWorker(QObject):
    progress = Signal(int, str)
    finished = Signal(object)
    failed = Signal(str)

    def __init__(self, ffmpeg: str, video_a: Path, video_b: Path, max_seconds: float) -> None:
        super().__init__()
        self.ffmpeg = ffmpeg
        self.video_a = video_a
        self.video_b = video_b
        self.max_seconds = max_seconds
        self.cancelled = False

    @Slot()
    def run(self) -> None:
        try:
            result = analyze_audio_sync(
                self.ffmpeg,
                self.video_a,
                self.video_b,
                max_seconds=self.max_seconds,
                progress=lambda p, m: self.progress.emit(p, m),
                cancelled=lambda: self.cancelled,
            )
            self.finished.emit(result)
        except Exception as exc:
            self.failed.emit(str(exc))


class MainWindow(QMainWindow):
    clip_edit_requested = Signal(object)

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Picklary Lite v0.7.5 · DualCam Mode")
        self.resize(1320, 870)
        self.setAcceptDrops(True)
        self.thread: QThread | None = None
        self.worker: ExportWorker | None = None
        self.sync_thread: QThread | None = None
        self.sync_worker: AudioSyncWorker | None = None
        self.audio_sync_result: AudioSyncResult | None = None
        self.audio_sync_paths: tuple[Path, Path] | None = None
        self.settings = QSettings("Picklary", "DualCamLite")
        saved_output = str(self.settings.value("output_directory", "") or "").strip()
        self.output_directory: Path | None = Path(saved_output) if saved_output else None
        self.ffmpeg = find_tool("ffmpeg")
        self.acceleration: AccelerationInfo | None = None
        self.active_card: VideoCard | None = None
        self.last_outputs: list[Path] = []
        self._build_ui()
        app = QApplication.instance()
        if app is not None:
            app.installEventFilter(self)
        self._install_shortcuts()
        self._apply_style()
        self.refresh_acceleration()
        self.refresh_summary()

    def _build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        self.scroll_area = QScrollArea(root)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll_content = QWidget()
        self.scroll_content.setObjectName("DualCamScrollContent")
        self.scroll_area.setWidget(self.scroll_content)
        root_layout.addWidget(self.scroll_area, 1)

        outer = QVBoxLayout(self.scroll_content)
        outer.setContentsMargins(22, 18, 22, 20)
        outer.setSpacing(14)

        header = QHBoxLayout()
        logo = QLabel("P")
        logo.setObjectName("logo")
        brand_box = QVBoxLayout()
        brand = QLabel("Picklary Lite · DualCam")
        brand.setObjectName("brand")
        tagline = QLabel("TWO VIDEOS · ONE FAST EXPORT")
        tagline.setObjectName("tagline")
        brand_box.addWidget(brand)
        brand_box.addWidget(tagline)
        header.addWidget(logo)
        header.addLayout(brand_box)
        header.addStretch(1)
        self.gpu_status = QLabel("처리 장치 확인 중")
        self.gpu_status.setObjectName("privacyChip")
        self.gpu_status.setToolTip("실제 시험 인코딩에 성공한 장치만 GPU 모드로 표시됩니다.")
        header.addWidget(self.gpu_status)
        self.gpu_refresh_button = QPushButton("GPU 다시 검사")
        self.gpu_refresh_button.setObjectName("compactButton")
        self.gpu_refresh_button.clicked.connect(self.refresh_acceleration)
        header.addWidget(self.gpu_refresh_button)
        self.gpu_detail_button = QPushButton("GPU 진단")
        self.gpu_detail_button.setObjectName("compactButton")
        self.gpu_detail_button.clicked.connect(self.show_gpu_diagnostic)
        header.addWidget(self.gpu_detail_button)
        self.ffmpeg_button = QPushButton("FFmpeg 변경")
        self.ffmpeg_button.setObjectName("compactButton")
        self.ffmpeg_button.clicked.connect(self._select_ffmpeg)
        header.addWidget(self.ffmpeg_button)
        outer.addLayout(header)

        intro = QLabel("두 영상의 같은 순간을 시작점으로 지정한 뒤, GPU 우선 1회 렌더로 빠르게 합칩니다.")
        intro.setObjectName("intro")
        outer.addWidget(intro)
        shortcut_hint = QLabel("키보드: Space = 활성 영상 재생/정지 · ←/→ = 활성 영상 3초 이동 · 드래그: A/B 영상 화면 전체에서 교체")
        shortcut_hint.setObjectName("shortcutHint")
        outer.addWidget(shortcut_hint)

        cards = QHBoxLayout()
        cards.setSpacing(14)
        self.card_a = VideoCard("A · 1번 영상(출력시 좌측/상단)", "합성 결과에서 좌측 또는 상단에 배치되며, 오디오는 1번 영상을 우선 사용합니다.")
        self.card_b = VideoCard("B · 2번 영상(출력시 우측/하단)", "합성 결과에서 우측 또는 하단에 배치됩니다. 1번 영상과 같은 순간을 맞추세요.")
        self.card_a.activated.connect(lambda: self.set_active_card(self.card_a))
        self.card_b.activated.connect(lambda: self.set_active_card(self.card_b))
        cards.addWidget(self.card_a, 1)
        cards.addWidget(self.card_b, 1)
        outer.addLayout(cards, 1)
        self.set_active_card(self.card_a)

        sync_card = QFrame()
        sync_card.setObjectName("syncCard")
        sync_layout = QHBoxLayout(sync_card)
        sync_layout.setContentsMargins(16, 10, 16, 10)
        sync_layout.setSpacing(10)
        sync_title = QLabel("사운드 자동 정렬")
        sync_title.setObjectName("syncTitle")
        sync_title.setToolTip("두 영상의 공통 소리를 찾아 먼저 시작한 영상만 시간차만큼 잘라 맞춥니다.")
        self.sync_range = QComboBox()
        self.sync_range.addItem("앞 2분 검색", 120.0)
        self.sync_range.addItem("앞 5분 검색", 300.0)
        self.sync_range.addItem("앞 10분 검색 · 기본", 600.0)
        self.sync_range.addItem("앞 20분 검색", 1200.0)
        self.sync_range.setCurrentIndex(2)
        self.auto_sync_button = QPushButton("사운드로 시작점 자동 찾기")
        self.auto_sync_button.setObjectName("primaryButton")
        self.auto_sync_button.clicked.connect(self.start_audio_sync)
        self.sync_progress = QProgressBar()
        self.sync_progress.setRange(0, 100)
        self.sync_progress.setValue(0)
        self.sync_progress.setFormat("A/B 영상을 불러온 뒤 자동 정렬")
        self.apply_sync_button = QPushButton("자동 정렬 결과 적용")
        self.apply_sync_button.setObjectName("secondaryButton")
        self.apply_sync_button.setEnabled(False)
        self.apply_sync_button.clicked.connect(self.apply_audio_sync_result)
        self.manual_sync_button = QPushButton("수동 시작점 사용")
        self.manual_sync_button.setObjectName("secondaryButton")
        self.manual_sync_button.clicked.connect(self.use_manual_sync)
        sync_layout.addWidget(sync_title)
        sync_layout.addWidget(self.sync_range)
        sync_layout.addWidget(self.auto_sync_button)
        sync_layout.addWidget(self.sync_progress, 1)
        sync_layout.addWidget(self.apply_sync_button)
        sync_layout.addWidget(self.manual_sync_button)
        outer.addWidget(sync_card)

        options = QFrame()
        options.setObjectName("optionsCard")
        grid = QGridLayout(options)
        grid.setContentsMargins(18, 14, 18, 14)
        grid.setHorizontalSpacing(28)
        grid.setVerticalSpacing(10)

        grid.addWidget(QLabel("화면 배치"), 0, 0)
        self.top_bottom = QRadioButton("상하")
        self.side_by_side = QRadioButton("좌우 · 기본")
        self.both_layouts = QRadioButton("상하/좌우 1개씩 생성")
        self.side_by_side.setChecked(True)
        self.layout_group = QButtonGroup(self)
        for radio in (self.top_bottom, self.side_by_side, self.both_layouts):
            self.layout_group.addButton(radio)
        layout_row = QHBoxLayout()
        layout_row.addWidget(self.top_bottom)
        layout_row.addWidget(self.side_by_side)
        layout_row.addWidget(self.both_layouts)
        layout_row.addStretch(1)
        grid.addLayout(layout_row, 1, 0)

        grid.addWidget(QLabel("출력 화질"), 0, 1)
        self.fhd = QRadioButton("FHD · 빠른 확인")
        self.uhd = QRadioButton("4K · 기본 / 최종본")
        self.uhd.setChecked(True)
        self.quality_group = QButtonGroup(self)
        self.quality_group.addButton(self.fhd)
        self.quality_group.addButton(self.uhd)
        quality_row = QHBoxLayout()
        quality_row.addWidget(self.fhd)
        quality_row.addWidget(self.uhd)
        quality_row.addStretch(1)
        grid.addLayout(quality_row, 1, 1)

        grid.addWidget(QLabel("결과 저장 폴더"), 2, 0)
        output_row = QHBoxLayout()
        self.output_path_edit = QLineEdit()
        self.output_path_edit.setReadOnly(True)
        self.output_path_edit.setPlaceholderText("합성 시작 전에 저장 폴더를 선택합니다.")
        if self.output_directory:
            self.output_path_edit.setText(str(self.output_directory))
            self.output_path_edit.setToolTip(str(self.output_directory))
        self.output_folder_button = QPushButton("저장 폴더 선택")
        self.output_folder_button.setObjectName("secondaryButton")
        self.output_folder_button.clicked.connect(self.choose_output_directory)
        output_row.addWidget(self.output_path_edit, 1)
        output_row.addWidget(self.output_folder_button)
        grid.addLayout(output_row, 3, 0, 1, 2)

        self.output_preserve_note = QLabel("기존 파일은 덮어쓰지 않으며 실행 시각을 붙여 자동 보존합니다.")
        self.output_preserve_note.setObjectName("muted")
        grid.addWidget(self.output_preserve_note, 4, 0, 1, 2)

        self.summary = QLabel("두 영상을 불러오면 예상 결과 길이가 표시됩니다.")
        self.summary.setObjectName("summary")
        grid.addWidget(self.summary, 5, 0, 1, 2)
        self.engine_detail = QLabel("처리 장치 확인 중")
        self.engine_detail.setObjectName("engineDetail")
        self.engine_detail.setWordWrap(True)
        grid.addWidget(self.engine_detail, 6, 0, 1, 2)
        outer.addWidget(options)

        bottom = QHBoxLayout()
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setFormat("준비")
        self.export_button = QPushButton("빠른 합성 시작")
        self.export_button.setObjectName("primaryButton")
        self.export_button.setMinimumHeight(52)
        self.export_button.clicked.connect(self.start_export)
        bottom.addWidget(self.progress, 1)
        bottom.addWidget(self.export_button)
        outer.addLayout(bottom)

        result_actions = QHBoxLayout()
        result_actions.addStretch(1)
        self.open_result_folder_button = QPushButton("저장위치 바로가기")
        self.open_result_folder_button.setObjectName("secondaryButton")
        self.open_result_folder_button.setEnabled(False)
        self.open_result_folder_button.clicked.connect(self.open_last_result_folder)
        self.edit_result_in_clip_button = QPushButton("Clip 편집으로 바로 이동")
        self.edit_result_in_clip_button.setObjectName("primaryButton")
        self.edit_result_in_clip_button.setEnabled(False)
        self.edit_result_in_clip_button.clicked.connect(self.send_last_result_to_clip)
        result_actions.addWidget(self.open_result_folder_button)
        result_actions.addWidget(self.edit_result_in_clip_button)
        outer.addLayout(result_actions)

        self.card_a.changed.connect(self.refresh_summary)
        self.card_b.changed.connect(self.refresh_summary)
        self.card_a.file_changed.connect(self.invalidate_audio_sync)
        self.card_b.file_changed.connect(self.invalidate_audio_sync)
        self.layout_group.buttonClicked.connect(lambda _button: self.refresh_summary())
        self.quality_group.buttonClicked.connect(lambda _button: self.refresh_summary())

    def _card_for_object(self, watched) -> VideoCard | None:
        widget = watched if isinstance(watched, QWidget) else None
        while widget is not None:
            if widget is self.card_a:
                return self.card_a
            if widget is self.card_b:
                return self.card_b
            widget = widget.parentWidget()
        return None

    def _card_under_cursor(self) -> VideoCard | None:
        return self._card_for_object(QApplication.widgetAt(QCursor.pos()))

    def _load_window_drop(self, paths: list[Path]) -> None:
        if len(paths) >= 2:
            self.card_a.load_file(paths[-2])
            self.card_b.load_file(paths[-1])
            self.set_active_card(self.card_b)
        elif not self.card_a.path:
            self.card_a.load_file(paths[-1])
            self.set_active_card(self.card_a)
        elif not self.card_b.path:
            self.card_b.load_file(paths[-1])
            self.set_active_card(self.card_b)
        else:
            target = self.active_card or self.card_b
            target.load_file(paths[-1])
            self.set_active_card(target)

    def eventFilter(self, watched, event) -> bool:
        # QVideoWidget may use a Windows-native rendering surface. Listening at
        # application level ensures the full visible A/B screen remains a drop target.
        if self.card_a.isVisible() or self.card_b.isVisible():
            event_type = event.type()
            if event_type == QEvent.Type.MouseButtonPress:
                card = self._card_for_object(watched) or self._card_under_cursor()
                if card is not None:
                    self.set_active_card(card)
            if event_type in (QEvent.Type.DragEnter, QEvent.Type.DragMove, QEvent.Type.Drop):
                paths = dropped_video_paths(event)
                card = self._card_for_object(watched) or self._card_under_cursor()
                if paths and card is not None:
                    event.acceptProposedAction()
                    if event_type == QEvent.Type.Drop:
                        card.load_dropped_files(paths)
                        self.set_active_card(card)
                    return True
        return super().eventFilter(watched, event)

    def dragEnterEvent(self, event) -> None:
        if dropped_video_paths(event):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event) -> None:
        if dropped_video_paths(event):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event) -> None:
        paths = dropped_video_paths(event)
        if not paths:
            event.ignore()
            return
        target = self._card_under_cursor()
        if target is not None:
            target.load_dropped_files(paths)
            self.set_active_card(target)
        else:
            self._load_window_drop(paths)
        event.acceptProposedAction()

    def _apply_style(self) -> None:
        self.setStyleSheet("""
            QMainWindow, QWidget { background: #06111f; color: #edf5ff; font-family: 'Segoe UI', 'Malgun Gothic'; font-size: 14px; }
            QScrollArea { border: none; background: #06111f; }
            QWidget#DualCamScrollContent { background: #06111f; }
            QFrame#videoCard, QFrame#optionsCard, QFrame#syncCard { background: #0b1b31; border: 1px solid #203b5e; border-radius: 18px; }
            QFrame#videoCard[activeCard="true"] { border: 2px solid #72e6c1; background: #0d2037; }
            QLabel#logo { background: #72e6c1; color: #062238; font-size: 32px; font-weight: 900; border-radius: 13px; padding: 8px 15px; }
            QLabel#brand { font-size: 26px; font-weight: 800; }
            QLabel#tagline { color: #8ca4c3; letter-spacing: 2px; font-size: 11px; }
            QLabel#privacyChip { background: #0d1d32; border: 1px solid #213a59; border-radius: 16px; padding: 10px 16px; color: #72e6c1; font-weight: 700; }
            QLabel#intro { color: #b7c8dc; font-size: 15px; padding: 2px 4px 2px 4px; }
            QLabel#shortcutHint { color: #72e6c1; font-size: 12px; padding: 0 4px 6px 4px; }
            QLabel#dropHint { color: #75b8ff; font-size: 11px; padding: 0 2px 2px 2px; }
            QLabel#cardTitle { font-size: 18px; font-weight: 800; color: #72e6c1; }
            QLabel#activeBadge { background:#72e6c1; color:#062238; border-radius:10px; padding:4px 9px; font-size:11px; font-weight:900; }
            QLabel#muted { color: #8fa7c4; font-size: 12px; }
            QLabel#timeLabel { color: #cfe0f4; font-family: Consolas; }
            QLabel#syncValue { color: #72e6c1; font-weight: 800; }
            QLabel#syncTitle { color: #72e6c1; font-size: 16px; font-weight: 900; }
            QComboBox { background:#071525; border:1px solid #29466b; border-radius:9px; padding:8px 12px; color:white; min-width:150px; }
            QLabel#rowLabel { color: #b7c8dc; font-weight: 700; min-width: 66px; }
            QLabel#summary { color: #75b8ff; font-weight: 700; padding-top: 6px; }
            QLabel#engineDetail { color: #72e6c1; font-weight: 700; }
            QLineEdit { background: #071525; border: 1px solid #29466b; border-radius: 10px; padding: 10px; color: white; }
            QLineEdit:focus { border: 1px solid #72e6c1; }
            QPushButton { background: #112743; border: 1px solid #335d8d; border-radius: 11px; padding: 10px 15px; color: #f5f9ff; font-weight: 700; }
            QPushButton:hover { border: 1px solid #72e6c1; background: #153253; }
            QPushButton:pressed { background: #0a1b31; padding-top: 12px; padding-bottom: 8px; }
            QPushButton#primaryButton { background: #69dfba; color: #052238; border: 1px solid #8bf3d3; font-size: 16px; padding: 12px 24px; }
            QPushButton#primaryButton:hover { background: #86efcf; }
            QPushButton#secondaryButton { background: #0c2038; color: #dcecff; }
            QPushButton#compactButton { padding: 7px 14px; min-width: 58px; }
            QSlider::groove:horizontal { height: 7px; background: #182f4e; border-radius: 3px; }
            QSlider::sub-page:horizontal { background: #72e6c1; border-radius: 3px; }
            QSlider::handle:horizontal { width: 17px; margin: -5px 0; background: white; border: 3px solid #72e6c1; border-radius: 8px; }
            QRadioButton { spacing: 8px; color: #d8e6f7; }
            QRadioButton::indicator { width: 18px; height: 18px; }
            QRadioButton::indicator:unchecked { border: 2px solid #4e6b8e; border-radius: 9px; background: #071525; }
            QRadioButton::indicator:checked { border: 5px solid #72e6c1; border-radius: 9px; background: #0b2037; }
            QProgressBar { background: #0b1b31; border: 1px solid #29466b; border-radius: 12px; text-align: center; height: 28px; font-weight: 700; }
            QProgressBar::chunk { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #397dff,stop:1 #72e6c1); border-radius: 11px; }
        """)

    def _install_shortcuts(self) -> None:
        self.space_shortcut = QShortcut(QKeySequence("Space"), self)
        self.left_shortcut = QShortcut(QKeySequence("Left"), self)
        self.right_shortcut = QShortcut(QKeySequence("Right"), self)
        for shortcut in (self.space_shortcut, self.left_shortcut, self.right_shortcut):
            shortcut.setContext(Qt.ShortcutContext.WindowShortcut)
        self.space_shortcut.activated.connect(self.toggle_active_playback)
        self.left_shortcut.activated.connect(lambda: self.step_active(-3.0))
        self.right_shortcut.activated.connect(lambda: self.step_active(3.0))

    def _shortcut_allowed(self) -> bool:
        return not isinstance(QApplication.focusWidget(), QLineEdit)

    def set_active_card(self, card: VideoCard) -> None:
        if card not in (self.card_a, self.card_b):
            return
        self.active_card = card
        self.card_a.set_active(card is self.card_a)
        self.card_b.set_active(card is self.card_b)

    @Slot()
    def toggle_active_playback(self) -> None:
        if not self._shortcut_allowed():
            return
        card = self.active_card or self.card_a
        if card.path:
            card.toggle_play()

    def step_active(self, seconds: float) -> None:
        if not self._shortcut_allowed():
            return
        card = self.active_card or self.card_a
        card.step_by(seconds, notify=False)

    # Backward-compatible aliases for internal callers from older packages.
    def toggle_both_playback(self) -> None:
        self.toggle_active_playback()

    def step_both(self, seconds: float) -> None:
        self.step_active(seconds)

    @Slot()
    def show_gpu_diagnostic(self) -> None:
        ffmpeg = self.ffmpeg or self._select_ffmpeg()
        if not ffmpeg:
            return
        try:
            report = acceleration_diagnostic_report(ffmpeg)
            self.acceleration = acceleration_info(ffmpeg)
            self._apply_acceleration_labels()
        except Exception as exc:
            report = f"GPU 진단을 완료하지 못했습니다.\n\n{exc}"
        box = QMessageBox(self)
        box.setWindowTitle("GPU 및 FFmpeg 진단")
        box.setIcon(QMessageBox.Icon.Information)
        box.setText("GPU 사용 여부를 결정한 진단 결과입니다.")
        box.setInformativeText("RTX가 있어도 FFmpeg의 NVENC 지원 또는 NVIDIA 드라이버 시험이 실패하면 CPU 모드가 됩니다.")
        box.setDetailedText(report)
        box.exec()

    def _apply_acceleration_labels(self) -> None:
        if not self.acceleration:
            return
        if self.acceleration.gpu:
            driver = f" · Driver {self.acceleration.driver_version}" if self.acceleration.driver_version else ""
            self.gpu_status.setText(f"GPU 사용 가능 · {self.acceleration.device_name}{driver}")
            self.export_button.setText("GPU 빠른 합성 시작")
        else:
            self.gpu_status.setText(f"CPU 모드 · {self.acceleration.device_name}")
            self.export_button.setText("CPU 빠른 합성 시작")
        self.gpu_status.setToolTip(self.acceleration.diagnostic)
        short_diagnostic = self.acceleration.diagnostic
        if len(short_diagnostic) > 320:
            short_diagnostic = short_diagnostic[:317] + "..."
        self.engine_detail.setText(
            f"처리 장치: {self.acceleration.short_label}\n"
            f"진단: {short_diagnostic}\n"
            f"FFmpeg: {self.acceleration.ffmpeg_path}"
        )

    @Slot()
    def refresh_acceleration(self) -> None:
        self.acceleration = None
        detected_ffmpeg = find_tool("ffmpeg")
        if detected_ffmpeg:
            self.ffmpeg = detected_ffmpeg
        if not self.ffmpeg:
            self.gpu_status.setText("FFmpeg를 찾지 못함")
            self.engine_detail.setText("처리 장치: FFmpeg 선택 필요")
            self.export_button.setText("FFmpeg 선택 후 합성")
            return
        try:
            clear_acceleration_cache()
            self.acceleration = acceleration_info(self.ffmpeg)
            self._apply_acceleration_labels()
        except Exception as exc:
            self.gpu_status.setText("FFmpeg 확인 필요")
            self.engine_detail.setText(f"처리 장치 확인 실패: {exc}")
            self.export_button.setText("빠른 합성 시작")

    @Slot()
    def invalidate_audio_sync(self) -> None:
        self.audio_sync_result = None
        self.audio_sync_paths = None
        if hasattr(self, "apply_sync_button"):
            self.apply_sync_button.setEnabled(False)
            self.sync_progress.setValue(0)
            self.sync_progress.setFormat("영상이 변경되었습니다. 사운드 자동 정렬을 다시 실행하세요.")

    @Slot()
    def start_audio_sync(self) -> None:
        if self.sync_thread and self.sync_thread.isRunning():
            return
        if self.thread and self.thread.isRunning():
            QMessageBox.information(self, "합성 작업 중", "영상 합성이 끝난 뒤 자동 정렬을 실행해 주세요.")
            return
        if not self.card_a.path or not self.card_b.path:
            QMessageBox.information(self, "영상 필요", "A와 B 영상을 모두 불러와 주세요.")
            return
        ffmpeg = self.ffmpeg or self._select_ffmpeg()
        if not ffmpeg:
            QMessageBox.warning(self, "FFmpeg 필요", "사운드 자동 정렬에는 FFmpeg가 필요합니다.")
            return
        self.card_a.player.pause()
        self.card_b.player.pause()
        self.audio_sync_result = None
        self.audio_sync_paths = (self.card_a.path.resolve(), self.card_b.path.resolve())
        max_seconds = float(self.sync_range.currentData() or 600.0)
        self.auto_sync_button.setEnabled(False)
        self.apply_sync_button.setEnabled(False)
        self.sync_progress.setValue(0)
        self.sync_progress.setFormat("사운드 분석 준비 중")
        self.sync_thread = QThread(self)
        self.sync_worker = AudioSyncWorker(ffmpeg, self.card_a.path, self.card_b.path, max_seconds)
        self.sync_worker.moveToThread(self.sync_thread)
        self.sync_thread.started.connect(self.sync_worker.run)
        self.sync_worker.progress.connect(self.on_sync_progress)
        self.sync_worker.finished.connect(self.on_sync_finished)
        self.sync_worker.failed.connect(self.on_sync_failed)
        self.sync_worker.finished.connect(self.sync_thread.quit)
        self.sync_worker.failed.connect(self.sync_thread.quit)
        self.sync_thread.finished.connect(self.cleanup_sync_worker)
        self.sync_thread.start()

    @Slot(int, str)
    def on_sync_progress(self, value: int, message: str) -> None:
        self.sync_progress.setValue(value)
        self.sync_progress.setFormat(message)

    @Slot(object)
    def on_sync_finished(self, result: AudioSyncResult) -> None:
        current_paths = (self.card_a.path.resolve(), self.card_b.path.resolve()) if self.card_a.path and self.card_b.path else None
        if current_paths != self.audio_sync_paths:
            self.sync_progress.setValue(0)
            self.sync_progress.setFormat("분석 중 영상이 변경되어 결과를 폐기했습니다.")
            return
        self.audio_sync_result = result
        self.apply_sync_button.setEnabled(True)
        self.sync_progress.setValue(100)
        self.sync_progress.setFormat(
            f"분석 완료 · A {format_time(result.start_a)} / B {format_time(result.start_b)} · 신뢰도 {result.confidence_ko}"
        )
        box = QMessageBox(self)
        box.setWindowTitle("사운드 자동 정렬 결과")
        box.setIcon(QMessageBox.Icon.Information if result.confidence != "low" else QMessageBox.Icon.Warning)
        box.setText(
            f"권장 시작점\nA 영상: {format_time(result.start_a)}\nB 영상: {format_time(result.start_b)}\n"
            f"정렬 신뢰도: {result.confidence_ko}"
        )
        box.setInformativeText(
            f"{result.detail}\n\n적용 후 A와 B 시작점을 각각 재생해 맞는지 확인하세요. "
            "맞지 않으면 기존 시작점 입력 기능으로 수동 조정할 수 있습니다."
        )
        apply_button = box.addButton("자동 결과 적용", QMessageBox.ButtonRole.AcceptRole)
        manual_button = box.addButton("수동으로 맞추기", QMessageBox.ButtonRole.RejectRole)
        box.exec()
        if box.clickedButton() is apply_button:
            self.apply_audio_sync_result()
        elif box.clickedButton() is manual_button:
            self.use_manual_sync()

    @Slot()
    def apply_audio_sync_result(self) -> None:
        result = self.audio_sync_result
        if result is None:
            QMessageBox.information(self, "자동 정렬 결과 없음", "먼저 사운드 자동 정렬을 실행해 주세요.")
            return
        current_paths = (self.card_a.path.resolve(), self.card_b.path.resolve()) if self.card_a.path and self.card_b.path else None
        if current_paths != self.audio_sync_paths:
            self.invalidate_audio_sync()
            QMessageBox.information(self, "영상 변경됨", "영상이 변경되었습니다. 자동 정렬을 다시 실행해 주세요.")
            return
        self.card_a.apply_start_seconds(result.start_a)
        self.card_b.apply_start_seconds(result.start_b)
        self.sync_progress.setFormat(
            f"자동 정렬 적용됨 · A {format_time(result.start_a)} / B {format_time(result.start_b)} · 각 영상을 재생해 확인하세요."
        )
        self.refresh_summary()

    @Slot()
    def use_manual_sync(self) -> None:
        self.apply_sync_button.setEnabled(self.audio_sync_result is not None)
        self.sync_progress.setFormat("수동 모드 · 각 영상에서 같은 순간을 찾아 '현재 위치 사용'을 누르세요.")
        self.set_active_card(self.card_a)

    @Slot(str)
    def on_sync_failed(self, detail: str) -> None:
        self.audio_sync_result = None
        self.apply_sync_button.setEnabled(False)
        self.sync_progress.setValue(0)
        self.sync_progress.setFormat("자동 정렬 실패 · 수동 시작점을 사용하세요.")
        box = QMessageBox(self)
        box.setWindowTitle("사운드 자동 정렬 실패")
        box.setIcon(QMessageBox.Icon.Warning)
        box.setText("두 영상의 공통 사운드를 확실하게 찾지 못했습니다.")
        box.setInformativeText(
            "한쪽 영상에 소리가 없거나, 바람·음악·소음이 너무 크거나, 공통 구간이 검색 범위 밖일 수 있습니다. "
            "검색 범위를 늘려 다시 시도하거나 기존 기능으로 시작점을 직접 지정해 주세요."
        )
        box.setDetailedText(detail)
        box.exec()

    @Slot()
    def cleanup_sync_worker(self) -> None:
        self.auto_sync_button.setEnabled(True)
        if self.sync_worker:
            self.sync_worker.deleteLater()
        if self.sync_thread:
            self.sync_thread.deleteLater()
        self.sync_worker = None
        self.sync_thread = None

    @Slot()
    def refresh_summary(self) -> None:
        if self.card_a.path and self.card_b.path:
            remain_a = max(0.0, self.card_a.duration - self.card_a.start_seconds)
            remain_b = max(0.0, self.card_b.duration - self.card_b.start_seconds)
            result = min(remain_a, remain_b)
            if self.both_layouts.isChecked():
                layout_text = "상하·좌우 2개 파일"
            elif self.side_by_side.isChecked():
                layout_text = "좌우 1개 파일"
            else:
                layout_text = "상하 1개 파일"
            quality_text = "4K" if self.uhd.isChecked() else "FHD"
            self.summary.setText(
                f"A {format_time(self.card_a.start_seconds)}부터 · B {format_time(self.card_b.start_seconds)}부터 · "
                f"예상 결과 {format_time(result)} · {layout_text} · {quality_text}"
            )
        else:
            self.summary.setText("두 영상을 불러오면 예상 결과 길이가 표시됩니다.")

    @Slot()
    def _select_ffmpeg(self) -> str | None:
        filename, _ = QFileDialog.getOpenFileName(self, "ffmpeg.exe 선택", "", "ffmpeg (ffmpeg.exe);;All Files (*)")
        if filename:
            os.environ["PICKLARY_FFMPEG"] = filename
            self.ffmpeg = save_tool("ffmpeg", filename)
            self.refresh_acceleration()
        return self.ffmpeg

    def _selected_layout(self) -> str:
        if self.both_layouts.isChecked():
            return "both"
        if self.side_by_side.isChecked():
            return "side_by_side"
        return "top_bottom"

    @Slot()
    def choose_output_directory(self) -> Path | None:
        initial = str(self.output_directory or (self.card_a.path.parent if self.card_a.path else Path.home()))
        selected = QFileDialog.getExistingDirectory(self, "결과물 저장 폴더 선택", initial)
        if not selected:
            return self.output_directory
        directory = Path(selected).expanduser().resolve()
        try:
            directory.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            QMessageBox.warning(self, "저장 폴더 확인", f"선택한 폴더를 사용할 수 없습니다.\n\n{exc}")
            return None
        self.output_directory = directory
        self.output_path_edit.setText(str(directory))
        self.output_path_edit.setToolTip(str(directory))
        self.settings.setValue("output_directory", str(directory))
        return directory

    @Slot()
    def start_export(self) -> None:
        if self.thread and self.thread.isRunning():
            return
        if self.sync_thread and self.sync_thread.isRunning():
            QMessageBox.information(self, "사운드 분석 중", "자동 정렬 분석이 끝난 뒤 합성을 시작해 주세요.")
            return
        if not self.card_a.path or not self.card_b.path:
            QMessageBox.information(self, "영상 필요", "A와 B 영상을 모두 불러와 주세요.")
            return
        if not self.card_a.apply_manual_start() or not self.card_b.apply_manual_start():
            return
        ffmpeg = self.ffmpeg or self._select_ffmpeg()
        if not ffmpeg:
            QMessageBox.warning(
                self,
                "FFmpeg 필요",
                "빠른 영상 합성을 위해 FFmpeg가 필요합니다.\nffmpeg.exe를 설치한 뒤 선택해 주세요.",
            )
            return
        if self.acceleration is None:
            self.refresh_acceleration()
        output_dir = self.output_directory or self.choose_output_directory()
        if not output_dir:
            QMessageBox.information(self, "저장 폴더 필요", "결과물을 저장할 폴더를 선택해 주세요.")
            return
        layout = self._selected_layout()
        quality = "4k" if self.uhd.isChecked() else "fhd"
        try:
            output, run_id = create_output_path(output_dir, layout, quality)
        except Exception as exc:
            QMessageBox.warning(self, "출력 파일명 확인", str(exc))
            return
        request = ExportRequest(
            video_a=self.card_a.path,
            video_b=self.card_b.path,
            start_a=self.card_a.start_seconds,
            start_b=self.card_b.start_seconds,
            layout=layout,
            quality=quality,
            output=output,
        )

        self.export_button.setEnabled(False)
        self.progress.setValue(0)
        self.progress.setFormat(f"준비 중 · 작업 {run_id}")
        if self.acceleration:
            kind = "GPU" if self.acceleration.gpu else "CPU"
            self.gpu_status.setText(f"처리 준비 · {kind} · {self.acceleration.device_name}")
            self.engine_detail.setText(f"처리 예정: {self.acceleration.short_label}")
        self.thread = QThread(self)
        self.worker = ExportWorker(ffmpeg, request)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.on_progress)
        self.worker.finished.connect(self.on_finished)
        self.worker.failed.connect(self.on_failed)
        self.worker.finished.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self._cleanup_worker)
        self.thread.start()

    @Slot(int, str)
    def on_progress(self, value: int, message: str) -> None:
        self.progress.setValue(value)
        self.progress.setFormat(message)
        if "GPU ·" in message or "CPU ·" in message:
            self.engine_detail.setText(f"처리 중: {message}")
            kind = "GPU" if "GPU ·" in message else "CPU"
            marker = f"{kind} ·"
            device = message.split(marker, 1)[1].split(" ·", 1)[0].strip() if marker in message else "처리 장치"
            self.gpu_status.setText(f"처리 중 · {kind} · {device}")

    def _select_clip_output(self) -> Path | None:
        outputs = [path for path in self.last_outputs if path.is_file()]
        if not outputs:
            QMessageBox.information(self, "합성 결과 없음", "먼저 DualCam 합성을 완료해 주세요.")
            return None
        if len(outputs) == 1:
            return outputs[0]
        labels = [path.name for path in outputs]
        default_index = next((i for i, name in enumerate(labels) if "Horizontal" in name), 0)
        selected, ok = QInputDialog.getItem(
            self,
            "Clip 편집 파일 선택",
            "Clip 편집으로 보낼 합성 결과를 선택하세요.",
            labels,
            default_index,
            False,
        )
        if not ok:
            return None
        return outputs[labels.index(selected)]

    @Slot()
    def open_last_result_folder(self) -> None:
        outputs = [path for path in self.last_outputs if path.exists()]
        if not outputs:
            QMessageBox.information(self, "합성 결과 없음", "먼저 DualCam 합성을 완료해 주세요.")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(outputs[0].parent)))

    @Slot()
    def send_last_result_to_clip(self) -> None:
        output = self._select_clip_output()
        if output is not None:
            self.clip_edit_requested.emit(output)

    @Slot(dict)
    def on_finished(self, result: dict) -> None:
        self.progress.setValue(100)
        self.progress.setFormat("완료")
        outputs = [Path(path).resolve() for path in result.get("outputs", [result["output"]])]
        self.last_outputs = outputs
        self.open_result_folder_button.setEnabled(True)
        self.edit_result_in_clip_button.setEnabled(True)
        device = str(result.get("device_name") or "처리 장치")
        kind = "GPU" if result.get("gpu_used") else "CPU"
        self.gpu_status.setText(f"완료 · {kind} · {device}")
        self.engine_detail.setText(f"실제 처리: {kind} · {device} · {result.get('encoder', '')}")
        output_lines = "\n".join(str(path) for path in outputs)
        box = QMessageBox(self)
        box.setWindowTitle("합성 완료")
        box.setIcon(QMessageBox.Icon.Information)
        box.setText(f"두 영상의 빠른 합성이 완료되었습니다. ({len(outputs)}개 파일)")
        box.setInformativeText(f"{result['mode']}\n{output_lines}")
        open_button = box.addButton("저장위치 바로가기", QMessageBox.ButtonRole.ActionRole)
        clip_button = box.addButton("Clip 편집으로 바로 이동", QMessageBox.ButtonRole.ActionRole)
        box.addButton(QMessageBox.StandardButton.Close)
        box.exec()
        if box.clickedButton() is open_button:
            self.open_last_result_folder()
        elif box.clickedButton() is clip_button:
            self.send_last_result_to_clip()

    @Slot(str)
    def on_failed(self, detail: str) -> None:
        self.progress.setValue(0)
        self.progress.setFormat("실패")
        self.gpu_status.setText("합성 실패 · 상세 내용 확인")
        box = QMessageBox(self)
        box.setWindowTitle("합성 실패")
        box.setIcon(QMessageBox.Icon.Warning)
        box.setText("영상 합성을 완료하지 못했습니다.")
        box.setInformativeText("두 영상 파일과 시작 지점을 확인해 주세요. GPU 실패 시 CPU 안전 모드까지 자동으로 시도합니다.")
        box.setDetailedText(detail)
        box.exec()

    @Slot()
    def _cleanup_worker(self) -> None:
        self.export_button.setEnabled(True)
        if self.worker:
            self.worker.deleteLater()
        if self.thread:
            self.thread.deleteLater()
        self.worker = None
        self.thread = None
        if self.progress.value() < 100:
            self.refresh_acceleration()

    def closeEvent(self, event) -> None:
        if self.sync_thread and self.sync_thread.isRunning() and self.sync_worker:
            answer = QMessageBox.question(self, "분석 중", "사운드 자동 정렬을 중단하고 종료할까요?")
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            self.sync_worker.cancelled = True
            self.sync_thread.quit()
            self.sync_thread.wait(4000)
        if self.thread and self.thread.isRunning() and self.worker:
            answer = QMessageBox.question(self, "작업 중", "합성 작업을 중단하고 종료할까요?")
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            self.worker.cancelled = True
            self.thread.quit()
            self.thread.wait(4000)
        super().closeEvent(event)


def run() -> int:
    app = QApplication.instance() or QApplication([])
    app.setApplicationName("Picklary Lite · DualCam")
    window = MainWindow()
    window.show()
    return app.exec()
