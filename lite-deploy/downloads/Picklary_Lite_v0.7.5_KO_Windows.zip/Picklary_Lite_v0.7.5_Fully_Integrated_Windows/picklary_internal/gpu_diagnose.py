from __future__ import annotations

from clip_core import find_ffmpeg
from gpu_core import choose_encoder


def main() -> int:
    ffmpeg = find_ffmpeg("")
    print("Picklary Clip Lite v0.5.15 GPU 진단")
    print("=" * 48)
    if not ffmpeg:
        print("FFmpeg: 찾지 못함")
        print("ffmpeg.exe를 앱 폴더 또는 Downloads 폴더에 두세요.")
        return 1
    decision = choose_encoder(ffmpeg)
    print(f"FFmpeg: {decision.ffmpeg_path}")
    print(f"감지 GPU: {', '.join(decision.gpu.names) if decision.gpu.names else '확인 실패'}")
    print(f"NVIDIA 드라이버: {decision.gpu.driver}")
    print(f"지원 인코더: {', '.join(decision.supported_encoders) if decision.supported_encoders else '확인 실패'}")
    print(f"NVENC 실제 시험: {'성공' if decision.nvenc_test_ok else '실패'}")
    print(f"선택 처리: {decision.mode} · {decision.encoder}")
    print(f"판정 이유: {decision.reason}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
