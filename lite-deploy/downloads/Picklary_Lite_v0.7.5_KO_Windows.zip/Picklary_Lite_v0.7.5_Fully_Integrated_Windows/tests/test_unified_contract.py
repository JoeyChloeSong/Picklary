import ast
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UNIFIED = (ROOT / "picklary_unified.py").read_text(encoding="utf-8")
CLIP = (ROOT / "picklary_internal" / "clip_mode.py").read_text(encoding="utf-8")
DUAL = (ROOT / "picklary_internal" / "dualcam" / "ui.py").read_text(encoding="utf-8")


class UnifiedContractTests(unittest.TestCase):
    def test_only_one_user_launcher_exists(self):
        launchers = sorted(path.name for path in ROOT.glob("00_RUN_*.bat"))
        self.assertEqual(launchers, ["00_RUN_PICKLARY_LITE_WINDOWS.bat"])

    def test_one_window_uses_stacked_pages(self):
        for token in [
            "class UnifiedMainWindow(QMainWindow):",
            "self.pages = QStackedWidget(root)",
            "self.pages.addWidget(self.clip_page)",
            "self.pages.addWidget(self.dualcam_page)",
            "self.pages.setCurrentIndex(self.MODE_CLIP)",
            "self.pages.setCurrentIndex(self.MODE_DUALCAM)",
        ]:
            self.assertIn(token, UNIFIED)

    def test_clip_button_switches_page_not_second_window(self):
        for token in [
            "self.clip.dualcam_button.clicked.disconnect()",
            "self.clip.dualcam_button.clicked.connect(self.show_dualcam_mode)",
            "DualCam 화면으로 이동",
        ]:
            self.assertIn(token, UNIFIED)
        method = next(
            node for node in ast.parse(UNIFIED).body
            if isinstance(node, ast.ClassDef) and node.name == "UnifiedMainWindow"
            for node in node.body
            if isinstance(node, ast.FunctionDef) and node.name == "show_dualcam_mode"
        )
        source = ast.get_source_segment(UNIFIED, method) or ""
        self.assertNotIn("showNormal", source)
        self.assertNotIn("raise_", source)
        self.assertNotIn("activateWindow", source)

    def test_state_is_preserved_between_modes(self):
        for token in [
            "self.clip.player.pause()",
            "self.dualcam.card_a.player.pause()",
            "self.dualcam.card_b.player.pause()",
            "if self.clip.source_path and not self.dualcam.card_a.path",
            "self.dualcam.card_a.load_file(self.clip.source_path)",
        ]:
            self.assertIn(token, UNIFIED)
        for forbidden in ["segments.clear()", "source_path = None", "card_a.path = None", "card_b.path = None"]:
            self.assertNotIn(forbidden, UNIFIED)

    def test_shortcuts_are_owned_by_unified_active_mode(self):
        for token in [
            "self._disable_internal_window_shortcuts()",
            '"Space": self._space_action',
            '"Left": self._left_action',
            '"Right": self._right_action',
            "if self.current_mode() == self.MODE_CLIP",
            "self.dualcam.toggle_active_playback()",
            "self.dualcam.step_active(-3.0)",
            "self.dualcam.step_active(3.0)",
        ]:
            self.assertIn(token, UNIFIED)

    def test_clip_preview_uses_non_native_video_sink_canvas(self):
        for token in [
            "class VideoPreviewWidget(QWidget):",
            "self.video_sink = QVideoSink(self)",
            "self.video_sink.videoFrameChanged.connect(self.video_widget.set_video_frame)",
            "self.player.setVideoOutput(self.video_sink)",
            "self.video_widget.clear_frame()",
        ]:
            self.assertIn(token, CLIP)
        self.assertNotIn("from PySide6.QtMultimediaWidgets import QVideoWidget", CLIP)

    def test_dualcam_output_loads_into_clip_page(self):
        for token in [
            "self.dualcam.clip_edit_requested.connect(self._load_dualcam_output_in_clip)",
            "self.clip.load_video(path)",
            "self.show_clip_mode()",
            "CUTS 편집 후 영상 추출 시 저장 위치를 선택하세요",
        ]:
            self.assertIn(token, UNIFIED)

    def test_internal_engines_are_not_root_programs(self):
        self.assertTrue((ROOT / "picklary_internal" / "clip_mode.py").is_file())
        self.assertTrue((ROOT / "picklary_internal" / "dualcam" / "ui.py").is_file())
        self.assertFalse((ROOT / "clip_lite_native.py").exists())
        self.assertFalse((ROOT / "dualcam").exists())

    def test_previous_clip_and_dualcam_features_remain(self):
        for token in ["pending_end_ms", "cancel_pending_start", "viewport_height * 0.65", "self.clip_list.setFixedHeight(174)"]:
            self.assertIn(token, CLIP)
        for token in ["class DropVideoWidget", "self.card_a.load_file(paths[-2])", "self.card_b.load_file(paths[-1])", 'QRadioButton("좌우 · 기본")']:
            self.assertIn(token, DUAL)


if __name__ == "__main__":
    unittest.main()
